# spscompDemoSPA

Proyecto demo de los componentes drets socials.

Arrancar con `npm run start`

## Server mock

Instalar mock `npm run install-mock`
Y en otra pestaña el servidor mockeado con `npm run start:server`
O si quieres delay con `npm run start:server:delay`

## HELP i18n

https://www.npmjs.com/package/ngx-i18nsupport
