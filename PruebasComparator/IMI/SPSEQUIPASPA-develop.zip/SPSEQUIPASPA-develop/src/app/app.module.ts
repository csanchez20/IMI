import 'moment/locale/ca';

import { registerLocaleData, DatePipe } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import localeCa from '@angular/common/locales/ca';
import {
  ErrorHandler,
  LOCALE_ID,
  NgModule,
  TRANSLATIONS,
  TRANSLATIONS_FORMAT,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AkitaNgDevtools } from '@datorama/akita-ngdevtools';
import { environment } from '@env/environment';
import { I18n } from '@ngx-translate/i18n-polyfill';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { PageNotFoundComponent } from './modulos-funcionales/componentes';
import { SharedModule } from './shared/shared.module';
import { NoCacheHeadersInterceptor } from './core/interceptors/no-cache.interceptor';
import { GlobalErrorHandler } from './core/error-handlers/global-error-handler';

// import localeEs from '@angular/common/locales/ca';
declare const require; // Use the require method provided by webpack
const defaultLocale = 'ca';

registerLocaleData(localeCa, defaultLocale);
@NgModule({
  declarations: [AppComponent, PageNotFoundComponent],
  imports: [
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AppRoutingModule,
    CoreModule,
    SharedModule.forRoot(),
    environment.production
      ? []
      : AkitaNgDevtools.forRoot({
          logTrace: false,
        }),
  ],
  providers: [
    { provide: LOCALE_ID, useValue: defaultLocale },
    { provide: TRANSLATIONS_FORMAT, useValue: 'xlf' },
    {
      provide: TRANSLATIONS,
      useFactory: (locale: any) => {
        const l = locale || defaultLocale;
        return require(`raw-loader!../translate/messages.${l}.xlf`);
      },
      deps: [LOCALE_ID],
    },
    I18n,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: NoCacheHeadersInterceptor,
      multi: true,
    },
    {provide: ErrorHandler, useClass: GlobalErrorHandler},
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}

/* export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
 */
