import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { ImiSpsInfo } from '@app/core/auth/model';
import { SessionQuery, SessionService } from '@app/core/auth/state';
import { HttpStatusService } from '@app/core/interceptors';
import { SERVICIO_RESPIRPLUS } from '@app/core/model';
import { UserQuery, UserService } from '@app/modulos-funcionales/generic/usuarios/state';
import { UsuariosService } from '@app/servicios';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { MenuItem, MessageService, SelectItem } from 'primeng/api';
import { Observable, Subscription } from 'rxjs';

export const ERROR_DURATION_SECONDS = 5;

@AutoUnsubscribe()
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit, OnDestroy {
  itemsMenuUser: MenuItem[];
  servicesList$: Observable<any>;
  currentService: SelectItem;
  currentLanguage: string;
  loading$ = this.httpStatus.loading$;
  acting$ = this.httpStatus.acting$;
  validationErrors$ = this.httpStatus.getvalidationErrors$;
  validationSuccess$ = this.httpStatus.getvalidationSuccess$;
  sub: Subscription;
  sub2: Subscription;
  sub3: Subscription;
  sub4: Subscription;

  itemsServicesMenu: MenuItem[] = [
    {
      items: []
    }
  ];

  constructor(
    private authService: SessionService,
    public authQuery: SessionQuery,
    public userQuery: UserQuery,
    private userStoreService: UserService,
    private userService: UsuariosService,
    private httpStatus: HttpStatusService,
    private messageService: MessageService,
    public router: Router,
    private cd: ChangeDetectorRef,
    private sessionQuery: SessionQuery,
    private sessionService: SessionService
  ) {}

  ngOnInit() {
    this.sub = this.authQuery.service$.subscribe(service => {
      if (service !== null) {
        this.sub4 = this.userService
        .getServiciosActivosUsuario()
        .subscribe(services => {
          let items: MenuItem[] = [];
          services.map(service => {
              const serviceActivo = this.authQuery.getServiceActiveValue();
              if (service.value === serviceActivo) {
                
                items = [
                  ...items,
                  {
                    label: service.label,
                    command: () => {
                      this.onChangeService(service);
                    }
                  }
                ];
                this.currentService = service;
                return;
              }
          });
        });
      }
    });

    this.sub2 = this.validationErrors$.subscribe(error => {
      this.messageService.add({
        key: 'error',
        severity: 'error',
        summary: `${error['status']}`,
        detail: error['message'],
        life: ERROR_DURATION_SECONDS * 1000
      });
      this.cd.markForCheck();
    });

    this.sub3 = this.validationSuccess$.subscribe(message => {
      this.messageService.add({
        key: 'success',
        severity: 'success',
        life: ERROR_DURATION_SECONDS * 1000,
        ...message
      });
    });

  }

  onChangeService(service): void {
    this.authService.setService(service);
    this.resetGlobalParams(service);
    this.authService.setPlacesSauv(null);
    this.router.navigate(['inici']);
  }

  resetGlobalParams(service: any) {
    if(service.value !== SERVICIO_RESPIRPLUS) {
      this.sessionService.resetParametresGlobalsRespirPlus();
    }
  }

  logout() {
    this.authService.logout();
  }

  ngOnDestroy() {
    // We'll throw an error if it doesn't
  }

  get userRol() {
    return this.authQuery.getRoleUser();
  }

  canviarGrup(){
    this.authService.setService(null);
    this.currentService.label=null;
    this.currentService.value=null;
    const imiSpsInfo: ImiSpsInfo = {
      centro: null
    };

    this.authService.updateImiSpsInfo(imiSpsInfo);
    this.router.navigate(['/selecciona-grup/']);
  }
}
