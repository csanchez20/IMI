import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { SessionQuery, SessionService } from '@app/core/auth';
import { ROLE_AREA_ECON } from '@app/core/auth/model';
import { DictionaryService } from '@app/core/dictionary/state';
import { ResultatConsultaEstatsSollicitudsSauvRDTO, ServiciosIMI } from '@app/core/model';
import { SolicitudesService } from '@app/servicios';
import { arrayAdd, arrayUpdate } from '@datorama/akita';
import { MenuItem, SelectItem } from 'primeng/api';
import { Subscription } from 'rxjs';

export const EQUIPAMENTS_ROOT = '';
@Component({
  selector: 'app-menu-principal',
  templateUrl: './menu-principal.component.html',
  styleUrls: ['./menu-principal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MenuPrincipalComponent implements OnInit, OnDestroy {
  service$ = this.sessionQuery.service$;
  sub: Subscription;
  itemsMenu: any[];
  totalEstats: ResultatConsultaEstatsSollicitudsSauvRDTO[];

  constructor(
    private sessionQuery: SessionQuery,
    private sessionService: SessionService,
    private solicitudesService: SolicitudesService,
    private dictionaryService: DictionaryService
  ) {}

  ngOnInit() {
    this._initMenu();
    this.sub = this.service$.subscribe(service => {
      if (service) {
        this._initMenu();
        if(!this.sessionQuery.isServiceViviendas()){
          this.solicitudesService.getTotalSolicitutsByEstats().subscribe(totalEstats => {
            this.totalEstats = totalEstats;
            this._initSollicitutsByEstat(service);
          });
        }
        this._updateMenuByService(service);
        this._updateMenuByRole();
      }
    });
  }

  updateVisibility(show: boolean, pareId: string, itemId: string) {
    this.itemsMenu = this.itemsMenu.map(item => {
      if (item.id === pareId) {
        return {
          ...item,
          items: arrayUpdate<any>(item.items, itemId, { visible: show }, 'id')
        };
      } else {
        return item;
      }
    });
  }

  private _initMenu() {
    this.itemsMenu = [
      {
        label: 'Inici',
        routerLink: EQUIPAMENTS_ROOT + '/inici'
      },
      {
        id: 'gestion_del_servicio',
        label: 'Gestió del servei',
        items: [
          {
            id: 'ficha_servicio',
            label: 'Fitxa de servei',
            icon: 'pi pi-fw pi-refresh',
            routerLink: EQUIPAMENTS_ROOT + '/serveis'
          },
          {
            id: 'equipamientos',
            label: 'Equipaments',
            icon: 'pi pi-fw pi-lock',
            routerLink: EQUIPAMENTS_ROOT + '/equipaments'
          },
          {
            label: 'Incidències',
            icon: 'pi pi-fw pi-refresh',
            routerLink: EQUIPAMENTS_ROOT + '/incidencies'
          },
          {
            id: 'listado_plazas',
            label: 'Llista de places',
            icon: 'pi pi-fw pi-list',
            routerLink: EQUIPAMENTS_ROOT + '/llistatPlaces'
          }
        ]
      },
      {
        id: 'gestion_asistencial',
        label: 'Gestió assistencial',
        items: [
          {
            label: 'Usuaris',
            icon: 'pi pi-fw pi-users',
            routerLink: EQUIPAMENTS_ROOT + '/usuaris'
          },
          {
            id: 'vincular',
            label: 'Vincular',
            icon: 'pi pi-fw pi-sign-in',
            routerLink: EQUIPAMENTS_ROOT + '/vincular'
          },
          {
            id: 'listados_viviendas',
            label: 'Llistats',
            icon: 'pi pi-fw pi-list',
            routerLink: EQUIPAMENTS_ROOT + '/llistats/habitatges'
          },
          {
            id: 'listados',
            label: 'Llistats',
            icon: 'pi pi-fw pi-list',
            items: [
              {
                label: 'Usuaris amb places municipals',
                routerLink: EQUIPAMENTS_ROOT + '/llistat/usuari/placamunicipal'
              },
              {
                label: 'Usuaris amb places públiques',
                routerLink: EQUIPAMENTS_ROOT + '/llistat/usuari/placapublica'
              },
              {
                label: 'Consultes SAUV',
                routerLink: EQUIPAMENTS_ROOT + '/llistat/consultesSauv'
              }
            ]
          }
        ]
      },
      {
        label: 'Ajuda',
        routerLink: EQUIPAMENTS_ROOT + '/ajuda'
      }
    ];
  }

  private _updateMenuByService(service: number) {
    this.updateVisibility(false, 'gestion_asistencial', 'vincular');
    this.updateVisibility(false, 'gestion_asistencial', 'listados_viviendas');
    if (service === ServiciosIMI.GUARDAMUEBLES) {
      this.updateVisibility(true, 'gestion_asistencial', 'solicitudes');
      this.updateVisibility(false, 'gestion_del_servicio', 'equipamientos');
      this.updateVisibility(true, 'gestion_del_servicio', 'ficha_servicio');
      this.updateVisibility(false, 'gestion_asistencial', 'listados');
      this.updateVisibility(false, 'gestion_del_servicio', 'listado_plazas');
    } else if (service === ServiciosIMI.RESPIRPLUS) {
      this.updateVisibility(true, 'gestion_asistencial', 'solicitudes');
      this.updateVisibility(false, 'gestion_del_servicio', 'equipamientos');
      this.updateVisibility(true, 'gestion_del_servicio', 'ficha_servicio');
      this.updateVisibility(false, 'gestion_asistencial', 'listados');
      this.updateVisibility(false, 'gestion_del_servicio', 'listado_plazas');
    } else if (service === ServiciosIMI.RESPIR) {
      this.updateVisibility(true, 'gestion_asistencial', 'solicitudes');
      this.updateVisibility(false, 'gestion_del_servicio', 'equipamientos');
      this.updateVisibility(false, 'gestion_del_servicio', 'ficha_servicio');
      this.updateVisibility(false, 'gestion_asistencial', 'listados');
      this.updateVisibility(false, 'gestion_del_servicio', 'listado_plazas');
    } else if (service === ServiciosIMI.VIVIENDAS) {
      this.updateVisibility(true, 'gestion_asistencial', 'vincular');
      this.updateVisibility(true, 'gestion_asistencial', 'listados_viviendas');
      this.updateVisibility(false, 'gestion_asistencial', 'solicitudes');
      this.updateVisibility(true, 'gestion_del_servicio', 'equipamientos');
      this.updateVisibility(true, 'gestion_del_servicio', 'ficha_servicio');
      this.updateVisibility(false, 'gestion_asistencial', 'listados');
      this.updateVisibility(false, 'gestion_del_servicio', 'listado_plazas');
    } else {
      // SAUV
      this.updateVisibility(true, 'gestion_asistencial', 'solicitudes');
      this.updateVisibility(true, 'gestion_del_servicio', 'equipamientos');
      this.updateVisibility(true, 'gestion_del_servicio', 'ficha_servicio');
      this.updateVisibility(true, 'gestion_del_servicio', 'listado_plazas');
      this.updateVisibility(true, 'gestion_asistencial', 'listados');
    }
  }

  private _updateMenuByRole() {
    if (this.sessionQuery.isUserRoleById(ROLE_AREA_ECON)) {
      this.itemsMenu = [
        {
          label: 'Inici',
          routerLink: EQUIPAMENTS_ROOT + '/inici'
        },
        {
          id: 'gestion_del_servicio',
          label: 'Gestió del servei',
          items: [
            {
              id: 'ficha_servicio',
              label: 'Fitxa de servei',
              icon: 'pi pi-fw pi-refresh',
              routerLink: EQUIPAMENTS_ROOT + '/serveis'
            }
          ]
        },
        {
          label: 'Ajuda',
          routerLink: EQUIPAMENTS_ROOT + '/ajuda'
        }
      ]
    }
  }

  private _initSollicitutsByEstat(service: number) {    
    this.itemsMenu = this.itemsMenu.map(item => {
      if (item.id === 'gestion_asistencial') {
        let menu: MenuItem[]
        return {
          ...item,
          items: arrayAdd(item.items, this._getMenuItemSolByEstat(service))
        }
      } else {
        return item;
      }
    })
  }

  private _getMenuItemSolByEstat(service: number): MenuItem {
    let estados: MenuItem[];
    if (service === ServiciosIMI.SAUV) {
      this.dictionaryService.getEstadosSolicitud_SAUV().subscribe();
      this.solicitudesService.getEstadosSolicitudSAUV().subscribe(res => {
        estados = this._mapEstadosToMenuItem(res)
      });
    } else if (service === ServiciosIMI.GUARDAMUEBLES) {
      this.dictionaryService.getEstadosSolicitud_GUARDAMOBLES().subscribe();
      this.solicitudesService.getEstadosSolicitudGUARDAMOBLES().subscribe(res => {
        estados = this._mapEstadosToMenuItem(res)
      });
    } else if (service === ServiciosIMI.RESPIR) {
      this.dictionaryService.getEstadosSolicitud_RESPIR().subscribe();
      this.solicitudesService.getEstadosSolicitudRESPIR().subscribe(res => {
        estados = this._mapEstadosToMenuItem(res)
      });
    } else if (service === ServiciosIMI.RESPIRPLUS) {
      // this.dictionaryService.getEstadosSolicitud_RESPIRPLUS().subscribe();
      // this.solicitudesService.getEstadosSolicitudRESPIRPLUS().subscribe(res => {
      //   estados = this._mapEstadosToMenuItem(res)
      // });
    }
    const solicitudesByEstat: MenuItem = {
      id: 'solicitudes',
      label: 'Sol·licituds',
      icon: 'pi pi-fw pi-refresh',
      routerLink: EQUIPAMENTS_ROOT + '/sol·licituds',
      items: estados,
      command: () => {
        this._resetEstatId()
      }
    }
    return solicitudesByEstat;
  }

  private _mapEstadosToMenuItem(estados: SelectItem[]): MenuItem[] {
    let estadosMapped: MenuItem[];
    return estadosMapped = estados.map(estado => {
      return {
        label: estado.label + "   (" + this._getTotalSolicituts(''+estado.value) + ')',
        icon: 'pi pi-circle-on',
        routerLink: EQUIPAMENTS_ROOT + '/sol·licituds',
        command: () => {
          this._setEstatId(estado.value)
        },
        
      }
    })
  }

  private _getTotalSolicituts(estatId: string): number {
    if (this.totalEstats !== null && this.totalEstats.length > 0) {
      const totalSolicitutsByEstat = this.totalEstats.find(estat => estat.estatId === estatId);
      return totalSolicitutsByEstat ? totalSolicitutsByEstat.totalSollicituds : 0;
    } else {
      return 0;
    }
  }

  private _setEstatId(estat: number) {
    this.sessionService.setFiltroEstadoSolicitud(estat);
  }

  private _resetEstatId() {
    this.sessionService.resetFiltroEstadoSolicitud();
  }

  ngOnDestroy() {
    this.sub && this.sub.unsubscribe();
  }
}
