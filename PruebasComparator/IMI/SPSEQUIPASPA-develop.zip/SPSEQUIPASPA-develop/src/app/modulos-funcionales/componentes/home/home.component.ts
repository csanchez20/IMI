import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { SessionQuery } from '@app/core/auth';
import { UsuariosService } from '@app/servicios';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class HomeComponent implements OnInit {

  isUserConfigured: boolean;

  constructor(
    private sessionQuery: SessionQuery
  ) { }

  ngOnInit() {
    this.sessionQuery.service$.subscribe(service => {
      this.isUserConfigured = service !== null;
    })
  }
}
