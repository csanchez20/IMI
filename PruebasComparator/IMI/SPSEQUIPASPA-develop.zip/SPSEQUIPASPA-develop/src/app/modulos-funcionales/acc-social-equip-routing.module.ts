import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthUserGuard } from '@app/core/auth/guards/auth-user.guard';
import { HomeComponent } from './componentes';
import { IncidenciasResolverService } from './generic/incidencias/incidencias-resolver.service';
import {
  ListadoPlacasMunicipalesResolverService
} from './generic/listado-placas-municipales/listado-placas-municipales-resolver.service';
import {
  ListadoPlacasPublicasResolverService
} from './generic/listado-placas-publicas/listado-placas-publicas-resolver.service';


const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'inici'
      },
      {
        path: 'inici',
        loadChildren: './generic/inicio/inicio.module#InicioEquipamentsModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup'
        }
      },
      {
        path: 'sol·licituds',
        loadChildren: './generic/solicitudes/solicitudes.module#SolicitudesModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'listaSolicitudes'
        }
      },
      {
        path: 'usuaris',
        loadChildren: './generic/usuarios/usuarios.module#UsuariosModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'listaUsuarios'
        }
      },
      {
        path: 'serveis',
        loadChildren: './generic/ficha-servicio/ficha-servicio.module#FichaServicioModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'servicios'
        },
      },
      {
        path: 'incidencies',
        resolve: { res: IncidenciasResolverService },
        loadChildren: './generic/incidencias/incidencias.module#IncidenciasModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'incidencias'
        }
      },
      {
        path: 'llistatPlaces',
        loadChildren: './generic/solicitudes/SAUV/detalle-solicitud/listado-plazas/listado-plazas.module#ListadoPlazasModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'listadoPlazas',
          readOnly: true
        }
      },
      {
        path: 'tareas/:id',
        loadChildren: './generic/tareas/tareas.module#TareasModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'tareasBread'
        },
      },
      {
        path: 'equipaments',
        loadChildren: './generic/equipaments/equipaments.module#EquipamentsModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'equipaments'
        }
      },
      {
        path: 'ajuda',
        loadChildren: './generic/ayuda/ayuda.module#AyudaEquipamentsModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'ayuda'
        },
      },
      {
        path: 'llistat/usuari/placamunicipal',
        resolve: { res: ListadoPlacasMunicipalesResolverService },
        loadChildren: './generic/listado-placas-municipales/listado-placas-municipales.module#ListadoPlacasMunicipalesModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'listaUsuariosPlacasMunicipales'
        },
      },
      {
        path: 'llistat/usuari/placapublica',
        resolve: { res: ListadoPlacasPublicasResolverService },
        loadChildren: './generic/listado-placas-publicas/listado-placas-publicas.module#ListadoPlacasPublicasModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'listaUsuariosPlacasPublicas'
        },
      },
      {
        path: 'llistat/consultesSauv',
        loadChildren: './generic/listado-consultas-sauv/listado-consultas-sauv.module#ListadoConsultasSauvModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'listaConsultasSauv'
        },
      },
      {
        path: 'vincular',
        loadChildren: './generic/vincular/vincular.module#VincularModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'vincular'
        },
      },
      {
        path: 'selecciona-grup',
        loadChildren: './generic/selecciona-grup/selecciona-grup.module#SeleccionaGrupModule',
        canActivate: [AuthUserGuard],
        data: {
          imiSpsInfoRequired: ['centro'],
          urlToRedirect: 'inici',
          inverse: true
        }
      },
      {
        path: 'llistats/habitatges',
        loadChildren: './generic/listados-viviendas/listados-viviendas.module#ListadosViviendasModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'listadosHabitatges'
        },
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccSocialEquipRoutingModule {}
