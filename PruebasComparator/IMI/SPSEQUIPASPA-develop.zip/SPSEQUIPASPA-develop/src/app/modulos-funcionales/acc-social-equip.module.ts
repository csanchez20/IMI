import { NgModule } from '@angular/core';
import { HomeComponent } from './componentes/home/home.component';
import {
  DropdownModule,
  PanelModule,
  MenubarModule,
  ProgressBarModule,
  AutoCompleteModule,
  SlideMenuModule,
  ButtonModule,
} from 'primeng/primeng';

import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {
  HeaderComponent,
  MenuPrincipalComponent,
  FooterComponent,
} from './componentes';
//import { SpsCompSpaModule } from '../../../projects/spscompspa/src/public_api';
import { AccSocialEquipRoutingModule } from './acc-social-equip-routing.module';
import { BreadcrumbModule } from '../../../projects/spscompspa/src/public_api';
import { ToastModule } from 'primeng/toast';
import { MomentModule } from 'ngx-moment';

@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    MenuPrincipalComponent,
    HomeComponent,
  ],
  imports: [
    CommonModule,
    // Primeng
    FormsModule,
    PanelModule,
    DropdownModule,
    MenubarModule,
    BreadcrumbModule,
    ProgressBarModule,
    AutoCompleteModule,
    SlideMenuModule,
    ButtonModule,
    ToastModule,
    MomentModule,
    // Routing
    AccSocialEquipRoutingModule,

    // Lib-BreadCrumb
    // SpsCompSpaModule
  ],
  exports: [],
})
export class AccSocialEquipModule {}
