import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RelacionesEquipamientosProveedorEdicionComponent } from './relaciones-equipamientos-proveedor-edicion.component';

describe('RelacionesEquipamientosProveedorEdicionComponent', () => {
  let component: RelacionesEquipamientosProveedorEdicionComponent;
  let fixture: ComponentFixture<RelacionesEquipamientosProveedorEdicionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RelacionesEquipamientosProveedorEdicionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RelacionesEquipamientosProveedorEdicionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
