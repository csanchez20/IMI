import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogAddInspeccionComponent } from './dialog-add-inspeccion.component';

describe('DialogEditInspeccionComponent', () => {
  let component: DialogAddInspeccionComponent;
  let fixture: ComponentFixture<DialogAddInspeccionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogAddInspeccionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogAddInspeccionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
