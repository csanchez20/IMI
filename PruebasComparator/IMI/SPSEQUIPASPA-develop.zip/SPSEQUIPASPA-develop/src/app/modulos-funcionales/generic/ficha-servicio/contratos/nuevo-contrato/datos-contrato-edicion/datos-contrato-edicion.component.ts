import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { I18nConfigService } from '../../../../../../../../projects/spscompspa/src/app/services';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { forkJoin } from 'rxjs';
import { DictionaryQuery, DictionaryService, DiccionarioKey } from '@app/core/dictionary/state';
import moment from 'moment'
@Component({
  selector: 'app-datos-contrato-edicion',
  templateUrl: './datos-contrato-edicion.component.html',
  styleUrls: ['./datos-contrato-edicion.component.scss'],
})
export class DatosContratoEdicionComponent implements OnInit {
  @Input() group: FormGroup;

  dictionaries: any;
  minDate: Date;
  diccionarioKey = DiccionarioKey;

  constructor(
    public i18nConfig: I18nConfigService,
    public i18n: I18n,
    public dictionaryQuery: DictionaryQuery,
    public dictionaryService: DictionaryService,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.setMinDate(); 
    
    forkJoin({
      tipos_contratos: this.dictionaryService.getTiposContrato(),
      estados_contratos: this.dictionaryService.getEstadosContrato(),
      capitulos_presupuestarios: this.dictionaryService.getCapitulosPresupuestarios(),
      periodos_presupuestarios: this.dictionaryService.getPeriodosPresupuestarios(),

    }).subscribe((dictionaries) => {
      this.dictionaries = dictionaries;
      this.group.patchValue({
        ...this.group,
        estatDid: 2023102, //Vigent
      });
    });
  }

  setMinDate(){
    let today = new Date();
    let nextMonth = new Date();
    nextMonth.setMonth(today.getMonth() + 1);
    this.minDate = nextMonth;
  }
  
  calculaDurada() {
    if(this.group.get('dataFi').value != '' && this.group.get('dataFi').value != null && this.group.get('dataInici').value != '' && this.group.get('dataInici').value != null) {
      this.group.patchValue({
        durada:  moment(this.group.get('dataFi').value).add(1, 'month').diff(moment(this.group.get('dataInici').value), 'months')  
      })
      return moment(this.group.get('dataFi').value).add(1, 'month').diff(moment(this.group.get('dataInici').value), 'months');     
    }
    else return  this.i18n({ id: 'sinEspecificar', value: 'Sense especificar' });
  }
}
