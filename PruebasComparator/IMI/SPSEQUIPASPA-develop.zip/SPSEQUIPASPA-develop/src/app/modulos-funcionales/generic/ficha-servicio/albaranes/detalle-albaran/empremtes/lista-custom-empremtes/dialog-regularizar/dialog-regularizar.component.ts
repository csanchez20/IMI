import { Component, OnInit, OnDestroy, OnChanges, ChangeDetectorRef } from '@angular/core';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { DynamicDialogRef, DynamicDialogConfig, MessageService } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { AltaEmpremta, ItemEmpremta } from '@app/core/model';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { ChangeDetectionStrategy } from '@angular/core/src/render3/jit/compiler_facade_interface';
@AutoUnsubscribe()
@Component({
  selector: 'app-dialog-regularizar',
  templateUrl: './dialog-regularizar.component.html',
  styleUrls: ['./dialog-regularizar.component.scss'],
})
export class DialogRegularizarComponent implements OnInit, OnDestroy {
  empremta: ItemEmpremta;
  errorCostAsumitIgualARegularitzacio = false;
  errorCostNoSuperiorALaRegularitzacio = false;
  form: FormGroup = this.fb.group({
    costRegularitzar: ["", Validators.required],
    costProveidor: ["", Validators.required],
    costAjuntament: ["", Validators.required],
  });
  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private i18n: I18n,
    private fb: FormBuilder,
    private albaranesService: AlbaranesService,
    private messageService: MessageService,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.empremta = this.config.data['empremta'];
    console.log('emprembta', this.empremta);
  }
  ngOnDestroy() {}

  closeDialog() {
    this.ref.close();
  }

  regularitzaEmpremta() {
    if(this.form.valid && !this.isInvalid()) {
      const valorPositiuRegularització = this.form.get('costRegularitzar').value >= 0
      const reguritzarEmpremta: AltaEmpremta = {
        "regularitzacio": true,
        "importRegularitzar": valorPositiuRegularització ? this.form.get('costAjuntament').value : this.form.get('costProveidor').value, 
        "empremtaId": this.empremta.empremtaId 
      }
      this.albaranesService
        .altaEmpremta(reguritzarEmpremta)
        .pipe(
          catchError((err) => {
            console.log(err);
            this.messageService.add({
              severity: 'error',
              summary: err.message,
            });
            return of(null);
          })
        )
        .subscribe((res) => {
          if  (res !== null)  {
            console.log(res);
            this.messageService.add({
              severity: 'success',
              summary: 'Empremta regularitzada',
            });
            this.ref.close();
          }
          
        });
    }
   
  }

  isInvalid(): boolean {
    console.log('form valid: ', this.form.valid)
    const costRegularitzar = this.form.get('costRegularitzar').value
    const costProveidor = this.form.get('costProveidor').value
    const costAjuntament = this.form.get('costAjuntament').value
    console.log('costRegularitzar', costRegularitzar)
    console.log('costProveidor', costProveidor)
    console.log('costAjuntament', costAjuntament)
    //Suma cost proveidor i ajuntament igual al total de la regularització
    if  (costRegularitzar !== (costProveidor + costAjuntament)) {
      this.errorCostAsumitIgualARegularitzacio = true;
      this.errorCostNoSuperiorALaRegularitzacio = false;
      setTimeout(() => {
      }, 1);
      return true;
    }
    //El costProveidor o costAjuntament no pot ser mes gran que costRegularitzar en valor absolut (negatiu o positiu)
    else if  (Math.abs(costProveidor) > Math.abs(costRegularitzar) || Math.abs(costAjuntament) > Math.abs(costRegularitzar)) {
      this.errorCostNoSuperiorALaRegularitzacio = true;
      this.errorCostAsumitIgualARegularitzacio = false;
      setTimeout(() => {
      }, 1);
      return true;
    }
    else {
      this.errorCostAsumitIgualARegularitzacio = false;
      this.errorCostNoSuperiorALaRegularitzacio = false;
      setTimeout(() => {
      }, 1);
      return false;
    }  
    
  }
}
