import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaAlbaranesEnRegularizacionComponent } from './lista-albaranes-en-regularizacion.component';

describe('ListaAlbaranesEnRegularizacionComponent', () => {
  let component: ListaAlbaranesEnRegularizacionComponent;
  let fixture: ComponentFixture<ListaAlbaranesEnRegularizacionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaAlbaranesEnRegularizacionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaAlbaranesEnRegularizacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
