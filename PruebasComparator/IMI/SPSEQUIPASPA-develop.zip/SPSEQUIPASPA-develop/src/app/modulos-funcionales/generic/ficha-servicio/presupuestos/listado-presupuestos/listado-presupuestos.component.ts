import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { TableData, InfoItem, FiltrosPresupuesto } from '@app/core/model';
import { PresupuestosService } from '@app/servicios/ficha-servicio/presupuestos.service';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { EventEmitter } from 'protractor';

@Component({
  selector: 'app-listado-presupuestos',
  templateUrl: './listado-presupuestos.component.html',
  styleUrls: ['./listado-presupuestos.component.scss'],
})
export class ListadoPresupuestosComponent implements OnInit {
  filtrosPresupuesto: FiltrosPresupuesto;
  constructor() {}

  ngOnInit() {}

  handleFilters(event: FiltrosPresupuesto) {
    console.log('evento filtreos', event);
    this.filtrosPresupuesto = event;
  }
}
