import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogEditDatosPresupuestoComponent } from './dialog-edit-datos-presupuesto.component';

describe('DialogEditDatosPresupuestoComponent', () => {
  let component: DialogEditDatosPresupuestoComponent;
  let fixture: ComponentFixture<DialogEditDatosPresupuestoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogEditDatosPresupuestoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogEditDatosPresupuestoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
