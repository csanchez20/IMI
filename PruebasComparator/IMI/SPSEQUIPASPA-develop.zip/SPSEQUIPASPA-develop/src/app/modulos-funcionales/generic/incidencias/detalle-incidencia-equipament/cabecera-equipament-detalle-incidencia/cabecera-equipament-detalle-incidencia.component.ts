import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { IncidenciaRDTO } from '@app/core/model';
import { UsuariosService } from '@app/servicios';
import { SelectItem } from 'primeng/api';

@Component({
  selector: 'app-cabecera-equipament-detalle-incidencia',
  templateUrl: './cabecera-equipament-detalle-incidencia.component.html',
  styleUrls: ['./cabecera-equipament-detalle-incidencia.component.scss']
})
export class CabeceraEquipamentDetalleIncidenciaComponent implements OnInit {

  @Input() incidencia: IncidenciaRDTO;
  servicio: SelectItem;

  constructor(
    private usuarioService: UsuariosService,
    private cd: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.usuarioService.getServiciosActivosUsuario().subscribe(servicios => {
      this.servicio = servicios.find(servicio => servicio.value === this.incidencia.tipusRespostaDid);
      this.cd.markForCheck();
    });
  }  

}
