import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { DynamicDialogRef, DynamicDialogConfig, SelectItem } from 'primeng/api';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';
import { InfoItem } from '@app/core/model/information';
import { EmpresaGestoraServeisCentresCercadesRDTO } from '@app/core/model/proveedores';
import { SessionQuery } from '@app/core/auth';
import { I18nConfigService } from '../../../../../../../../../projects/spscompspa/src/app/services';
import { ProveedoresService } from '@app/servicios';
import { DatePipe } from '@angular/common';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { HttpStatusService } from '@app/core/interceptors';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { ActivatedRoute } from '@angular/router';
import { ContracteRDTO } from '@app/core/model';
import { FormatterService } from '@app/core/services/formatter.service';
import moment from 'moment';
import { validateRange } from '@app/core/services';
import { GeneralValidationsService } from '@app/core/services/general-validations.service';
import {
  KIT_SERVICIO_ID,
  KIT_TIPO_UNIDAD_ID,
  TIPUS_SERVEI_ESTADA,
  TIPUS_PLANIFICACIO_PLANIFICAT,
  TIPUS_PLANIFICACIO_PUNTUAL,
  KIT_TIPO_SERVICIO_ID,
} from '@app/servicios/equipaments/serveisPrestats.service';

@AutoUnsubscribe()
@Component({
  selector: 'app-dialog-edit-equipamiento-proveedor',
  templateUrl: './dialog-edit-equipamiento-proveedor.component.html',
  styleUrls: ['./dialog-edit-equipamiento-proveedor.component.scss'],
  providers: [DatePipe],
})
export class DialogEditEquipamientoProveedorComponent
  implements OnInit, OnDestroy {
  serviciosEquipamiento: EmpresaGestoraServeisCentresCercadesRDTO[];
  cols: InfoItem[];
  centreId: string;
  contrato: ContracteRDTO;

  diccionarioKey = DiccionarioKey;

  equipamientoForm: FormGroup = this.fb.group({
    elementos: this.fb.array([]),
  });

  editingRowKeys: { [s: string]: boolean } = {};
  clonedServicios: {
    [s: string]: EmpresaGestoraServeisCentresCercadesRDTO;
  } = {};
  count = 0;

  tipusPlanificacioOptions: SelectItem[] = [];
  tipusPlanificacioKitOptions: SelectItem[] = [];
  unitatOptions: SelectItem[] = [];
  unitatKitOptions: SelectItem[] = [];
  // activeKit = false;
  isEditing = false;

  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private fb: FormBuilder,
    public dictionaryQuery: DictionaryQuery,
    public cd: ChangeDetectorRef,
    private sessionQuery: SessionQuery,
    public i18nConfig: I18nConfigService,
    private proveedorService: ProveedoresService,
    private datepipe: DatePipe,
    private httpStatusService: HttpStatusService,
    private i18n: I18n,
    private route: ActivatedRoute,
    private formatterService: FormatterService,
    private generalValidations: GeneralValidationsService
  ) {}

  ngOnInit() {
    this.contrato = this.route.snapshot.data['contratoRes'].contrato;
    this.serviciosEquipamiento = this.config.data.serviciosEquipamiento;
    this.cols = this.config.data.cols;
    console.log(this.cols);
    this.cols.splice(7, 1);
    this.centreId = this.config.data.centreId;

    this.tipusPlanificacioOptions = this.dictionaryQuery.getDictionaryKey(
      this.diccionarioKey.TIPOS_SERVICIOS_PRESTADOS
    );
    this.unitatOptions = this.dictionaryQuery.getDictionaryKey(
      this.diccionarioKey.TIPO_UNIDADES
    );

    // this.splitDictionaries();

    this.serviciosEquipamiento.map((servicio) => {
      this.addNewElemento(servicio);
    });
  }

  get elementos() {
    return this.equipamientoForm.controls.elementos as FormArray;
  }

  addNewElemento(servicio: EmpresaGestoraServeisCentresCercadesRDTO) {
    this.elementos.push(
      this.fb.group(
        {
          serveiContrCentreId: [
            servicio.serveiContrCentreId,
            Validators.required,
          ],
          centreId: [servicio.centreId, Validators.required],
          contracteId: [servicio.contracteId, Validators.required],
          dataFiVigencia: [
            servicio.dataFiVigencia ? new Date(servicio.dataFiVigencia) : null,
            Validators.required,
          ],
          dataIniciVigencia: [
            servicio.dataIniciVigencia
              ? new Date(servicio.dataIniciVigencia)
              : null,
            Validators.required,
          ],
          iva: [
            servicio.iva,
            [Validators.required, Validators.min(0), Validators.max(100)],
          ],
          /* preuPublicUnitari: [
        servicio.preuPublicUnitari ? servicio.preuPublicUnitari : null
      ], */
          preuUnitari: [servicio.preuUnitari, Validators.required],
          tipusPlanificacioDid: [
            servicio.tipusPlanificacioDid,
            Validators.required,
          ],
          tipusRespostaDid: [servicio.tipusRespostaDid, Validators.required],
          tipusServeiDid: [servicio.tipusServeiDid, Validators.required],
          unitatDid: [servicio.unitatDid, Validators.required],
        },
        { validators: [validateRange('dataIniciVigencia', 'dataFiVigencia')] }
      )
    );
  }

  //Necesario para poder tener rows editables
  trackByFn(index, row) {
    return index;
  }

  onRowEditInit(servicio: EmpresaGestoraServeisCentresCercadesRDTO) {
    this.isEditing = true;
    this.editingRowKeys[servicio.serveiContrCentreId] = true;
    this.clonedServicios[servicio.serveiContrCentreId] = { ...servicio };
    // KIT_SERVICIO_ID === servicio.tipusServeiDid ?
    //   this.activeKit = true :
    //   this.activeKit = false;
  }

  onRowSave(servicio: EmpresaGestoraServeisCentresCercadesRDTO, index: number) {
    this.elementos
      .get('' + index)
      .get('dataFiVigencia')
      .setValue(
        this.formatterService.getDateLastDayMonth(
          this.elementos.get('' + index).get('dataFiVigencia').value
        )
      );
    const validRepeatedServices = this.validateRepeatedServices(index);
    const validEstadaPuntual = this.validateEstadaPuntual(index);
    const validDateInContratoRange = this.validateDateInContratoRange(index);
    if (
      validRepeatedServices &&
      validEstadaPuntual &&
      validDateInContratoRange
    ) {
      servicio = {
        ...servicio,
        preuPublicUnitari: servicio.preuPublicUnitari
          ? servicio.preuPublicUnitari
          : null,
        dataFiVigencia: this.datepipe.transform(
          this.elementos.get('' + index).get('dataFiVigencia').value,
          'dd/MM/yyyy'
        ),
        dataIniciVigencia: this.datepipe.transform(
          this.elementos.get('' + index).get('dataIniciVigencia').value,
          'dd/MM/yyyy'
        ),
      };
      this.clonedServicios[servicio.serveiContrCentreId]
        ? this.onSaveEdit(servicio)
        : this.onSaveAdd(servicio, index);
    } else {
      this.editingRowKeys[servicio.serveiContrCentreId] = true;
      if (!validRepeatedServices) {
        this._addErrorToElement(index, { ilegalDate: true });
      }
      if (!validEstadaPuntual) {
        this._addErrorToElement(index, { ilegalEstada: true });
      }
      if (!validDateInContratoRange) {
        this._addErrorToElement(index, { ilegalDateInContrato: true });
      }
    }
  }

  onRowEditCancel(
    servicio: EmpresaGestoraServeisCentresCercadesRDTO,
    index: number
  ) {
    this.isEditing = false;
    delete this.editingRowKeys[servicio.serveiContrCentreId];
    this.clonedServicios[servicio.serveiContrCentreId]
      ? this.onCancelEdit(servicio, index)
      : this.onCancelAdd(index);
  }

  onRemove(i: number) {
    this.elementos.removeAt(i);
  }

  onSaveAdd(servicio: EmpresaGestoraServeisCentresCercadesRDTO, index: number) {
    this.proveedorService
      .postServicioContratoEmpresaGestora({
        ...servicio,
        serveiContrCentreId: null,
      })
      .subscribe((res) => {
        if (res) {
          this.isEditing = false;
          this.elementos
            .get('' + index)
            .get('serveiContrCentreId')
            .setValue(res.serveiContrCentreId);
          delete this.editingRowKeys[servicio.serveiContrCentreId];
          this.httpStatusService.validationSucces = {
            summary: this.i18n({
              id: 'peticionCorrecta',
              value: 'Petició correcte',
            }),
            detail: this.i18n({
              id: 'servicioAñadidoCorr',
              value: 'Servei afegit correctament',
            }),
          };
        }
      });
  }

  onSaveEdit(servicio: EmpresaGestoraServeisCentresCercadesRDTO) {
    delete this.clonedServicios[servicio.serveiContrCentreId];
    this.proveedorService
      .putServicioContratoEmpresaGestora(servicio)
      .subscribe((res) => {
        if (res) {
          this.isEditing = false;
          delete this.editingRowKeys[servicio.serveiContrCentreId];
          this.httpStatusService.validationSucces = {
            summary: this.i18n({
              id: 'peticionCorrecta',
              value: 'Petició correcte',
            }),
            detail: this.i18n({
              id: 'servicioEditadoCorr',
              value: 'Servei editat correctament',
            }),
          };
        }
      });
  }

  onCancelAdd(index: number) {
    this.isEditing = false;
    this.onRemove(index);
  }

  onCancelEdit(
    servicio: EmpresaGestoraServeisCentresCercadesRDTO,
    index: number
  ) {
    this.elementos
      .get('' + index)
      .setValue(this.clonedServicios[servicio.serveiContrCentreId]);
    delete this.clonedServicios[servicio.serveiContrCentreId];
  }

  addElementoEquipamiento() {
    const newServicio: EmpresaGestoraServeisCentresCercadesRDTO = {
      serveiContrCentreId: this.count--,
      centreId: this.centreId,
      contracteId: this.contrato.contracteId,
      dataFiVigencia: null,
      dataIniciVigencia: null,
      iva: null,
      preuPublicUnitari: null,
      preuUnitari: null,
      tipusPlanificacioDid: null,
      tipusRespostaDid: this.sessionQuery.getServiceActiveValue(),
      tipusServeiDid: null,
      unitatDid: null,
    };
    this.editingRowKeys[newServicio.serveiContrCentreId] = true;
    this.isEditing = true;
    this.addNewElemento(newServicio);
  }

  validateKit(event, index: number) {
    if (KIT_SERVICIO_ID === event.value) {
      // this.elementos.get(''+index).get('tipusPlanificacioDid').setValue(KIT_TIPO_SERVICIO_ID);
      this.elementos
        .get('' + index)
        .get('unitatDid')
        .setValue(KIT_TIPO_UNIDAD_ID);
      // this.activeKit = true;
    } else if (event.value === TIPUS_SERVEI_ESTADA) {
      this.elementos
        .get('' + index)
        .get('unitatDid')
        .setValue(null);
      this.elementos
        .get('' + index)
        .get('tipusPlanificacioDid')
        .setValue(TIPUS_PLANIFICACIO_PLANIFICAT);
      // this.activeKit = false;
    } else {
      this.elementos
        .get('' + index)
        .get('tipusPlanificacioDid')
        .setValue(null);
      this.elementos
        .get('' + index)
        .get('unitatDid')
        .setValue(null);
      // this.activeKit = false;
    }
  }

  validateDateInContratoRange(index: number): boolean {
    let valid = false;
    const dataFiVigencia = this.elementos.get('' + index).get('dataFiVigencia')
      .value as Date;
    const dataIniciVigencia = this.elementos
      .get('' + index)
      .get('dataIniciVigencia').value as Date;
    if (dataIniciVigencia && dataFiVigencia) {
      if (
        moment(this.contrato.dataInici, 'DD/MM/YYYY').toDate() <=
          dataIniciVigencia &&
        moment(this.contrato.dataFinal, 'DD/MM/YYYY').toDate() >= dataFiVigencia
      ) {
        valid = true;
      }
      return valid;
    }
  }

  validateEstadaPuntual(index: number): boolean {
    let valid = true;
    const tipusServeiDid = this.elementos.get('' + index).get('tipusServeiDid')
      .value;
    const tipusPlanificacioDid = this.elementos
      .get('' + index)
      .get('tipusPlanificacioDid').value;
    if (
      tipusServeiDid === TIPUS_SERVEI_ESTADA &&
      tipusPlanificacioDid === TIPUS_PLANIFICACIO_PUNTUAL
    ) {
      valid = false;
    }
    return valid;
  }

  validateRepeatedServices(index: number): boolean {
    const dataFiVigencia = this.elementos.get('' + index).get('dataFiVigencia')
      .value as Date;
    const dataIniciVigencia = this.elementos
      .get('' + index)
      .get('dataIniciVigencia').value as Date;
    const tipusServeiDid = this.elementos.get('' + index).get('tipusServeiDid')
      .value;
    const serveiContrCentreId = this.elementos
      .get('' + index)
      .get('serveiContrCentreId').value;
    const servicios: EmpresaGestoraServeisCentresCercadesRDTO[] = this.elementos
      .value;
    let valid = true;
    servicios.map((servicio) => {
      if (
        valid &&
        servicio.serveiContrCentreId !== serveiContrCentreId &&
        servicio.tipusServeiDid === tipusServeiDid
      ) {
        valid = this.generalValidations.validateDateANotInDateB(
          new Date(servicio.dataIniciVigencia),
          new Date(servicio.dataFiVigencia),
          dataIniciVigencia,
          dataFiVigencia
        );
      }
    });
    return valid;
  }

  splitDictionaries(): void {
    const diccionariTipusPlanificacio = this.dictionaryQuery.getDictionaryKey(
      this.diccionarioKey.TIPOS_SERVICIOS_PRESTADOS
    );
    const diccionariUnitats = this.dictionaryQuery.getDictionaryKey(
      this.diccionarioKey.TIPO_UNIDADES
    );
    diccionariTipusPlanificacio.map((obj) => {
      obj.value !== KIT_TIPO_SERVICIO_ID
        ? (this.tipusPlanificacioOptions = [
            ...this.tipusPlanificacioOptions,
            obj,
          ])
        : (this.tipusPlanificacioKitOptions = [
            ...this.tipusPlanificacioKitOptions,
            obj,
          ]);
    });

    diccionariUnitats.map((obj) => {
      obj.value !== KIT_TIPO_UNIDAD_ID
        ? (this.unitatOptions = [...this.unitatOptions, obj])
        : (this.unitatKitOptions = [...this.unitatKitOptions, obj]);
    });
  }

  private _addErrorToElement(index: number, error: any) {
    this.elementos.get('' + index).setErrors({
      ...this.elementos.get('' + index).errors,
      ...error,
    });
  }

  ngOnDestroy() {}
}
