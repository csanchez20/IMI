import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ResultadoConsultaAlbaran } from '@app/core/model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-datos-albaran',
  templateUrl: './datos-albaran.component.html',
  styleUrls: ['./datos-albaran.component.scss'],
})
export class DatosAlbaranComponent implements OnInit {
  @Input() albara: ResultadoConsultaAlbaran;
  state$: Observable<object>;
  constructor(private activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    
  }
}
