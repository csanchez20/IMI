import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-relaciones-equipamientos-proveedor-edicion',
  templateUrl: './relaciones-equipamientos-proveedor-edicion.component.html',
  styleUrls: ['./relaciones-equipamientos-proveedor-edicion.component.scss']
})
export class RelacionesEquipamientosProveedorEdicionComponent implements OnInit {

  @Input() equipamientos: string[];
  
  constructor() { }

  ngOnInit() { }

}
