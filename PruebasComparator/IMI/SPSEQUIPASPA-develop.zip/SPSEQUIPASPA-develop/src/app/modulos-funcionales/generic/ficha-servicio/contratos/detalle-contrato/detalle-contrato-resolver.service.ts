import { Injectable } from '@angular/core';
import {
  Resolve,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
} from '@angular/router';
import { Observable, forkJoin, of } from 'rxjs';
import { ContratosService } from '@app/servicios/ficha-servicio/contratos.service';
import { switchMap, map, catchError } from 'rxjs/operators';
import { ContracteRDTO } from '@app/core/model/ficha-servicio/contratos';
import { ProveedoresService } from '@app/servicios';
import { SessionQuery } from '@app/core/auth';
import { ProveedoresEquipamentsService } from '@app/servicios/proveedores/proveedores-equipaments.service';

@Injectable({
  providedIn: 'root',
})
export class DetalleContratoResolverService implements Resolve<any> {
  constructor(
    private contratoService: ContratosService,
    private proveedoresService: ProveedoresService,
    private proveedoresEquipamentsService: ProveedoresEquipamentsService,
    private sessionQuery: SessionQuery
  ) { 
  }

  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> {
    const contracteId = route.paramMap.get('contracteId');
    return this.contratoService.getContratoById(+contracteId).pipe(
      switchMap((contrato: ContracteRDTO) => {
        return forkJoin({
          contrato: of(contrato),
          empresaGestora: this.proveedoresService.getEmpresaGestoraById(contrato.empresaGestoraId),
          serviciosContratoEmpresa: this.proveedoresService.getServiciosByEmpresaIdContratoId({
            contracteId: +contracteId
          }),
          equipamientos: this.proveedoresEquipamentsService.getEquipamentsByEmpresaGestoraId({
            empresaGestoraId: contrato.empresaGestoraId,
            tipusRespostaDid: this.sessionQuery.getServiceActiveValue()
          })
        })
      })
    );
  }
}
