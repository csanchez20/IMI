import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DictionaryQuery ,DiccionarioKey } from '@app/core/dictionary/state';
import { ConsultaAdrecaRDTO } from '@app/core/model';
import { RespuestaConsultaFacturaProforma } from '@app/core/model/ficha-servicio/facturasProforma';
import { FormatterService } from '@app/core/services/formatter.service';

@Component({
  selector: 'app-detalle-factura-proforma',
  templateUrl: './detalle-factura-proforma.component.html',
  styleUrls: ['./detalle-factura-proforma.component.scss']
})
export class DetalleFacturaProformaComponent implements OnInit {

  facturaProforma: RespuestaConsultaFacturaProforma;
  adrecaEquipament: ConsultaAdrecaRDTO;
  id: number;
  diccionarioKey = DiccionarioKey;
  
  constructor(
    private route: ActivatedRoute,
    private formatterService: FormatterService,
    public dictionaryQuery: DictionaryQuery,
  ) { }

  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      this.id = +params.get('facturaProformaId');
    });
    this.facturaProforma = this.route.snapshot.data['res'].facturaProforma;
    this.adrecaEquipament = this.route.snapshot.data['res'].adrecaEquipament;
  }

  getAdrecaToString(direccion: ConsultaAdrecaRDTO) {
    return this.formatterService.getAdrecaToString(direccion);
  }
  
}
