import { Component, OnInit } from '@angular/core';
import { FiltrosAlbaranes } from '@app/core/model/ficha-servicio/albaranes';

@Component({
  selector: 'app-albaranes-en-curso',
  templateUrl: './albaranes-en-curso.component.html',
  styleUrls: ['./albaranes-en-curso.component.scss'],
})
export class AlbaranesEnCursoComponent implements OnInit {
  constructor() {}
  filtros: FiltrosAlbaranes;
  showList = false;
  ngOnInit() {}

  selectedFilters(event: FiltrosAlbaranes) {
    console.log('per aqui passa', event);
    this.filtros = event;
  }
}
