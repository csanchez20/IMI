import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FiltrosEmpremtas } from '@app/core/model';

@Component({
  selector: 'app-empremtes',
  templateUrl: './empremtes.component.html',
  styleUrls: ['./empremtes.component.scss'],
})
export class EmpremtesComponent implements OnInit {
  @Input() editable: boolean;
  @Output() actualitzaDetall = new EventEmitter;

  showList = false;
  filtres: FiltrosEmpremtas;
  constructor() {}

  ngOnInit() {}

  handleFilters(filtres: FiltrosEmpremtas) {
    console.log('busqueda fitres', this.filtres);
    this.filtres = filtres;
  }

  empremtaRegularitzada() {
    console.log('!empremtaRegularitzada')
    this.actualitzaDetall.emit()
  }
}
