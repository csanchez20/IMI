import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListadoPresupuestosComponent } from './listado-presupuestos.component';

describe('ListadoPresupuestosComponent', () => {
  let component: ListadoPresupuestosComponent;
  let fixture: ComponentFixture<ListadoPresupuestosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListadoPresupuestosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListadoPresupuestosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
