import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { IncidenciasService } from '@app/servicios';
import { Observable } from 'rxjs';
import { IncidenciaRDTO } from '@app/core/model';
import { DialogService } from 'primeng/api';
import { ActivatedRoute } from '@angular/router';
import { DataDocumentacionEntidad, TIPUS_ENTIDAD_INCIDENCIA } from '@app/shared/agrupaciones/documentacion-general/documentacion-general.component';

@Component({
  selector: 'app-detalle-incidencia-equipament',
  templateUrl: './detalle-incidencia-equipament.component.html',
  styleUrls: ['./detalle-incidencia-equipament.component.scss'],
  providers: [DialogService]
})
export class DetalleIncidenciaEquipamentComponent implements OnInit {

  incidencia: IncidenciaRDTO;
  dataDocEntidad: DataDocumentacionEntidad;

  constructor(
    private incidenciasService: IncidenciasService,
    private route: ActivatedRoute,
    private cd: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.incidenciasService.getDetalleIncidencia(
      this.route.snapshot.params['idIncidencia']
    ).subscribe(incidencia => {
      this.incidencia = incidencia;
      this.dataDocEntidad = {
        entitatId: ''+incidencia.id,
        tipusEntitatDid: TIPUS_ENTIDAD_INCIDENCIA
      }
      this.cd.markForCheck()
    });
  }

}
