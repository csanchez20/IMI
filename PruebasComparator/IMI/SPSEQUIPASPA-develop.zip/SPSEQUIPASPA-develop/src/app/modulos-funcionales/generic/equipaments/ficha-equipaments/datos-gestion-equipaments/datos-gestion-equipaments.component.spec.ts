// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { of, from, Observable } from 'rxjs';
// import { UserResourcesComponent } from './user-resources.component';
// import { PanelMenuModule, PanelModule, TabViewModule, ButtonModule } from 'primeng/primeng';
// import { TableModule } from 'primeng/table';
// import { ReactiveFormsModule } from '@angular/forms';
// import { HttpClientModule } from '@angular/common/http';
// import { Servicio, Servicios } from '@app/core/model/servicio';
// import { Recurso, EstadoRecurso } from '@app/core/model/respuesta';
// import { UsuariosService } from '@app/servicios';
// import { HistoricoComponent } from './bloques/historico/historico.component';
// import { DatosRecursoComponent } from './bloques/datos-recurso/datos-recurso.component';


// describe('UserResourcesComponent', () => {
//   let component: UserResourcesComponent;
//   let fixture: ComponentFixture<UserResourcesComponent>;
//   let recursoActivo: Recurso[] = [
//     {
//       idUsuario: "123456-X",
//       idSolicitud: "4",
//       label: "Recurso 01/06/18",
//       fechaSolicitud: "04/11/2018",
//       fechaIngreso: "10/10/2018",
//       fechaInicio: "05/11/2016",
//       fechaFinal: "17/11/2017",
//       estado: EstadoRecurso.activo,
//       residencia: {
//         nombreResidencia: "Maria del Olivo",
//         nombreResponsable: "Margarita Vila Rius",
//         nombreTS: "Oscar Díaz López"
//       },
//       nombrePersona: "Marcos Fernandez Montes",
//       centroProcedencia: "Referent Poble Sec"
//     }
//   ]

//   let recursoNoActivo: Recurso[] = [
//     {
//       idUsuario: "123456-X",
//       idSolicitud: "4",
//       label: "Recurso 01/06/18",
//       fechaSolicitud: "04/11/2018",
//       fechaIngreso: "10/10/2018",
//       fechaInicio: "05/11/2016",
//       fechaFinal: "17/11/2017",
//       estado: EstadoRecurso.cancelado,
//       residencia: {
//         nombreResidencia: "Maria del Olivo",
//         nombreResponsable: "Margarita Vila Rius",
//         nombreTS: "Oscar Díaz López"
//       },
//       nombrePersona: "Marcos Fernandez Montes",
//       centroProcedencia: "Referent Poble Sec"
//     }
//   ]

//   let obRec: Observable<Recurso[]> = from([recursoActivo]);
//   let obRecNo: Observable<Recurso[]> = from([recursoNoActivo]);

//   let serviciosActivos: Servicio[] = [
//     { label: Servicios.Guardamuebles, value: 1 },
//     { label: Servicios.SAUV, value: 2 },
//     { label: Servicios.Respir, value: 3 },
//     { label: Servicios.RespirPlus, value: 4 }
//   ]

//   let service: UsuariosService;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [
//         UserResourcesComponent,
//         HistoricoComponent,
//         DatosRecursoComponent
//       ],
//       imports: [
//         PanelMenuModule,
//         PanelModule,
//         TabViewModule,
//         TableModule,
//         ReactiveFormsModule,
//         ButtonModule,
//         HttpClientModule
//       ]
//     })
//       .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(UserResourcesComponent);
//     component = fixture.componentInstance;
//     service = TestBed.get(UsuariosService);
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('should beeen called functions of UsuarioService for set values of variables', () => {

//     const spy = spyOn(service, 'getServiciosActivosUsuario').and.returnValue(
//       from([serviciosActivos])
//     );

//     const spyRA = spyOn(service, 'getRecursosActivos').and.returnValue(obRec);

//     const spyRNA = spyOn(service, 'getRecursosNoActivos').and.returnValue(obRecNo);

//     component.ngOnInit();
//     expect(spy).toHaveBeenCalled();
//     expect(spyRA).toHaveBeenCalled();
//     expect(spyRNA).toHaveBeenCalled();
//     expect(component.recursosActivos$).toBe(obRec);
//     expect(component.recursosNoActivos$).toBe(obRecNo);

//   });
// });
