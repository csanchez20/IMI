import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroFacturasProformaComponent } from './filtro-facturas-proforma.component';

describe('FiltroFacturasProformaComponent', () => {
  let component: FiltroFacturasProformaComponent;
  let fixture: ComponentFixture<FiltroFacturasProformaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiltroFacturasProformaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltroFacturasProformaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
