import { Component, OnInit, Input, ChangeDetectionStrategy } from '@angular/core';
import { DialogService } from 'primeng/api';
import { EmpresaGestoraRDTO } from '@app/core/model/proveedores';

@Component({
  selector: 'app-datos-proveedor',
  templateUrl: './datos-proveedor.component.html',
  styleUrls: ['./datos-proveedor.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush, 
  providers: [DialogService]
})
export class DatosProveedorComponent implements OnInit {

  @Input() empresaGestora: EmpresaGestoraRDTO;

  constructor() { }

  ngOnInit() {
  }

}
