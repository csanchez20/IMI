import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosContratoEdicionComponent } from './datos-contrato-edicion.component';

describe('DatosContratoEdicionComponent', () => {
  let component: DatosContratoEdicionComponent;
  let fixture: ComponentFixture<DatosContratoEdicionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatosContratoEdicionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatosContratoEdicionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
