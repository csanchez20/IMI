import { TestBed } from '@angular/core/testing';

import { AlbaranesResolverService } from './albaranes-resolver.service';

describe('AlbaranesResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AlbaranesResolverService = TestBed.get(AlbaranesResolverService);
    expect(service).toBeTruthy();
  });
});
