import { Component, OnInit , Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { ContratosService } from '@app/servicios/ficha-servicio/contratos.service';
import { ProveedoresService } from '@app/servicios';
import { EmpresaGestoraRDTO, EmpresaGestoraCercadesRDTO } from '@app/core/model/proveedores';

@Component({
  selector: 'app-datos-proveedor-edicion',
  templateUrl: './datos-proveedor-edicion.component.html',
  styleUrls: ['./datos-proveedor-edicion.component.scss']
})
export class DatosProveedorEdicionComponent implements OnInit {

 @Output() empresaGestoraSelected: EventEmitter<number> = new EventEmitter<number>();

 results: EmpresaGestoraCercadesRDTO[];
 empresaGestora: EmpresaGestoraRDTO;
 
  constructor(
    private proveedoresService: ProveedoresService,
    private cd: ChangeDetectorRef
  ) { }

  ngOnInit() {
  }

  buscarProveedor(event){
    this.proveedoresService.getEmpresasGestoras({nomComercial: event.query}).subscribe(empresasGestoras => {
      this.results = empresasGestoras;
      this.cd.markForCheck();
    })
  }

  onSelect(empresasGestora: EmpresaGestoraCercadesRDTO){
    if (empresasGestora) {
      this.proveedoresService.getEmpresaGestoraById(empresasGestora.empresaGestoraId).subscribe(empresaGestora => {
        this.empresaGestora = empresaGestora;
        this.empresaGestoraSelected.emit(empresaGestora.empresaGestoraId);
        this.cd.markForCheck();
      });
    }
  }

  onClear(){
    this.empresaGestoraSelected.emit(null);
    this.empresaGestora = null;
  }

}
