import {
  Component,
  OnInit,
  ViewChild,
  ChangeDetectionStrategy,
  OnDestroy
} from '@angular/core';
import {
  FileUpload,
  DynamicDialogRef,
  DynamicDialogConfig
} from 'primeng/primeng';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { DictionaryQuery } from '@app/core/dictionary/state';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { I18nConfigService } from '../../../../../../../../projects/spscompspa/src/app/services';
import { SessionQuery } from '@app/core/auth';
import { InspeccionService } from '@app/servicios/equipaments/inspeccion.service';
import { InspeccioRDTO, InspeccioIdRDTO, AltaDocumentRDTO } from '@app/core/model/equipaments';
import moment from 'moment';
import { DocumentacionCintraosService } from '@app/servicios/equipaments/documentacion-cintraos.service';
import { ButonGestionDocumental } from '@app/shared/agrupaciones/boton-multifuncion-gestion-documentos/boton-multifuncion-gestion-documentos.component';
import { Subject } from 'rxjs';

interface AddEditInspeccionParams {
  idEquipament: string;
  inspeccion: InspeccioRDTO;
}
@AutoUnsubscribe()
@Component({
  selector: 'app-dialog-add-inspeccion',
  templateUrl: './dialog-add-inspeccion.component.html',
  styleUrls: ['./dialog-add-inspeccion.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DialogAddInspeccionComponent implements OnInit, OnDestroy {
  params: AddEditInspeccionParams;
  idEquipament: string;
  mode: 'edit' | 'add';
  form: FormGroup = this.fb.group({
    dataInspeccio: [new Date(), Validators.required],
    tipusInspeccioDid: ['', Validators.required],
    comentaris: ['']
  });

  botonGestionDocumental: ButonGestionDocumental = {};
  documentFile: File = null;

  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private fb: FormBuilder,
    private inspeccionService: InspeccionService,
    public dictionaryQuery: DictionaryQuery,
    public i18nConfig: I18nConfigService,
    public sessionQuery: SessionQuery,
    private documentacionCintraosService: DocumentacionCintraosService
  ) {}

  ngOnInit() {
    this.params = this.config.data;
    this.idEquipament = this.params.idEquipament;

    this.mode = this.params.inspeccion !== undefined ? 'edit' : 'add';
    if (this.isEditMode()) {
      const inspeccion = this.params.inspeccion;
      this.form.patchValue({
        dataInspeccio: moment(inspeccion.dataInspeccio).toDate(),
        tipusInspeccioDid: inspeccion.tipusInspeccioDid,
        comentaris: inspeccion.comentaris,
        document: inspeccion.document
      });
    } else {
      this._ompleDadesButonsDocumentsAdd();
    }
  }

  onSaveInspeccion(): void {
    this._emitButonsDocuments();
    this.isEditMode() ? this.onEditInspeccion() : this.onAddInspeccion();
  }

  private _ompleDadesButonsDocumentsAdd() {
    this.botonGestionDocumental = {
      documentId: null,
      returnEmitter: new Subject<void>()
    }
  }

  private _emitButonsDocuments() {
    if (this.emitterDocument) {
      this.botonGestionDocumental.returnEmitter.next();
    }
  }

  get emitterDocument() {
    return this.botonGestionDocumental
      && this.botonGestionDocumental.returnEmitter
        && this.botonGestionDocumental.returnEmitter.asObservable();
  }

  setDocument(document: AltaDocumentRDTO) {
    this.documentFile = document.document;
  }

  private onAddInspeccion() {
    let newInspeccion: InspeccioRDTO = {
      ...this.form.value,
      centreId: this.idEquipament,
      idProfessionalDocument: this.sessionQuery.getUserLoggedId()
    };

    if(this.documentFile !== null) {
      this.documentacionCintraosService.postDocumentacio(this.documentFile).subscribe(res => {
        if (res && res['documentId']) {
          newInspeccion = {
            ...newInspeccion,
            document: res['documentId']
          }
          this._postInspeccio(newInspeccion);
        }
      });
    } else {
      this._postInspeccio(newInspeccion);
    }
  }

  private _postInspeccio(inspeccion: InspeccioRDTO) {
    this.inspeccionService
      .postInspeccionEquipament(inspeccion)
      .subscribe((inspRes: InspeccioIdRDTO) => {
        this.ref.close({
          ...inspeccion,
          id: inspRes.inspeccioId
        });
});
  }

  private onEditInspeccion() {
    const newInspeccion: InspeccioRDTO = {
      ...this.form.value,
      idProfessionalDocument: this.sessionQuery.getUserLoggedId(),
      document: this.params.inspeccion.document
    };
    this.inspeccionService
      .putInspeccionEquipament(this.params.inspeccion.id, newInspeccion)
      .subscribe(insRes => {
        this.ref.close({
          ...newInspeccion,
          id: insRes.inspeccioId
        });
      });
  }

  closeDialog() {
    this.ref.close();
  }

  private isEditMode(): boolean {
    return this.mode === 'edit';
  }

  ngOnDestroy() {}
}
