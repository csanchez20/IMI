import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaAlbaranesFacturaProformaComponent } from './lista-albaranes-factura-proforma.component';

describe('ListaAlbaranesFacturaProformaComponent', () => {
  let component: ListaAlbaranesFacturaProformaComponent;
  let fixture: ComponentFixture<ListaAlbaranesFacturaProformaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaAlbaranesFacturaProformaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaAlbaranesFacturaProformaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
