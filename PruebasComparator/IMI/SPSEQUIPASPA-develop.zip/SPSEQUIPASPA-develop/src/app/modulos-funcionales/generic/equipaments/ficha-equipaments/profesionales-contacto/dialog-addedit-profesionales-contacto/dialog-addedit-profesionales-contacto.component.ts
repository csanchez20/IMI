import { Component, OnInit, ViewEncapsulation, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/api';
import { PersonaContacteRDTO } from '@app/core/model/equipaments';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { PersonasContactoService } from '@app/servicios/equipaments/personas-contacto.service';

interface AddEditProfesionalContactoParams {
  idEquipament: string;
  profesional: PersonaContacteRDTO
}
@AutoUnsubscribe()
@Component({
  selector: 'app-dialog-addedit-profesionales-contacto',
  templateUrl: './dialog-addedit-profesionales-contacto.component.html',
  styleUrls: ['./dialog-addedit-profesionales-contacto.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class DialogAddeditProfesionalesContactoComponent implements OnInit, OnDestroy {

  mode: 'edit' | 'add';
  idEquipament: string;
  profesionalContacto: PersonaContacteRDTO;
  profesionalContactoForm: FormGroup = this.fb.group({
    nom: ['', Validators.required],
    correuElectronic: ['', [Validators.required, Validators.email]],
    telefon1: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
    telefon2: ['', Validators.pattern('^[0-9]*$')],
    comentaris: ['']
  })

  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private fb: FormBuilder,
    private personasContService: PersonasContactoService,
  ) { }

  ngOnInit() {
    const params: AddEditProfesionalContactoParams = this.config.data;
    this.idEquipament = params.idEquipament;
    this.mode = params.profesional !== undefined ? 'edit' : 'add';
    if (this.isEditMode()) {
      this.profesionalContacto = params.profesional;
      this.profesionalContactoForm.patchValue(this.profesionalContacto);
      // this.profesionalContactoForm.get('nom').disable();
    }

  }

  onSaveProfesionalContacto(): void {
    this.isEditMode() ? this.onSaveEditProfesionalContacto() : this.onSaveAddProfesionalContacto();
  }

  private onSaveEditProfesionalContacto() {
    // Cambiar id por la que nos devuelve el back (cuando funcione), ahora dbjson nos devuelve el objeto entero por defecto
    // (descomentar)
    this.personasContService.putPersonaContactoEquipament(this.profesionalContacto.id, this.profesionalContactoForm.value).subscribe(id => {
      this.ref.close({
        ...this.profesionalContactoForm.value,
        // Id: id.personaContacteId,
        id: this.profesionalContacto.id,
        centreId: this.idEquipament
      });
    })

  }

  private onSaveAddProfesionalContacto() {
    const newPerson: PersonaContacteRDTO = {
      ...this.profesionalContactoForm.value, 
      centreId: this.idEquipament
    };
    this.personasContService.postPersonaContactoEquipament(newPerson).subscribe(id => {
      this.ref.close({
        ...newPerson,
        id: id.personaContacteId
      });
    })
  }

  closeDialog() {
    this.ref.close();
  }

  private isEditMode(): boolean {
    return this.mode === 'edit';
  }

  isValidForm(): boolean {
    return this.profesionalContactoForm.valid;
  }

  ngOnDestroy() { }

}
