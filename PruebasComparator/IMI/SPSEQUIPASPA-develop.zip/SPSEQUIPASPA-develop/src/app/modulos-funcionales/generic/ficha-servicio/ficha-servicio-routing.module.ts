import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FichaServicioComponent } from './ficha-servicio.component';
import { NuevoContratoComponent } from './contratos/nuevo-contrato/nuevo-contrato.component';
import { DetalleContratoComponent } from './contratos/detalle-contrato/detalle-contrato.component';
import { DetalleContratoResolverService } from './contratos/detalle-contrato/detalle-contrato-resolver.service';
import { DetallePresupuestoComponent } from './presupuestos/detalle-presupuesto/detalle-presupuesto.component';
import { NuevoPresupuestoComponent } from './presupuestos/nuevo-presupuesto/nuevo-presupuesto.component';
import { PresupuestosResolverService } from './presupuestos/presupuestos-resolver.service';
import { DetalleAlbaranComponent } from './albaranes/detalle-albaran/detalle-albaran.component';
import { DetalleFacturaProformaComponent } from './albaranes/detalle-factura-proforma/detalle-factura-proforma.component';
import { DetalleFacturaProformaResolverService } from './albaranes/detalle-factura-proforma/detalle-factura-proforma-resolver.service';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: FichaServicioComponent,
      },
      {
        path: 'contrato/:contracteId',
        component: DetalleContratoComponent,
        resolve: { contratoRes: DetalleContratoResolverService },
        data: {
          breadcrumb: 'detalleContrato',
        },
      },
      {
        path: 'nuevoContrato',

        component: NuevoContratoComponent,
        data: {
          breadcrumb: 'nuevoContrato',
        },
      },
      {
        resolve: { res: PresupuestosResolverService },
        path: 'presupuesto/:presupuestoId',
        component: DetallePresupuestoComponent,
        data: {
          breadcrumb: 'detallePresupuesto',
        },
      },
      {
        resolve: { res: PresupuestosResolverService },
        path: 'nuevoPresupuesto',
        component: NuevoPresupuestoComponent,
        data: {
          breadcrumb: 'nuevoPresupuesto',
        },
      },
      {
        path: 'albaran/:albaranId',
        component: DetalleAlbaranComponent,
        data: {
          breadcrumb: 'detalleAlbaran',
        },
      },
      {
        path: 'facturaProforma/:facturaProformaId',
        component: DetalleFacturaProformaComponent,
        resolve: { res: DetalleFacturaProformaResolverService },
        data: {
          breadcrumb: 'detalleFacturaProforma',
        },
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FichaServicioRoutingModule {}
