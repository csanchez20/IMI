import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroContratosComponent } from './filtro-contratos.component';

describe('FiltroContratosComponent', () => {
  let component: FiltroContratosComponent;
  let fixture: ComponentFixture<FiltroContratosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiltroContratosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltroContratosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
