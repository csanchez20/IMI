import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { I18nConfigService } from '../../../../../../../projects/spscompspa/src/app/services';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { PresupuestosService } from '@app/servicios/ficha-servicio/presupuestos.service';
import { NuevoPresupuesto } from '@app/core/model';
import { Router, ActivatedRoute } from '@angular/router';
import { SessionQuery } from '@app/core/auth';
import { DatePipe } from '@angular/common';
import moment from 'moment';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { HttpStatusService } from '@app/core/interceptors';
import { DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';
@Component({
  selector: 'app-nuevo-presupuesto',
  templateUrl: './nuevo-presupuesto.component.html',
  styleUrls: ['./nuevo-presupuesto.component.scss'],
})
export class NuevoPresupuestoComponent implements OnInit {
  form: FormGroup = this.fb.group({
    dataInici: ['', Validators.required],
    dataFi: ['', Validators.required],
    partidaInicial: ['', Validators.required],
    periodeFacturacioDid: ['', Validators.required],
    territoriDid: ['', Validators.required],
    capitolDid: ['', Validators.required],
  });
  diccionarioKey = DiccionarioKey;
  isSubmitted = false;
  minDate: Date;
  dropDownTerritoriOptions = [];
  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    public i18nConfig: I18nConfigService,
    public i18n: I18n,
    private presupuestosService: PresupuestosService,
    private httpStatusService: HttpStatusService,
    private router: Router,
    private sessionQuery: SessionQuery,
    private datepipe: DatePipe,
    public dictionaryQuery: DictionaryQuery
  ) {}

  ngOnInit() {
    this.setMinDate(); 
    const territoriOptions = this.dictionaryQuery.getDictionaryKey(
      this.diccionarioKey.TERRITORIOS_PRESUPUESTO
    );

    for (const territori of territoriOptions) {
      if (territori['label'] === 'Ciutat') {
        this.dropDownTerritoriOptions.push(territori);
      }
    }
  }

  onSubmit() {
    const presupuesto: NuevoPresupuesto = {
      ...this.form.value,
      dataInici: this.form.get('dataInici').value
        ? moment(this.form.get('dataInici').value).format()
        : null,
      dataFi: this.form.get('dataFi').value
        ? moment(this.form.get('dataFi').value).endOf('month').format()
        : null,
      tipusRespostaDid: this.sessionQuery.getServiceActiveValue(),
      capitolDid: this.form.get('capitolDid').value['value'],
      territoriDid: this.form.get('territoriDid').value['value'],
      periodeFacturacioDid: this.form.get('periodeFacturacioDid').value[
        'value'
      ],
    };

    this.presupuestosService
      .postPresupuesto(presupuesto)
      .pipe(
        catchError((err) => {
          if (err.status == 404) {
            return of(null);
          } else {
            this.httpStatusService.validationErrors = err;
            return of(null);
          }
        })
      )
      .subscribe((res) => {
        if (res) {
          console.log(res);
          this.router.navigate(['../presupuesto/' + res.pressupostServeiId], {
            relativeTo: this.route,
          });
        }
      });
  }

  setMinDate(){
    //No deixem crear un contracte en el mes que ja ha començat
    //Es posa automaticament el primer dia del mes seguent
    let nextMonth = new Date();
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    nextMonth.setDate(1);
    this.minDate = nextMonth;
  }
}
