import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Input,
  OnDestroy,
  OnInit,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DiccionarioKey, DictionaryService } from '@app/core/dictionary/state';
import { InfoItem, TableData } from '@app/core/model/information';
import {
  EmpresaGestoraCentresCercadesRDTO,
  EmpresaGestoraServeisCentresCercadesRDTO,
} from '@app/core/model/proveedores';
import { ProveedoresService } from '@app/servicios';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { DialogService } from 'primeng/api';
import { forkJoin } from 'rxjs';

import { DialogEditEquipamientoProveedorComponent } from './dialog-edit-equipamiento-proveedor/dialog-edit-equipamiento-proveedor.component';

@AutoUnsubscribe()
@Component({
  selector: 'app-relaciones-equipamientos-proveedor',
  templateUrl: './relaciones-equipamientos-proveedor.component.html',
  styleUrls: ['./relaciones-equipamientos-proveedor.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [DialogService],
})
export class RelacionesEquipamientosProveedorComponent
  implements OnInit, OnDestroy {
  @Input() serviciosContratoEmpresa: EmpresaGestoraServeisCentresCercadesRDTO[];
  @Input() equipamientos: EmpresaGestoraCentresCercadesRDTO[] = [];

  dictionaries: any;

  diccionarioKey = DiccionarioKey;

  tableData: TableData[] = [];

  cols: InfoItem[] = [
    {
      field: 'tipusServeiDid',
      header: this.i18n({ id: 'concepto', value: 'Concepte' }),
      type: 'dictionary',
      typeKey: this.diccionarioKey.SERVICIOS_PRESTADOS,
    },
    {
      field: 'unitatDid',
      header: this.i18n({ id: 'unidad', value: 'Unitat' }),
      type: 'dictionary',
      typeKey: this.diccionarioKey.TIPO_UNIDADES,
    },
    {
      field: 'dataIniciVigencia',
      header: this.i18n({
        id: 'fechaIniVigencia',
        value: 'Data inici vigència',
      }),
      type: 'date',
    },
    {
      field: 'dataFiVigencia',
      header: this.i18n({ id: 'fechaFinVigencia', value: 'Data fi vigència' }),
      type: 'date',
    },
    {
      field: 'tipusPlanificacioDid',
      header: this.i18n({
        id: 'tipoPlanificacion',
        value: 'Tipus planificació',
      }),
      type: 'dictionary',
      typeKey: this.diccionarioKey.TIPOS_SERVICIOS_PRESTADOS,
    },
    {
      field: 'preuUnitari',
      header: this.i18n({ id: 'precioUnitario', value: 'Preu unitari €' }),
      type: 'currency',
    },
    {
      field: 'iva',
      header: this.i18n({ id: 'iva', value: 'IVA %' }),
      type: 'percent',
    },
    /*  {
      field: 'preuPublicUnitari',
      header: this.i18n({
        id: 'precioPublicoUnitario',
        value: 'Preu públic unitari €'
      }),
      type: 'currency'
    } */
  ];

  constructor(
    private i18n: I18n,
    private dialogService: DialogService,
    private cd: ChangeDetectorRef,
    private dictionaryService: DictionaryService,
    private route: ActivatedRoute,
    private proveedorService: ProveedoresService
  ) {}

  ngOnInit() {
    forkJoin({
      tiposServiciosPrestados: this.dictionaryService.getTiposServiciosPrestados(),
      serviciosPrestados: this.dictionaryService.getServiciosPrestados(),
      unidades: this.dictionaryService.getTipoUnidades(),
    }).subscribe((dictionaries) => {
      this.dictionaries = dictionaries;
      this.cd.markForCheck();
    });

    this._saveServiciosToTable();
  }

  updateServicios() {
    const contracteId = this.route.snapshot.paramMap.get('contracteId');
    this.proveedorService
      .getServiciosByEmpresaIdContratoId({
        contracteId: +contracteId,
      })
      .subscribe((serviciosEquipamiento) => {
        this.serviciosContratoEmpresa = serviciosEquipamiento;
        this._saveServiciosToTable();
        this.cd.markForCheck();
      });
  }

  /**
   * Mapeamos los datos de los servicios en un array de TableData, agrupandolos segun centro,
   * con el centroId como key para acceder desde la template
   */
  _saveServiciosToTable() {
    this.equipamientos.map((equipamiento) => {
      this.tableData[equipamiento.centreId] = {
        cols: this.cols,
        rows: this.serviciosContratoEmpresa.filter((s) => {
          s.preuPublicUnitari = s.preuPublicUnitari
            ? s.preuPublicUnitari
            : null;
          s.dataIniciVigencia = s.dataIniciVigencia
            ? new Date(s.dataIniciVigencia)
            : null;
          s.dataFiVigencia = s.dataFiVigencia
            ? new Date(s.dataFiVigencia)
            : null;
          return equipamiento.centreId === s.centreId;
        }),
      };
    });
  }

  editEquipamientoProveedor(equipamiento: EmpresaGestoraCentresCercadesRDTO) {
    const ref = this.dialogService.open(
      DialogEditEquipamientoProveedorComponent,
      {
        data: {
          serviciosEquipamiento: this.tableData[equipamiento.centreId].rows,
          cols: this.cols,
          centreId: equipamiento.centreId,
        },
        header: this.i18n({
          id: 'editarDatosDelEquipamiento',
          value: "Editar dades de l'equipament",
        }),
        width: '80%',
      }
    );

    ref.onClose.subscribe(() => {
      this.updateServicios();
    });
  }

  ngOnDestroy() {}
}
