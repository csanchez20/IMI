import {
  Component,
  OnInit,
  OnChanges,
  Input,
  ChangeDetectorRef,
} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PresupuestosService } from '@app/servicios/ficha-servicio/presupuestos.service';
import { I18n } from '@ngx-translate/i18n-polyfill';
import {
  TableData,
  InfoItem,
  ConsultaPresupuestos,
  ResultadoConsultaPresupuestos,
} from '@app/core/model';
import { SessionQuery } from '@app/core/auth';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { HttpStatusService } from '@app/core/interceptors';
import moment from 'moment';
@Component({
  selector: 'app-lista-presupuestos',
  templateUrl: './lista-presupuestos.component.html',
  styleUrls: ['./lista-presupuestos.component.scss'],
})
export class ListaPresupuestosComponent implements OnInit, OnChanges {
  @Input() filtros;
  presupuestos: ResultadoConsultaPresupuestos;
  presupuestosTableData: TableData;
  numRows = 5;
  listButtonsTable: InfoItem[] = [
    {
      icon: 'pi pi-plus-circle',
      label: this.i18n({ id: 'nuevoPresupuesto', value: 'Nou pressupost' }),
      action: 'add',
    },
  ];
  private cols: InfoItem[] = [
    {
      field: 'dataInici',
      header: this.i18n({ id: 'dataInici', value: 'Data inici' }),
      type: 'date',
    },
    {
      field: 'dataFi',
      header: this.i18n({ id: 'dataFi', value: 'Data fi' }),
      type: 'date',
    },
    {
      field: 'partidaInicial',
      header: this.i18n({ id: 'partidaInicial', value: 'Partida Inicial' }),
      type: 'currency',
    },
  ];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private presupuestosService: PresupuestosService,
    private sessionQuery: SessionQuery,
    private i18n: I18n,
    private httpStatusService: HttpStatusService,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this._savePresupuestosToTable();
  }

  getPresupuestos(consultaPresupuestos: ConsultaPresupuestos) {
    this._setLoading(true);
    this.presupuestosService
      .getPresupuestos(consultaPresupuestos)
      .pipe(
        catchError((err) => {
          console.log('error', err);
          this._setLoading(false);
          if (err.status === 400) {
            return of({
              totalRegistres: 0,
              llistaResultatsCercaPressupostServeiRDTO: [],
            });
          } else {
            this.httpStatusService.validationErrors = err;
          }
        })
      )
      .subscribe((res: ResultadoConsultaPresupuestos) => {
        console.log('response', res);
        this.presupuestos = res;
        this._savePresupuestosToTable();
      });
  }

  ngOnChanges() {
    if (this.filtros != null) {
      const consultaPresupuestos: ConsultaPresupuestos = {
        tipusRespostaDid: this.sessionQuery.getServiceActiveValue(),
        dataInici: this.filtros.dataInici
          ? moment(this.filtros.dataInici).format()
          : null,
        dataFi: this.filtros.dataFi
          ? moment(this.filtros.dataFi).endOf('month').format()
          : null,
        vigent: this.filtros.vigent ? this.filtros.vigent : null,
      };
      console.log('consultaPresupuestos', consultaPresupuestos);
      this.getPresupuestos(consultaPresupuestos);
    }
  }

  nouPressupost() {
    this.router.navigate(['nuevoPresupuesto'], { relativeTo: this.route });
  }

  nuevoPresupuesto() {
    this.router.navigate(['nuevoPresupuesto'], { relativeTo: this.route });
  }
  handleSelectedRow(rowSelected: any) {
    this._viewPresupuesto(rowSelected.data.pressupostServeiId);
  }

  /*Paginator */
  paginator(event) {
    this.numRows = event.tamanyPagina;
    this._savePresupuestosToTable();
  }

  private _viewPresupuesto(presupuestoId: number) {
    this.router.navigate(['./presupuesto/' + presupuestoId], {
      relativeTo: this.route,
    });
  }

  private _savePresupuestosToTable() {
    this.presupuestosTableData = {
      cols: this.cols,
      rows: this.presupuestos
        ? this.presupuestos.llistaResultatsCercaPressupostServeiRDTO === null
          ? []
          : this.presupuestos.llistaResultatsCercaPressupostServeiRDTO
        : null,
      numRowsPerPage: this.numRows,
      numeroTotalResultados: this.presupuestos
        ? this.presupuestos.totalRegistres
        : null,
      loading: false,
    };
  }

  private _setLoading(loading: boolean) {
    this.presupuestosTableData = {
      ...this.presupuestosTableData,
      loading: loading,
      rows: null,
    };
  }
}
