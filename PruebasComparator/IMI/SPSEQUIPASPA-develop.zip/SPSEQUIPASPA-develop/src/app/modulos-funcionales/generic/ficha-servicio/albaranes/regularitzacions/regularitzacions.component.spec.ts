import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegularitzacionsComponent } from './regularitzacions.component';

describe('RegularitzacionsComponent', () => {
  let component: RegularitzacionsComponent;
  let fixture: ComponentFixture<RegularitzacionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegularitzacionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegularitzacionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
