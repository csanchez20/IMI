import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AyudaEquipamentsComponent } from './ayuda.component';
import { AyudaEquipamentsRoutingModule } from './ayuda-routing.module';
import { TabViewModule, CardModule, PanelModule } from 'primeng/primeng';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';


@NgModule({
  imports: [
    CommonModule,
    CardModule,
    PanelModule,
    TabViewModule,
    DatatableListModule,
    AyudaEquipamentsRoutingModule,
  ],
  declarations: [
    AyudaEquipamentsComponent
  ],
  exports: [
    AyudaEquipamentsComponent
  ]
})
export class AyudaEquipamentsModule { }
