import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogEditEquipamientoProveedorComponent } from './dialog-edit-equipamiento-proveedor.component';

describe('DialogEditEquipamientoProveedorComponent', () => {
  let component: DialogEditEquipamientoProveedorComponent;
  let fixture: ComponentFixture<DialogEditEquipamientoProveedorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogEditEquipamientoProveedorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogEditEquipamientoProveedorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
