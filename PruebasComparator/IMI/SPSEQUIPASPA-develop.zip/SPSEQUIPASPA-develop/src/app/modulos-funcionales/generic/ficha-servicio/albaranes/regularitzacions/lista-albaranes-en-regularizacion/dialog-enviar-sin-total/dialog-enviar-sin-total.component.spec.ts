import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogEnviarSinTotalComponent } from './dialog-enviar-sin-total.component';

describe('DialogEnviarSinTotalComponent', () => {
  let component: DialogEnviarSinTotalComponent;
  let fixture: ComponentFixture<DialogEnviarSinTotalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogEnviarSinTotalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogEnviarSinTotalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
