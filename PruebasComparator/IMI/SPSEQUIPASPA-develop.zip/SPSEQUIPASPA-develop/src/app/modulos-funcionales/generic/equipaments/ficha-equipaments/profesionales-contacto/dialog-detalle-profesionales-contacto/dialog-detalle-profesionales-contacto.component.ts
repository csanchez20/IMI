import { Component, OnInit } from '@angular/core';
import { PersonaContacteRDTO } from '@app/core/model/equipaments';
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/api';

@Component({
  selector: 'app-dialog-detalle-profesionales-contacto',
  templateUrl: './dialog-detalle-profesionales-contacto.component.html',
  styleUrls: ['./dialog-detalle-profesionales-contacto.component.scss']
})
export class DialogDetalleProfesionalesContactoComponent implements OnInit {

  profesionalContacto: PersonaContacteRDTO;
  
  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
  ) { }

  ngOnInit() {
    this.profesionalContacto = this.config.data;
  }

  closeDialog() {
    this.ref.close();
  }

}
