import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemListaAlbaranesEnCursoComponent } from './item-lista-albaranes-en-curso.component';

describe('ItemListaAlbaranesEnCursoComponent', () => {
  let component: ItemListaAlbaranesEnCursoComponent;
  let fixture: ComponentFixture<ItemListaAlbaranesEnCursoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItemListaAlbaranesEnCursoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemListaAlbaranesEnCursoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
