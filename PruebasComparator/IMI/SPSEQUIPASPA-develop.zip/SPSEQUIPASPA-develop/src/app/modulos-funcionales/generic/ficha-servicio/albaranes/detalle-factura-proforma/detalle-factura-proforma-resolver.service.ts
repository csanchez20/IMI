import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { of, Observable, forkJoin } from 'rxjs';
import { DictionaryService } from '@app/core/dictionary/state';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import { switchMap } from 'rxjs/operators';
import { RespuestaConsultaFacturaProforma } from '@app/core/model/ficha-servicio/facturasProforma';
import { DireccionService } from '@app/servicios';

@Injectable({
  providedIn: 'root'
})
export class DetalleFacturaProformaResolverService implements Resolve<any>{

  constructor(
    private dictionaryService: DictionaryService,
    private albaranesService: AlbaranesService,
    private direccionService: DireccionService,
    ) {}

  resolve(
    route: ActivatedRouteSnapshot,
  ): Observable<any> {
    const facturaProformaId = route.paramMap.get('facturaProformaId');
    return this.albaranesService.getFacturaProforma(+facturaProformaId).pipe(
      switchMap((facturaProforma: RespuestaConsultaFacturaProforma) => {
        return forkJoin({
          d1: this.dictionaryService.getTiposVia(),
          d2: this.dictionaryService.getPeriodosPresupuestarios(),
          facturaProforma: of(facturaProforma),
          adrecaEquipament: this.direccionService.getDireccionUsuarioByUbicacionId(facturaProforma.infoEquipament.ubicacioId),
          
        });
      })
    )
  }
}





