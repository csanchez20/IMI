import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosProveedorEdicionComponent } from './datos-proveedor-edicion.component';

describe('DatosProveedorEdicionComponent', () => {
  let component: DatosProveedorEdicionComponent;
  let fixture: ComponentFixture<DatosProveedorEdicionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatosProveedorEdicionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatosProveedorEdicionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
