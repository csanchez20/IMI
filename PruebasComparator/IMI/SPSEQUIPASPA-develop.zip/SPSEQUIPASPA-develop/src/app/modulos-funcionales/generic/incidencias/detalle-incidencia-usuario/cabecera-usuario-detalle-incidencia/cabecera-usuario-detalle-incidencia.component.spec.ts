import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CabeceraUsuarioDetalleIncidenciaComponent } from './cabecera-usuario-detalle-incidencia.component';

describe('CabeceraUsuarioDetalleIncidenciaComponent', () => {
  let component: CabeceraUsuarioDetalleIncidenciaComponent;
  let fixture: ComponentFixture<CabeceraUsuarioDetalleIncidenciaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CabeceraUsuarioDetalleIncidenciaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CabeceraUsuarioDetalleIncidenciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
