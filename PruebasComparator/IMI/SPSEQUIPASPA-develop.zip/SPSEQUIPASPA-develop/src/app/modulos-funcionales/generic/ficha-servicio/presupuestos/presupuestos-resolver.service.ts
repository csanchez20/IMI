import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { of, Observable, forkJoin } from 'rxjs';
import { DictionaryService } from '@app/core/dictionary/state';

@Injectable({
  providedIn: 'root',
})
export class PresupuestosResolverService implements Resolve<any> {
  constructor(private dictionaryService: DictionaryService) {}

  resolve(): Observable<any> {
    return forkJoin({
      d1: this.dictionaryService.getCapitulosPresupuestarios(),
      d3: this.dictionaryService.getPeriodosPresupuestarios(),
      d4: this.dictionaryService.getTerritorios(),
    });
  }
}
