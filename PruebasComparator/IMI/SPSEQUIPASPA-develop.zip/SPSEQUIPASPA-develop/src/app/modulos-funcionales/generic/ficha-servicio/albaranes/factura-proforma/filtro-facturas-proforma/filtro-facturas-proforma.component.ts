import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { FiltersService } from '@app/core/services';
import moment from 'moment';
@Component({
  selector: 'app-filtro-facturas-proforma',
  templateUrl: './filtro-facturas-proforma.component.html',
  styleUrls: ['./filtro-facturas-proforma.component.scss'],
})
export class FiltroFacturasProformaComponent
  extends FiltersService
  implements OnInit {
  @Output() selectedFilters: EventEmitter<any> = new EventEmitter<any>();

  form: FormGroup = this.fb.group({
    dataInici: [''],
    dataFi: [''],
    empresa: [],
  });
  aplicarFiltres: string = this.i18n({
    id: 'buscar',
    value: 'Buscar',
  });

  //sps-applied-filters
  dataToAppliedFilters: any[] = [];

  labelsAppliedFilters: string[] = [
    this.i18n({ id: 'fechaInicio', value: 'Data inici' }),
    this.i18n({ id: 'fechaFinal', value: 'Data fi' }),
    this.i18n({ id: 'empresa', value: 'Empresa' }),
  ];
  constructor(private fb: FormBuilder, private i18n: I18n) {
    super();
  }

  ngOnInit() {}

  handleEmpresaSelected($event) {
    this.form.patchValue({
      ...this.form,
      empresa: $event,
    });
    console.log('emrpesa selected', this.form.value);
  }

  onActivateFilters() {
    let formFilters: FormGroup = this.fb.group({
      dataInici: [''],
      dataFi: [''],
      empresa: [],
    });
    formFilters.patchValue({
      ...this.form.value,
      dataFi: this.form.get('dataFi').value
        ? moment(this.form.get('dataFi').value).endOf('month').toDate()
        : null,
      empresa: this.form.get('empresa').value
        ? this.form.get('empresa').value['nom']
        : null,
    });
    //const dataOutput: any[] = this.whenActivateFilters(this.form);
    this.dataToAppliedFilters = this.whenActivateFiltersToAppliedFilters(
      formFilters
    );
    this.selectedFilters.emit(this.form.value);
  }

  setFields(outputData: any) {
    this.whenSetFields(this.form, outputData);
  }

  setResetFilters() {
    this.whenSetResetFields(this.form);
  }
}
