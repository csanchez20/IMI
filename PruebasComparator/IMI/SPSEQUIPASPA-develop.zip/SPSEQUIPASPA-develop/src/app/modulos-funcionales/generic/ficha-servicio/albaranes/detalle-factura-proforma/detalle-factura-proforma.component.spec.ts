import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleFacturaProformaComponent } from './detalle-factura-proforma.component';

describe('DetalleFacturaProformaComponent', () => {
  let component: DetalleFacturaProformaComponent;
  let fixture: ComponentFixture<DetalleFacturaProformaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalleFacturaProformaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalleFacturaProformaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
