import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { SessionQuery } from '@app/core/auth';
import { HttpStatusService } from '@app/core/interceptors';
import { ConsultaAlbaranes, InfoItem, TableData, ResultadoCercaAlbaranesTable, ItemCercaAlbaraTable } from '@app/core/model';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { EMPTY, Subscription } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Component({
  selector: 'app-lista-albaranes-factura-proforma',
  templateUrl: './lista-albaranes-factura-proforma.component.html',
  styleUrls: ['./lista-albaranes-factura-proforma.component.scss']
})
export class ListaAlbaranesFacturaProformaComponent implements OnInit {
  @Input() facturaProformaId: number;
  dataAlbarans: TableData;
  sub: Subscription;
  numRows = 5;
  filtersApplied: ConsultaAlbaranes = {
    tipusRespostaDid: null
  };

  info: InfoItem[] = [
    {
      field: 'albaraId',
      header: this.i18n({ id: 'id', value: 'id' })
    },
    {
      field: 'dataInici',
      header: this.i18n({ id: 'fechaInicio', value: 'Data inici' }),
      type: 'date',
    },
    {
      field: 'dataFi',
      header: this.i18n({ id: 'fechaFin', value: 'Data fi' }),
      type: 'date',
    },
    {
      field: 'nomAlbaraCentre',
      header: this.i18n({id: 'centro', value: 'Centre' })
    },
    {
      field: 'unitatsPrevistes',
      header: this.i18n({ id: 'unidadesRealizadas', value: 'Unitats relitzades' })
    },
    {
      field: 'importFinalAmbIva',
      header: this.i18n({ id: 'costeFinalConIva', value: 'Cost final amb iva' }),
      type: 'currency',
    },
    {
      field: 'importFinalSenseIva',
      header: this.i18n({ id: 'costeFinalSinIva', value: 'Cost final sense iva' }),
      type: 'currency',
    }
  ];
  
  constructor(
    private cd: ChangeDetectorRef,
    private albaranesService: AlbaranesService,
    private httpStatusService: HttpStatusService,
    private i18n: I18n,
    private sessionQuery: SessionQuery,
  ) { }

  ngOnInit() {
    this.filtersApplied = {
      tipusRespostaDid: this.sessionQuery.getServiceActiveValue(),
      facturaProformaId : this.facturaProformaId,
      tamanoPagina: 5,
      numeroPagina: 0,
    }

   this.getAlbarans(this.filtersApplied);
  }

  getAlbarans(params: ConsultaAlbaranes) {
    this._setLoading(true);
    this.sub = this.albaranesService.getAlbaranes(params)
      .pipe(
        catchError(err => {
          this._setLoading(false);
          if (err.status === 404) {
            this._saveAlbaransToTable({
              totalRegistres: 0,
              llistaCercaAlbarans: []
            });
            return EMPTY;
          } else {
            this.httpStatusService.validationErrors = err;
          }
        }),
        map(albarans => {
          let llista: ItemCercaAlbaraTable[] = albarans.llistaCercaAlbarans.map( albara => 
            ({
              ...albara, 
              unitatsPrevistes: albara.indicadors.unitatsPrevistes,
              importFinalAmbIva: albara.indicadors.importFinalAmbIva,
              importFinalSenseIva: albara.indicadors.importFinalSenseIva,
            })
          );

          let albaransTable: ResultadoCercaAlbaranesTable = {
            totalRegistres: albarans.totalRegistres,
            llistaCercaAlbarans: llista
          }

          this._saveAlbaransToTable(albaransTable);
        })
      )
      .subscribe();
  }

  _saveAlbaransToTable(albarans: ResultadoCercaAlbaranesTable) {
    
    this.dataAlbarans = {
      cols: this.info,
      rows: albarans ? albarans.llistaCercaAlbarans : null,
      numeroTotalResultados: albarans ? albarans.totalRegistres : null,
      numRowsPerPage: this.numRows,
      loading: false
    };
    this.cd.markForCheck();
  }

  private _setLoading(loading: boolean) {
    this.dataAlbarans = {
      ...this.dataAlbarans,
      loading: loading,
      rows: null
    }
  }

  paginator(event) {
    this.dataAlbarans.numRowsPerPage = event.tamanyPagina;
    this.getAlbarans(this.setParams(
      event
    ));
  }

  onLazyLoad(event) {
    if (event && event.tamanyPagina) {
      this.getAlbarans({
        ...this.setParams(event)
      });
    }
  }

  setParams(params: ConsultaAlbaranes) {
    this.filtersApplied = {
      ...this.filtersApplied,
      ...params
    }
    return this.filtersApplied;
  }
}
