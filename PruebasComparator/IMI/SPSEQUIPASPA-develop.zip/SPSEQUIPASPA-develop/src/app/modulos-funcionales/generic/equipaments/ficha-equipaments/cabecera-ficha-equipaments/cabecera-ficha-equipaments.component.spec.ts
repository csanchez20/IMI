import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CabeceraFichaEquipamentsComponent } from './cabecera-ficha-equipaments.component';

describe('CabeceraFichaEquipamentsComponent', () => {
  let component: CabeceraFichaEquipamentsComponent;
  let fixture: ComponentFixture<CabeceraFichaEquipamentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CabeceraFichaEquipamentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CabeceraFichaEquipamentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
