import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ItemEmpremta } from '@app/core/model';
import { ItemLlistaCercaFacturesProforma, RegularitzarProforma } from '@app/core/model/ficha-servicio/facturasProforma';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { DynamicDialogConfig, DynamicDialogRef, MessageService } from 'primeng/api';
import { of } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-dialog-regularitzar-factura',
  templateUrl: './dialog-regularitzar-factura.component.html',
  styleUrls: ['./dialog-regularitzar-factura.component.scss']
})
export class DialogRegularitzarFacturaComponent implements OnInit {

  factura: ItemLlistaCercaFacturesProforma;
  form: FormGroup = this.fb.group({
    importRegularitzarAmbIva: ["", Validators.required],
    importRegularitzarSenseIva: ["", Validators.required],
  });
  importInicialFacturaAmbIva: number;
  importInicialFacturaSenseIva: number;


  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private i18n: I18n,
    private fb: FormBuilder,
    private albaranesService: AlbaranesService,
    private messageService: MessageService
  ) {}

  ngOnInit() {
    this.factura = this.config.data['factura'];
    this.form.patchValue({
      importRegularitzarAmbIva: this.factura.importRegularitzatAmbIva,
      importRegularitzarSenseIva: this.factura.importRegularitzatSenseIva
    });
    this.importInicialFacturaAmbIva = this.restaRegularitzacio(this.factura.importPrevistAmbIva , this.factura.importRegularitzatAmbIva);
    this.importInicialFacturaSenseIva = this.restaRegularitzacio(this.factura.importPrevistSenseIva , this.factura.importRegularitzatSenseIva);
  }
  
  ngOnDestroy() {}

  closeDialog() {
    this.ref.close();
  }

  regularitzaFactura() {
    if(this.form.valid) {
      const reguritzarProforma: RegularitzarProforma = {
        importRegularitzarAmbIva: this.form.get('importRegularitzarAmbIva').value,
        importRegularitzarSenseIva: this.form.get('importRegularitzarSenseIva').value
      }
      this.albaranesService
        .regularitzaProforma(reguritzarProforma, this.factura.facturaProformaId)
        .pipe(
          catchError((err) => {
            console.log(err);
            this.messageService.add({
              severity: 'error',
              summary: err.message,
            });
            return of(null);
          })
        )
        .subscribe((res) => {
          if  (res !== null)  {
            console.log(res);
            this.messageService.add({
              severity: 'success',
              summary: 'Proforma regularitzada',
            });
            this.ref.close('ok');
          }
          
        });
    } 
    }
    

  sumaPrevist(costActual, regularitzacio): number {
    let costActualAux = 0;
    let regularitzacioAux = 0;
    if(costActual !== null && costActual !== "") {
      costActualAux = costActual
    }
    if(regularitzacio !== null && regularitzacio !== "") {
      regularitzacioAux = regularitzacio
    }
    return costActualAux + regularitzacioAux + 0.0;
  }

  restaRegularitzacio(costPrevist, regularitzacio): number {
    let costPrevistAux = 0;
    let regularitzacioAux = 0;
    if(costPrevist !== null && costPrevist !== "") {
      costPrevistAux = costPrevist
    }
    if(regularitzacio !== null && regularitzacio !== "") {
      regularitzacioAux = regularitzacio
    }
    return costPrevistAux - regularitzacioAux + 0.0;
  }
  /*
  isInvalid(): boolean {
    /* console.log('form valid: ', this.form.valid)
    const costRegularitzar = this.form.get('costRegularitzar').value
    const costProveidor = this.form.get('costProveidor').value
    const costAjuntament = this.form.get('costAjuntament').value
    console.log('costRegularitzar', costRegularitzar)
    console.log('costProveidor', costProveidor)
    console.log('costAjuntament', costAjuntament)
    //Suma cost proveidor i ajuntament igual al total de la regularització
    if  (costRegularitzar !== (costProveidor + costAjuntament)) return true;
    //El costProveidor o costAjuntament no pot ser mes gran que costRegularitzar en valor absolut (negatiu o positiu)
    if  (Math.abs(costProveidor) > Math.abs(costRegularitzar) || Math.abs(costAjuntament) > Math.abs(costRegularitzar)) return true;
     return false;
  }*/

}
