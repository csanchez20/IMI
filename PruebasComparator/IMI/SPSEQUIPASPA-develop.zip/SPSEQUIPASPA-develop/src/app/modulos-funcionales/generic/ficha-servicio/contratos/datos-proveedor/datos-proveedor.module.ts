import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatosProveedorComponent } from './datos-proveedor.component';

@NgModule({
  declarations: [
    DatosProveedorComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    DatosProveedorComponent
  ]
})
export class DatosProveedorModule { }
