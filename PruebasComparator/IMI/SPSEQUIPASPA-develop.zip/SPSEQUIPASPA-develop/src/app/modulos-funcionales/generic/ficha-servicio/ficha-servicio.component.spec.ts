import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FichaServicioComponent } from './ficha-servicio.component';

describe('FichaServicioComponent', () => {
  let component: FichaServicioComponent;
  let fixture: ComponentFixture<FichaServicioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FichaServicioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FichaServicioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
