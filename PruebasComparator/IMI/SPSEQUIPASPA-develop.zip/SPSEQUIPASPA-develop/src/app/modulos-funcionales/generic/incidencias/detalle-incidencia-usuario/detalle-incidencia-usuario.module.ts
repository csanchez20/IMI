import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DetalleIncidenciaUsuarioComponent } from './detalle-incidencia-usuario.component';
import { CabeceraUsuarioDetalleIncidenciaComponent } from './cabecera-usuario-detalle-incidencia/cabecera-usuario-detalle-incidencia.component';
import { DetalleConsultaIncidenciaModule } from '../detalle-incidencia/detalle-consulta-incidencia/detalle-consulta-incidencia.module';
import { DocumentosConsultaIncidenciaModule } from '../detalle-incidencia/documentos-consulta-incidencia/documentos-consulta-incidencia.module';
import { DialogEditDetalleIncidenciaComponent } from '../detalle-incidencia/detalle-consulta-incidencia/dialog-edit-detalle-incidencia/dialog-edit-detalle-incidencia.component';

@NgModule({
  declarations: [
    DetalleIncidenciaUsuarioComponent,
    CabeceraUsuarioDetalleIncidenciaComponent
  ],
  imports: [
    CommonModule,
    DetalleConsultaIncidenciaModule,
    DocumentosConsultaIncidenciaModule
  ],
  bootstrap: [DetalleIncidenciaUsuarioComponent],
  entryComponents: [DialogEditDetalleIncidenciaComponent]
})
export class DetalleIncidenciaUsuarioModule { }
