import { Component, OnInit, Input, OnChanges, ViewChild } from '@angular/core';
import {
  FiltrosAlbaranes,
  ConsultaAlbaranes,
  ResultadoConsultaPresupuestos,
  ResultadoCercaAlbaranes,
  ItemCercaAlbaran,
} from '@app/core/model';
import { SessionQuery } from '@app/core/auth';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import moment from 'moment';
import { SelectItem } from 'primeng/api';
import { Paginator } from 'primeng/primeng';
import { EventEmitter } from 'protractor';
@Component({
  selector: 'app-lista-albaranes-en-curso',
  templateUrl: './lista-albaranes-en-curso.component.html',
  styleUrls: ['./lista-albaranes-en-curso.component.scss'],
})
export class ListaAlbaranesEnCursoComponent implements OnInit, OnChanges {
  @Input() filtros: FiltrosAlbaranes;
  @ViewChild('paginator') paginator: Paginator;

  albaranes: ResultadoCercaAlbaranes;
  albaranesPaginated: ItemCercaAlbaran[];
  numeros: SelectItem[] = [
    { label: '5', value: 5 },
    { label: '10', value: 10 },
    { label: '20', value: 20 },
    { label: '50', value: 50 },
    { label: '100', value: 100 },
  ];
  tamanoPagina = 10;
  numeroPagina = 1;
  constructor(
    private sessionQuery: SessionQuery,
    private albaranesService: AlbaranesService
  ) {}

  ngOnInit() {}

  ngOnChanges() {
    this.getAlbaranes();
  }

  getAlbaranes() {
    if (this.filtros) {
      const consultaAlbaranes = this.construyeObjetoConsultaAlbaranes()
      console.log('consultaAlbaranes', consultaAlbaranes);
      this.albaranesService.getAlbaranes(consultaAlbaranes).subscribe((res) => {
        //Mocked
        /* for (let i = 0; i < res['llistaCercaAlbarans'].length; ++i) {
          res['llistaCercaAlbarans'][i]['albaraId'] = i;
        } */
       /*  if (res['totalRegistres'] !== 0) { */
          //MOCKED!!!
          /* res['totalRegistres'] = 16 */

          //MOCKED!!!
          /* res['llistaCercaAlbarans'][0]['usuarisRevisar'] = 1; */
          this.albaranes = res;
          console.log('albaranes list', this.albaranes);
          console.log('albaranes paginated', this.albaranesPaginated);
       /*  } */
      });
    }
  }

  eventNumeroAlbaranesPorPagina(event) {
    this.tamanoPagina =  event.value;
    this.numeroPagina = 1;
    this.paginator.changePage(0);
    this.getAlbaranes();
  }

  eventCambioDePagina(event) {
    this.numeroPagina = event.page+1;
    this.getAlbaranes();
  }

  private paginaAlbaranes() {
  
  }

/*   private paginaAlbaranes() {
    const numeroAlbaranesPorPagina =
      this.numero <= this.albaranes.llistaCercaAlbarans.length
        ? this.numero
        : this.albaranes.llistaCercaAlbarans.length - 1;
    const recorteInicial = numeroAlbaranesPorPagina * this.numeroPagina;
    const recorteFinal = numeroAlbaranesPorPagina * (this.numeroPagina + 1) - 1;
    console.log('recorteInicial', recorteInicial);
    console.log('recorteFinal', recorteFinal);

    //Hacemos una copia del array
    this.albaranesPaginated = [...this.albaranes.llistaCercaAlbarans];
    //Eliminamos la parte final del array
    const posicionInicialEliminar = recorteFinal + 1;
    const numeroElementosEliminar =
      this.albaranesPaginated.length - recorteFinal - 1;
    this.albaranesPaginated.splice(
      posicionInicialEliminar,
      numeroElementosEliminar
    );
    console.log('posicionInicialEliminar', posicionInicialEliminar);
    console.log('numeroElementosEliminar', numeroElementosEliminar);
    //Eliminamos la parte incial del array
    const posicionInicialEliminar2 = 0;
    const numeroElementosEliminar2 = recorteInicial;
    this.albaranesPaginated.splice(
      posicionInicialEliminar2,
      numeroElementosEliminar2
    );
  }
  } */

  private construyeObjetoConsultaAlbaranes() {
    console.log('get albaranes', this.filtros);
    const consultaAlbaranes: ConsultaAlbaranes = {
      empresaGestoraId: this.filtros.empresa
        ? this.filtros.empresa['empresaGestoraId']
        : null,
      tipusRespostaDid: this.sessionQuery.getServiceActiveValue(),
      dataInici: this.filtros.dataInici
        ? moment(this.filtros.dataInici).format()
        : null,
      dataFi: this.filtros.dataFi
        ? moment(this.filtros.dataFi).endOf('month').format()
        : null,
      teIncidencia: this.filtros.teIncidencia['value'],
      teFacturaProforma: false,
      teRegularitzacio: false,
      tamanoPagina: this.tamanoPagina ? this.tamanoPagina : null,
      numeroPagina: this.numeroPagina ? this.numeroPagina : null,
    };
    return consultaAlbaranes
  }
}
