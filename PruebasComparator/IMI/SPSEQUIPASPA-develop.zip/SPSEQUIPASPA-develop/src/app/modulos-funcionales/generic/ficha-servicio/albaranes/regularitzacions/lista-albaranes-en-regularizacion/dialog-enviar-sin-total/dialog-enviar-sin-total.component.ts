import { Component, OnInit } from '@angular/core';
import { DynamicDialogRef } from 'primeng/api';

@Component({
  selector: 'app-dialog-enviar-sin-total',
  templateUrl: './dialog-enviar-sin-total.component.html',
  styleUrls: ['./dialog-enviar-sin-total.component.scss'],
})
export class DialogEnviarSinTotalComponent implements OnInit {
  constructor(public ref: DynamicDialogRef) {}

  ngOnInit() {}

  dismiss() {
    this.ref.close(false);
  }
  accept() {
    this.ref.close(true);
  }
}
