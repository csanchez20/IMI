import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaAlbaranesEnCursoComponent } from './lista-albaranes-en-curso.component';

describe('ListaAlbaranesEnCursoComponent', () => {
  let component: ListaAlbaranesEnCursoComponent;
  let fixture: ComponentFixture<ListaAlbaranesEnCursoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaAlbaranesEnCursoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaAlbaranesEnCursoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
