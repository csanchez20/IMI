import { Component, OnInit } from '@angular/core';
import { DynamicDialogRef } from 'primeng/api';

@Component({
  selector: 'app-dialog-enviar-regularizar',
  templateUrl: './dialog-enviar-regularizar.component.html',
  styleUrls: ['./dialog-enviar-regularizar.component.scss'],
})
export class DialogEnviarRegularizarComponent implements OnInit {
  constructor(public ref: DynamicDialogRef) {}

  ngOnInit() {}

  dismiss() {
    this.ref.close(false);
  }
  accept() {
    this.ref.close(true);
  }
}
