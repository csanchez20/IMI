import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroEmpremtesComponent } from './filtro-empremtes.component';

describe('FiltroEmpremtesComponent', () => {
  let component: FiltroEmpremtesComponent;
  let fixture: ComponentFixture<FiltroEmpremtesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiltroEmpremtesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltroEmpremtesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
