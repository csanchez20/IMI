import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { SharedModule } from '@app/shared/shared.module';
import { CheckboxModule } from 'primeng/checkbox';
import {
  ButtonModule,
  CalendarModule,
  DropdownModule,
  InputTextModule
} from 'primeng/primeng';
import { TableModule } from 'primeng/table';

import { AppliedFiltersModule } from '../../../../../../projects/spscompspa/src/public_api';
import { FiltroListadoEquipamentsComponent } from './filtro-listado-equipaments/filtro-listado-equipaments.component';
import { ListadoEquipamentsComponent } from './listado-equipaments.component';

@NgModule({
  imports: [
    CommonModule,
    TableModule,
    ButtonModule,
    CalendarModule,
    DropdownModule,
    FormsModule,
    InputTextModule,
    ReactiveFormsModule,
    AppliedFiltersModule,
    DatatableListModule,
    CheckboxModule,
    SharedModule
  ],
  declarations: [
    ListadoEquipamentsComponent,
    FiltroListadoEquipamentsComponent
  ],
  exports: [ListadoEquipamentsComponent, FiltroListadoEquipamentsComponent],
  providers: []
})
export class ListadoEquipamentsModule {}
