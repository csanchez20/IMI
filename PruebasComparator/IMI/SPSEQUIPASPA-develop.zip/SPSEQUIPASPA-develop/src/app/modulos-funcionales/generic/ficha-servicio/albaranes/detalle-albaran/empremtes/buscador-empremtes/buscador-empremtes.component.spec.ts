import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuscadorEmpremtesComponent } from './buscador-empremtes.component';

describe('BuscadorEmpremtesComponent', () => {
  let component: BuscadorEmpremtesComponent;
  let fixture: ComponentFixture<BuscadorEmpremtesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuscadorEmpremtesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuscadorEmpremtesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
