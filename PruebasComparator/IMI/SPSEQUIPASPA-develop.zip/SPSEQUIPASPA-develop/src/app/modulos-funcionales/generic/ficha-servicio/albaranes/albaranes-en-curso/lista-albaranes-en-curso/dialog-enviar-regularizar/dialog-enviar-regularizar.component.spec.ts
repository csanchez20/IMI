import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogEnviarRegularizarComponent } from './dialog-enviar-regularizar.component';

describe('DialogEnviarRegularizarComponent', () => {
  let component: DialogEnviarRegularizarComponent;
  let fixture: ComponentFixture<DialogEnviarRegularizarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogEnviarRegularizarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogEnviarRegularizarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
