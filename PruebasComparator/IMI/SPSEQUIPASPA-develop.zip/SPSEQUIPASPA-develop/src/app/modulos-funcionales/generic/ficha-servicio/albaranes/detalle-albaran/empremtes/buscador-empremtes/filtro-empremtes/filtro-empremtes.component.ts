import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { FiltersService } from '@app/core/services';
import * as _ from 'lodash';
import { DictionaryQuery, DiccionarioKey, DictionaryService } from '@app/core/dictionary/state';

@Component({
  selector: 'app-filtro-empremtes',
  templateUrl: './filtro-empremtes.component.html',
  styleUrls: ['./filtro-empremtes.component.scss'],
})
export class FiltroEmpremtesComponent extends FiltersService implements OnInit {
  @Output() filtresActivats = new EventEmitter();
  @Input() form: FormGroup;
  dictionaryServicios:any;
  diccionarioKey = DiccionarioKey;
  dataToAppliedFilters: any[] = [];
  labelsAppliedFilters: string[] = [
    // this.i18n({ id: 'fechaInicio', value: 'Data inici' }),
    // this.i18n({ id: 'fechaFinal', value: 'Data fi' }),
    this.i18n({ id: 'nomComplet', value: 'Nom' }),
    this.i18n({ id: 'expedientId', value: 'Expedient' }),
    this.i18n({ id: 'document', value: 'Document' }),
    this.i18n({ id: 'tipusServeiDid', value: 'Concepte' }),
    this.i18n({ id: 'teIncidencia', value: 'Té incidència' }),
  ];
  aplicarFiltres: string = this.i18n({
    id: 'buscar',
    value: 'Buscar',
  });

  teIncidenciaDropdownOptions = [
    {
      label: this.i18n({ id: 'si', value: 'Sí' }),
      value: true,
    },
    {
      label: this.i18n({ id: 'no', value: 'No' }),
      value: false,
    },
    {
      label: this.i18n({ id: 'indeferente', value: 'Indiferent' }),
      value: null,
    },
  ];

  constructor(
    private fb: FormBuilder, 
    private i18n: I18n,
    public dictionaryQuery: DictionaryQuery,
    public dictionaryService: DictionaryService
    ) {
    super();
  }

  onActivateFilters() {
     const formAux: FormGroup = this.fb.group({
      nomComplet: [''],
      expedientId: [''],
      document: [''],
      tipusServeiDid: [''],
      teIncidencia: ['']
    });
    console.log("form",this.form);
    
    formAux.patchValue({
      ...this.form.value,
      tipusServeiDid: this.form.get('tipusServeiDid').value
        ? this.dictionaryQuery.getItemDictionaryByKey(this.form.get('tipusServeiDid').value, this.diccionarioKey.SERVICIOS_PRESTADOS)
        : null,
    });
    console.log("formAux",formAux);

    this.dataToAppliedFilters = this.whenActivateFiltersToAppliedFilters(
      formAux
    ); 
    // this.dataToAppliedFilters = this.whenActivateFiltersToAppliedFilters(
    //   this.form
    // );
    console.log('dataToAppliedFilters', this.dataToAppliedFilters);
    this.filtresActivats.emit();
  }

  ngOnInit() {
    // Cargamos los tipos de servicios en el diccionario.
    this.dictionaryService.getServiciosPrestados().subscribe(dictionary => {
      this.dictionaryServicios = dictionary;
    });
  }

}
