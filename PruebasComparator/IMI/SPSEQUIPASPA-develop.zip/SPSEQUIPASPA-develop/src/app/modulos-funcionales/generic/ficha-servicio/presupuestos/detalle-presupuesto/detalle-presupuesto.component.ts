import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { PresupuestosService } from '@app/servicios/ficha-servicio/presupuestos.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogService, Message } from 'primeng/api';
import { DialogEditDatosPresupuestoComponent } from './dialog-edit-datos-presupuesto/dialog-edit-datos-presupuesto.component';
import { I18n } from '@ngx-translate/i18n-polyfill';
import {
  TableData,
  InfoItem,
  RespuestaPresupuesto,
  RespuestaEditarPresupuesto,
} from '@app/core/model';
import moment from 'moment';
import { DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { HttpStatusService } from '@app/core/interceptors';
import { DialogConfirmComponent } from '@app/shared/componentes';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-detalle-presupuesto',
  templateUrl: './detalle-presupuesto.component.html',
  styleUrls: ['./detalle-presupuesto.component.scss'],
})
export class DetallePresupuestoComponent implements OnInit {
  public presupuesto: RespuestaPresupuesto;
  diccionarioKey = DiccionarioKey;
  id: number;
  constructor(
    private presupuestosService: PresupuestosService,
    private albaranesService: AlbaranesService,
    private route: ActivatedRoute,
    private dialogService: DialogService,
    private i18n: I18n,
    private cd: ChangeDetectorRef,
    public dictionaryQuery: DictionaryQuery,
    private router: Router,
    private httpStatusService: HttpStatusService
  ) {}
  public ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      this.id = +params.get('presupuestoId');
      this.getPresupuesto(this.id);
    });
  }

  public editaDatosPresupuesto() {
    if (
      this.presupuesto &&
      this.presupuesto.vigent &&
      !this.presupuesto.empremtesGenerades
    ) {
      const ref = this.dialogService.open(DialogEditDatosPresupuestoComponent, {
        data: this.presupuesto,
        header: this.i18n({
          id: 'editarDatosPresupuesto',
          value: 'Editar dades del pressupost',
        }),
        width: '60%',
      });

      ref.onClose.subscribe(
        (respuestaEditarPresupuesto: RespuestaEditarPresupuesto) => {
          if (respuestaEditarPresupuesto) {
            this.router.navigate(
              [
                './serveis/presupuesto/' +
                  respuestaEditarPresupuesto.pressupostServeiId,
              ],
              {}
            );
          }
        }
      );
    }
  }

  public handleGenerarAlbarans() {

    const ref = this.dialogService.open(DialogConfirmComponent, {
      data: {
        confirmDeleteMessage: 'A continuació es generaran els Albarans i les Empremtes '+
         'en tràmit i en servei per al període pressupostari. '+
        'Aquesta acció no es pot desfer des de l’aplicació. '+
        'Està segur que vol continuar?',
        acceptLabel: this.i18n({ id: 'continuar', value: 'Continuar' }),
        cancelLabel: this.i18n({ id: 'cancelar', value: 'Cancel·lar' }),
      },
      header: "Confirmació de generació d'albarans",
      width: '40%',
    });

    ref.onClose.subscribe((data: any) => {
      if (data) {
        this.albaranesService
        .generaEmpremtes(this.id)
        .pipe(
          catchError((err) => {
            this.httpStatusService.validationErrors = err;  
            return of(null);
        })
        )
        .subscribe((res) => {
          
          if (res) {
            //window.location.reload();
            const message: Message = {
              detail:  "Albarans generats"
            }
            this.httpStatusService.validationSucces =message;
            this.route.paramMap.subscribe((params) => {
              this.id = +params.get('presupuestoId');
              this.getPresupuesto(this.id);
            });
          }
        });
      }
    });

  }

  private getPresupuesto(id: number) {
    this.presupuesto = null;
    this.presupuestosService.getPresupuesto(id).subscribe((res) => {
      this.presupuesto = res;
      this.cd.markForCheck();
    });
  }
}
