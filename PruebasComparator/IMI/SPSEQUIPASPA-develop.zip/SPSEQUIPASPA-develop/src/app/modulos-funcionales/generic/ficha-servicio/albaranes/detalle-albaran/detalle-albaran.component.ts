import { Component, OnInit } from '@angular/core';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import { ActivatedRoute } from '@angular/router';
import { ResultadoConsultaAlbaran } from '@app/core/model';

@Component({
  selector: 'app-detalle-albaran',
  templateUrl: './detalle-albaran.component.html',
  styleUrls: ['./detalle-albaran.component.scss'],
})
export class DetalleAlbaranComponent implements OnInit {
  constructor(
    private albaranService: AlbaranesService,
    private route: ActivatedRoute
  ) {}
  albara: ResultadoConsultaAlbaran;
  idAlbara;
  enPeriodoRevision: boolean = false;

  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      this.idAlbara = +params.get('albaranId');
      this.getAlbara();
    });
  }

  getAlbara() {
    this.albaranService.getAlbara(this.idAlbara).subscribe((res) => {
      this.albara = res;
      this.enPeriodoRevision = 
        this.albara.obert 
        && (new Date().getTime() >= this.albara.dataInici);
    });
  }

  actualitzaDetall() {
      console.log('ACTUALITZA DETALL')
      this.getAlbara();
  }
}
