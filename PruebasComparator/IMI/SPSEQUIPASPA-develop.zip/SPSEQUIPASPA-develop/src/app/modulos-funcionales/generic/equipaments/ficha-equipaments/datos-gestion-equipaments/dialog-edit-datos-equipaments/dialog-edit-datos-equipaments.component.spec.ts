import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogEditDatosEquipamentsComponent } from './dialog-edit-datos-equipaments.component';

describe('DialogEditDatosEquipamentsComponent', () => {
  let component: DialogEditDatosEquipamentsComponent;
  let fixture: ComponentFixture<DialogEditDatosEquipamentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogEditDatosEquipamentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogEditDatosEquipamentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
