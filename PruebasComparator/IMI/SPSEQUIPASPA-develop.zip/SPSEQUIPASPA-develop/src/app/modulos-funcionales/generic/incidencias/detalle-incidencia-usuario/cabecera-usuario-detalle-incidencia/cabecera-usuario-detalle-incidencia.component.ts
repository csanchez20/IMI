import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { IncidenciaRDTO } from '@app/core/model';
import { SelectItem } from 'primeng/api';
import { UsuariosService } from '@app/servicios';

@Component({
  selector: 'app-cabecera-usuario-detalle-incidencia',
  templateUrl: './cabecera-usuario-detalle-incidencia.component.html',
  styleUrls: ['./cabecera-usuario-detalle-incidencia.component.scss']
})
export class CabeceraUsuarioDetalleIncidenciaComponent implements OnInit {

  @Input() incidencia: IncidenciaRDTO;
  servicio: SelectItem;

  constructor(
    private usuarioService: UsuariosService,
    private cd: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.usuarioService.getServiciosActivosUsuario().subscribe(servicios => {
      this.servicio = servicios.find(servicio => servicio.value === this.incidencia.tipusRespostaDid);
      this.cd.markForCheck();
    });
  } 

}
