import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { IncidenciaRDTO } from '@app/core/model';
import { DiccionarioKey, DictionaryService, DictionaryQuery } from '@app/core/dictionary/state';
import { SessionQuery, IncidenciaType } from '@app/core/auth';
import { DialogService } from 'primeng/api';
import { DialogEditDetalleIncidenciaComponent } from './dialog-edit-detalle-incidencia/dialog-edit-detalle-incidencia.component';
import { I18n } from '@ngx-translate/i18n-polyfill';

@Component({
  selector: 'app-detalle-consulta-incidencia',
  templateUrl: './detalle-consulta-incidencia.component.html',
  styleUrls: ['./detalle-consulta-incidencia.component.scss']
})
export class DetalleConsultaIncidenciaComponent implements OnInit {

  @Input() incidencia: IncidenciaRDTO;

  diccionarioKey = DiccionarioKey;

  constructor(
    public dictionaryQuery: DictionaryQuery,
    private sessionQuery: SessionQuery,
    private dialogService: DialogService,
    private i18n: I18n,
    private cd: ChangeDetectorRef
  ) { }

  ngOnInit() {}

  editIncidencia() {
    const ref = this.dialogService.open(
      DialogEditDetalleIncidenciaComponent,
      {
        data: this.incidencia,
        header: this.i18n({
          id: 'editarDetalleIncidencia',
          value: 'Editar detall incidència'
        }),
        width: '50%'
      }
    );

    ref.onClose.subscribe(data => {
      if (data) {
        this.incidencia = data;
        this.cd.markForCheck();
      }
    });
  }

  get valueTipusIncidencia() {
    return this.dictionaryQuery.getItemDictionaryByKey(
      this.incidencia.tipusIncidenciaDid,
      this.sessionQuery.getIncidenciaType() === IncidenciaType.USUARIO
        ? this.diccionarioKey.TIPO_INCIDENCIAS_USUARIO
        : this.diccionarioKey.TIPO_INCIDENCIAS_EQUIPAMENT
    )
  }

}
