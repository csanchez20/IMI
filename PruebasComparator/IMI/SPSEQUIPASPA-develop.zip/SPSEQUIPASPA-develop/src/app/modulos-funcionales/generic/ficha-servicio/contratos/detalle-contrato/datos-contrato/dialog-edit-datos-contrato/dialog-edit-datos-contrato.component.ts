import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';
import {
  ContracteRDTO,
  ModificaContracteRDTO,
} from '@app/core/model/ficha-servicio/contratos';
import { ContratosService } from '@app/servicios/ficha-servicio/contratos.service';
import { I18nConfigService } from '../../../../../../../../../projects/spscompspa/src/app/services';
import { DatePipe } from '@angular/common';
import moment from 'moment';
import { FormatterService } from '@app/core/services/formatter.service';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { HttpStatusService } from '@app/core/interceptors';

@Component({
  selector: 'app-dialog-edit-datos-contrato',
  templateUrl: './dialog-edit-datos-contrato.component.html',
  styleUrls: ['./dialog-edit-datos-contrato.component.scss'],
  providers: [DatePipe],
})
export class DialogEditDatosContratoComponent implements OnInit {
  diccionarioKey = DiccionarioKey;

  contrato: ContracteRDTO;

  form: FormGroup = this.fb.group({
    dataInici: ['', Validators.required],
    dataFi: ['', Validators.required],
    durada: ['', Validators.required],
    estatDid: [{value: '', disabled: true}, Validators.required],
    numeroExpedient: ['', Validators.required],
    tipologiaContracteDid: ['', Validators.required],
    importSenseIva: ['', Validators.required],
    importAmbIva: ['', Validators.required],
    capitolDid: ['', Validators.required],
    periodeFacturacioDid: ['', Validators.required],
  });

  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private fb: FormBuilder,
    public i18nConfig: I18nConfigService,
    public i18n: I18n,
    private contratoService: ContratosService,
    public dictionaryQuery: DictionaryQuery,
    private datepipe: DatePipe,
    private formatterService: FormatterService,
    private httpStatusService: HttpStatusService
  ) {}
  ngOnInit() {
    this.contrato = this.config.data;
    this.form.patchValue({
      ...this.contrato,
      dataInici: moment(this.contrato.dataInici, "DD/MM/YYYY").toDate(),
      dataFi: moment(this.contrato.dataFinal, "DD/MM/YYYY").toDate(),
      estatDid: this.dictionaryQuery.getItemDictionaryByKey(
        this.contrato.estatDid,
        this.diccionarioKey.ESTADO_CONTRATO
      ),
    });
  }

  
  calculaDurada() {
    if(this.form.get('dataFi').value != '' && this.form.get('dataFi').value != null && this.form.get('dataInici').value != '' && this.form.get('dataInici').value != null) {
      this.form.patchValue({
        durada:  moment(this.form.get('dataFi').value).add(1, 'month').diff(moment(this.form.get('dataInici').value), 'months')  
      })
      return moment(this.form.get('dataFi').value).add(1, 'month').diff(moment(this.form.get('dataInici').value), 'months');     
    }
    else return  this.i18n({ id: 'sinEspecificar', value: 'Sense especificar' });
  }

  handleGeoLocation() {
    // TODO call service
  }

  closeDialog() {
    this.ref.close();
  }

  onSave() {
    this.form.get('dataFi').setValue(
      this.formatterService.getDateLastDayMonth(this.form.get('dataFi').value)
    )
    const newContrato: ModificaContracteRDTO = {
      ...this.form.value,
      durada: 0,
      dataInici: this.datepipe.transform(
        this.form.get('dataInici').value,
        'dd/MM/yyyy'
      ),
      dataFinal: this.datepipe.transform(
        this.form.get('dataFi').value,
        'dd/MM/yyyy'
      ),
      numeroExpedient: this.form.get('numeroExpedient').value.toUpperCase(),
      capitolDid: this.form.get('capitolDid').value,
    };
    const contracteId = this.contrato.contracteId;
    this.contratoService
      .putContratoById(+contracteId, newContrato)
      .pipe(
        catchError((err) => {
          if (err.status == 404) {
            return of(null);
          } else {
            this.httpStatusService.validationErrors = err;
            return of(null);
          }
        })
      )
      .subscribe((res) => {
        this.ref.close({
          ...newContrato,
          estatDid: this.contrato.estatDid,
          contracteId: res.contracteId,
          numeroExpedient: newContrato.numeroExpedient.toUpperCase(),
        });
      });
  }
}
