import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogResoldreComponent } from './dialog-resoldre.component';

describe('DialogResoldreComponent', () => {
  let component: DialogResoldreComponent;
  let fixture: ComponentFixture<DialogResoldreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogResoldreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogResoldreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
