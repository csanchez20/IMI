import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosAlbaranComponent } from './datos-albaran.component';

describe('DatosAlbaranComponent', () => {
  let component: DatosAlbaranComponent;
  let fixture: ComponentFixture<DatosAlbaranComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatosAlbaranComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatosAlbaranComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
