import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlbaranesEnCursoComponent } from './albaranes-en-curso.component';

describe('AlbaranesEnCursoComponent', () => {
  let component: AlbaranesEnCursoComponent;
  let fixture: ComponentFixture<AlbaranesEnCursoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlbaranesEnCursoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlbaranesEnCursoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
