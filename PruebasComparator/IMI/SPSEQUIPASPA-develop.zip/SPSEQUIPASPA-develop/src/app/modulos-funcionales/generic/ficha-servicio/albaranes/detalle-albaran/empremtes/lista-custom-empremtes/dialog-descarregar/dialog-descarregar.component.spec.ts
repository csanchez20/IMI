import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogDescarregarComponent } from './dialog-descarregar.component';

describe('DialogDescarregarComponent', () => {
  let component: DialogDescarregarComponent;
  let fixture: ComponentFixture<DialogDescarregarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogDescarregarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogDescarregarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
