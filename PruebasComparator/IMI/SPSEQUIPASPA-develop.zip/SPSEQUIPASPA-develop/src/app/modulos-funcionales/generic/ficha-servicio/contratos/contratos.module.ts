import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContratosComponent } from './contratos.component';
import { FiltroContratosComponent } from './filtro-contratos/filtro-contratos.component';
import { DropdownModule, ButtonModule, InputTextModule, DialogModule } from 'primeng/primeng';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { RangeDatePickerModule, AppliedFiltersModule } from '../../../../../../projects/spscompspa/src/public_api';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { SharedModule } from '@app/shared/shared.module';

@NgModule({
  declarations: [
    ContratosComponent,
    FiltroContratosComponent,
  ],
  imports: [
    CommonModule,
    DropdownModule,
    FormsModule,
    ButtonModule,
    InputTextModule,
    TableModule,
    RangeDatePickerModule,
    AppliedFiltersModule,
    ReactiveFormsModule,
    DynamicDialogModule,
    DialogModule,
    DatatableListModule,
    SharedModule
  ],
  exports: [
    ContratosComponent,
    FiltroContratosComponent
  ]
})
export class ContratosModule { }
