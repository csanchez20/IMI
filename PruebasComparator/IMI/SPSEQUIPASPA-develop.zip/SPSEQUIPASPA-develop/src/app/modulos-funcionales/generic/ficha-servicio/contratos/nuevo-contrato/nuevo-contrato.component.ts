import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ProveedoresService } from '@app/servicios';
import { ContracteRDTO } from '@app/core/model/ficha-servicio/contratos';
import { ContratosService } from '@app/servicios/ficha-servicio/contratos.service';
import { DatePipe } from '@angular/common';
import { EmpresaGestoraCentresCercadesRDTO } from '@app/core/model/proveedores';
import { SessionQuery } from '@app/core/auth';
import { FormatterService } from '@app/core/services/formatter.service';
import { stringLiteral } from '@babel/types';
import { Message, MessageService } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { ProveedoresEquipamentsService } from '@app/servicios/proveedores/proveedores-equipaments.service';

@Component({
  selector: 'app-nuevo-contrato',
  templateUrl: './nuevo-contrato.component.html',
  styleUrls: ['./nuevo-contrato.component.scss'],
  providers: [DatePipe],
})
export class NuevoContratoComponent implements OnInit {
  equipamientos: EmpresaGestoraCentresCercadesRDTO[] = [];

  form: FormGroup = this.fb.group({
    dadesContracte: this.fb.group({
      dataFi: ['', Validators.required],
      dataInici: ['', Validators.required],
      estatDid: ['', Validators.required],
      importSenseIva: ['', Validators.required],
      importAmbIva: ['', Validators.required],
      numeroExpedient: ['', Validators.required],
      tipologiaContracteDid: ['', Validators.required],
      capitolDid: ['', Validators.required],
      periodeFacturacioDid: ['', Validators.required],
    }),
    empresaGestoraId: ['', Validators.required],
  });
  errorProveedorSeleccionadoNoPrestaServicio= false;

  isSubmitted = false;

  msgs: Message[];

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private proveedorService: ProveedoresService,
    private proveedoresEquipamentsService: ProveedoresEquipamentsService,
    private contratoService: ContratosService,
    private cd: ChangeDetectorRef,
    private datepipe: DatePipe,
    private sessionQuery: SessionQuery,
    private formatterService: FormatterService,
    private messageService: MessageService,
  ) {}

  ngOnInit() {}

  get dadesContracteForm() {
    return this.form && this.form.get('dadesContracte');
  }

  onSubmit() {
    this.isSubmitted = true;
    if (!this.form.valid) {
      return;
    } else {
      this.postContrato();
    }
  }

  postContrato() {
    this.dadesContracteForm
      .get('dataFi')
      .setValue(
        this.formatterService.getDateLastDayMonth(
          this.dadesContracteForm.get('dataFi').value
        )
      );
    const newContrato: ContracteRDTO = {
      ...this.form.value,
      ...this.dadesContracteForm.value,
      durada: 0,
      dataFinal: this.datepipe.transform(
        this.dadesContracteForm.get('dataFi').value,
        'dd/MM/yyyy'
      ),
      dataInici: this.datepipe.transform(
        this.dadesContracteForm.get('dataInici').value,
        'dd/MM/yyyy'
      ),
      tipusRespostaDid: this.sessionQuery.getServiceActiveValue(),
      numeroExpedient: this.dadesContracteForm
        .get('numeroExpedient')
        .value.toUpperCase(),
    };
    this.contratoService
      .postContrato(newContrato)
      .pipe(
        catchError((res) => {
          console.log('error', res.error);
          return of(null);
        })
      )
      .subscribe((res) => {
        console.log('res', res);
        if (res && res != null) {
          // this.messageService.add({
          //   key: 'success',
          //   severity: 'success',
          //   summary: 'Correcto',
          //   detail: 'Contrato creado correctamente',
          //   // sticky: true
          //   life: 4000,
          // });
          this.router.navigate(['../contrato/' + res.contracteId], {
            relativeTo: this.route,
          });
        }
      });
  }

  empresaGestoraSelected(empresaGestoraId: number) {
    if (empresaGestoraId) {
      this.proveedoresEquipamentsService
        .getEquipamentsByEmpresaGestoraId({
          empresaGestoraId: empresaGestoraId,
          tipusRespostaDid: this.sessionQuery.getServiceActiveValue(),
        })
        .pipe(
          catchError((res) => {
            this.messageService.add({
              key: 'error',
              severity: 'error',
              summary: 'Correcto',
              detail: "El proveïdor escollit per aquest contracte no presta el servei",
              // sticky: true
              life: 4000,
            });
            this.errorProveedorSeleccionadoNoPrestaServicio = true;
            return of(null);
          })
        )
        .subscribe((empresasGestoras) => {
          console.log('empresa', empresasGestoras);
          if (empresasGestoras !== null) {
            this.errorProveedorSeleccionadoNoPrestaServicio = false;
            console.log(
              'empresa gestora id',
              this.form.get('empresaGestoraId').value
            );
            this.form.get('empresaGestoraId').setValue(empresaGestoraId);
            this.equipamientos = empresasGestoras;
          }

          this.cd.markForCheck();
        });
    } else {
      this.form.get('empresaGestoraId').reset();
      this.equipamientos = [];
    }
  }
}
