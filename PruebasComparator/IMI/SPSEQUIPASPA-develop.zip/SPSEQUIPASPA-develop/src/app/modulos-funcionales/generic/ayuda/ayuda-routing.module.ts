import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AyudaEquipamentsComponent } from './ayuda.component';

const routes: Routes = [
  {
    path: '',
    component: AyudaEquipamentsComponent,
    data: {
      breadcrumb: 'Ajuda'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AyudaEquipamentsRoutingModule { }
