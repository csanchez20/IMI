import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { ButtonModule } from 'primeng/button';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DialogService, DialogModule, PanelModule, ChipsModule, MultiSelectModule, MessageModule } from 'primeng/primeng';
import { DynamicDialogModule } from 'primeng/components/dynamicdialog/dynamicdialog';
import { DatosGestionEquipamentsComponent } from './datos-gestion-equipaments.component';
import { DialogEditDatosEquipamentsComponent } from './dialog-edit-datos-equipaments/dialog-edit-datos-equipaments.component';
import { SharedModule } from '@app/shared/shared.module';
import { AyudaContextualModule } from '@app/shared/agrupaciones/ayuda-contextual/ayuda-contextual.module';

@NgModule({
  declarations: [
    DatosGestionEquipamentsComponent,
    DialogEditDatosEquipamentsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MessageModule,
    DatatableListModule,
    DynamicDialogModule,
    DialogModule,
    ButtonModule,
    PanelModule,
    ChipsModule,
    MultiSelectModule,
    AyudaContextualModule,
    SharedModule
  ],
  exports: [
    DatosGestionEquipamentsComponent
  ],
  entryComponents: [
    DialogEditDatosEquipamentsComponent
  ],
  providers: [DialogService]
})
export class DatosGestionEquipamentsModule { }
