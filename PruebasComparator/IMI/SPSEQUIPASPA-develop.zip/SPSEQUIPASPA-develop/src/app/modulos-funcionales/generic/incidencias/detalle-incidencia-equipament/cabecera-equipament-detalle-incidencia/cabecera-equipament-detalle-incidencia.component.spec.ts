import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CabeceraEquipamentDetalleIncidenciaComponent } from './cabecera-equipament-detalle-incidencia.component';

describe('CabeceraEquipamentDetalleIncidenciaComponent', () => {
  let component: CabeceraEquipamentDetalleIncidenciaComponent;
  let fixture: ComponentFixture<CabeceraEquipamentDetalleIncidenciaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CabeceraEquipamentDetalleIncidenciaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CabeceraEquipamentDetalleIncidenciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
