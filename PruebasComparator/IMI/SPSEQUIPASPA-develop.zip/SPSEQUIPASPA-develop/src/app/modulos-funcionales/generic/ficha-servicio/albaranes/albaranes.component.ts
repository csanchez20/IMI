import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-albaranes',
  templateUrl: './albaranes.component.html',
  styleUrls: ['./albaranes.component.scss'],
})
export class AlbaranesComponent implements OnInit {
  constructor() {}
  menuTabSelected = 0;
  ngOnInit() {}

  handleMenuTabChange($event) {
    this.menuTabSelected = $event.index;
  }
}
