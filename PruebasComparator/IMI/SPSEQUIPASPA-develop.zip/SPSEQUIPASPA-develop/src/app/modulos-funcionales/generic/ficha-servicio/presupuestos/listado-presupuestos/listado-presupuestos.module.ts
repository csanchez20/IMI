import { NgModule } from '@angular/core';
import { FiltroPresupuestosComponent } from './filtro-presupuestos/filtro-presupuestos.component';
import { ListadoPresupuestosComponent } from './listado-presupuestos.component';

import { CardModule } from 'primeng/card';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SharedModule } from '@app/shared/shared.module';
import {
  InputTextModule,
  CalendarModule,
  DropdownModule,
  MessageModule,
  AutoCompleteModule,
  CheckboxModule,
} from 'primeng/primeng';
import { DireccionEdicionModule } from '@app/shared/agrupaciones/direccion-edicion/direccion-edicion.module';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { CommonModule } from '@angular/common';
import {
  AppliedFiltersModule,
  RangeDatePickerModule,
  DireccionConsultaModule,
} from '../../../../../../../projects/spscompspa/src/public_api';
import { MomentModule } from 'ngx-moment';
import { DatosProveedorModule } from '../../contratos/datos-proveedor/datos-proveedor.module';
import { ListaPresupuestosComponent } from './lista-presupuestos/lista-presupuestos.component';

@NgModule({
  declarations: [
    FiltroPresupuestosComponent,
    ListadoPresupuestosComponent,
    ListaPresupuestosComponent,
  ],
  imports: [
    AppliedFiltersModule,
    AutoCompleteModule,
    ButtonModule,
    CalendarModule,
    CardModule,
    CheckboxModule,
    CommonModule,
    DatatableListModule,
    DatosProveedorModule,
    DialogModule,
    DireccionConsultaModule,
    DireccionEdicionModule,
    DropdownModule,
    DynamicDialogModule,
    FormsModule,
    InputTextModule,
    MessageModule,
    MomentModule,
    PanelModule,
    RangeDatePickerModule,
    ReactiveFormsModule,
    SharedModule,
    TableModule,
    CommonModule,
  ],
  exports: [ListadoPresupuestosComponent],
})
export class ListadoPresupuestosModule {}
