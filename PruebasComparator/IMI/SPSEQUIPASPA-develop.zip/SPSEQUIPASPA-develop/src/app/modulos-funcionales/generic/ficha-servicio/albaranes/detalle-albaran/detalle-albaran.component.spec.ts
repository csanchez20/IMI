import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleAlbaranComponent } from './detalle-albaran.component';

describe('DetalleAlbaranComponent', () => {
  let component: DetalleAlbaranComponent;
  let fixture: ComponentFixture<DetalleAlbaranComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalleAlbaranComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalleAlbaranComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
