import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroAlbaranesEnCursoComponent } from './filtro-albaranes-en-curso.component';

describe('FiltroAlbaranesEnCursoComponent', () => {
  let component: FiltroAlbaranesEnCursoComponent;
  let fixture: ComponentFixture<FiltroAlbaranesEnCursoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiltroAlbaranesEnCursoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltroAlbaranesEnCursoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
