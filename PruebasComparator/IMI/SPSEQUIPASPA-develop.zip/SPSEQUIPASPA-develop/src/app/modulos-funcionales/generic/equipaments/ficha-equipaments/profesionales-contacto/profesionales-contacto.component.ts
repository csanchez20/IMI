import { Component, OnInit, ChangeDetectorRef, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { InfoItem, TableData, InfoPaginator} from '@app/core/model/information';
import { DialogService } from 'primeng/api';
import { DialogAddeditProfesionalesContactoComponent } from './dialog-addedit-profesionales-contacto/dialog-addedit-profesionales-contacto.component';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { ActivatedRoute } from '@angular/router';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { PersonaContacteRDTO, ParamInEquipament, PersonaContacteCercadesRDTO } from '@app/core/model/equipaments';
import { DialogDetalleProfesionalesContactoComponent } from './dialog-detalle-profesionales-contacto/dialog-detalle-profesionales-contacto.component';
import { map } from 'rxjs/operators';
import { PersonasContactoService } from '@app/servicios/equipaments/personas-contacto.service';

@AutoUnsubscribe()
@Component({
  selector: 'app-profesionales-contacto',
  templateUrl: './profesionales-contacto.component.html',
  styleUrls: ['./profesionales-contacto.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProfesionalesContactoComponent implements OnInit, OnDestroy {
  idEquipament: number;
  cols: any[] = [
    { field: 'nom', header: this.i18n({ id: 'nombre', value: 'Nom' }) },
    {
      field: 'correuElectronic',
      header: this.i18n({ id: 'email', value: 'Correu electrònic' })
    },
    {
      field: 'telefon1',
      header: this.i18n({ id: 'telefono1', value: 'Telèfon 1' })
    },
    {
      field: 'telefon2',
      header: this.i18n({ id: 'telefono2', value: 'Telèfon 2' })
    },
    {
      field: 'acciones',
      header: this.i18n({ id: 'acciones', value: 'Accions' }),
      actionIcons: [
        { icon: 'fa fa-eye', action: 'show' },
        { icon: 'fa fa-pencil', action: 'edit' },
        { icon: 'fa fa-trash', action: 'delete' }
      ]
    }
  ];
  listButtonsTable: InfoItem[] = [
    {
      icon: 'fa fa-plus-circle',
      label: this.i18n({
        id: 'anadirProfesional',
        value: 'Afegir professional de contacte'
      }),
      action: 'add'
    }
  ];
  tableDataProfesionales: TableData;
  params: ParamInEquipament;

  constructor(
    private dialogService: DialogService,
    private cd: ChangeDetectorRef,
    private personasContService: PersonasContactoService,
    private i18n: I18n,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    // Inicializamos solo con los headers para que se muestren mientras se procesa la peticion
    this.tableDataProfesionales = {
      cols: this.cols
    }
    this.idEquipament = this.route.snapshot.params.idEquipament;
    // TODO: Modificar cuando se tenga paginacion en CINTRAOS.
    this.params = {
      centreId: this.idEquipament,
      numeroPagina: 1
      // tamanyPagina: '5',
      // tots: 'true'
    };
    this.updateProfesionalesContacto();
  }

  deleteProfesionalContacto(profesionalContacto: PersonaContacteCercadesRDTO) {
    this.personasContService
      .deletePersonaContactoEquipament(profesionalContacto.id)
      .subscribe(id => {
        if (id) {
          this.updateProfesionalesContacto();
        }
      });
  }

  showDialogAddProfesionalContacto() {
    const ref = this.dialogService.open(
      DialogAddeditProfesionalesContactoComponent,
      {
        header: this.i18n({
          id: 'anadirProfesional',
          value: 'Afegir professional de contacte'
        }),
        data: {
          idEquipament: this.idEquipament
        },
        width: '40%'
      }
    );
    ref.onClose.subscribe(
      (profesionalContacto: Partial<PersonaContacteRDTO>) => {
        if (profesionalContacto) {
          this.updateProfesionalesContacto();
        }
      }
    );
  }

  showDialogEditProfesionalContacto(
    profesionalContacto: PersonaContacteCercadesRDTO
  ) {
    this.personasContService
      .getPersonaContactoEquipament(profesionalContacto.id)
      .subscribe(profesional => {
        const ref = this.dialogService.open(
          DialogAddeditProfesionalesContactoComponent,
          {
            data: {
              idEquipament: this.idEquipament,
              profesional: profesional
            },
            header: this.i18n({
              id: 'modificarProfesional',
              value: 'Modifica professional de contacte'
            }),
            width: '40%'
          }
        );
        ref.onClose.subscribe((pro: PersonaContacteRDTO) => {
          if (pro) {
            this.updateProfesionalesContacto();
          }
        });
      });
  }

  selectProfesionalContacto(profesionalContacto: PersonaContacteCercadesRDTO) {
    this.personasContService
      .getPersonaContactoEquipament(profesionalContacto.id)
      .subscribe(profesional => {
        this.dialogService.open(DialogDetalleProfesionalesContactoComponent, {
          data: profesional,
          header: this.i18n({
            id: 'detalleProfesional',
            value: 'Detall professional de contacte'
          }),
          width: '40%'
        });
      });
  }

  updateProfesionalesContacto() {
    this.personasContService
    .getPersonasContactoEquipament(this.params)
    .pipe(
      map(resPro => {
        return {
          rows: resPro,
          cols: this.cols,
          numeroTotalResultados: resPro.length
        } as TableData;
      })
    ).subscribe(tableDataProfesionales => {
      this.tableDataProfesionales = tableDataProfesionales;
      this.cd.markForCheck();
    });
  }

  changePage(infoPaginator: InfoPaginator) {
    this.params = {
      ...this.params,
      numeroPagina: infoPaginator.numeroPagina,
      tamanyPagina: infoPaginator.tamanyPagina
    };
    this.updateProfesionalesContacto();
  }

  ngOnDestroy() {}
}
