import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FichaEquipamentsComponent } from '@app/modulos-funcionales/generic/equipaments/ficha-equipaments/ficha-equipaments.component';
import { EquipamentsComponent } from './equipaments.component';
import { FichaEquipamentResolverService } from './ficha-equipaments/ficha-equipaments-resolver.service';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: EquipamentsComponent,
      },
      {
        path: ':idEquipament',
        component: FichaEquipamentsComponent,
        resolve: { equipament: FichaEquipamentResolverService },
        data: {
          breadcrumb: 'detalleEquipaments'
        },
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EquipamentsRoutingModule { }
