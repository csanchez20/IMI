import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NuevoContratoComponent } from './nuevo-contrato.component';
import { DatosContratoEdicionComponent } from './datos-contrato-edicion/datos-contrato-edicion.component';
import { DatosProveedorEdicionComponent } from './datos-proveedor-edicion/datos-proveedor-edicion.component';
import { CardModule } from 'primeng/card';
import { PanelModule } from 'primeng/panel';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import {
  InputTextModule,
  CalendarModule,
  DropdownModule,
  AutoCompleteModule,
  DialogModule,
  DialogService,
  MessageModule,
  MessagesModule,
  MessageService,
} from 'primeng/primeng';
import { DireccionConsultaModule } from '../../../../../../../projects/spscompspa/src/public_api';
import { TableModule } from 'primeng/table';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { RelacionesEquipamientosProveedorEdicionComponent } from './relaciones-equipamientos-proveedor-edicion/relaciones-equipamientos-proveedor-edicion.component';
import { DatosProveedorModule } from '../datos-proveedor/datos-proveedor.module';
import { ToastModule } from 'primeng/toast';
import { SharedModule } from '@app/shared/shared.module';

@NgModule({
  declarations: [
    NuevoContratoComponent,
    DatosContratoEdicionComponent,
    DatosProveedorEdicionComponent,
    RelacionesEquipamientosProveedorEdicionComponent,
  ],
  imports: [
    CommonModule,
    CardModule,
    PanelModule,
    FormsModule,
    ButtonModule,
    InputTextModule,
    ReactiveFormsModule,
    CalendarModule,
    DropdownModule,
    AutoCompleteModule,
    DireccionConsultaModule,
    TableModule,
    DialogModule,
    DynamicDialogModule,
    DatosProveedorModule,
    MessageModule,
    ToastModule,
    SharedModule
  ],
  providers: [DialogService],
})
export class NuevoContratoModule {}
