import { Component, OnInit } from '@angular/core';
import { SessionService, UbicacionUI } from '@app/core/auth';

@Component({
  selector: 'app-equipaments',
  templateUrl: './equipaments.component.html',
  styleUrls: ['./equipaments.component.scss']
})
export class EquipamentsComponent implements OnInit {

  constructor(
    private sessionService: SessionService
  ) {}

  ngOnInit() {
    this._setUbicacionUI();
  }

  private _setUbicacionUI() {
    this.sessionService.setUbicacionUI(UbicacionUI.EQUIPAMENTS);
  }

}
