import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogEnviarConTotalComponent } from './dialog-enviar-con-total.component';

describe('DialogEnviarConTotalComponent', () => {
  let component: DialogEnviarConTotalComponent;
  let fixture: ComponentFixture<DialogEnviarConTotalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogEnviarConTotalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogEnviarConTotalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
