import { Component, OnInit } from '@angular/core';
import { DynamicDialogRef } from 'primeng/api';

@Component({
  selector: 'app-dialog-enviar-con-total',
  templateUrl: './dialog-enviar-con-total.component.html',
  styleUrls: ['./dialog-enviar-con-total.component.scss'],
})
export class DialogEnviarConTotalComponent implements OnInit {
  constructor(public ref: DynamicDialogRef) {}

  ngOnInit() {}

  dismiss() {
    this.ref.close(false);
  }
  accept() {
    this.ref.close(true);
  }
}
