import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfesionalesContactoComponent } from './profesionales-contacto.component';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { DialogAddeditProfesionalesContactoComponent } from './dialog-addedit-profesionales-contacto/dialog-addedit-profesionales-contacto.component';
import { ButtonModule } from 'primeng/button';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule, DialogService, InputTextareaModule, MessageModule } from 'primeng/primeng';
import { DynamicDialogModule } from 'primeng/components/dynamicdialog/dynamicdialog';
import { SharedModule } from '@app/shared/shared.module';
import { DialogDetalleProfesionalesContactoComponent } from './dialog-detalle-profesionales-contacto/dialog-detalle-profesionales-contacto.component';

@NgModule({
  declarations: [
    ProfesionalesContactoComponent,
    DialogAddeditProfesionalesContactoComponent,
    DialogDetalleProfesionalesContactoComponent
  ],
  imports: [
    CommonModule,
    DatatableListModule,
    ButtonModule,
    ReactiveFormsModule,
    InputTextModule,
    InputTextareaModule,
    DynamicDialogModule,
    SharedModule,
    MessageModule
  ],
  exports: [
    ProfesionalesContactoComponent
  ],
  entryComponents: [
    DialogAddeditProfesionalesContactoComponent,
    DialogDetalleProfesionalesContactoComponent
  ],
  providers: [DialogService]
})
export class ProfesionalesContactoModule { }
