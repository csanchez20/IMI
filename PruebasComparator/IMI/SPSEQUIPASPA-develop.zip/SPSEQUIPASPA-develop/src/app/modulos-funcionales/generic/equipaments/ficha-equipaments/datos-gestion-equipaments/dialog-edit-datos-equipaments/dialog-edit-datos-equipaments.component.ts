import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef
} from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { DynamicDialogRef, DynamicDialogConfig, SelectItem } from 'primeng/api';
import { CentreggRDTO } from '@app/core/model/equipaments';
import { EquipamentsService } from '@app/servicios/equipaments/equipaments.service';
import { SessionQuery } from '@app/core/auth';
import { SERVICIO_SAUV } from '@app/core/model/servicio';

@Component({
  selector: 'app-dialog-edit-datos-equipaments',
  templateUrl: './dialog-edit-datos-equipaments.component.html',
  styleUrls: ['./dialog-edit-datos-equipaments.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DialogEditDatosEquipamentsComponent implements OnInit {
  datosGestionEquipaments: CentreggRDTO;
  caracteristicasActivas: SelectItem[];
  listCaractEquipDisponibles: Array<SelectItem>;
  idEquipament;
  isSauv: boolean;
  form: FormGroup = this.fb.group(
    {
      caracteristiques: [''],
      codiReferencia: [''],
      placesTotal: ['', [Validators.min(0)]],
      placesLliures: ['', [Validators.min(0)]],
      placesLliuresDona: ['', [Validators.required, Validators.min(0)]],
      placesLliuresHome: ['', [Validators.required, Validators.min(0)]],
      placesLliuresIndiferent: ['', [Validators.required, Validators.min(0)]],
      previsioPlacesLliuresHome: ['', [Validators.min(0)]],
      previsioPlacesLliuresDona: ['', [Validators.min(0)]],
      previsioPlacesLliuresIndiferent: ['', [Validators.min(0)]],
      prioritat: ['', Validators.min(0)]
    },
    // { validator: this.checkNumPlazasLibreLTNumTotal }
  );

  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private fb: FormBuilder,
    private service: EquipamentsService,
    public sessionQuery: SessionQuery,
    private cd: ChangeDetectorRef
  ) {}

  checkNumPlazasLibreLTNumTotal(group: FormGroup) {
    const total = group.get('placesTotal').value;
    const libres = group.get('placesLliures').value;
    return total >= libres ? null : { invalidPlazasLibres: true };
  }

  ngOnInit() {
    // Obtener datos del paso de parametros al dialog
    this.listCaractEquipDisponibles = this.config.data.listaCarac;
    this.caracteristicasActivas = this.config.data.caracActivas;
    this.datosGestionEquipaments = this.config.data.datos;
    this.idEquipament = this.config.data.idEquipament;
    // Incializar formulario
    this.form.patchValue(this.datosGestionEquipaments);
    this.form.get('caracteristiques').setValue(this.caracteristicasActivas);

    this.sessionQuery.service$.subscribe(service => {
      service === SERVICIO_SAUV
        ? (this.isSauv = true)
        : (this.isSauv = false);
      this._checkValidatorByService();
      this.cd.markForCheck();
    });
  }

  onSaveDatosEquipaments(): void {
    this.form.get('caracteristiques').setValue(
      this.form.get('caracteristiques').value.map(caracteristica => {
        return caracteristica.value;
      })
    );
    this.service
      .putDatosGestionEquipament(this.idEquipament, this.form.value)
      .subscribe(data => {
        const eq: CentreggRDTO = {
          ...this.form.value,
          centreId: data.centreggId,
          respostaDid: this.datosGestionEquipaments.respostaDid,
          actiu: this.datosGestionEquipaments.actiu,
          dataModificacio: new Date()
        };
        this.ref.close(eq);
      });
  }

  closeDialog() {
    this.ref.close();
  }

  isValidForm(): boolean {
    return this.form.valid;
  }

  private _checkValidatorByService() {
    if (this.isSauv) {
      this.form.get('previsioPlacesLliuresHome').setValidators(Validators.required);
      this.form.get('previsioPlacesLliuresDona').setValidators(Validators.required);
      this.form.get('previsioPlacesLliuresIndiferent').setValidators(Validators.required);
    } else {
      this.form.setValidators(this.checkNumPlazasLibreLTNumTotal);
      this.form.get('placesTotal').setValidators(Validators.required);
      this.form.get('placesLliures').setValidators(Validators.required);
    }
  }
}
