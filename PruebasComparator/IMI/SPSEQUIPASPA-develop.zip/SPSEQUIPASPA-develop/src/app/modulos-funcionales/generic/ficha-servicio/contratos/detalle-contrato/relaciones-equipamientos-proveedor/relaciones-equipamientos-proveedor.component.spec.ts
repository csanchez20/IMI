import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RelacionesEquipamientosProveedorComponent } from './relaciones-equipamientos-proveedor.component';

describe('RelacionesEquipamientosProveedorComponent', () => {
  let component: RelacionesEquipamientosProveedorComponent;
  let fixture: ComponentFixture<RelacionesEquipamientosProveedorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RelacionesEquipamientosProveedorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RelacionesEquipamientosProveedorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
