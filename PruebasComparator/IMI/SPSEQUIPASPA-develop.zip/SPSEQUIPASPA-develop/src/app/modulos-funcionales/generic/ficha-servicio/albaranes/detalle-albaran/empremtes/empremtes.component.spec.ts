import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpremtesComponent } from './empremtes.component';

describe('EmpremtesComponent', () => {
  let component: EmpremtesComponent;
  let fixture: ComponentFixture<EmpremtesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpremtesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpremtesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
