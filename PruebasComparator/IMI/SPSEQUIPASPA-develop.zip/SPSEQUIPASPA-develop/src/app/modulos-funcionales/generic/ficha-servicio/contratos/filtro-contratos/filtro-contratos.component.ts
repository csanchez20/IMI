import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { FiltersService } from '@app/core/services';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { FormGroup, FormBuilder } from '@angular/forms';
import { I18nConfigService } from '../../../../../../../projects/spscompspa/src/app/services';
import { DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';
import moment from 'moment';
@Component({
  selector: 'app-filtro-contratos',
  templateUrl: './filtro-contratos.component.html',
  styleUrls: ['./filtro-contratos.component.scss'],
})
export class FiltroContratosComponent extends FiltersService implements OnInit {
  @Output() selectedFilters: EventEmitter<any> = new EventEmitter<any>();

  diccionarioKey = DiccionarioKey;

  fechaInicioContrato: string = this.i18n({
    id: 'fechaInicioContrato',
    value: 'Data inici contracte',
  });
  fechaFinalContrato: string = this.i18n({
    id: 'fechaFinalContrato',
    value: 'Data fi contracte',
  });

  labels: string[] = [
    this.i18n({ id: 'fechaInicioContrato', value: 'Data inici contracte' }),
    this.i18n({ id: 'fechaFinalContrato', value: 'Data fi contracte' }),
    this.i18n({ id: 'numeroReferencia', value: 'Núm. Referència' }),
    this.i18n({ id: 'proveedor', value: 'Proveïdor' }),
    this.i18n({ id: 'estado', value: 'Estat' }),
  ];

  form: FormGroup = this.fb.group({
    dataInici: [''],
    dataFi: [''],
    numeroExpedient: [''],
    nomComercial: [''],
    estatDid: [''],
  });

  dataOutput: any[] = [];
  dataToAppliedFilters: any[] = [];

  constructor(
    private i18n: I18n,
    public i18nConfig: I18nConfigService,
    private fb: FormBuilder,
    public dictionaryQuery: DictionaryQuery
  ) {
    super();
  }

  ngOnInit() {}

  onActivateFilters() {
    /* this.dataOutput = this.whenActivateFilters(this.form);
    this.dataToAppliedFilters = this.whenActivateFiltersToAppliedFilters(this.form);
    this.selectedFilters.emit(this.parseToParams(this.dataOutput, 'dataInici', 'dataFinal')); */
    const formFilters: FormGroup = this.fb.group({
      dataInici: [''],
      dataFi: [''],
      numeroExpedient: [''],
      nomComercial: [''],
      estatDid: [''],
    });
    formFilters.patchValue({
      ...this.form.value,
      dataFi: this.form.get('dataFi').value
        ? moment(this.form.get('dataFi').value).endOf('month').toDate()
        : null,
    });
    this.dataOutput = this.whenActivateFilters(this.parseDates(this.form));
    this.dataToAppliedFilters = this.whenActivateFiltersToAppliedFilters(
      formFilters
    );
    this.selectedFilters.emit(
      this.parseToParams(this.dataOutput, 'dataInici', 'dataFinal')
    );
  }

  setFields(outputData: any) {
    this.whenSetFields(this.form, outputData);
  }

  setResetFilters() {
    this.whenSetResetFields(this.form);
  }

  parseDates(form: FormGroup): FormGroup {
    let formAux: FormGroup = this.fb.group({
      dataInici: [''],
      dataFinal: [''],
      numeroExpedient: [''],
      nomComercial: [''],
      estatDid: [''],
    });

    formAux.patchValue({
      numeroExpedient: form.get('numeroExpedient').value,
      nomComercial: form.get('nomComercial').value,
      estatDid: form.get('estatDid').value,
      dataInici: form.get('dataInici').value
        ? moment(form.get('dataInici').value).format('DD/MM/YYYY')
        : null,
      dataFinal: form.get('dataFi').value
        ? moment(form.get('dataFi').value).endOf('month').format('DD/MM/YYYY')
        : null,
    });
    console.log('formAux', formAux);
    return formAux;
  }
}
