import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListDetallePresupuestoComponent } from './list-detalle-presupuesto.component';

describe('ListDetallePresupuestoComponent', () => {
  let component: ListDetallePresupuestoComponent;
  let fixture: ComponentFixture<ListDetallePresupuestoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListDetallePresupuestoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListDetallePresupuestoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
