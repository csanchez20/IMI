import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ContracteRDTO } from '@app/core/model/ficha-servicio/contratos';
import { EmpresaGestoraRDTO, EmpresaGestoraCentresCercadesRDTO, EmpresaGestoraServeisCentresCercadesRDTO } from '@app/core/model/proveedores';
import { DataDocumentacionEntidad, TIPUS_ENTIDAD_CONTRACTE } from '@app/shared/agrupaciones/documentacion-general/documentacion-general.component';

@Component({
  selector: 'app-detalle-contrato',
  templateUrl: './detalle-contrato.component.html',
  styleUrls: ['./detalle-contrato.component.scss'],
})
export class DetalleContratoComponent implements OnInit {
  contrato: ContracteRDTO;
  empresaGestora: EmpresaGestoraRDTO;
  serviciosContratoEmpresa: EmpresaGestoraServeisCentresCercadesRDTO[];
  equipamientos: EmpresaGestoraCentresCercadesRDTO[];
  dataDocEntidad: DataDocumentacionEntidad;

  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    this.contrato = this.route.snapshot.data['contratoRes'].contrato;
    console.log(this.contrato);
    this.empresaGestora = this.route.snapshot.data[
      'contratoRes'
    ].empresaGestora;
    this.serviciosContratoEmpresa = this.route.snapshot.data[
      'contratoRes'
    ].serviciosContratoEmpresa;
    this.equipamientos = this.route.snapshot.data['contratoRes'].equipamientos;
    this.dataDocEntidad = {
      entitatId: ''+this.contrato.contracteId,
      tipusEntitatDid: TIPUS_ENTIDAD_CONTRACTE
    }
  }

  download(contrato) {}
}
