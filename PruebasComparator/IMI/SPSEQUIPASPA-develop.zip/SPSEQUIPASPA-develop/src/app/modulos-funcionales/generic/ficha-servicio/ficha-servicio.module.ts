import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '@app/shared/shared.module';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import {
  ButtonModule,
  CardModule,
  DropdownModule,
  TabViewModule,
} from 'primeng/primeng';
import { TableModule } from 'primeng/table';

import { ContratosModule } from './contratos/contratos.module';
import { DetalleContratoModule } from './contratos/detalle-contrato/detalle-contrato.module';
import { NuevoContratoModule } from './contratos/nuevo-contrato/nuevo-contrato.module';
import { FichaServicioRoutingModule } from './ficha-servicio-routing.module';
import { FichaServicioComponent } from './ficha-servicio.component';
import { PresupuestosModule } from './presupuestos/presupuestos.module';
import { NuevoPresupuestoModule } from './presupuestos/nuevo-presupuesto/nuevo-presupuesto.module';
import { DetallePresupuestoModule } from './presupuestos/detalle-presupuesto/detalle-presupuesto.module';
import { AlbaranesModule } from './albaranes/albaranes.module';

@NgModule({
  declarations: [FichaServicioComponent],
  imports: [
    CommonModule,
    FichaServicioRoutingModule,
    DetalleContratoModule,
    ContratosModule,
    TabViewModule,
    CardModule,
    NuevoContratoModule,
    TableModule,
    ReactiveFormsModule,
    DropdownModule,
    SharedModule,
    ButtonModule,
    InputTextModule,
    PanelModule,
    PresupuestosModule,
    NuevoPresupuestoModule,
    AlbaranesModule,
  ],
  exports: [FichaServicioComponent],
})
export class FichaServicioModule {}
