import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { FiltersService } from '@app/core/services';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { FormGroup, FormBuilder } from '@angular/forms';
import { DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';
import { I18nConfigService } from '../../../../../../../../projects/spscompspa/src/app/services';
import { InfoItem } from '@app/core/model';
import moment from 'moment';
import { SessionQuery } from '@app/core/auth';
@Component({
  selector: 'app-filtro-presupuestos',
  templateUrl: './filtro-presupuestos.component.html',
  styleUrls: ['./filtro-presupuestos.component.scss'],
})
export class FiltroPresupuestosComponent
  extends FiltersService
  implements OnInit {
  @Output() selectedFilters: EventEmitter<any> = new EventEmitter<any>();

  form: FormGroup = this.fb.group({
    dataInici: [''],
    dataFi: [''],
    vigent: [''],
  });

  aplicarFiltres: string = this.i18n({
    id: 'buscar',
    value: 'Buscar',
  });

  //sps-applied-filters
  dataToAppliedFilters: any[] = [];

  labelsAppliedFilters: string[] = [
    this.i18n({ id: 'fechaInicio', value: 'Data inici' }),
    this.i18n({ id: 'fechaFinal', value: 'Data fi' }),
    //this.i18n({ id: 'vigente', value: 'Núm. Referència' }),
  ];

  constructor(
    private i18n: I18n,
    private fb: FormBuilder,
    public dictionaryQuery: DictionaryQuery,
    private sessionQuery: SessionQuery,
    public i18nConfig: I18nConfigService
  ) {
    super();
  }

  ngOnInit() {
    this.form.patchValue({ vigent: true });
  }

  onActivateFilters() {
    let formFilters = this.fb.group({
      dataInici: [''],
      dataFi: [''],
    });
    formFilters.patchValue({
      ...this.form.value,
      dataFi: this.form.get('dataFi').value
        ? moment(this.form.get('dataFi').value).endOf('month').toDate()
        : null,
    });
    const dataOutput = {};
    console.log(dataOutput);
    this.dataToAppliedFilters = this.whenActivateFiltersToAppliedFilters(
      formFilters
    );

    this.selectedFilters.emit(this.form.value);
  }

  setFields(outputData: any) {
    this.whenSetFields(this.form, outputData);
  }

  setResetFilters() {
    this.whenSetResetFields(this.form);
  }
}
