import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { PresupuestosComponent } from './presupuestos.component';
import { ListadoPresupuestosComponent } from './listado-presupuestos/listado-presupuestos.component';
import { DetallePresupuestoComponent } from './detalle-presupuesto/detalle-presupuesto.component';
import { NuevoPresupuestoComponent } from './nuevo-presupuesto/nuevo-presupuesto.component';
import { ButtonModule } from 'primeng/button';
import {
  InputTextModule,
  CalendarModule,
  DropdownModule,
  AutoCompleteModule,
  DialogModule,
  DialogService,
  MessageModule,
  MessagesModule,
} from 'primeng/primeng';
import { SharedModule } from '@app/shared/shared.module';
import { TableModule } from 'primeng/table';

import { CardModule } from 'primeng/card';
import { PanelModule } from 'primeng/panel';
import { DialogEditDatosPresupuestoComponent } from './detalle-presupuesto/dialog-edit-datos-presupuesto/dialog-edit-datos-presupuesto.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DetallePresupuestoModule } from './detalle-presupuesto/detalle-presupuesto.module';
import { ListadoPresupuestosModule } from './listado-presupuestos/listado-presupuestos.module';
@NgModule({
  declarations: [PresupuestosComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CardModule,
    PanelModule,
    ButtonModule,
    InputTextModule,
    CalendarModule,
    DropdownModule,
    AutoCompleteModule,
    TableModule,
    DialogModule,
    MessageModule,
    SharedModule,
    DetallePresupuestoModule,
    ListadoPresupuestosModule,
  ],
  providers: [DatePipe],
  exports: [PresupuestosComponent],
  entryComponents: [DialogEditDatosPresupuestoComponent],
})
export class PresupuestosModule {}
