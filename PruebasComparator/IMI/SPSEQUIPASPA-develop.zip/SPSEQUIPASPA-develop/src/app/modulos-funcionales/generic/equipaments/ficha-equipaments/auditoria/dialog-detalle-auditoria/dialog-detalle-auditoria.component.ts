import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { AuditoriaRDTO } from '@app/core/model/equipaments';
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/api';
import * as FileSaver from 'file-saver';
import { GeneralService } from '@app/core/services';
import { DocumentacionCintraosService } from '@app/servicios/equipaments/documentacion-cintraos.service';
import { HttpStatusService } from '@app/core/interceptors';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { ButonGestionDocumental } from '@app/shared/agrupaciones/boton-multifuncion-gestion-documentos/boton-multifuncion-gestion-documentos.component';

@Component({
  selector: 'app-dialog-detalle-auditoria',
  templateUrl: './dialog-detalle-auditoria.component.html',
  styleUrls: ['./dialog-detalle-auditoria.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DialogDetalleAuditoriaComponent implements OnInit {

  auditoria: AuditoriaRDTO;
  documentoAuditoria: ButonGestionDocumental;

  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    public generalService: GeneralService
  ) { }

  ngOnInit() {
    this.auditoria = this.config.data;
    this.documentoAuditoria = {
      documentId: this.auditoria.document
        ? this.auditoria.document
        : null
    }
  }

  closeDialog() {
    this.ref.close();
  }

}
