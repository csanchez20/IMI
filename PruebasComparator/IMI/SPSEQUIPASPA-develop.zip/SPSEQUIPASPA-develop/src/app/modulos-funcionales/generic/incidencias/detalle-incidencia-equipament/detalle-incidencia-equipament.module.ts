import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DetalleIncidenciaEquipamentComponent } from './detalle-incidencia-equipament.component';
import { CabeceraEquipamentDetalleIncidenciaComponent } from './cabecera-equipament-detalle-incidencia/cabecera-equipament-detalle-incidencia.component';
import { DetalleConsultaIncidenciaModule } from '../detalle-incidencia/detalle-consulta-incidencia/detalle-consulta-incidencia.module';
import { DocumentosConsultaIncidenciaModule } from '../detalle-incidencia/documentos-consulta-incidencia/documentos-consulta-incidencia.module';
import { DialogEditDetalleIncidenciaComponent } from '../detalle-incidencia/detalle-consulta-incidencia/dialog-edit-detalle-incidencia/dialog-edit-detalle-incidencia.component';

@NgModule({
  declarations: [
    DetalleIncidenciaEquipamentComponent,
    CabeceraEquipamentDetalleIncidenciaComponent
  ],
  imports: [
    CommonModule,
    DetalleConsultaIncidenciaModule,
    DocumentosConsultaIncidenciaModule
  ],
  bootstrap: [DetalleIncidenciaEquipamentComponent],
  entryComponents: [DialogEditDetalleIncidenciaComponent]
})
export class DetalleIncidenciaEquipamentModule { }
