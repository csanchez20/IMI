import { Component, OnInit, ChangeDetectorRef, Input, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { DialogEditDatosEquipamentsComponent } from './dialog-edit-datos-equipaments/dialog-edit-datos-equipaments.component';
import { DialogService, SelectItem } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { CentreggRDTO } from '@app/core/model/equipaments';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { DictionaryService, DictionaryQuery } from '@app/core/dictionary/state';
import { ActivatedRoute } from '@angular/router';
import { SessionQuery } from '@app/core/auth';
import { SERVICIO_SAUV } from '@app/core/model/servicio';
import { RecursosService } from '@app/servicios';

@AutoUnsubscribe()
@Component({
  selector: 'app-datos-gestion-equipaments',
  templateUrl: './datos-gestion-equipaments.component.html',
  styleUrls: ['./datos-gestion-equipaments.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DatosGestionEquipamentsComponent implements OnInit, OnDestroy {
  @Input() datosEquipament: CentreggRDTO;
  caracteristicasActivas: SelectItem[];
  listCaractEquipDisponibles: Array<SelectItem>;
  lastUpdate: string;
  caracteristicas$ = this.dictionaryQuery.caracteristicas$;
  isSauv: boolean;

  constructor(
    private cd: ChangeDetectorRef,
    private dialogService: DialogService,
    private i18n: I18n,
    private dictionaryService: DictionaryService,
    public dictionaryQuery: DictionaryQuery,
    private route: ActivatedRoute,
    public sessionQuery: SessionQuery,
    private recursosSerive: RecursosService
  ) {}

  ngOnInit() {
    // nos suscribimos para saber cuando las tenemos
    this.caracteristicas$.subscribe(carac => {
      if (carac) {
        this.listCaractEquipDisponibles = carac;
        this.caracteristicasActivas = this.transformaCaracteristicas(
          this.datosEquipament.caracteristiques
        );
        this.cd.markForCheck();
      }
    });
    // nos suscribimos al servicio activo para mostrar unos datos u otros
    this.sessionQuery.service$.subscribe(service => {
      service === SERVICIO_SAUV
        ? (this.isSauv = true)
        : (this.isSauv = false);
      this.cd.markForCheck();
    });

    this.lastUpdate = this.recursosSerive.actualizaUltimaModificacion(this.datosEquipament.dataModificacio);
  }

  showDialogEditDatosEquipaments() {
    const ref = this.dialogService.open(DialogEditDatosEquipamentsComponent, {
      data: {
        datos: this.datosEquipament,
        caracActivas: this.caracteristicasActivas,
        listaCarac: this.listCaractEquipDisponibles,
        idEquipament: this.route.snapshot.params.idEquipament
      },
      header: this.i18n({
        id: 'editarDatosEquipaments',
        value: 'Editar dades equipaments'
      }),
      width: '60%'
    });

    ref.onClose.subscribe((datosEquipament: CentreggRDTO) => {
      if (datosEquipament) {
        this.datosEquipament = datosEquipament;
        console.log(this.datosEquipament.dataModificacio)
        this.lastUpdate = this.recursosSerive.actualizaUltimaModificacion(this.datosEquipament.dataModificacio);
        console.log(this.lastUpdate)
        this.caracteristicasActivas = this.transformaCaracteristicas(
          this.datosEquipament.caracteristiques
        );
        this.cd.markForCheck();
      }
    });
  }

  // Transforma las características a SelectItem, asociandolas a la característica correspondiente
  transformaCaracteristicas(caracteristicas: number[]) {
    return (
      caracteristicas &&
      caracteristicas
        .map(caracteristica =>
          this.listCaractEquipDisponibles.find(c => caracteristica === c.value)
        )
        .filter(value => value)
    );
  }



  ngOnDestroy() {}
}
