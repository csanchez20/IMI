import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroPresupuestosComponent } from './filtro-presupuestos.component';

describe('FiltroPresupuestosComponent', () => {
  let component: FiltroPresupuestosComponent;
  let fixture: ComponentFixture<FiltroPresupuestosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiltroPresupuestosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltroPresupuestosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
