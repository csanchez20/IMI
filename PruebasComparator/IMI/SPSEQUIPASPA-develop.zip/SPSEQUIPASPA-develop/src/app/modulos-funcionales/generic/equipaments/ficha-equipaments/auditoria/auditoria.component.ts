import { Component, OnInit, OnDestroy, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { InfoItem, TableData, InfoPaginator } from '@app/core/model/information';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { DialogService } from 'primeng/api';
import { ActivatedRoute } from '@angular/router';
import { SessionQuery } from '@app/core/auth';
import { DialogAddAuditoriaComponent } from './dialog-add-auditoria/dialog-add-auditoria.component';
import { AuditoriaRDTO, ParamInEquipament, AuditoriaCercadesRDTO } from '@app/core/model/equipaments';
import { DialogDetalleAuditoriaComponent } from './dialog-detalle-auditoria/dialog-detalle-auditoria.component';
import { map } from 'rxjs/operators';
import { AuditoriaService } from '@app/servicios/equipaments/auditoria.service';
import { GeneralService } from '@app/core/services';
import { DocumentacionCintraosService } from '@app/servicios/equipaments/documentacion-cintraos.service';

@AutoUnsubscribe()
@Component({
  selector: 'app-auditoria',
  templateUrl: './auditoria.component.html',
  styleUrls: ['./auditoria.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AuditoriaComponent implements OnInit, OnDestroy {
  idEquipament: number;
  tableDataAuditorias: TableData;
  params: ParamInEquipament;

  listButtonsTable: InfoItem[] = [
    {
      icon: 'pi pi-plus-circle',
      label: this.i18n({ id: 'nuevaAuditoria', value: 'Nova auditoria' }),
      action: 'add'
    }
  ];

  cols: InfoItem[] = [
    {
      field: 'dataAuditoria',
      header: this.i18n({ id: 'dataAuditoria', value: "Data de l'auditoria" }),
      type: 'date'
    },
    { field: 'tipus', header: this.i18n({ id: 'tipo', value: 'Tipus' }) },
    {
      field: 'nomProfessionalDocument',
      header: this.i18n({ id: 'profesional', value: 'Professional' })
    },
    {
      field: 'acciones',
      header: this.i18n({ id: 'acciones', value: 'Accions' }),
      actionIcons: [
        { icon: 'fa fa-eye', action: 'show' },
        {
          icon: 'fa fa-pencil',
          action: 'edit',
          fieldIdOwner: 'idProfessionalDocument'
        },
        {
          icon: 'fa fa-trash',
          action: 'delete',
          fieldIdOwner: 'idProfessionalDocument'
        }
      ]
    }
  ];

  constructor(
    public auditoriaService: AuditoriaService,
    public generalService: GeneralService,
    private i18n: I18n,
    private dialogService: DialogService,
    private cd: ChangeDetectorRef,
    private route: ActivatedRoute,
    private documentacionCintraosService: DocumentacionCintraosService,
    public sessionQuery: SessionQuery,
  ) {}

  ngOnInit() {
    // Inicializamos solo con los headers para que se muestren mientras se procesa la peticion
    this.tableDataAuditorias = {
      cols: this.cols
    }
    this.idEquipament = this.route.snapshot.params.idEquipament;
    // TODO: Modificar cuando se tenga paginacion en CINTRAOS.
    this.params = {
      centreId: this.idEquipament,
      numeroPagina: 1
      // tamanyPagina: '5',
      // tots: 'true'
    };
    this.updateAuditorias();
  }

  openDialogAddAuditoria() {
    const ref = this.dialogService.open(DialogAddAuditoriaComponent, {
      header: this.i18n({ id: 'anadirAuditoria', value: 'Afegir auditoria' }),
      width: '40%',
      data: {
        idEquipament: this.idEquipament
      }
    });

    ref.onClose.subscribe((auditoria: AuditoriaRDTO) => {
      if (auditoria) {
        this.updateAuditorias();
      }
    });
  }

  openDialogEditAuditoria(auditoria: AuditoriaRDTO) {
    this.auditoriaService
      .getAuditoriaEquipament(auditoria.id)
      .subscribe(aud => {
        const ref = this.dialogService.open(DialogAddAuditoriaComponent, {
          data: {
            idEquipament: this.idEquipament,
            auditoria: aud
          },
          header: this.i18n({
            id: 'modificarAuditoria',
            value: 'Modifica auditoria'
          }),
          width: '40%'
        });
        ref.onClose.subscribe((data: AuditoriaRDTO) => {
          if (data) {
            this.updateAuditorias();
          }
        });
      });
  }

  deleteAuditoria(auditoria: AuditoriaCercadesRDTO) {
    this.auditoriaService
      .getAuditoriaEquipament(auditoria.id)
      .subscribe(aud => {
        this.auditoriaService.eliminarAuditoria(auditoria.id).subscribe(id => {
          this._deleteDocumentCintraosAuditoria(aud.document);
          this.updateAuditorias();
        });
      })
  }

  private _deleteDocumentCintraosAuditoria(documentId: string) {
    if (documentId !== null) {
      this.documentacionCintraosService.deleteDocument(documentId).subscribe();
    }
  }

  selectAuditoria(auditoria: AuditoriaCercadesRDTO) {
    this.auditoriaService
      .getAuditoriaEquipament(auditoria.id)
      .subscribe(aud => {
        this.dialogService.open(DialogDetalleAuditoriaComponent, {
          header: this.i18n({
            id: 'detalleAuditoria',
            value: 'Detall auditoria'
          }),
          width: '40%',
          data: aud
        });
      });
  }

  updateAuditorias() {
    this._setLoading(true);
    this.auditoriaService
      .getAuditoriasEquipament(this.params)
      .pipe(
        map(resAud => {
          return {
            rows: resAud,
            cols: this.cols,
            numeroTotalResultados: resAud.length
          } as TableData;
        })
      ).subscribe(tableDataInspecciones => {
        this.tableDataAuditorias = tableDataInspecciones;
        if(this.tableDataAuditorias['rows'] && this.tableDataAuditorias['rows'].length>0 ){
          for(let row of this.tableDataAuditorias['rows']){
            row['nomProfessionalDocument']=row['nomProfessionalDocument'].split('null').join('');
          }
        }
        this.cd.markForCheck();
      });
  }  

  changePage(infoPaginator: InfoPaginator) {
    this.params = {
      ...this.params,
      numeroPagina: infoPaginator.numeroPagina,
      tamanyPagina: infoPaginator.tamanyPagina
    };
    this.updateAuditorias();
  }

  private _setLoading(loading: boolean) {
    this.tableDataAuditorias = {
      ...this.tableDataAuditorias,
      loading: loading,
      rows: null,
    };
  }

  ngOnDestroy() {}
}
