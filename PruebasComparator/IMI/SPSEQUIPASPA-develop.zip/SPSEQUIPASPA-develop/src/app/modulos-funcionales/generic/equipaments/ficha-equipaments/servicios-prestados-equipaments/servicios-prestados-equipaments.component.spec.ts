import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiciosPrestadosEquipamentsComponent } from './servicios-prestados-equipaments.component';

describe('ServiciosPrestadosEquipamentsComponent', () => {
  let component: ServiciosPrestadosEquipamentsComponent;
  let fixture: ComponentFixture<ServiciosPrestadosEquipamentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiciosPrestadosEquipamentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiciosPrestadosEquipamentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
