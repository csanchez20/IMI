import { Component, OnInit } from '@angular/core';
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/api';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { I18nConfigService } from '../../../../../../../../projects/spscompspa/src/app/services';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { ContratosService } from '@app/servicios/ficha-servicio/contratos.service';
import { DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';
import { DatePipe } from '@angular/common';
import { FormatterService } from '@app/core/services/formatter.service';
import { RespuestaPresupuesto, EditarPresupuesto } from '@app/core/model';
import { PresupuestosService } from '@app/servicios/ficha-servicio/presupuestos.service';
import moment from 'moment';
import { catchError } from 'rxjs/operators';
import { HttpStatusService } from '@app/core/interceptors';
import { of } from 'rxjs';

@Component({
  selector: 'app-dialog-edit-datos-presupuesto',
  templateUrl: './dialog-edit-datos-presupuesto.component.html',
  styleUrls: ['./dialog-edit-datos-presupuesto.component.scss'],
})
export class DialogEditDatosPresupuestoComponent implements OnInit {
  presupuesto: RespuestaPresupuesto;
  initialDropdownValue = 'Seleccionar';
  minDate: Date;
  form: FormGroup = this.fb.group({
    dataFi: ['', Validators.required],
    partidaInicial: ['', Validators.required],
    periodeFacturacioDid: ['', Validators.required],
  });
  diccionarioKey = DiccionarioKey;
  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private fb: FormBuilder,
    public i18nConfig: I18nConfigService,
    public i18n: I18n,
    private presupuestosService: PresupuestosService,
    public dictionaryQuery: DictionaryQuery,
    private datepipe: DatePipe,
    private formatterService: FormatterService,
    private httpStatusService: HttpStatusService
  ) {}

  ngOnInit() {
    this.setMinDate();
    this.presupuesto = this.config.data;
    this.form.patchValue({
      ...this.presupuesto,
      dataFi: moment(this.presupuesto.dataFi).toDate(),
      periodeFacturacioDid: { value: this.presupuesto.periodeFacturacioDid },
    });
    this.initialDropdownValue = this.dictionaryQuery.getItemDictionaryByKey(
      this.presupuesto.periodeFacturacioDid,
      this.diccionarioKey.PERIODOS_FACTURACION_PRESUPUESTARIOS
    );
  }
  closeDialog() {
    this.ref.close();
  }
  dropDownSelected(event) {
    /*     this.form.patchValue({
      periodeFacturacioDid: event.value.value,
    }); */
  }

  onSave() {
    const editarPresupuesto: EditarPresupuesto = {
      ...this.form.value,
      dataFi: this.form.get('dataFi').value
        ? moment(this.form.get('dataFi').value).endOf('month').format()
        : null,
      periodeFacturacioDid: this.form.get('periodeFacturacioDid').value[
        'value'
      ],
    };
    this.presupuestosService
      .putPresupuesto(this.presupuesto.pressupostServeiId, editarPresupuesto)
      .pipe(
        catchError((err) => {
          if (err.status == 404) {
            return of(null);
          } else {
            this.httpStatusService.validationErrors = err;
            return of(null);
          }
        })
      )
      .subscribe((res) => {
        if (res) this.ref.close(res);
      });
  }

  setMinDate(){
    let today = new Date();
    let nextMonth = new Date();
    nextMonth.setMonth(today.getMonth() + 1);
    this.minDate = nextMonth;
  }
}
