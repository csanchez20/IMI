import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemListaAlbaranesEnRegularizacionComponent } from './item-lista-albaranes-en-regularizacion.component';

describe('ItemListaAlbaranesEnRegularizacionComponent', () => {
  let component: ItemListaAlbaranesEnRegularizacionComponent;
  let fixture: ComponentFixture<ItemListaAlbaranesEnRegularizacionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItemListaAlbaranesEnRegularizacionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemListaAlbaranesEnRegularizacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
