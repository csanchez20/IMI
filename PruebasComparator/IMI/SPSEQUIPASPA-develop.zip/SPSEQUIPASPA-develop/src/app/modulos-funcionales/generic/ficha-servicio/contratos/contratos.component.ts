import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionQuery, SessionService, UbicacionUI } from '@app/core/auth';
import { DiccionarioKey, DictionaryService } from '@app/core/dictionary/state';
import { HttpStatusService } from '@app/core/interceptors';
import { ParamsCercaContracte } from '@app/core/model/ficha-servicio/contratos';
import { InfoItem, TableData } from '@app/core/model/information';
import { ContratosService, PaginacionContratos } from '@app/servicios/ficha-servicio/contratos.service';
import { I18n } from '@ngx-translate/i18n-polyfill';
import moment from 'moment';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { DialogService } from 'primeng/api';
import { of, Subscription } from 'rxjs';
import { catchError } from 'rxjs/operators';

@AutoUnsubscribe()
@Component({
  selector: 'app-contratos',
  templateUrl: './contratos.component.html',
  styleUrls: ['./contratos.component.scss'],
  providers: [DialogService, DatePipe],
  encapsulation: ViewEncapsulation.None,
})
export class ContratosComponent implements OnInit, OnDestroy {
  dictionary: any;

  diccionarioKey = DiccionarioKey;

  contratos: TableData;
  cols: InfoItem[] = [
    {
      field: 'numeroExpedient',
      header: this.i18n({ id: 'numeroReferencia', value: 'Núm. Referència' }),
    },
    {
      field: 'dataInici',
      header: this.i18n({ id: 'fechaInicio', value: 'Data inici' }),
    },
    {
      field: 'dataFinal',
      header: this.i18n({ id: 'fechaFinal', value: 'Data fi' }),
    },
    {
      field: 'nomComercial',
      header: this.i18n({ id: 'proveedor', value: 'Proveïdor' }),
    },
    {
      field: 'estatDid',
      header: this.i18n({ id: 'estado', value: 'Estat' }),
      type: 'dictionary',
      typeKey: this.diccionarioKey.ESTADO_CONTRATO,
    },
  ];

  listButtonsTable: InfoItem[] = [
    {
      icon: 'pi pi-plus-circle',
      label: this.i18n({ id: 'nuevoContrato', value: 'Nou contracte' }),
      action: 'add',
    },
    {
      action: 'export',
      label: moment(new Date()).format('DD/MM/YYYY') + '_Llistat_contractes',
    },
  ];

  showFilters = false;
  numRows = 5;

  filtersApplied: any = {};

  private sub: Subscription;

  constructor(
    private i18n: I18n,
    private contratoService: ContratosService,
    private sessionQuery: SessionQuery,
    private sessionService: SessionService,
    private dictionaryService: DictionaryService,
    private router: Router,
    private route: ActivatedRoute,
    private cd: ChangeDetectorRef,
    private httpStatusService: HttpStatusService
  ) {}

  ngOnInit() {

    this._setUbicacionUI();
    this._resetFilters();
    this._saveContratosToTable(null);

    this.dictionaryService.getEstadosContrato().subscribe((dictionary) => {
      this.dictionary = dictionary;
    });
  }

  getContratos(params: ParamsCercaContracte) {
    this._setLoading(true);
    this.sub = this.contratoService
      .getContratos(params)
      .pipe(
        catchError((err) => {
          this._setLoading(false);
          if (err.status === 404) {
            return of({
              llistaContracteCercadesTotalRDTO: [],
              totalRegistres: 0,
            });
          } else {
            this.httpStatusService.validationErrors = err;
          }
        })
      )
      .subscribe((contratos) => {
        this._saveContratosToTable(contratos);
        this.cd.markForCheck();
      });
  }

  private _saveContratosToTable(contratos: PaginacionContratos) {
    this.contratos = {
      cols: this.cols,
      rows: contratos
        ? contratos.llistaContracteCercadesTotalRDTO === null
          ? []
          : contratos.llistaContracteCercadesTotalRDTO
        : null,
      numRowsPerPage: this.numRows,
      numeroTotalResultados: contratos ? contratos.totalRegistres : 0,
      loading: false,
    };
  }

  searchByIndex(numeroExpedient: string) {
    this._resetFilters();
    this.getContratos(
      this.setParams({
        numeroExpedient: numeroExpedient,
      })
    );
  }

  handleFilters(data: ParamsCercaContracte) {
    console.log('ParamsCercaContracte', data);
    this._resetFilters();
    this.getContratos(this.setParams(data));
  }

  handleSelectedRow(rowSelected: any) {
    this.viewContrato(rowSelected.data.contracteId);
  }

  viewContrato(contracteId: number) {
    this.router.navigate(['./contrato/' + contracteId], {
      relativeTo: this.route,
    });
  }

  nuevoContracto() {
    this.router.navigate(['./nuevoContrato/'], { relativeTo: this.route });
  }

  paginator(event) {
    this.contratos.numRowsPerPage = event.tamanyPagina;
    this.getContratos(this.setParams(this._getTamanoPaginaMapped(event)));
  }

  onLazyLoad(event) {
    if (event && event.tamanyPagina) {
      this.getContratos({
        ...this.setParams(this._getTamanoPaginaMapped(event)),
      });
    }
  }

  setParams(params: ParamsCercaContracte) {
    this.filtersApplied = {
      ...this.filtersApplied,
      ...params,
    };
    return this.filtersApplied;
  }

  private _getTamanoPaginaMapped(params) {
    this.numRows = params.tamanyPagina;
    params['tamanoPagina'] = params.tamanyPagina;
    delete params['tamanyPagina'];
    return params;
  }

  private _resetFilters() {
    this.filtersApplied = {
      ...new ParamsCercaContracte(
        this.sessionQuery.getServiceActiveValue(),
        this.filtersApplied.tamanoPagina
      ),
    };
  }

  private _setLoading(loading: boolean) {
    this.contratos = {
      ...this.contratos,
      loading: loading,
      rows: null,
    };
  }

  private _setUbicacionUI() {
    this.sessionService.setUbicacionUI(UbicacionUI.CONTRACTES);
  }

  ngOnDestroy() { }

}
