import { Component, OnInit, ViewChild } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
import html2canvas from 'html2canvas';

import h2c from 'html2canvas'
import { DireccionService, UsuariosService } from '@app/servicios';
import { UserService } from '@app/modulos-funcionales/generic/usuarios/state';
import { map, switchMap, tap } from 'rxjs/operators';
import { forkJoin, of } from 'rxjs';
import { DiccionarioKey, DictionaryQuery, DictionaryService } from '@app/core/dictionary/state';
import { FormatterService } from '@app/core/services/formatter.service';
import { PlazasService } from '@app/servicios/solicitudes/plazas.service';
import { ConsultaAdrecaRDTO, PersonaMibPadroResDTO } from '@app/core/model';
/* import 'jspdf-autotable'
import jspdf from 'jspdf'; */
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { NullTemplateVisitor } from '@angular/compiler';
@Component({
  selector: 'app-dialog-descarregar',
  templateUrl: './dialog-descarregar.component.html',
  styleUrls: ['./dialog-descarregar.component.scss'],
  providers: [FormatterService]
})
export class DialogDescarregarComponent implements OnInit {
  @ViewChild('pdf') pdf;
  datosUsuario;
  prova = 'dw'
  user;
  address;
  direccionPadron;
  dadesRebudes = false;
  diccionarioKey = DiccionarioKey;
  constructor( public ref: DynamicDialogRef, private userService: UserService, private plazasService: PlazasService, private formatterService: FormatterService, private dictionaryService: DictionaryService,  public dictionaryQuery: DictionaryQuery, public config: DynamicDialogConfig,  public usuarioService: UsuariosService, private direccionService: DireccionService,) { }

  ngOnInit() {
   
    const expedientId = this.config.data['expedientId'];
    this.repDades( expedientId).subscribe((datosUsuario) => {
      
      this.user = datosUsuario.usuario.usuario;
      this.address = datosUsuario.usuario.direccion
      this.direccionPadron = datosUsuario.usuario.direccionPadron;
      console.log('user: ', this.user)
      this.dadesRebudes = true;
      setTimeout(() => {
        this.descarregaPdf(expedientId);
      }, 1000)
      
    })

  }

  repDades(expedientId) {
    
    return forkJoin({
      d1: this.dictionaryService.getEstadosSolicitud_SAUV(),
      d2: this.dictionaryService.getEstadosSolicitud_RESPIR(),
      d3: this.dictionaryService.getEstadosSolicitud_RESPIRPLUS(),
      d4: this.dictionaryService.getEstadosFactura_RESPIRPLUS(),
      d5: this.dictionaryService.getEstadosSolicitud_GUARDAMOBLES(),
      d6: this.dictionaryService.getTipoDocumentos(),
      d7: this.dictionaryService.getGeneros(),
      d8: this.dictionaryService.getPaises(),
      d9: this.dictionaryService.getEstadosCiviles(),
      d10: this.dictionaryService.getIdiomas(),
      d11: this.dictionaryService.getPBA(),
      d12: this.dictionaryService.getDistrictes(),
      d14: this.dictionaryService.getTiposTratamiento(),
      d15: this.dictionaryService.getTiposVia(),
      d17: this.dictionaryService.getGradosPev(),
      usuario: this.usuarioService.getUsuarioByExpediente(expedientId).pipe(
        tap((usuario) => {
          if (usuario) {
            // guardar usuario activo
            this.userService.setUserActive({
              id: 3,
              name: usuario.blocBasiques.cognom2
                ? usuario.blocBasiques.nom +
                  ' ' +
                  usuario.blocBasiques.cognom1 +
                  ' ' +
                  usuario.blocBasiques.cognom2
                : usuario.blocBasiques.nom + ' ' + usuario.blocBasiques.cognom1,
            });
          }
        }),
        switchMap((usuario) => {
          return this.direccionService.isPadronActivo().pipe(
            switchMap((active) => {
              return forkJoin({
                usuario: of(usuario),
                direccion: this.direccionService.getDireccionUsuarioByUbicacionId(
                  this.direccionService.getDireccionHabitual(usuario)
                ),
                direccionPadron: this.direccionService.getDireccionPadronByDocument(
                  usuario.blocBasiques.document,
                  usuario.blocBasiques.tipusDocumentDid,
                  active
                ).pipe(switchMap((padron) => {
                  return of(this.transformarPadrondADireccion(padron));
                })),
              });
            })
          );
        }) 
      )       
    })
  }

  transformarPadrondADireccion(padron: PersonaMibPadroResDTO): ConsultaAdrecaRDTO {
    if(padron && padron['llistaPersones'].length>0){
      padron=padron['llistaPersones'][0];
      return {
        esForaBarcelona: false,
        adrTipusVia: padron.tipusVia,
        adrNomCarrer: padron.nomVia,
        adrNum1: padron.numIni?(+padron.numIni).toString():null,
        adrNum2: padron.numFi === padron.numIni?null:(+padron.numFi).toString(),
        adrPPis: padron.pis,
        adrMunicipi: padron.poblacio?padron.poblacio.replace(/[0-9]/g, ''):null,
        adrPPorta: padron.porta,
        adrDistricte: padron.districte,
        adrEscala: padron.escala,
        adrLletra1: padron.lletraIni,
        adrLletra2: padron.lletraFi,
        adrCP:padron.codiPostal,
        adrAPDescr:padron.descripcioAdreca
      };
    }else return null;
  }
  getAdrecaToString(direccion: ConsultaAdrecaRDTO) {
    return this.formatterService.getAdrecaToString(direccion);
  }

  descarregaPdf(nomDocument) {
    let doc = new  jsPDF();
    doc.text("Dades personals", 15, 17);
    (doc as any).autoTable({ html: '#dadesPersonals1', startY: 22, });
    (doc as any).autoTable({ html: '#dadesPersonals2' });
    (doc as any).autoTable({ html: '#dadesPersonals3' });
    doc.text("Ubicació", 15, 95);
    (doc as any).autoTable({ html: '#ubicacio', startY: 100, });
    doc.save(nomDocument)
    this.ref.close();
  }

}
