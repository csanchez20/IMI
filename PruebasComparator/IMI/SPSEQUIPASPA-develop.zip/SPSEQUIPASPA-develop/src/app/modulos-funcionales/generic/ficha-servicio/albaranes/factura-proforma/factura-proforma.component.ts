import { Component, OnInit } from '@angular/core';
import { FiltrosFacturasProforma } from '@app/core/model/ficha-servicio/facturasProforma';
@Component({
  selector: 'app-factura-proforma',
  templateUrl: './factura-proforma.component.html',
  styleUrls: ['./factura-proforma.component.scss']
})
export class FacturaProformaComponent implements OnInit {

  filtros: FiltrosFacturasProforma;
  showList = false;

  constructor() {}

  ngOnInit() {}
  
  selectedFilters(event: FiltrosFacturasProforma) {
    this.filtros = event;
  }
}