import { Component, OnInit, Input, OnChanges, ChangeDetectorRef, Output, EventEmitter, ViewChild } from '@angular/core';
import { I18n } from '@ngx-translate/i18n-polyfill';
import {
  ConsultaEmpremtes,
  FiltrosEmpremtas,
  InfoItem,
  ItemEmpremta,

} from '@app/core/model';
import {
  DictionaryQuery,
  DiccionarioKey,
  DictionaryService,
} from '@app/core/dictionary/state';
import { SelectItem, DialogService } from 'primeng/api';
import { FormatterService } from '@app/core/services/formatter.service';
import { SessionQuery } from '@app/core/auth';
import moment from 'moment';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import { DialogRegularizarComponent } from './dialog-regularizar/dialog-regularizar.component';
import { ChangeDetectionStrategy } from '@angular/core/src/render3/jit/compiler_facade_interface';


import { DialogDescarregarComponent } from './dialog-descarregar/dialog-descarregar.component';
import { DialogResoldreComponent } from './dialog-resoldre/dialog-resoldre.component';
@Component({
  selector: 'app-lista-custom-empremtes',
  templateUrl: './lista-custom-empremtes.component.html',
  styleUrls: ['./lista-custom-empremtes.component.scss'],
})
export class ListaCustomEmpremtesComponent implements OnInit, OnChanges {
  @Input() filtres: FiltrosEmpremtas;
  @Input() editable: boolean;
  @Output() empremtaRegularitzada = new EventEmitter();

  dictionaryServicios: any;
  diccionarioKey = DiccionarioKey;
  empremtes: ItemEmpremta[] = [];
  numeroPagina = 1;
  numero: number = 5;
  numeros: SelectItem[] = [
    { label: '5', value: 5 },
    { label: '10', value: 10 },
    { label: '20', value: 20 },
    { label: '50', value: 50 },
    { label: '100', value: 100 },
  ];
  totalRegistres = 0;
  cols: InfoItem[] = [
    {
      field: 'nomComplet',
      header: this.i18n({ id: 'nom', value: 'Nom' }),
    },
    {
      field: 'expedientId',
      header: this.i18n({ id: 'codiExpedient', value: 'Codi expedient' }),
    },
    {
      field: 'tipusServeiDid',
      header: this.i18n({ id: 'concepte', value: 'Concepte' }),
      type: 'dictionary',
      typeKey: this.diccionarioKey.SERVICIOS_PRESTADOS,
    },
    // {
    //   field: 'dataInici',
    //   header: this.i18n({ id: 'dataInici', value: 'Data inici' }),
    //   type: 'date',
    // },
    // {
    //   field: 'dataFi',
    //   header: this.i18n({ id: 'dataFi', value: 'Data fi' }),
    //   type: 'date',
    // },
    {
      field: 'teIncidencia',
      header: this.i18n({ id: 'teIncidencia', value: 'Té incidència' }),
      type: 'booleanText',
    },
    {
      field: 'esRegularitzacio',
      header: this.i18n({ id: 'regularització', value: 'Regularització' }),
      type: 'booleanText',
    },
    {
      field: 'numUnitats',
      header: this.i18n({ id: 'unitats', value: 'Unitats' }),
    },
    {
      field: 'importTotal',
      header: this.i18n({ id: 'importAmbIva', value: 'Import amb iva' }),
      type: 'currency',
    },
    {
      field: 'importSenseIva',
      header: this.i18n({ id: 'importSenseIva', value: 'Import sense iva' }),
      type: 'currency',
    },
    {
      field: 'acciones',
      header: this.i18n({ id: 'acciones', value: 'Accions' }),
    },
  ];

  constructor(
    private i18n: I18n,
    private sessionQuery: SessionQuery,
    private albaranesService: AlbaranesService,
    private dialogService: DialogService,
    private dictionaryService: DictionaryService,
    public dictionaryQuery: DictionaryQuery,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.dictionaryService.getServiciosPrestados().subscribe((dictionary) => {
      this.dictionaryServicios = dictionary;
    });
  }

  ngOnChanges() {
    if (this.filtres) {
      this.getEmpremtes();
    }
  }
 

  getEmpremtes() {
    const consultaEmpremtes: ConsultaEmpremtes = {
      ...this.filtres,
      teIncidencia: this.filtres.teIncidencia['value'],
      tipusRespostaDid: this.sessionQuery.getServiceActiveValue(),
      estatEmpremtaDid: 2990602,
      // dataInici: this.filtres.dataInici
      //   ? moment(this.filtres.dataInici).format()
      //   : null,
      // dataFi: this.filtres.dataFi
      //   ? moment(this.filtres.dataFi).endOf('month').format()
      //   : null,
      tamanoPagina: this.numero,
      numeroPagina: this.numeroPagina,
    };
    this.albaranesService.getEmpremtes(consultaEmpremtes).subscribe((res) => {
      this.empremtes = res.llistaResultatsCercaEmpremtaRDTO.map((empremta) => {
        return {
          ...empremta,
          nomComplet:empremta.cognom2?
              empremta.nom + ' ' + empremta.cognom1 + ' ' + empremta.cognom2:
              empremta.nom + ' ' + empremta.cognom1 + ' ',
          importSenseIva: empremta.importTotal / (1 + empremta.iva / 100),
        };
      });
      this.totalRegistres = res.totalRegistres;
    });
  }

  updateNumberOfEntries() {
    this.getEmpremtes();
  }

  accion(event) {
    console.log('accion', event);
  }

  booleanText(value: boolean) {
    return FormatterService.textBoolean(value);
  }

  regularitzar(rowData) {
    const ref = this.dialogService.open(DialogRegularizarComponent, {
      header: this.i18n({ id: 'regularizar', value: 'Regulartizar' }),
      width: '40%',
      data: { empremta: rowData },
    });

    ref.onClose.subscribe((res) => {
      this.getEmpremtes();
      this.empremtaRegularitzada.emit();
      if (res) {
        
        console.log(res);
      }
    });
  }

  openDialogDescarregar(rowData) {
    const ref = this.dialogService.open(DialogDescarregarComponent, {
      header: this.i18n({ id: 'Descargando', value: 'Descarregant' }),
      
      data: { expedientId: rowData.expedientId },
    });

    ref.onClose.subscribe((res) => {
      this.getEmpremtes();
      this.empremtaRegularitzada.emit();
      if (res) {
        
        console.log(res);
      }
    });
  }

  enviarResoldre(rowData) {
      const ref = this.dialogService.open(DialogResoldreComponent, {
        header: this.i18n({ id: 'resolver', value: 'Resoldre' }),
        width: '40%',
        data: { empremta: rowData },
      });
      ref.onClose.subscribe((data: boolean) => {
        console.log('rebut')
      });

      ref.onClose.subscribe((res) => {
        this.getEmpremtes();
        this.empremtaRegularitzada.emit();
        if (res) {
          
          console.log(res);
        }
      });
  }
/*   download(divId) {
      const doc = new jsPDF();

      const specialElementHandlers = {
        '#editor': function (element, renderer) {
          return true;
        }
      };

      const pdfTable = this.pdfTable.nativeElement;

      doc.fromHTML(pdfTable.innerHTML, 15, 15, {
        width: 190,
        'elementHandlers': specialElementHandlers
      });

      doc.save('tableToPdf.pdf');
  } */
}
