import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaFacturasProformaComponent } from './lista-facturas-proforma.component';

describe('ListaFacturasProformaComponent', () => {
  let component: ListaFacturasProformaComponent;
  let fixture: ComponentFixture<ListaFacturasProformaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaFacturasProformaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaFacturasProformaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
