import { Component, OnInit } from '@angular/core';
import { ItemEmpremta } from '@app/core/model';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import { DynamicDialogConfig, DynamicDialogRef, MessageService } from 'primeng/api';
import { of } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-dialog-resoldre',
  templateUrl: './dialog-resoldre.component.html',
  styleUrls: ['./dialog-resoldre.component.scss']
})
export class DialogResoldreComponent implements OnInit {

  constructor(public ref: DynamicDialogRef, public config: DynamicDialogConfig, private messageService: MessageService, private albaranesService: AlbaranesService,) { }
  empremta: ItemEmpremta;
  ngOnInit() {
    this.empremta = this.config.data['empremta'];
  }

  closeDialog() {
    this.ref.close();
  }

  resoldreEmpremta() {
    
    this.albaranesService
      .resoldreEmpremta(this.empremta.empremtaId)
      .pipe(
        catchError((err) => {
          console.log(err);
          this.messageService.add({
            severity: 'error',
            summary: err.message,
          });
          return of(null);
        })
      )
      .subscribe((res) => {
        if  (res !== null)  {
          console.log(res);
          this.messageService.add({
            severity: 'success',
            summary: 'Empremta resolta',
          });
          this.ref.close();
        }
        
      });
  }

}
