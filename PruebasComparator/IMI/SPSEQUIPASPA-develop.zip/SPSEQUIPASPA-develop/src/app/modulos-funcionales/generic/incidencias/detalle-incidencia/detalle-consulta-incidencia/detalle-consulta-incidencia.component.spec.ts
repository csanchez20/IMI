import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleConsultaIncidenciaComponent } from './detalle-consulta-incidencia.component';

describe('DetalleConsultaIncidenciaComponent', () => {
  let component: DetalleConsultaIncidenciaComponent;
  let fixture: ComponentFixture<DetalleConsultaIncidenciaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalleConsultaIncidenciaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalleConsultaIncidenciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
