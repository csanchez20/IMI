import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogEditDatosContratoComponent } from './dialog-edit-datos-contrato.component';

describe('DialogEditDatosContratoComponent', () => {
  let component: DialogEditDatosContratoComponent;
  let fixture: ComponentFixture<DialogEditDatosContratoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogEditDatosContratoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogEditDatosContratoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
