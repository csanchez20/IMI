import { Component, OnInit, Output, EventEmitter } from '@angular/core';

import { FiltersService } from '@app/core/services';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-buscador-empremtes',
  templateUrl: './buscador-empremtes.component.html',
  styleUrls: ['./buscador-empremtes.component.scss'],
})
export class BuscadorEmpremtesComponent implements OnInit {
  @Output() filtresActivats = new EventEmitter();
  showFilters = true;
  form: FormGroup = this.fb.group({
    tipusRespostaDid: [''],
    // dataInici: [''],
    // dataFi: [''],
    // campGoogle: [''],
    expedientId: [''],
    nomComplet: [''],
    document: [''],
    tipusServeiDid: [''],
    teIncidencia: [''],
    tamanoPagina: [''],
    numeroPagina: [''],
    albaraId: ['']
  });
  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute
    ) {}

  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      const albaraId = +params.get('albaranId');
      this.form.patchValue({albaraId: albaraId});
    });
  }

  handleFilters() {
    console.log('form', this.form.value);
    this.filtresActivats.emit(this.form.value);
  }

  // handleBusqueda() {
  //   console.log('form', this.form.value);
  //   this.filtresActivats.emit(this.form.value);
  // }
}
