import { Component, OnInit, OnChanges, Input, ViewChild } from '@angular/core';
import {
  FiltrosAlbaranes,
  ConsultaAlbaranes,
  ResultadoConsultaPresupuestos,
  ResultadoCercaAlbaranes,
  ItemCercaAlbaran,
} from '@app/core/model';
import { SessionQuery } from '@app/core/auth';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import moment from 'moment';
import { Paginator, SelectItem } from 'primeng/primeng';
@Component({
  selector: 'app-lista-albaranes-en-regularizacion',
  templateUrl: './lista-albaranes-en-regularizacion.component.html',
  styleUrls: ['./lista-albaranes-en-regularizacion.component.scss'],
})
export class ListaAlbaranesEnRegularizacionComponent
  implements OnInit, OnChanges {
    @Input() filtros: FiltrosAlbaranes;
    @ViewChild('paginator') paginator: Paginator;
  
    albaranes: ResultadoCercaAlbaranes;
    albaranesPaginated: ItemCercaAlbaran[];
    numeros: SelectItem[] = [
      { label: '5', value: 5 },
      { label: '10', value: 10 },
      { label: '20', value: 20 },
      { label: '50', value: 50 },
      { label: '100', value: 100 },
    ];
    tamanoPagina = 10;
    numeroPagina = 1;
    constructor(
      private sessionQuery: SessionQuery,
      private albaranesService: AlbaranesService
    ) {}
  
    ngOnInit() {}
  
    ngOnChanges() {
      this.getAlbaranes();
    }
  

  getAlbaranes() {
    console.log('filtros', this.filtros);
    if (this.filtros) {
      const consultaAlbaranes: ConsultaAlbaranes = {
        empresaGestoraId: this.filtros.empresa
          ? this.filtros.empresa['empresaGestoraId']
          : null,
        tipusRespostaDid: this.sessionQuery.getServiceActiveValue(),
        dataInici: this.filtros.dataInici
          ? moment(this.filtros.dataInici).format()
          : null,
        dataFi: this.filtros.dataFi
          ? moment(this.filtros.dataFi).endOf('month').format()
          : null,
        teRegularitzacio: true,
        teFacturaProforma: false,
        teIncidencia: this.filtros.teIncidencia['value'],
        tamanoPagina: this.tamanoPagina ? this.tamanoPagina : null,
        numeroPagina: this.numeroPagina ? this.numeroPagina : null,
      };
      console.log('consultaAlbaranesRegularitzacio', consultaAlbaranes);
      this.albaranesService.getAlbaranes(consultaAlbaranes).subscribe((res) => {
        this.albaranes = res;
      });
    }
  }

  
  eventNumeroAlbaranesPorPagina(event) {
    this.tamanoPagina =  event.value;
    this.numeroPagina = 1;
    this.paginator.changePage(0);
    this.getAlbaranes();
  }

  eventCambioDePagina(event) {
    this.numeroPagina = event.page+1;
    this.getAlbaranes();
  }

  

}
