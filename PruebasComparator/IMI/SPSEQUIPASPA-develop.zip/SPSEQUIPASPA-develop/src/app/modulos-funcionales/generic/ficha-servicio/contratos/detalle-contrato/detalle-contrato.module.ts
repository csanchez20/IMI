import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DetalleContratoComponent } from './detalle-contrato.component';
import { CardModule } from 'primeng/card';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { DatosContratoComponent } from './datos-contrato/datos-contrato.component';
import { DialogModule } from 'primeng/dialog';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SharedModule } from '@app/shared/shared.module';
import { InputTextModule, CalendarModule, DropdownModule, MessageModule } from 'primeng/primeng';
import { DireccionEdicionModule } from '@app/shared/agrupaciones/direccion-edicion/direccion-edicion.module';
import { DialogEditDatosContratoComponent } from './datos-contrato/dialog-edit-datos-contrato/dialog-edit-datos-contrato.component';
import { RelacionesEquipamientosProveedorComponent } from './relaciones-equipamientos-proveedor/relaciones-equipamientos-proveedor.component';
import { DialogEditEquipamientoProveedorComponent } from './relaciones-equipamientos-proveedor/dialog-edit-equipamiento-proveedor/dialog-edit-equipamiento-proveedor.component';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { DatosProveedorModule } from '../datos-proveedor/datos-proveedor.module';
import { DocumentacionGeneralModule } from '@app/shared/agrupaciones/documentacion-general/documentacion-general.module';

@NgModule({
  declarations: [
    DetalleContratoComponent, 
    DatosContratoComponent, 
    RelacionesEquipamientosProveedorComponent,
    DialogEditDatosContratoComponent,
    DialogEditEquipamientoProveedorComponent
  ],
  imports: [
    CommonModule,
    CardModule,
    PanelModule,
    TableModule,
    DialogModule,
    DynamicDialogModule,
    FormsModule,
    ButtonModule,
    SharedModule,
    InputTextModule,
    DireccionEdicionModule,
    ReactiveFormsModule,
    CalendarModule,
    DropdownModule,
    DatatableListModule,
    DatosProveedorModule,
    MessageModule,
    DocumentacionGeneralModule
  ],
  entryComponents: [
    DialogEditDatosContratoComponent,
    DialogEditEquipamientoProveedorComponent
  ]
})
export class DetalleContratoModule { }
