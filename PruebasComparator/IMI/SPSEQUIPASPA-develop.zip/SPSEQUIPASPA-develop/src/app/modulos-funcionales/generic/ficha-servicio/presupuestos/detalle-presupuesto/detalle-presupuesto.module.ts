import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { DialogEditDatosPresupuestoComponent } from './dialog-edit-datos-presupuesto/dialog-edit-datos-presupuesto.component';

import { CardModule } from 'primeng/card';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SharedModule } from '@app/shared/shared.module';
import {
  InputTextModule,
  CalendarModule,
  DropdownModule,
  MessageModule,
} from 'primeng/primeng';
import { DireccionEdicionModule } from '@app/shared/agrupaciones/direccion-edicion/direccion-edicion.module';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { DetallePresupuestoComponent } from './detalle-presupuesto.component';
import { ListDetallePresupuestoComponent } from './list-detalle-presupuesto/list-detalle-presupuesto.component';
import { RangeDatePickerModule } from '../../../../../../../projects/spscompspa/src/public_api';

@NgModule({
  declarations: [
    DialogEditDatosPresupuestoComponent,
    DetallePresupuestoComponent,
    ListDetallePresupuestoComponent,
  ],
  imports: [
    CommonModule,
    CardModule,
    PanelModule,
    TableModule,
    DialogModule,
    DynamicDialogModule,
    FormsModule,
    ButtonModule,
    SharedModule,
    InputTextModule,
    DireccionEdicionModule,
    ReactiveFormsModule,
    CalendarModule,
    DropdownModule,
    DatatableListModule,
    MessageModule,
    RangeDatePickerModule,
  ],
  entryComponents: [DialogEditDatosPresupuestoComponent],
  providers: [DatePipe],
})
export class DetallePresupuestoModule {}
