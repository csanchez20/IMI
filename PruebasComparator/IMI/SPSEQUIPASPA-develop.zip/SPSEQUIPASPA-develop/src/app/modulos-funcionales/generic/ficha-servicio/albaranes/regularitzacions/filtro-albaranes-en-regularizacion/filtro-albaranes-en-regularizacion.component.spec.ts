import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroAlbaranesEnRegularizacionComponent } from './filtro-albaranes-en-regularizacion.component';

describe('FiltroAlbaranesEnRegularizacionComponent', () => {
  let component: FiltroAlbaranesEnRegularizacionComponent;
  let fixture: ComponentFixture<FiltroAlbaranesEnRegularizacionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiltroAlbaranesEnRegularizacionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltroAlbaranesEnRegularizacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
