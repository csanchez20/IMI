import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogRegularizarComponent } from './dialog-regularizar.component';

describe('DialogRegularizarComponent', () => {
  let component: DialogRegularizarComponent;
  let fixture: ComponentFixture<DialogRegularizarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogRegularizarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogRegularizarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
