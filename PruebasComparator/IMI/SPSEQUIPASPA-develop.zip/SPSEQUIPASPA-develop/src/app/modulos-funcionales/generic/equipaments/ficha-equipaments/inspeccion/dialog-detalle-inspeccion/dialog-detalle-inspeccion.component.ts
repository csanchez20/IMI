import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { DynamicDialogRef, DynamicDialogConfig, SelectItem } from 'primeng/api';
import { EquipamentsService } from '@app/servicios/equipaments/equipaments.service';
import * as FileSaver from 'file-saver';
import { GeneralService } from '@app/core/services';
import { InspeccioRDTO } from '@app/core/model/equipaments';
import { ButonGestionDocumental } from '@app/shared/agrupaciones/boton-multifuncion-gestion-documentos/boton-multifuncion-gestion-documentos.component';

@Component({
  selector: 'app-dialog-detalle-inspeccion',
  templateUrl: './dialog-detalle-inspeccion.component.html',
  styleUrls: ['./dialog-detalle-inspeccion.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DialogDetalleInspeccionComponent implements OnInit {
  inspeccion: InspeccioRDTO;
  tipoInspeccion: SelectItem;
  documentoInspeccion: ButonGestionDocumental;

  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    public equipamentsService: EquipamentsService,
    public generalService: GeneralService
  ) { }

  ngOnInit() {
    this.inspeccion = this.config.data.inspeccion;
    this.tipoInspeccion = this.config.data.tipoInspeccion;
    this.documentoInspeccion = {
      documentId: this.inspeccion.document
        ? this.inspeccion.document
        : null
    }
  }

  closeDialog() {
    this.ref.close();
  }

}
