import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { PersonaServicio } from '@app/core/model/servicio';
import { SessionQuery } from '@app/core/auth';

@Component({
  selector: 'app-ficha-servicio',
  templateUrl: './ficha-servicio.component.html',
  styleUrls: ['./ficha-servicio.component.scss']
})
export class FichaServicioComponent implements OnInit {

  prescriptors = ['CSS', 'SADEP', 'Salut', 'CAP'];

  constructor(
    public sessionQuery: SessionQuery
    ) { }

  ngOnInit() {}

  showContractes() {
    return !this.sessionQuery.isServiceRespirPlus();
  }

}
