import { Component, OnInit, Input, Output } from '@angular/core';
import {
  FiltrosFacturasProforma,
  RespuestaCercaFacturasProforma,
  CercaFacturasProforma,
  ItemLlistaCercaFacturesProforma,
} from '@app/core/model/ficha-servicio/facturasProforma';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { InfoItem, ResultatCercaDocumentRDTO, TableData } from '@app/core/model';
import { SessionQuery } from '@app/core/auth';
import moment from 'moment';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { HttpStatusService } from '@app/core/interceptors';
import { DialogRegularitzarFacturaComponent } from './dialog-regularitzar-factura/dialog-regularitzar-factura.component';
import { DialogService } from 'primeng/api';
import { Router } from '@angular/router';
@Component({
  selector: 'app-lista-facturas-proforma',
  templateUrl: './lista-facturas-proforma.component.html',
  styleUrls: ['./lista-facturas-proforma.component.scss'],
})
export class ListaFacturasProformaComponent implements OnInit {
  @Input() filtros: FiltrosFacturasProforma;
  facturasProforma: RespuestaCercaFacturasProforma;
  facturasProformaTableData: TableData;
  numRows = 10;
  
  private cols: InfoItem[] = [
    {
      field: 'facturaProformaId',
      header: this.i18n({ id: 'id', value: 'id' }),
    },
    {
      field: 'dataInici',
      header: this.i18n({ id: 'dataInici', value: 'Data inici' }),
      type: 'date',
    },
    {
      field: 'dataFi',
      header: this.i18n({ id: 'dataFinal', value: 'Data fi' }),
      type: 'date',
    },
    {
      field: 'nomEmpresaGestora',
      header: this.i18n({ id: 'EmpresaGestora', value: 'Empresa Gestora' }),
    },
    {
      field: 'nomCentre',
      header: this.i18n({ id: 'NombreCentro', value: 'Centre' }),
    },
    {
      field: 'importPrevistAmbIva',
      header: this.i18n({ id: 'costeConIva', value: 'Cost amb IVA' }),
      type: 'currency',
    },
    {
      field: 'importPrevistSenseIva',
      header: this.i18n({ id: 'costeSinIva', value: 'Cost sense IVA' }),
      type: 'currency',
    },
    {
      field: 'acciones',
      header: this.i18n({ id: 'accions', value: 'Accions' }),
      actionIcons: [
        { icon: 'fa fa-eye', action: 'show' },
        { icon: 'fa fa-pencil', action: 'edit'},
        { icon: 'fa fa-download', action: 'download'},
      ]
    }
  ];
  constructor(
    private i18n: I18n,
    private sessionQuery: SessionQuery,
    private albaranesService: AlbaranesService,
    private httpStatusService: HttpStatusService,
    private dialogService: DialogService,
    private router: Router,
  ) {}

  ngOnInit() {
    this._savePresupuestosToTable();
  }

  regularitzaFactura(event) {
    console.log('regularitzaFactura event', event)
      const ref = this.dialogService.open(DialogRegularitzarFacturaComponent, {
        header: this.i18n({ id: 'regularizarFactura', value: 'Regulartizar factura' }),
        width: '40%',
        data: { factura: event },
      });
  
      ref.onClose.subscribe((res) => {
        //this.getEmpremtes();
       
        if (res) {
          this.cercaFactures();
          console.log(res);
        }
      });
  }

  veureFactura($event) {
    console.log("Veure factura",$event);
    
    this.router.navigate(['./serveis/facturaProforma/' + $event.facturaProformaId]);
  }


  ngOnChanges() {
    this.cercaFactures();
  }

  cercaFactures() {
    if (this.filtros != null) {
      const consultaFacturas: CercaFacturasProforma = {
        tipusRespostaDid: this.sessionQuery.getServiceActiveValue(),
        dataInici: this.filtros.dataInici
          ? moment(this.filtros.dataInici).format()
          : null,
        dataFi: this.filtros.dataFi
          ? moment(this.filtros.dataFi).endOf('month').format()
          : null,
        empresaGestoraId: this.filtros.empresa
          ? this.filtros.empresa['empresaGestoraId']
          : null,
      };
      console.log('consultaFacturas', consultaFacturas);
      this.getFacturas(consultaFacturas);
    }
  }

  getFacturas(consultaFacturas: CercaFacturasProforma) {
    this._setLoading(true);
    this.albaranesService
      .getFacturasProforma(consultaFacturas)
      .pipe(
        catchError((err) => {
          console.log('error', err);
          this._setLoading(false);
          if (err.status === 400) {
            return of({
              totalRegistres: 0,
              llistaCercaFacturesProforma: [],
            });
          } else {
            this.httpStatusService.validationErrors = err;
          }
        })
      )
      .subscribe((res: RespuestaCercaFacturasProforma) => {
        this.facturasProforma = res;
        this.facturasProforma.llistaCercaFacturesProforma.map(factura => {
          //Si la factura esta tancada no mostrem el boto de EDITAR
          if(factura.obert == false) factura.actionIconVisible = [true,false,true];
        })
        this._savePresupuestosToTable();
      });
  }

  private _savePresupuestosToTable() {


    this.facturasProformaTableData = {
      cols: this.cols,
      rows: this.facturasProforma
        ? this.facturasProforma.llistaCercaFacturesProforma === null
          ? []
          : this.facturasProforma.llistaCercaFacturesProforma
        : null,
      numRowsPerPage: this.numRows,
      numeroTotalResultados: this.facturasProforma
        ? this.facturasProforma.totalRegistres
        : null,
      loading: false,
    };
  }

  private _setLoading(loading: boolean) {
    this.facturasProformaTableData = {
      ...this.facturasProformaTableData,
      loading: loading,
      rows: null,
    };
  }


  handleDownloadDocument(factura: ItemLlistaCercaFacturesProforma) {   
    const fileName = 'Factura_Proforma_' + factura.facturaProformaId;      
    this.albaranesService.getPdfFacturaProforma(factura.facturaProformaId, fileName).subscribe();
  }

}
