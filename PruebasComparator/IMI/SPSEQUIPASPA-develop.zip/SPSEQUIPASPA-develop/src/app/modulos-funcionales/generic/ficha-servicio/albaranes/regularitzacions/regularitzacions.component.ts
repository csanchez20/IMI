import { Component, OnInit } from '@angular/core';
import { FiltrosAlbaranes } from '@app/core/model';

@Component({
  selector: 'app-regularitzacions',
  templateUrl: './regularitzacions.component.html',
  styleUrls: ['./regularitzacions.component.scss']
})
export class RegularitzacionsComponent implements OnInit {
  constructor() {}
  filtros: FiltrosAlbaranes;
  showList = false;
  ngOnInit() {}

  selectedFilters(event: FiltrosAlbaranes) {
    console.log('per aqui passa', event);
    this.filtros = event;
  }
}
