import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { AlbaranesComponent } from './albaranes.component';
import { TabViewModule } from 'primeng/tabview';
import { AlbaranesEnCursoComponent } from './albaranes-en-curso/albaranes-en-curso.component';
import { RegularitzacionsComponent } from './regularitzacions/regularitzacions.component';
import { FacturaProformaComponent } from './factura-proforma/factura-proforma.component';
import { FiltroAlbaranesEnCursoComponent } from './albaranes-en-curso/filtro-albaranes-en-curso/filtro-albaranes-en-curso.component';
import { ListaAlbaranesEnCursoComponent } from './albaranes-en-curso/lista-albaranes-en-curso/lista-albaranes-en-curso.component';
import {
  AppliedFiltersModule,
  RangeDatePickerModule,
} from '../../../../../../projects/spscompspa/src/public_api';
import {
  CheckboxModule,
  DropdownModule,
  ButtonModule,
  CardModule,
  InputTextModule,
  ProgressSpinnerModule,
  MessageModule,
} from 'primeng/primeng';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
2;
import { PanelModule } from 'primeng/panel';
import { ItemListaAlbaranesEnCursoComponent } from './albaranes-en-curso/lista-albaranes-en-curso/item-lista-albaranes-en-curso/item-lista-albaranes-en-curso.component';
import { SharedModule } from '@app/shared/shared.module';
import { DetalleAlbaranComponent } from './detalle-albaran/detalle-albaran.component';
import { DatosAlbaranComponent } from './detalle-albaran/datos-albaran/datos-albaran.component';
import { FiltroEmpremtesComponent } from './detalle-albaran/empremtes/buscador-empremtes/filtro-empremtes/filtro-empremtes.component';
import { EmpremtesComponent } from './detalle-albaran/empremtes/empremtes.component';
import { BuscadorEmpremtesComponent } from './detalle-albaran/empremtes/buscador-empremtes/buscador-empremtes.component';
import { TableModule } from 'primeng/table';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { ListaCustomEmpremtesComponent } from './detalle-albaran/empremtes/lista-custom-empremtes/lista-custom-empremtes.component';
import { MomentModule } from 'ngx-moment';
import { DialogRegularizarComponent } from './detalle-albaran/empremtes/lista-custom-empremtes/dialog-regularizar/dialog-regularizar.component';
import { ListaAlbaranesEnRegularizacionComponent } from './regularitzacions/lista-albaranes-en-regularizacion/lista-albaranes-en-regularizacion.component';
import { ItemListaAlbaranesEnRegularizacionComponent } from './regularitzacions/lista-albaranes-en-regularizacion/item-lista-albaranes-en-regularizacion/item-lista-albaranes-en-regularizacion.component';
import { FiltroAlbaranesEnRegularizacionComponent } from './regularitzacions/filtro-albaranes-en-regularizacion/filtro-albaranes-en-regularizacion.component';
import { FiltroFacturasProformaComponent } from './factura-proforma/filtro-facturas-proforma/filtro-facturas-proforma.component';
import { ListaFacturasProformaComponent } from './factura-proforma/lista-facturas-proforma/lista-facturas-proforma.component';
import { DialogEnviarRegularizarComponent } from './albaranes-en-curso/lista-albaranes-en-curso/dialog-enviar-regularizar/dialog-enviar-regularizar.component';
import { ToastModule } from 'primeng/toast';
import { DialogEnviarConTotalComponent } from './regularitzacions/lista-albaranes-en-regularizacion/dialog-enviar-con-total/dialog-enviar-con-total.component';
import { DialogEnviarSinTotalComponent } from './regularitzacions/lista-albaranes-en-regularizacion/dialog-enviar-sin-total/dialog-enviar-sin-total.component';
import { PaginatorModule } from 'primeng/paginator';
import { DialogDescarregarComponent } from './detalle-albaran/empremtes/lista-custom-empremtes/dialog-descarregar/dialog-descarregar.component';
import { DatosPersonalesFichaUsuarioModule } from '@app/shared/agrupaciones/datos-personales-ficha-usuario/datos-personales-ficha-usuario.module';
import { DialogResoldreComponent } from './detalle-albaran/empremtes/lista-custom-empremtes/dialog-resoldre/dialog-resoldre.component';
import { DialogRegularitzarFacturaComponent } from './factura-proforma/lista-facturas-proforma/dialog-regularitzar-factura/dialog-regularitzar-factura.component';
import { DetalleFacturaProformaComponent } from './detalle-factura-proforma/detalle-factura-proforma.component';
import { ListaAlbaranesFacturaProformaComponent } from './detalle-factura-proforma/lista-albaranes-factura-proforma/lista-albaranes-factura-proforma.component';

@NgModule({
  declarations: [
    AlbaranesComponent,
    AlbaranesEnCursoComponent,
    RegularitzacionsComponent,
    FacturaProformaComponent,
    FiltroAlbaranesEnCursoComponent,
    ListaAlbaranesEnCursoComponent,
    ItemListaAlbaranesEnCursoComponent,
    DetalleAlbaranComponent,
    DatosAlbaranComponent,
    FiltroEmpremtesComponent,
    EmpremtesComponent,
    BuscadorEmpremtesComponent,
    ListaCustomEmpremtesComponent,
    DialogRegularizarComponent,
    ListaAlbaranesEnRegularizacionComponent,
    ItemListaAlbaranesEnRegularizacionComponent,
    FiltroAlbaranesEnRegularizacionComponent,
    FiltroFacturasProformaComponent,
    ListaFacturasProformaComponent,
    DialogEnviarRegularizarComponent,
    DialogEnviarConTotalComponent,
    DialogEnviarSinTotalComponent,
    DialogDescarregarComponent,
    DialogResoldreComponent,
    DialogRegularitzarFacturaComponent,
    DetalleFacturaProformaComponent,
    ListaAlbaranesFacturaProformaComponent,
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    TabViewModule,
    AppliedFiltersModule,
    RangeDatePickerModule,
    CheckboxModule,
    ButtonModule,
    DropdownModule,
    CardModule,
    PanelModule,
    SharedModule,
    InputTextModule,
    TabViewModule,
    DatatableListModule,
    TableModule,
    MomentModule,
    ToastModule,
    PaginatorModule,
    DatosPersonalesFichaUsuarioModule,
    ProgressSpinnerModule,
    MessageModule
  ],
  entryComponents: [
    DialogRegularizarComponent,
    DialogEnviarRegularizarComponent,
    DialogEnviarConTotalComponent,
    DialogEnviarSinTotalComponent,
    DialogDescarregarComponent,
    DialogResoldreComponent,
    DialogRegularitzarFacturaComponent
  ],
  providers: [DatePipe],
  exports: [AlbaranesComponent],
})
export class AlbaranesModule {}
