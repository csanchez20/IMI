import {
  Component,
  OnInit,
  ChangeDetectorRef,
  OnChanges,
  Input,
} from '@angular/core';
import {
  TableData,
  InfoItem,
  RespuestaPresupuestoListResum,
} from '@app/core/model';
import { DialogService } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { EventEmitter } from 'protractor';

@Component({
  selector: 'app-list-detalle-presupuesto',
  templateUrl: './list-detalle-presupuesto.component.html',
  styleUrls: ['./list-detalle-presupuesto.component.scss'],
})
export class ListDetallePresupuestoComponent implements OnInit, OnChanges {
  public presupuestoTableData: TableData;
  public periode: Boolean = true;
  @Input() listResumTotal: RespuestaPresupuestoListResum[];
  @Input() listResumPeriodes: RespuestaPresupuestoListResum[];

  public cols: InfoItem[] = [
    {
      field: 'dataIniciPeriode',
      header: this.i18n({ id: 'fechaInicio', value: 'Data inici' }),
      type: 'date'
    },
    {
      field: 'dataFiPeriode',
      header: this.i18n({ id: 'fechaFin', value: 'Data fi' }),
      type: 'date'
    },
    {
      field: 'partidaTramit',
      header: this.i18n({ id: 'compromesEnTramit', value: 'Compromès tràmit' }),
      type: 'currency',
    },
    {
      field: 'partidaServei',
      header: this.i18n({ id: 'compromesEnServei', value: 'Compromès servei' }),
      type: 'currency',
    },
    {
      field: 'partidaFacturat',
      header: this.i18n({ id: 'facturado', value: 'Facturat' }),
      type: 'currency',
    },
    {
      field: 'partidaDisponible',
      header: this.i18n({ id: 'disponible', value: 'Disponible' }),
      type: 'currency',
    },
  ];

  dropDownVistaOptions = [
    { label: this.i18n({ id: 'periodo', value: 'Període' }), value: 'periode' },
    { label: this.i18n({ id: 'total', value: 'Total' }), value: 'total' },
  ];
  constructor(
    private dialogService: DialogService,
    private i18n: I18n,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit() {}

  ngOnChanges() {
    this._savePresupuestosToTable();
  }

  changeListView(e) {
    console.log('selected view', e.value);
    this.periode = e.value === 'periode';
    this._savePresupuestosToTable();
  }

  private _savePresupuestosToTable() {
    if(this.periode){
      let dades:number[]=[];
      let listResumPeriodesCopy:RespuestaPresupuestoListResum[]=[];
      this.listResumPeriodes.forEach(periode => dades.push(periode['dataIniciPeriode']));
      this.listResumPeriodes.forEach(periode => listResumPeriodesCopy.push(Object.assign({}, periode)));
      let maxNum=Math.max(...dades)+1;
      for(let i=0;i<dades.length;i++){
        let index=dades.indexOf(Math.min(...dades));
        if (index > -1) {
          this.listResumPeriodes[i]=listResumPeriodesCopy[index];
          dades[index]=maxNum;
        }
      }
    }
    this.presupuestoTableData = {
      cols: this.cols,
      rows: this.periode ? this.listResumPeriodes : this.listResumTotal,
    };
  }
}
