import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaCustomEmpremtesComponent } from './lista-custom-empremtes.component';

describe('ListaCustomEmpremtesComponent', () => {
  let component: ListaCustomEmpremtesComponent;
  let fixture: ComponentFixture<ListaCustomEmpremtesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaCustomEmpremtesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaCustomEmpremtesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
