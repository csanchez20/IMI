import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ItemCercaAlbaran } from '@app/core/model';
import { DiccionarioKey, DictionaryQuery } from '@app/core/dictionary/state';
import { Router } from '@angular/router';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import { DialogService, MessageService } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { DialogEnviarConTotalComponent } from '../dialog-enviar-con-total/dialog-enviar-con-total.component';
@Component({
  selector: 'app-item-lista-albaranes-en-regularizacion',
  templateUrl: './item-lista-albaranes-en-regularizacion.component.html',
  styleUrls: ['./item-lista-albaranes-en-regularizacion.component.scss'],
})
export class ItemListaAlbaranesEnRegularizacionComponent implements OnInit {
  @Input() albaran: ItemCercaAlbaran;
  @Output() albaranEnviado: EventEmitter<any> = new EventEmitter<any>();

  diccionarioKey = DiccionarioKey;
  enPeriodoRevision: boolean = false;
  constructor(
    public dictionaryQuery: DictionaryQuery,
    private router: Router,
    private albaranesService: AlbaranesService,
    private dialogService: DialogService,
    private i18n: I18n,
    private messageService: MessageService
  ) {}

  ngOnInit() {
     //Estarem en periode de revisio d'un albarà si l'albara esta obert i la dataActual es mes gran o igual a la dataInici
    //Un procés Batch tancarà l'albarà X dies despres de la dataFi del albarà
    if(this.albaran){
      this.enPeriodoRevision = 
          this.albaran.obert 
          && (new Date().getTime() >= this.albaran.dataInici );
    }
  }

  handleDetalleAlbaran(albaraId: number) {
    this.router.navigate(['./serveis/albaran/' + albaraId], {});
  }
  enviarConTotal(albaraId: number) {
    const ref = this.dialogService.open(DialogEnviarConTotalComponent, {
      header: this.i18n({
        id: 'atenciión',
        value: 'Atenció',
      }),
      width: '40%',
      //data: aud,
    });
    ref.onClose.subscribe((data: boolean) => {
      console.log('data', data);
      if (data) {
        this.albaranesService.facturarAlbara(albaraId).subscribe(() => {
          this.messageService.add({
            severity: 'success',
            summary: 'Enviat a factura proforma amb total',
          });
          //this.albaranEnviado.emit();
        });
      }
    });
  }

  enviarSinTotal(albaraId: number) {
    const ref = this.dialogService.open(DialogEnviarConTotalComponent, {
      header: this.i18n({
        id: 'atenciión',
        value: 'Atenció',
      }),
      width: '40%',
      //data: aud,
    });
    ref.onClose.subscribe((data: boolean) => {
      console.log('data', data);
      if (data) {
        this.albaranesService.regularitzaAlbara(albaraId).subscribe((res) => {
          if (res) {
            console.log('Creat Albara en regularització amb id:', res.albaraId);
            //Enviar a factura proforma
            this.albaranesService.facturarAlbara(albaraId).subscribe((res) => {
              console.log('Enviat a Factura Proforma albaraId:', albaraId);

              this.messageService.add({
                severity: 'success',
                summary: 'Enviat a factura proforma sense total',
              });
              //this.albaranEnviado.emit();
            });
          }
        });
      }
    });
  }
}
