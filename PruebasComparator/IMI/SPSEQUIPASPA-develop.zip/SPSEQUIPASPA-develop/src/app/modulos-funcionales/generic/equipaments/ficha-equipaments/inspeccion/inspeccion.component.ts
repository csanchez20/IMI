import {
  Component,
  OnInit,
  ChangeDetectorRef,
  ChangeDetectionStrategy,
  OnDestroy,
} from '@angular/core';
import { DialogService } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';
import {
  InfoItem,
  TableData,
  InfoPaginator
} from '@app/core/model/information';
import { ActivatedRoute } from '@angular/router';
import {
  ParamInEquipament,
  InspeccioCercadesRDTO,
  InspeccioRDTO
} from '@app/core/model/equipaments';
import * as FileSaver from 'file-saver';
import { DialogAddInspeccionComponent } from './dialog-add-inspeccion/dialog-add-inspeccion.component';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { SessionQuery } from '@app/core/auth';
import { DialogDetalleInspeccionComponent } from './dialog-detalle-inspeccion/dialog-detalle-inspeccion.component';
import { DictionaryService, DictionaryQuery } from '@app/core/dictionary/state';
import { map } from 'rxjs/operators';
import { InspeccionService } from '@app/servicios/equipaments/inspeccion.service';
import { GeneralService } from '@app/core/services';
import { DocumentacionCintraosService } from '@app/servicios/equipaments/documentacion-cintraos.service';

@AutoUnsubscribe()
@Component({
  selector: 'app-inspeccion',
  templateUrl: './inspeccion.component.html',
  styleUrls: ['./inspeccion.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InspeccionComponent implements OnInit, OnDestroy {
  dictionaryInspeccion: any;
  idEquipament: number;
  tableDataInspecciones: TableData;
  params: ParamInEquipament;

  listButtonsTable: InfoItem[] = [
    {
      icon: 'pi pi-plus-circle',
      label: this.i18n({ id: 'nuevaInspeccion', value: 'Nova inspecció' }),
      action: 'add'
    }
  ];

  cols: InfoItem[] = [
    {
      field: 'dataInspeccio',
      header: this.i18n({
        id: 'fechaInspeccion',
        value: "Data de l'inspecció"
      }),
      type: 'date'
    },
    {
      field: 'tipusInspeccioDid',
      header: this.i18n({ id: 'tipo', value: 'Tipus' }),
      type: 'dictionary',
      typeKey: 'tipo_inspecciones'
    },
    {
      field: 'nomProfessionalDocument',
      header: this.i18n({ id: 'profesional', value: 'Professional' })
    },
    {
      field: 'acciones',
      header: this.i18n({ id: 'acciones', value: 'Accions' }),
      actionIcons: [
        { icon: 'fa fa-eye', action: 'show' },
        {
          icon: 'fa fa-pencil',
          action: 'edit',
          fieldIdOwner: 'idProfessionalDocument'
        },
        {
          icon: 'fa fa-trash',
          action: 'delete',
          fieldIdOwner: 'idProfessionalDocument'
        }
      ]
    }
  ];

  constructor(
    public inspeccionService: InspeccionService,
    public generalService: GeneralService,
    private i18n: I18n,
    private dialogService: DialogService,
    private cd: ChangeDetectorRef,
    private route: ActivatedRoute,
    public sessionQuery: SessionQuery,
    private dictionaryService: DictionaryService,
    public dictionaryQuery: DictionaryQuery,
    private documentacionCintraosService: DocumentacionCintraosService
  ) {}

  ngOnInit() {
    // Inicializamos solo con los headers para que se muestren mientras se procesa la peticion
    this.tableDataInspecciones = {
      cols: this.cols
    }
    this.idEquipament = this.route.snapshot.params.idEquipament;
    this.dictionaryService.getTipoInspecciones().subscribe(dictionary => {
      this.dictionaryInspeccion = dictionary;
      this.cd.markForCheck();
    });
    // TODO: Modificar cuando se tenga paginacion en CINTRAOS.
    this.params = {
      centreId: this.idEquipament,
      numeroPagina: 1
      // tamanyPagina: '5',
      // tots: 'true'
    };
    this.updateInspecciones();
  }

  openDialogAddInspeccion() {
    const ref = this.dialogService.open(DialogAddInspeccionComponent, {
      header: this.i18n({ id: 'anadirInspeccion', value: 'Afegir inspecció' }),
      width: '40%',
      data: {
        idEquipament: this.idEquipament
      }
    });
    ref.onClose.subscribe((inspeccion: InspeccioRDTO) => {
      if (inspeccion) {
        this.updateInspecciones();
      }
    });
  }

  deleteInspeccion(inspeccion: InspeccioCercadesRDTO) {
    this.inspeccionService
      .getInspeccionEquipament(inspeccion.id)
      .subscribe(ins => {
        this.inspeccionService.eliminarInspeccion(inspeccion.id).subscribe(id => {
          this._deleteDocumentCintraosInspeccion(ins.document);
          this.updateInspecciones();
        })
      });
  }

  private _deleteDocumentCintraosInspeccion(documentId: string) {
    if (documentId !== null) {
      this.documentacionCintraosService.deleteDocument(documentId).subscribe();
    }
  }

  openDialogEditInspeccion(inspeccion: InspeccioCercadesRDTO) {
    this.inspeccionService
      .getInspeccionEquipament(inspeccion.id)
      .subscribe(ins => {
        const ref = this.dialogService.open(DialogAddInspeccionComponent, {
          data: {
            idEquipament: this.idEquipament,
            inspeccion: ins
          },
          header: this.i18n({
            id: 'modificarInspeccion',
            value: 'Modifica inspecció'
          }),
          width: '40%'
        });
        ref.onClose.subscribe((data: InspeccioRDTO) => {
          if (data) {
            this.updateInspecciones();
          }
        });
      });
  }

  selectInspeccion(inspeccion: InspeccioCercadesRDTO) {
    this.inspeccionService.getInspeccionEquipament(inspeccion.id)
      .subscribe(ins => {
        const tipoInspeccion = this.dictionaryQuery.getItemDictionaryByKey(
          ins.tipusInspeccioDid,
          'tipo_inspecciones'
        );
        this.dialogService.open(DialogDetalleInspeccionComponent, {
          header: this.i18n({
            id: 'detalleInspeccion',
            value: 'Detall inspecció'
          }),
          width: '40%',
          data: {
            inspeccion: ins,
            tipoInspeccion: tipoInspeccion
          }
        });
      });
  }

  handleDownloadRow(data: any) {
    this.generalService.getFile(data.document).subscribe(res => {
      FileSaver.saveAs(res, 'document' + data.document);
    });
  }

  updateInspecciones() {
    this._setLoading(true); 
    this.inspeccionService
    .getInspeccionesEquipament(this.params)
    .pipe(
      map(resIns => {
        return {
          rows: resIns,
          cols: this.cols,
          numeroTotalResultados: resIns.length
        } as TableData;
      })
    ).subscribe(tableDataInspecciones => {
      this.tableDataInspecciones = tableDataInspecciones;
      if(this.tableDataInspecciones['rows'] && this.tableDataInspecciones['rows'].length>0 ){
        for(let row of this.tableDataInspecciones['rows']){
          row['nomProfessionalDocument']=row['nomProfessionalDocument'].split('null').join('');
        }
      }
      this.cd.markForCheck();
    });
  }

  changePage(infoPaginator: InfoPaginator) {
    this.params = {
      ...this.params,
      numeroPagina: infoPaginator.numeroPagina,
      tamanyPagina: infoPaginator.tamanyPagina
    };
    this.updateInspecciones();
  }

  private _setLoading(loading: boolean) {
    this.tableDataInspecciones = {
      ...this.tableDataInspecciones,
      loading: loading,
      rows: null,
    };
  }

  ngOnDestroy() {}
}
