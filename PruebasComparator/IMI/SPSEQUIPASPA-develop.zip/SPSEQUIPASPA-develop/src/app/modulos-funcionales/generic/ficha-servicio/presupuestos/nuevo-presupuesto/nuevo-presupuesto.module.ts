import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NuevoPresupuestoComponent } from './nuevo-presupuesto.component';
import { CardModule } from 'primeng/card';
import { PanelModule } from 'primeng/panel';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import {
  InputTextModule,
  CalendarModule,
  DropdownModule,
  AutoCompleteModule,
  DialogModule,
  DialogService,
  MessageModule,
  MessagesModule,
} from 'primeng/primeng';
import {
  DireccionConsultaModule,
  RangeDatePickerModule,
} from '../../../../../../../projects/spscompspa/src/public_api';
import { TableModule } from 'primeng/table';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { SharedModule } from '@app/shared/shared.module';
@NgModule({
  declarations: [NuevoPresupuestoComponent],
  imports: [
    CommonModule,
    CardModule,
    PanelModule,
    FormsModule,
    ButtonModule,
    InputTextModule,
    ReactiveFormsModule,
    CalendarModule,
    DropdownModule,
    AutoCompleteModule,
    DireccionConsultaModule,
    TableModule,
    DialogModule,
    DynamicDialogModule,
    MessageModule,
    RangeDatePickerModule,
    SharedModule,
  ],
  exports: [NuevoPresupuestoComponent],
})
export class NuevoPresupuestoModule {}
