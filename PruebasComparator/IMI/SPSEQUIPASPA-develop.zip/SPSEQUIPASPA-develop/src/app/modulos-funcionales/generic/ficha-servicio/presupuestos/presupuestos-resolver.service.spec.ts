import { TestBed } from '@angular/core/testing';

import { PresupuestosResolverService } from './presupuestos-resolver.service';

describe('PresupuestosResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PresupuestosResolverService = TestBed.get(PresupuestosResolverService);
    expect(service).toBeTruthy();
  });
});
