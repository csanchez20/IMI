import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ItemCercaAlbaran } from '@app/core/model';
import { DiccionarioKey, DictionaryQuery } from '@app/core/dictionary/state';
import { Router } from '@angular/router';
import { AlbaranesService } from '@app/servicios/ficha-servicio/albaranes.service';
import { ResultRegularitzarAlbara } from '@app/core/model';
import { DialogService } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { DialogEnviarRegularizarComponent } from '../dialog-enviar-regularizar/dialog-enviar-regularizar.component';
import { MessageService } from 'primeng/api';
import { DialogResoldreComponent } from '../../../detalle-albaran/empremtes/lista-custom-empremtes/dialog-resoldre/dialog-resoldre.component';

@Component({
  selector: 'app-item-lista-albaranes-en-curso',
  templateUrl: './item-lista-albaranes-en-curso.component.html',
  styleUrls: ['./item-lista-albaranes-en-curso.component.scss'],
})
export class ItemListaAlbaranesEnCursoComponent implements OnInit {
  @Input() albaran: ItemCercaAlbaran;
  @Output() albaranEnviado: EventEmitter<any> = new EventEmitter<any>();

  diccionarioKey = DiccionarioKey;
  enPeriodoRevision: boolean = false;

  constructor(
    public dictionaryQuery: DictionaryQuery,
    private router: Router,
    private albaranesService: AlbaranesService,
    private dialogService: DialogService,
    private i18n: I18n,
    private messageService: MessageService
  ) {}

  ngOnInit() {
    //Estarem en periode de revisio d'un albarà si l'albara esta obert i la dataActual es mes gran o igual a la dataInici
    //Un procés Batch tancarà l'albarà X dies despres de la dataFi del albarà
    if(this.albaran){
      this.enPeriodoRevision = 
          this.albaran.obert 
          && (new Date().getTime() >= this.albaran.dataInici );
    }
  }

 
  handleDetalleAlbaran($event) {
    this.router.navigate(['./serveis/albaran/' + $event], { state: { dadesRecollidesLlistatAlbara: this.albaran} });

  }

  enviarRegularizar(albaraId: number) {
    const ref = this.dialogService.open(DialogEnviarRegularizarComponent, {
      header: this.i18n({
        id: 'atenciión',
        value: 'Atenció',
      }),
      width: '40%',
      //data: aud,
    });
    ref.onClose.subscribe((aceptado: boolean) => {
      if (aceptado) {
        this.albaranesService
          .regularitzaAlbara(albaraId)
          .subscribe((res: ResultRegularitzarAlbara) => {
            if (res && res.albaraId) {
              //this.albaranEnviado.emit();
              this.messageService.add({
                severity: 'success',
                summary: 'Albarà enviat a regularitzar',
              });
              console.log(
                'Nou albarà a regularitzar amb id:',
                res.albaraId
              );
            }
          });
      }
    });
  }

  enviarProforma(albaraId: number, numIncidencies: number) {
    if(numIncidencies > 0) {
      this.albaranesService.regularitzaAlbara(albaraId).subscribe((res) => {
        this.albaranesService.facturarAlbara(albaraId).subscribe(() => {
          console.log('Enviat a Factura Proforma');
          this.albaranEnviado.emit();
        });
      });
    }
    else {
      this.albaranesService.facturarAlbara(albaraId).subscribe(() => {
        console.log('Enviat a Factura Proforma');
        this.albaranEnviado.emit();
      });
    }
  }

  
}
