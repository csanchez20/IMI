import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { DialogService } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { DialogEditDatosContratoComponent } from './dialog-edit-datos-contrato/dialog-edit-datos-contrato.component';
import {
  DictionaryService,
  DictionaryQuery,
  DiccionarioKey,
} from '@app/core/dictionary/state';
import { Observable, forkJoin } from 'rxjs';
import { ContracteRDTO } from '@app/core/model/ficha-servicio/contratos';

@Component({
  selector: 'app-datos-contrato',
  templateUrl: './datos-contrato.component.html',
  styleUrls: ['./datos-contrato.component.scss'],
  providers: [DialogService],
})
export class DatosContratoComponent implements OnInit {
  dictionary$: Observable<any>;

  diccionarioKey = DiccionarioKey;

  @Input() contrato: ContracteRDTO;

  constructor(
    private i18n: I18n,
    private dialogService: DialogService,
    private cd: ChangeDetectorRef,
    private dictionaryService: DictionaryService,
    public dictionaryQuery: DictionaryQuery
  ) {}

  ngOnInit() {
    this.dictionary$ = forkJoin({
      tipos_contratos: this.dictionaryService.getTiposContrato(),
      estados_contratos: this.dictionaryService.getEstadosContrato(),
      capitulos_presupuestarios: this.dictionaryService.getCapitulosPresupuestarios(),
      periodos_presupuestarios: this.dictionaryService.getPeriodosPresupuestarios(),
    });
  }

  editaDatosContrato() {
    const ref = this.dialogService.open(DialogEditDatosContratoComponent, {
      data: this.contrato,
      header: this.i18n({
        id: 'editarDatosContrato',
        value: 'Editar dades del contracte',
      }),
      width: '60%',
    });

    ref.onClose.subscribe((contrato: ContracteRDTO) => {
      if (contrato) {
        this.contrato = contrato;
        this.cd.markForCheck();
      }
    });
  }
}
