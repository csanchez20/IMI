import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogRegularitzarFacturaComponent } from './dialog-regularitzar-factura.component';

describe('DialogRegularitzarFacturaComponent', () => {
  let component: DialogRegularitzarFacturaComponent;
  let fixture: ComponentFixture<DialogRegularitzarFacturaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogRegularitzarFacturaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogRegularitzarFacturaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
