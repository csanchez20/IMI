import { Injectable } from '@angular/core';
import { HttpRestClientService } from './http-rest-client.service';
import { environment } from '@env/environment';
import { HttpClient } from '@angular/common/http';
import { MAP_URL_SEGURIDAD_EQUIPAMENTS, SessionQuery } from '../auth';
import { SeguridadKeysService } from '../auth/seguridad-keys.service';


@Injectable({
  providedIn: 'root'
})
export class HttpRestClientEquipaService extends HttpRestClientService {

  constructor(
    public httpClient: HttpClient,
    public sessionQuery: SessionQuery
  ) { 
    super(
      httpClient, 
      environment.equipaments,
      new SeguridadKeysService(MAP_URL_SEGURIDAD_EQUIPAMENTS),
      sessionQuery
    )
  }

}
