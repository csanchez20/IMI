import { Injectable } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  constructor(
    public httpClient: HttpClient
  ) { }

  getListaTipoMovimientos(): SelectItem[] {
    return [
      { label: 'TipoMovimiento1', value: '0' },
      { label: 'TipoMovimiento2', value: '1' },
      { label: 'TipoMovimiento3', value: '2' },
      { label: 'TipoMovimiento4', value: '3' }
    ]
  }

  getListaResidencias(): SelectItem[] {
    return [
      { label: 'Residencia1', value: '0' },
      { label: 'Residencia2', value: '1' },
      { label: 'Residencia3', value: '2' },
      { label: 'Residencia4', value: '3' },
      { label: 'Residencia5', value: '4' },
      { label: 'Residencia6', value: '5' },
      { label: 'Residencia7', value: '6' }

    ]
  }

  getListaPosiciones(): SelectItem[] {
    return [
      { label: '1', value: '1' },
      { label: '2', value: '2' },
      { label: '3', value: '3' },
      { label: '4', value: '4' }
    ]
  }

  getFile(id?: number): Observable<any> {
    const url = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWAAAACPCAMAAADz2vGdAAABBVBMVEX///9ChfR1dXXqQzX7vAU0qFNycnJwcHBtbW33/PgyfvPJ5tAfo0ZJsGT7uQBra2vG2ft8fHyZmZk6gfSwsLDpNCLqPi/pOSmcvPgvfPPpOyvl5eXz8/OCgoLGxsb3+v/R0dFlmvbQ0NCNjY3pLRnr6+ujo6O/v7/b5/3znpjrSDr98O9ArVyKior4ycba2tro8P6Vt/j86OZVkfX//PP3v7uFrff1sayzy/r50c690vtKivTi6/32uLT73NrylI7+8dL803B2o/bvdWzsWU6qw/nuaV//9uLwfnb+6bnxjIX94J/+783rUUQbdfP93pf8yUf8zVhrnfb8xTD91n792430pqGCk7GdAAAPWklEQVR4nO2dC1viRhfHA2yTNG0NEEIIclFAQCmConjBdV0Vdb20u2673/+jvEnmmuRMwG7fJfSZ3/O0lWQCk39Ozpw5Z5IqikQikUgkEolEIpFIJBKJRCKRSCQSiUQikUgkEolEIpFIJBKJRCL5rzPOz6fbk4yRmU2m835z1d35b9HMTyeuYViZAMvy/tyujFfdqyg/Y1bdjzfTrMxcrC2HYV3nV92zED//9nvAT7+suidvo1nJxNVFlmxs91fdO46ff/sp4Nf1EvjcMmB5A9yD9DjjtRR4vJ0kr+8oJqkx4nUU+FzkHXhHcb7qXmLWUOC5G/G5FvqPEZLdray6n4j1E7jCuwcjs13J98fN5njcP51OOI2tSTr88NoJXGH2a7mT01DY6wXGNCreToe+ayfwKbNfYwZEvONrN032u3YC56n9WobAyfYnlme/P7ZbCayXwGPmHmbiQGzqvqbFftdN4GuL6puUc5inR9/1EvicOeAUSZjMOgncZEFY6nJmQtZJ4DkxYCNdCbNE1kjgJh3gDlbdlTewRgLTEHi2Ng5YWSuBt4mDOF11T97C+gh8QUO07/+uweHhYKmGR/f390dLtGuO+/0LcE+iwEv340dAhrjv9cBnu3d75XK1nLt93E88u/unL+8QX57ukxpezCcZyyOzXYmLLBT48hvpx+7lm05g1OgWh+1iqbG5qOXOVqPRGEU21lqlbrfba9Wirckkw/2eXPrgZK/jlHMB5ardudsXtfz0eWNjAwvs//WnyJDPJ65Fby732pP44A/X548g1hEI/P6F9cPp5E6WPYFWUTd11UfTzWwpqlIpIFC+1iuYuodp9tj+Wq9u6pp3sHd0cSvYNOr5tFgMMVu2LwAnOTsXoty5O4MaPn8l4hI8iaGG/e1wGtoy5krF4oJJUOD9W7sc6od9C3YjSqNuqlkOTYtInNU1TTNbftOsjpuazNJLqs6OV826v6cUXIaiMsZpHmu6TE9ADu8i8gYS24/xln9F5Q0k/hp3FKdWrLjiVhYKvNspx7vxfmH/a209JG8gcbbFNyn42/QtRemaVMc62blT18MHq7pn3D3N/6tI82iehfxDzuzYaWHribjio5j5EomfI1954Ebl9U3AyiQL/ABc51yus7ug/5vZmLyBgZa4NkTgIpNSb+B9IzN+vNmlApM8BDyL6+eFkKD5rAPK61ENKyzU11P402J9KSKBb0B9PYW/JeurEn1Uz6/6nhRQGAk8apiciNiJjKjmWnA8OtzsEYHJNAMe4yauiD9w+0uHnYpjdzodzp6dO/67OH03EJzCV1xDvrhiGW6kKCgS+JHpWw36UaUKC0dcjxqxX13rNjZ3drZKbWKROhvFkMAtrKMnqUnkJ9dHNQul1mhns9HNBoqrQxUJPCc3HhhubovtCE1LBi9Ez7L9srt/eXj5/sGmmjsP7Ks+bjB5Pz5d3V99+vsdJzELJljyP+NO5vl+Pz+fheqFoMDHVF/HeTweKIfHjw7uR3kvIWwcYn20Hh3WNofYKNkwVuD8azcI0DZx8wI6Xits0a8sBVYcbPcErpBiG5hIEwtsIZ/9QMR0Xo7JQYNHasXMeD4xMf+iYj5RiTe+kG00rMlwS4nOZ8yKQYEHe+QnnQ9UTmLU/HWO0ENaasMasFXNxgTWi+Hwoota6l1+Y61Ovc4/t2ArqCxRB2yHzuGM2vUe3nL0lep7xTU8+kIVJm74gEgZql01t6nCoMDfsJblMh+XfcCXvyOactSw9yxGtrfMsJMgAoeF9AII3K4U3kwV5nywAfrgBIGDid9dGbaRQ3K/2jjUf6IGHInJqMKf0WdavXLDYU1zkijwHvm9sJS4f+XQYMBRQv6yHtuBbbiAPxYEF6KrgZuVHWbBNIoAl+wssOBLYje30QMvO+E9wohMIaaNxzmyPCMWl1PlIYGJB7aP+UMOd4nunUPo7LwJBDJAYHLcDmyQxGLEgiMzvBq82aOhE4H7LidYDG8+FYUI7BsYuQXt+C1IdwW37DO2042/Yg2vwrsm5AdiudO5IRb4BrDU/YcOG20/QGenbAV3uNoFdm1qWKAAJLAW8QRKS49EG4w6GeSaZIB+hXowr8TAt2oQRdzi87qJHznAJ+cEcf7fxBEAmQfqJPwPF+J5Dxn9IIHx/WLTMXVwcsviNK8XVejslG6ggrkD7UMmjI0TCaxHG3ZVgQETE/YvEDEZa8l0+zWbsB5Wo+fF8VDljOprNFbgIPHFhu+dafYfCGqmwqkycUg53PLyMceF42Xb2YVdRKCbWgD3IYXMEWuYjTWsq5yVh6mZRGAyasNOOEZzhsegC3+SjAWGGtLA1P8Az9gQR/xO0htohQseLgCB8W9hD3F82+GN17k7Br4swARvfMQOf/sXspCSNY330xGo+DSuX27VDrmH/frSiSMY4nwOSYjkhaX30ISNQsz7SaGjKpicvhAK/A39VvVDMLCFjDf3KM4KoyBLIJCiceoXwCuxiY6PZoYRXSIwMcnAJhdD7mH/cuzi8wLj+AEewf0YlA5kYPIXO+GNv72/eQ8fpSl0EXhEdXbPbhxu6l7u3J4k5f5HSQKhCAMPgLDAWzromREljRj9lDjh64S+UHgTw+dVBRKT/iSahRE0iAC/Ek+igzBiluSvhAI/EpfgcMbr2A8LksEoT2MKKhi8g4UFxkEENMaxdKWi9N+yLIKO8n7bt1sw+J1fAIHfZsGPnM8lvuH228Ky3DICJ1lwosDMgpVXEnousTZ1yoep2PXB8yTqgw85gcEa3Ge80y9t4JgGjMrHQoF3nbC8jn2TlEEjYB+6Be8NQjBtCRcBXyBOYDLXWKKq0Q/Ns0ig4EBNaYgxiAQKUUI78QUE3VVfOMi951PBZdsWRGVRUCgFzhOU7x7kipyHoYsr3QVljSZJaqHsMZkp25Cv+8CHGETDj0BD6qD9WTSZrkGLYOZCCz7jc8HiqCyGeCJH/AcOMWCBa2pCmEdmcj5sebCbuPiEprQsNO0jbhZ0wmRfMAJ+TJjJfeQdNLmboFGORBjimVyuvJcQlcXByWBwX3CLk1keLDA6Xh1Ch2+anMDKKc1xi9a3+zRpnoCUP3AKIGfHb8mTUPqFztbiJWQaIwezPBo0xqPyfEIugmT1csv5BgIWEbzHUTKhwE2V4wLjZBrkhEuhXAZzEhlDGKz1adLbINMA4oSrsWTEgNy0qJpwJMpWslQE9s90Yhm7l0i+EhKYOOF4UudwL8FjYDODTBDNlPEYJxJ4FGrEU8OFEjr5YxUDC3oGxn+ImZVtJnQrMRw7WrqliWIcI1Mf8TXiJGgaCHuPi+hdQjgwEgQeEBccrb8NXsqdG3G8Vg8lJTlwIpIMYAKBSRIobsLItjmBmRv2Tm075gCbp1xZzGKnTgoJOTtkOoMbEjcR53FPKxfhVRB/0u3EedBAMBO60OwxSTDhTgM1J+SDD/18XzXHjLhWatfbLGwgaduYQiiXRm1bJLAoYd/CVT0ufdHnS7fGpMLZzzg/zXBVR5eXn5bC7Dt2Zsd71Zju3JqTJ9rw6jPdSi17TH/KYs+eN6fcY2ZwTY7GwFyV/n0Odc8mRlwr+OujzDZtgWqWajaiMC61Ue8sEljBJb12eOsI2W84P3Qx4yW2jMzrwXw+rxy8ZsJ183Cmdp8GSOXO3bF/GpcnL2zbC214RPV9t/Hu6crbcv+JyctXOtiIa1mV4GUr/QN+oQ9cVWahsL337TLaEbL6BNfKWA1tC5uwyXuJnSESiJWChALjW0Cr81eox5b/8Am45iTyrH24hEFOLzL47LIQtGx70ZLTYfmAcpUb1K+4Gn2wJCK0LoKPLq45b2S41swKvyBEsC7igc3mHLvjVDtcRxw8CG+SRSIFOr3tkhL9cIS3bXbx4hGVtRIKrBSxs9W7WOJaA62kUmMC++PIosftLSs2AsILlpAthSYgXOE+SriSxFWQIUQre24dUT+IvsTeQpFVHd/Oql4olkql7lDX4o3EAtcKpICsD7ve8cUCvjxFKBmfnyW/MMKYAIUGkcLlTmSCJ1Q4WqljAXf46iYLrNwJFLZproQJzFKMtSERNKtqmsYtpOLCY7HAyg47Ijge3xBbLJsWYp4RS2xl4Jn0rgOt/nNeYkH/8ztQ4o2n2Fdex3thXYtLRphH6FKXuQBnEzvH8LDf5VecEbTQuJcgsFKra9GDVS/wEwjsv7QHltiypqKn6C7j61er9iMQfR59jCu88fkK+MrYy0Hc6yXWB7/fi3XEfuEj4zbSwgwHvr1sVCLVDK/gSRJYqXUj6yv1wkgRCuzHvNuuERnbLHd2kPSQ4skeXwYrO50HwZz1+TM/tnkD3VcoweYxPnC5C21kzukkz0UC//4rIrTCffCtzC+m9T6E17jXhqZ3I5uxrE1J51dQa2Y7MnvO+qupY4dRRtwCblVHMQpKV8KJJGV8Pp347zoJ8LR+nS98vuDs8aVq247t/VNOzHVf/fmVra78eCVu2JxPLNQHC818iMCoL79goi9OO77xoggn6MjeQ3ya3Ci2S1DuoDFUNX9Juq6p7V6sCLTl00p4eGNUzKLD1SFeRZgocHB+/fz56en5eb6/7PO1h2cnJyfHZ5cLKwlHz5+enj49Pyc+AkP7QDswDQmcwOX+ycn7/bO3PQOj1DZHrUZra+EjMCKCw0fUswRRhCbINaeTV+yN1+N5SeSNBRXrVEIzmavuyFKgJQGiet/KuQBegYcrRha4xmuF7JSguj3OB//w3ixF/toFilekXJeS94phWkUTii5q0Ew5HXjBgz9jt6LLYMb/xgOT/zalYGKsxU0Y5YPNFnDMirkgubvog5EkQZGqdwKgVBGXFcL0RAu7UwCpXlnhvAfdnC4PgbOdhbANl8wUxxAXZAJnZVhmP0/TP/DDOisDPzmnqlzAO2pj2cFy8+qhxbeMMav0x82L/Jxlqo20vZWFPPupF7pbO7XazqhXpw8zw6sCVw+XDrZcw3D5LPX3PLL+/4FmO4MHPdmToqpo1ebqGcPp4EDwNIUQmHbkUXCsr5pafcUKA/WUNBDNViKPkdY5XEATfBW3lVlqifiPZ1QPvw9B1UWp4/Qwj70wwjKu0xQBh2kMNfS+FP+NKdqwBy8ZThUXU4t/LbRhpOx/MxFlp9Ettuv1eru7+J0/KaF5+mq4fhTh/et6nlLvsO5c5PP5/tIZf4lEIpFIJBKJRCKRSCQSiUQikUgkEolEIpFIJBKJRCKRSCQSiUQikUgkkhXxP6DjoeZWH9X4AAAAAElFTkSuQmCC';
    return this.httpClient.get(url, { responseType: 'blob' });
  }

}
