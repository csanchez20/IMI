import { Injectable } from '@angular/core';
import { SessionQuery } from '../auth';
import { ConsultaAdrecaRDTO } from '../model';
import { DictionaryQuery } from '../dictionary/state/dictionary.query';
import { DiccionarioKey } from '../dictionary/state/dictionary.service';
export const SPECIAL_KEYS: Array<string> = [
  'Backspace',
  'Tab',
  'End',
  'Home',
  '-',
  'ArrowLeft',
  'ArrowRight',
  'Del',
  'Delete',
];

@Injectable({
  providedIn: 'root',
})
export class FormatterService {
  diccionarioKey = DiccionarioKey;

  constructor(
    private sessionQuery: SessionQuery,
    private dictionaryQuery: DictionaryQuery
  ) {}

  static toNegative(value: number) {
    return value !== 0 ? -Math.abs(value) : value;
  }

  /**
   * Retorna la fusion de dos objetos. Se toma como referencia el objRef, al que se
   * le sobreescriben aquellas propiedades comunes con el objToMerge.
   * @param objRef Objeto a retornar, que será fusionado.
   * @param objToMerge Objeto que se fusionará
   */
  public static mergeObjectCommonKeys(objRef: Object, objToMerge: Object) {
    Object.keys(objToMerge)
      .filter((key) => key in objRef)
      .forEach((key) => {
        objRef[key] = objToMerge[key];
      });
    return objRef;
  }

  public static textBoolean(value: boolean) {
    if (value === true) {
      return 'Sí';
    } else if (value === false) {
      return 'No';
    }
  }

  /**
   * Mapea un objeto de forma que todos aquellos campos que no tienen valor sean null
   * @param obj Objeto a mapear
   */
  public static mapEmptyFieldsToNull(obj: Object): Object {
    let objMapped = {};
    Object.keys(obj).map((key) => {
      objMapped = {
        ...objMapped,
        [key]: obj[key] || obj[key] === false ? obj[key] : null,
      };
    });
    return objMapped;
  }

  /**
   * Retorna el primer dia del mes de la fecha que se envia por parametro, en formato Date
   * @param date Fecha de la que se quiere obtener el primer dia del mes
   */
  getDateLastDayMonth(date: Date): Date {
    return date ? new Date(date.getFullYear(), date.getMonth() + 1, 0) : null;
  }

  getCentroDescr(centreId: string) {
    const centros = this.sessionQuery.isServiceSAUV()
      ? this.sessionQuery.getPlacesSauv()
      : this.sessionQuery.getPlacesViviendas();
    const found = centros && centros.filter((el) => el.value === centreId);
    if (found && found.length === 1) {
      return found[0]['label'];
    }
    return 'No trobat';
  }

  getAdrecaToString(direccion: ConsultaAdrecaRDTO) {
    let direccionFormatted: string;
    if (direccion) {
      direccionFormatted =
        this.dictionaryQuery.getItemDictionaryByKey(
          direccion.adrTipusVia,
          this.diccionarioKey.TIPOS_VIA
        ) +
        ' ' +
        direccion.adrNomCarrer +
        ', ' +
        direccion.adrNum1 +
        (direccion.adrNum2 && direccion.adrNum2.length > 0 ? '-' + direccion.adrNum2 + ', ' : ', ') +
        (direccion.adrLletra1 && direccion.adrLletra1.length > 0 ? ' ' + direccion.adrLletra1 + ', ' : '') +
        (direccion.adrLletra2 && direccion.adrLletra2.length > 0 ? direccion.adrLletra2 + ', ' : '') +
        (direccion.adrPortal && direccion.adrPortal.length > 0 ? direccion.adrPortal + ', ' : '') +
        (direccion.adrEscala && direccion.adrEscala.length > 0 ? direccion.adrEscala + ', ' : '') +
        (direccion.adrAPDescr && direccion.adrAPDescr.length > 0 ? direccion.adrAPDescr + ', ' : '') +
        (direccion.adrPPis && direccion.adrPPis.length > 0 ? direccion.adrPPis + ', ' : '') +
        (direccion.adrPPorta && direccion.adrPPorta.length > 0 ? direccion.adrPPorta + ', ' : '') +
        (direccion.distrDesc && direccion.distrDesc.length > 0 ? direccion.distrDesc + ', ' : '') +
        (direccion.barriDesc && direccion.barriDesc.length > 0 ? direccion.barriDesc + ', ' : '') +
        (direccion.adrMunicipi && direccion.adrMunicipi.length > 0 ? direccion.adrMunicipi + ', ' : '') +
        (direccion.adrCP && direccion.adrCP.length> 0 ? direccion.adrCP : '') +
        '.';
    }
    return direccionFormatted;
  }

  getNumAdrecaToString(direccion: ConsultaAdrecaRDTO) {
    let direccionFormatted: string;
    if (direccion) {
      direccionFormatted =
        this.dictionaryQuery.getItemDictionaryByKey(
          direccion.adrTipusVia,
          this.diccionarioKey.TIPOS_VIA
        ) +
        ' ' +
        direccion.adrNomCarrer +
        ', ' +
        direccion.adrNum1 +
        (direccion.adrNum2 ? '-' + direccion.adrNum2 + ', ' : ', ') +
        (direccion.adrLletra1 ? ' ' + direccion.adrLletra1 + ', ' : '') +
        (direccion.adrLletra2 ? direccion.adrLletra2 + ', ' : '') +
        (direccion.adrPortal ? direccion.adrPortal + ', ' : '') +
        (direccion.adrEscala ? direccion.adrEscala + ', ' : '') +
        (direccion.adrAPDescr ? direccion.adrAPDescr + ', ' : '') +
        (direccion.adrPPis ? direccion.adrPPis + ', ' : '') +
        (direccion.adrPPorta ? direccion.adrPPorta + ', ' : '') +
        (direccion.distrDesc ? direccion.distrDesc + ', ' : '') +
        (direccion.barriDesc ? direccion.barriDesc + ', ' : '') +
        (direccion.adrMunicipi ? direccion.adrMunicipi + ', ' : '') +
        (direccion.adrCP ? direccion.adrCP : '') +
        '.';
    }
    return direccionFormatted;
  }
}
