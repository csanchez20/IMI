import { Injectable } from '@angular/core';
import * as FileSaver from 'file-saver';
import * as xlsx from 'xlsx';
import { InfoItem } from '../model';
export const EXCEL_EXTENSION = '.xlsx';
export const CSV_EXTENSION = '.csv';

declare const require: any;
const jsPDF = require('jspdf');
require('jspdf-autotable');

@Injectable({
  providedIn: 'root'
})
export class FileService {

  constructor() {}


  downloadFile(fileBase64: any, filename: string, encoded?: boolean) {
    if (encoded === true) {
      fileBase64 = atob(fileBase64);
    }
    const pdf = 'data:application/pdf;base64,' + fileBase64;
    FileSaver.saveAs(pdf, filename);
  }

  fileNameAndExt(str) {
    const file = str.split('/').pop();
    return [
      file.substr(0, file.lastIndexOf('.')),
      file.substr(file.lastIndexOf('.') + 1, file.length)
    ];
  }

  // Servicios para la exportación de data de la tablas

  exportTableToPdf(columns: InfoItem[], rows: Object[], fileName: string) {
    const doc = new jsPDF();
    doc.autoTable(columns, this._mapDataToPDF(rows));
    doc.save(fileName);
  }

  exportTableToExcel(columns: InfoItem[], rows: Object[], fileName: string) {
    const worksheet = xlsx.utils.json_to_sheet(
      this._mapDataToExcel(columns, rows)
    );
    const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
    this._saveAsExcelFile(excelBuffer, fileName);
  }

  exportTableToCSV(columns: InfoItem[], rows: Object[], fileName: string) {
    const replacer = (key, value) => value === null ? '' : value; // specify how you want to handle null values here
    const header = columns.map(col => col.header);
    rows = this._mapDataToExcel(columns, rows);
    const csv = rows.map(row => 
      header.map(fieldName => 
        JSON.stringify(row[fieldName], replacer)
      ).join(',')
    );
    csv.unshift(header.join(','));
    const csvArray = csv.join('\r\n');
    const blob = new Blob(['\ufeff' + csvArray], {type: 'text/csv' })
    FileSaver.saveAs(blob, fileName + CSV_EXTENSION);
  }
  

  /**
   * Transforma un array de objetos a un array de arrays con solo los valores.
   * @param rows Array de Objetos
   */
  private _mapDataToPDF(rows: Object[]) {
    let rowsMapped = [];
    rows.map(row => {
      let rowMapped = [];
      Object.keys(row).map(key => {
        rowMapped = [
          ...rowMapped,
          row[key]
        ]
      })
      rowsMapped = [
        ...rowsMapped,
        rowMapped
      ]
    })
    return rowsMapped;
  }

  /**
   * Mappea el nombre de los campos del array de objetos por los definidos en 
   * el array que contiene las columnas (field -> nombre del campo actual, header -> nombre
   * del campo mappeado a mostrar).
   * @param columns Array InfoItem que contiene los datos basicos de las columnas
   * @param rows Array de objetos que contiene la data de la tabla.
   */
  private _mapDataToExcel(columns: InfoItem[], rows: Object[]): Object[] {
    let rowsMapped = [];
    rows.map(row => {
      let rowMapped = {};
      Object.keys(row).map(key => {
        rowMapped = {
          ...rowMapped,
          [columns.find(col => col.field === key).header]: row[key]
        }
      })
      rowsMapped = [
        ...rowsMapped,
        rowMapped
      ]
    });
    return rowsMapped;
  }

  private _saveAsExcelFile(buffer: any, fileName: string): void {
    const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    const data: Blob = new Blob([buffer], {
        type: EXCEL_TYPE
    });
    FileSaver.saveAs(data, fileName + EXCEL_EXTENSION);
  }

}
