import { Usuario } from '../model/usuarios';
import { Adapter } from '../model/adapter';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CourseAdapter implements Adapter<Usuario> {
  adapt(item: any): Usuario {
    return new Usuario(
      item.idUsuario,
      item.nombre,
      item.apellido1,
      item.apellido2
    );
  }
}
