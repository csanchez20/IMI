import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { MAP_URL_SEGURIDAD_CINTRAOS, SessionQuery } from '../auth';
import { SeguridadKeysService } from '../auth/seguridad-keys.service';
import { HttpRestClientService } from './http-rest-client.service';


@Injectable({
  providedIn: 'root'
})
export class HttpRestClientCintraosService extends HttpRestClientService {

  constructor(
    public httpClient: HttpClient,
    public sessionQuery: SessionQuery
  ) { 
    super(
      httpClient, 
      environment.cintraos,
      new SeguridadKeysService(MAP_URL_SEGURIDAD_CINTRAOS),
      sessionQuery
    )
  }
  
}
