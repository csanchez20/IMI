export interface FiltrosFacturasProforma {
  dataInici: Date;
  dataFi: Date;
  empresa: number;
}

export interface CercaFacturasProforma {
  dataInici: String;
  dataFi: String;
  empresaGestoraId: number;
  numeroPagina?: number;
  tamanoPagina?: number;
  tipusRespostaDid?: number;
}

export interface RespuestaConsultaFacturaProforma {
  facturaProformaId: number,
  dataInici: string,
  dataFi: string,
  dataCreacio: string,
  tipusRespostaDid: number,
  periodeFacturacioDid: number,
  importPrevistAmbIva: number,
  importPrevistSenseIva: number,
  importFinalAmbIva: number,
  importFinalSenseIva: number,
  importRegularitzatAmbIva: number,
  importRegularitzatSenseIva: number,
  obert: boolean,
  modelFact: string,
  infoProveidor: InfoProveedor,
  infoEquipament: InfoEquipament,
  infoLicitador: InfoLicitador
}

export interface RespuestaCercaFacturasProforma {
  totalRegistres: number;
  llistaCercaFacturesProforma: ItemLlistaCercaFacturesProforma[];
}

export interface ItemLlistaCercaFacturesProforma {
  centreId: string;
  dataFi: number;
  dataInici: number;
  empresaGestoraId:  number;
  facturaProformaId:  number;
  importFinalAmbIva:  number;
  importFinalSenseIva:  number;
  importPrevistAmbIva:  number;
  importPrevistSenseIva:  number;
  importRegularitzatAmbIva:  number;
  importRegularitzatSenseIva:  number;
  nomCentre: string;
  nomEmpresaGestora: string;
  obert: boolean;
  tipusRespostaDid: number;
  actionIconVisible?: boolean[]; //Per poder amagar algun dels actionItems
}

export interface RegularitzarProforma {
  importRegularitzarAmbIva: number;
  importRegularitzarSenseIva: number;
}

export interface InfoProveedor {
  empresaGestoraId: number,
  nomComercial: string,
  raoSocial: string,
  cif: string,
  adreca: string,
  telefon: string,
  personaContacte: string
}

export interface InfoEquipament {
  centre: string,
  nomCentre: string,
  ubicacioId: number,
}

export interface InfoLicitador {
  raoSocial: string,
  cif: string,
  adreca: string
}