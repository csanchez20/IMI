export interface ServiciosPrestadosCentro {
  serveiContrCentreId: number;
  tipusServeiDid: number;
}

export interface ServiciosPrestados {
  recursId: number[];
  serveiContracteCentreId: number;
  dataPrestacio: string;
  numUnitats: number;
  mode?: 'PUT' | 'POST';
}

export interface ServiciosPrestadosPersona {
  nom: string;
  recursId: number[];
  expedientId: string;
}

export interface DefinicioServeiRDTO {
  definicioServeiId?: number;
  tipusPlacaDid?: number;
}

export interface ParamServiciosPrestadosCentro {
  centreId: string;
  dataPrestacio: string; // dd/MM/yyyy
}

export interface ParamServiciosPrestados extends ParamServiciosPrestadosCentro {
  tipusPlanificacioDid: string;
}

export interface ParamsCercaDefinicioServei {
  centreId?: string;
  dataInici?: string; // dd/MM/yyyy
  dataFinal?: string; // dd/MM/yyyy
  tipusPlanificacioDid?: string;
  tipusRespostaDid?: number;
  recursId?: number;
  serveiContracteCentreId?: number;
}
