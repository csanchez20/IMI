export class NotificacionLite {
    asunto: string;
    detalle: string;
    remitente: string;
    fechaNotificacion: string;
    adjunto: string;
    leido:boolean;
}