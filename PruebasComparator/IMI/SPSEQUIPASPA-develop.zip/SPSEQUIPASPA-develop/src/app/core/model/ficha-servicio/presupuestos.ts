export interface DetallePresupuesto {
  nombre: string;
  presupuesto: number;
  enTramite: number;
  enServicio: number;
  facturado: number;
  acumulado: number;
}

export interface FiltrosPresupuesto {
  dataInici?: Date;
  dataFi?: Date;
  vigent?: Boolean;
}

//--BACK--//

//REQUEST
export interface ConsultaPresupuestos {
  tipusRespostaDid: number;
  dataInici?: string;
  dataFi?: string;
  vigent?: true;
}

export interface NuevoPresupuesto {
  tipusRespostaDid: number;
  dataInici?: number;
  dataFi: number;
  partidaInicial?: number;
  periodeFacturacio: true;
}

export interface EditarPresupuesto {
  partidaInicial: number;
  periodeFacturacioDid?: number;
  dataFi: number;
}

//RESPONSE
export interface ResultadoConsultaPresupuestos {
  totalRegistres: number;
  llistaResultatsCercaPressupostServeiRDTO: ItemPresupuesto[];
}

export interface ResultadoGenerarEmpremtes {
  id: number;
}

export interface ItemPresupuesto {
  pressupostServeiId: number;
  partidaInicial: number;
  dataInici: number;
  dataFi: number;
  vigent: boolean;
}

export interface RespuestaAltaPressupostServei {
  pressupostServeiId: number;
}

export interface RespuestaPresupuesto {
  pressupostServeiId: number;
  tipusRespostaDid: number;
  partidaInicial: number;
  dataInici: number;
  dataFi: number;
  vigent: boolean;
  periodeFacturacioDid: number;
  territoriDid: number;
  capitolDid: number;
  empremtesGenerades: boolean;
  listResumTotal: RespuestaPresupuestoListResum[];
  listResumPeriodes: RespuestaPresupuestoListResum[];
}

export interface RespuestaPresupuestoListResum {
  dataIniciPeriode: number;
  dataFiPeriode: number;
  partidaDisponible: number;
  partidaEspera: number;
  partidaTramit: number;
  partidaServei: number;
  partidaFacturat: number;
}

export interface RespuestaEditarPresupuesto {
  pressupostServeiId: number;
}
