import { ResultatCercaDocumentRDTO } from "../equipaments";

export class CercaSauvRDTO {
  campGoogle?:string;
  cognom1Usuari?: string;
  cognom2Usuari?: string;
  dataFiSollicitud?: Date;
  dataIniciSollicitud?: Date;
  estatSollicitud?: number;
  nomUsuari?: string;
  onEsTrobaUsuariDid?: number[];
  numeroPagina?: number;
  tamanyPagina?: number;

  constructor() {
    if (!this.numeroPagina) {
      this.numeroPagina = 1;
    }

    if (!this.tamanyPagina) {
      this.tamanyPagina = 5;
    }
  }
}

export class ResultatCercaSauvRDTO {
  sollicitudId: number;
  expedientId: string;
  nom: string;
  cognom1: string;
  cognom2: string;
  numeroDocumentIdentitat: string;
  dataCreacio: Date;
  estatSollicitud: number;
  centreCss: number;
  centreSalut: number; // Si viene informado centreSalut se prioriza, sino centreCSS.
  onEsTrobaUsuariDid: number;
  onEsTrobaUsuari: string;
}

export interface PaginacionCercaSAUV {
  content?: ResultatCercaSauvRDTO[];
  pageNumber?: number;
  pageSize?:number;
  total?: number;
  count?: number;
}

export interface ResultatConsultaSauvRDTO {
  casComplexAutoritzat: boolean;
  casComplexDocAdjunt: string;
  casComplexDocAdjuntId: string;
  casComplexJustificacio: string;
  ctxAcompanyamentEmocional: string;
  ctxDadesSocioFamiliars: string;
  ctxDeixaAnimals: boolean;
  ctxDeixaAnimalsObs: string;
  ctxIndicisMaltractamentAbus: boolean;
  ctxIndicisMaltractamentObs: string;
  ctxInformacioRellevant: string;
  dadesSollicitudOriginal: string;
  dataActualitzacioEstat: Date;
  dataSollicitud: Date;
  documentCartaServeis: ResultatCercaDocumentRDTO;
  documentFullConsentimentIngres: ResultatCercaDocumentRDTO;
  documentInformeMedic: ResultatCercaDocumentRDTO;
  documentSentenciaJudicialAutoritzacio: ResultatCercaDocumentRDTO;
  documentSentenciaJudicialIncapacitacio: ResultatCercaDocumentRDTO;
  estatSollicitud: number;
  expedientId: string;
  ingresAcceptat: boolean;
  instanciaFluxId: number;
  motiuEstat: string;
  sollicitudId: number;
  urgFetPrecipitantDid: number;
  urgFetPrecipitantObs: string;
  urgIngresInvoluntari: boolean;
  urgMotiuDemanda: number;
  urgPerfilUsuariAltres: string;
  urgPerfilUsuariDid: number;
  urgQuiPlantejaDid: number;
  urgSociosanitariDid: number;
  urgUbicacioActualDid: number;
  usuariCognom1: string;
  usuariCognom2: string;
  usuariNom: string;
  usuariCreacio: string;
}

export class ModificaEstatSauvRDTO {
  entitatExternaId: number;
  estatIdDesti: number;
  instanciaId: number;
  observacions: string; 
}

export interface ResultatModificaEstatSauvRDTO {
  instanciaId: number;
}

export interface JustificacionCasoComplejoRDTO {
  justificacio: string;
  autoritzacioDirector: boolean;
  adjunts: string[];
}

export class ParamsLlistatInformeSauvRDTO {
  dataInici?: string;
  dataFi?: string;
  numeroPagina?: number;
  tamanyPagina?: number;

  constructor(tamanyPagina?: number, numeroPagina?: number) {
    this.numeroPagina = numeroPagina ? numeroPagina : 1;
    this.tamanyPagina = tamanyPagina ? tamanyPagina : 5;
  }
}

export interface ResultatLlistatSollicitudsSauvRDTO {
  sollicitudId: number;	
  expedientId: string;
  nom: string;
  cognom1: string;
  cognom2: string;
  document: string;	
  dataCreacio: Date;
  estatSollicitud: number;
  centreCss: string;	
  centreSalut: number;	
  onEsTrobaUsuariDid: number;
  dataNaixement: Date;
  nacionalitatDid: number;	
  professionalReferent: string;
}


export interface ResultatLlistatUsuarisSauvRDTO {
  nom: string;
  cognom1: string;
  cognom2: string;
  document: string;	
  dataNaixement: Date;
  genereDid: number;
  pevGrauDid: number;	
  pevDataResolucio: Date;	
  dataIngresResidencia: Date;
  dataFiResidencia:Date;
  centre: string;	
  copagamentUsuari:number;
  aportAjuntamentCostResiden: number;
  dataIniciPacte:Date
}

