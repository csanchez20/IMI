
export interface ParametreCercaRDTO {
  comptador: number;
  llistaCercaParametres: ParametreResultsRDTO[];
}

export interface ParametreLlistaRDTO {
  comptador: number;
  llistaCercaParametres: ParametreResultsRDTO[];
}

export interface ParametreResultsRDTO {
  parametreId: number;
  codiParametre: string;
  nom: string;
  descripcio: string;
  valor: string;
  dataCreacio: number;
  dataModificacio: number;
  usuariCreacio: string;
  usuariModificacio: string;
}

export interface ParametreRebutsCercaRDTO {
  codiParametre?: string;
  nom?: string;
  descripcio?: string;
  valor?: string;
}

export interface ParametreRebutsLlistaRDTO {
  codiParametre: string;
  nom: string;
  descripcio: string;
  valor: string;
}