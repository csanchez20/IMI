import { ResultatCercaDocumentRDTO } from "../equipaments";

export interface PaginacionCercaRESPIRPLUS {
    content?: ResultatCercaRespirPlusRDTO[];
    pageNumber?: number;
    pageSize?:number;
    total?: number;
    count?: number;
}

export interface ResultatCercaRespirPlusRDTO {
    centre?: string;
    cognom1?: string;
    cognom2?: string;
    nom?: string;
    dataCreacio?: Date;
    estatSollicitud?: number;
    expedientId?: string;
    numeroDocumentIdentitat?: string;
    periodeSollicitat?: string;
    sollicitudId?: string;
}

export class ModificaEstatRespirPlusRDTO {
    entitatExternaId: number;
    estatIdDesti: number;
    instanciaId: number;
    observacions?: string; 
  }

export interface ResultatConsultaRespirPlusRDTO{
    sollicitudId?: number;
    instanciaFluxId?: number;
    dadesSollicitudOriginal?: string;
    documentDniCuidador?: ResultatCercaDocumentRDTO;
    documentDniSollicitant?: ResultatCercaDocumentRDTO;
    usuariCognom1?: string;
    usuariCognom2?: string;
    usuariNom?: string;
    usuariDataNaixement?: Date; 
    usuariDocument?: string;
    usuariTipusDocument?: number;
    expedientId?: string;
    dataSollicitud?: Date;
    estatSollicitud?: number;
    motiuEstat?: string;
    dataActualitzacioEstat?: Date;
    centreCss?: string;
    periodeSollicitat?: number;
    periodeAtorgat?: number; // Dies Atorgats
    preuPerDia?: number; 
    importTotal?: number; 
    estatSollicitudRespir?: string; 
    dataSollicitudRespir?: Date; 
    motiuEstatSollicitudRespir?: string;
    periodesSollicitatsRespir?: RespirDadesPeriodesRDTO; 
    cuidador?: RespirPlusDadesCuidadorRDTO;
    ec?: RespirPlusDadesEfectesComunicacioRDTO;
    recursActiu?: boolean;
    rendaAnual: number;
}

export interface RespirPlusDadesCuidadorRDTO{
    expedient: string;
    nom: string;
    cognoms: string;
    tipusDocumentDid: number;
    document: string;
    parentiuDid?: number;
    edat?: number;
    genereDid?: number;
    telefon: string;
    adreca?: string;
    email: string;
    poblacioAdreca: string;
    convivencia: boolean;
    codiPostalAdreca?: string;
    comunicacionsCorreuPostal?: boolean;
}

export interface RespirPlusDadesEfectesComunicacioRDTO {
    nom: string;
    cognoms: string;
    parentiuDid?: number;
    sexe?: number;
    telefon: string;
    adreca?: string;
    poblacioAdreca: string;
    codiPostalAdreca?: string;
}

export interface RespirDadesPeriodesRDTO{
    dataInici: Date;
    dataFi: Date;
}

export interface CalculRespirPlusRDTO{
    periodeAtorgat: number;
    preuPerDia: number;
    importTotal: number;
    convivencia: boolean;
}

export interface ResultatAltaRespirPlusRDTO{
    sollicitudId: number;
}
