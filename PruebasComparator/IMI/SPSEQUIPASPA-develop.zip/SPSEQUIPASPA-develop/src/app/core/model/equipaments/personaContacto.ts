export interface PersonaContacteCercadesRDTO {
  id: number;
  centreId: string;
  nom: string;
  telefon1: string;
  telefon2: string;
  correuElectronic: string;
  actiu: boolean;
}

export interface PersonaContacteRDTO extends PersonaContacteCercadesRDTO {
  comentaris: string;
}

export class PersonaContacteIdRDTO {
  personaContacteId: number;
}
