import { ResultatCercaDocumentRDTO } from "../equipaments";
import { CalculRespirPlusRDTO } from "./solicitud-respirplus";

export interface CercaRespirRDTO {
    cognom1Usuari?: string;
    cognom2Usuari?: string;
    nomUsuari?: string;
    dataIniciSollicitud?: Date; 
    dataFiSollicitud?: Date;  
    estatSollicitud?: number;
    idSollicitud?: number;
    periodePreferent?: number;
    numeroPagina?: number;
    tamanyPagina?: number;
  }

  export interface ResultatCercaRespirRDTO {
      centre?: string;
      cognom1?: string;
      cognom2?: string;
      nom?: string;
      dataCreacio?: Date;
      estatSollicitud?: number;
      expedientId?: string;
      numeroDocumentIdentitat?: string;
      periodeSollicitat?: string;
      sollicitudId?: string;
  }

  export interface PaginacionCercaRESPIR {
    content?: ResultatCercaRespirRDTO[];
    pageNumber?: number;
    pageSize?:number;
    total?: number;
    count?: number;
  }

  export interface ResultatConsultaRespirRDTO{
    sollicitudId?: number;
    instanciaFluxId?: number;
    dadesSollicitudOriginal?: string;

    //Datos basicos
    usuariCognom1?: string;
    usuariCognom2?: string;
    usuariNom?: string;
    usuariDataNaixement?: Date; 
    usuariDocument?: string;
    expedientId?: string;
    dataSollicitud?: Date;
    estatSollicitud?: number;
    estatSollicitudRespir?: number;
    motiuEstat?: string;
    dataActualitzacioEstat?: Date;
    estatSollicitudRespirPlus?: string; 
    dataSollicitudRespirPlus?: Date;
    motiuEstatSollicitudRespirPlus?: String;
    centreCss?: string;
    periodeConcedit?: RespirDadesPeriodesRDTO;

    //Datos solicitud
    //Derivacion
    motiuDerivacio?: number;
    motiuAltres?: string;
    //Periodo solicitud
    periodeDisponible: boolean,
    periodePendentDates: boolean,
    periodesSollicitats?: RespirDadesPeriodesRDTO[];
    //Datos cuidador
    cuidador?: RespirDadesCuidadorRDTO;
    // Documentos Adjuntos
    documentDni: ResultatCercaDocumentRDTO;
    documentInformeMedic: ResultatCercaDocumentRDTO;
    documentInformeSocial: ResultatCercaDocumentRDTO;
    documentPerfilSollicitant: ResultatCercaDocumentRDTO;
    documentTargetaSanitaria: ResultatCercaDocumentRDTO;
  }

  export interface RespirDadesCuidadorRDTO{
      expedient: string;
      nom: string;
      cognom1: string;
      cognom2: string;
      tipusDocument: number;
      document: string;
      parentiu?: number;
      dataNaixement?: number;
      telefon: string;
      altresTelefons?: string;
      adreca?: string;
      email: string;
      poblacio: string;
      codiPostal?: string;
      comunicacioSMS: boolean;
  }

  export interface RespirDadesPeriodesRDTO{
    dataInici: Date;
    dataFi: Date;
  }

  export interface ResultatModificaEstatRespirRDTO {
    instanciaId: number;
  }

  export class ModificaEstatRespirRDTO {
    entitatExternaId: number;
    estatIdDesti: number;
    instanciaId: number;
    observacions?: string; 
  }

