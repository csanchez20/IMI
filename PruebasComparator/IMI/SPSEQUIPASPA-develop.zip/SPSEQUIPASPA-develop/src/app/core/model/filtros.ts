export interface OptionsDateRange {

    formControlName: string;
    keyStart?: string;
    keyEnd?: string;

}