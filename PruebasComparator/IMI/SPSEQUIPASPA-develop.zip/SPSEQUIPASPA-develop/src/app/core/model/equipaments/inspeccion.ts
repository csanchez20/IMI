export interface InspeccioCercadesRDTO {
  id: number;
  tipusInspeccioDid: number;
  dataInspeccio: number;
  idProfessionalDocument: string; 
  nomProfessionalDocument: string; 
  document: string; 
  actiu: boolean; 
}

export interface InspeccioRDTO extends InspeccioCercadesRDTO {
  comentaris: string;
  centreId: string;
}

export interface InspeccioIdRDTO {
  inspeccioId: number;
}