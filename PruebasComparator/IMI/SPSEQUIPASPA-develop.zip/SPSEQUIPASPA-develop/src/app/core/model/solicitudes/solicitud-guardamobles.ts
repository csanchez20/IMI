import { PersonaAutoritzada, ConsultaAdrecaRDTO } from '..';

export class ModificaEstatResidusGuardamoblesRDTO {
  aprovada?: boolean;
  observacions?: string;
  dataPublicacioBoe?: number;
}

export class ModificaEstatGuardamoblesRDTO {
  entitatExternaId: number;
  estatIdDesti: number;
  instanciaId: number;
  observacions?: string;
}

export interface ResultatModificaEstatGuardamobles {
  instanciaId: number;
}

export interface PaginacionCercaGuardamobles {
  content?: ResultatCercaGuardamobles[];
  pageNumber?: number;
  pageSize?: number;
  total?: number;
  count?: number;
}

export interface ResultatCercaGuardamobles {
  centre?: string;
  cognom1?: string;
  cognom2?: string;
  nom?: string;
  dataCreacio?: Date;
  estatSollicitud?: number;
  expedientId?: string;
  numeroDocumentIdentitat?: string;
  sollicitudId?: string;
}

export interface ResultatConsultaGuardamoblesRDTO {
  adrecaDescarrega1?: number; // Si és Domicili a Domicili, no cal informar la direccio del Guardamobles
  adrecaDescarrega2?: number; // Si és Domicili a 2 Domicili
  adrecaRecollida: number;
  centreCss: string;
  dadesSollicitudOriginal: string;
  dataActualitzacioEstat: Date;
  dataDesnonament: number;
  dataRecollida: number;
  dataSollicitud: number;
  detallsTrasllat: string;
  estatSollicitud: number;
  expedientId: string;
  instanciaFluxId: number;
  motiuEstat: string;
  motiuSollicitud: number;
  professionalPrescriptor?: string;
  relacioBens: string;
  sollicitudId: number;
  tipusTrasllat: number; //A borrar
  tipusPeticio: number; //Canviar a tipusPeticio //tipusTrasllat
  usuariNom: string;
  usuariCognom1: string;
  usuariCognom2: string;
  usuariDataNaixement: number;
  usuariTipusDocument: number;
  usuariDocument: string;
  personaAutoritzada?: PersonaAutoritzada;
  altresPersonesAut?: string;
  valoracioEconomica: number;
  numCaixes?: number;
  autoritzat_nom_complet: string;
  autoritzat_num_complet: string;
}
