export class ParamsCercaContracte {
    contracteId?: number;
    dataFinal?: string;
    dataInici?: string;
    estatDid?: number;
    nomComercial?: string;
    numeroExpedient?: string;
    numeroPagina?: number;
    tamanoPagina?: number;
    tipusRespostaDid?: number;

    constructor(tipusRespostaDid?: number, tamanoPagina?: number, numeroPagina?: number) {
        if (tipusRespostaDid) {
            this.tipusRespostaDid = tipusRespostaDid;
        }
        this.numeroPagina = numeroPagina ? numeroPagina : 1;
        this.tamanoPagina = tamanoPagina ? tamanoPagina : 5;
    }
}

export interface ContracteCercadesRDTO {
    contracteId: number;
    dataFinal: string;
    dataInici: string;
    empresaGestoraId: number;
    estatDid: number;
    nomComercial: string;
    numeroExpedient: string;
}

export interface ModificaContracteRDTO {
    dataFinal: string;
    dataInici: string;
    durada: number;
    importAmbIva: number;
    importSenseIva: number;
    numeroExpedient: string;
    tipologiaContracteDid: number;
}

export interface ContracteRDTO extends ModificaContracteRDTO { 
    contracteId?: number; 
    empresaGestoraId: number;
    estatDid: number;    
    prioritat?: number;
    tipusRespostaDid: number;
    periodeFacturacioDid?: number;
}

export interface ContracteIdRDTO {
    contracteId: number;
}