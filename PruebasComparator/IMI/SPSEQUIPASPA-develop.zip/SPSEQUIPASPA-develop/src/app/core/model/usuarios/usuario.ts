import { Direccion } from '.';
import { ResultatCercaDocumentRDTO } from '../equipaments';
import { Persona } from '../information';
import { BlocExpedientUbicacioDTO } from '../persona';
import { GGPlacaPublica } from './recursos';

export const TIPO_PACTO_GERIATRIA = 2038101;
export const TIPO_PACTO_LIMPIEZA = 2038102;
export enum PactosA {
  TIPO_PACTO_GERIATRIA = 'Geriatria',
  TIPO_PACTO_LIMPIEZA = 'Neteja'
}
export class UsuarioLiteFiltros {
  //actiu = true;
  campGoogle?: string;
  document?: string;
  expedientId?: string;
  nomComplet?: string;
  numeroPagina?: number;
  servei?: number;
  tamanyPagina?: number;

  constructor(servicio?: number, tamanyPagina?: number, numeroPagina?: number) {
    if (servicio) {
      this.servei = servicio;
    }
    this.numeroPagina = numeroPagina ? numeroPagina : 1;
    this.tamanyPagina = tamanyPagina ? tamanyPagina : 5;
  }
}

// Formato que devolvera SPSequipa para un UsuariLite
export class UsuarioLite {
  expedientId: string;
  nom: string;
  cognom1: string;
  cognom2: string;
  nomComplet: string;
  document: string;
  dataNaixement: Date;
  centre: string;
  nomCentre: string;
  professionalId: string;
  nomProfessional: string;
  cognom1Professional: string;
  cognom2Professional: string;
  nomCompletProfessional: string;
  habilitat: boolean;
  actiu: boolean;
}

export class Usuario {
  apodo?: string;
  genero?: string;
  fechaNacimiento?: string;
  pais?: string;
  nacionalidad?: string;
  direccion?: Direccion;
  servicios?: string[];
  personas: Persona[];
  personasOtras?: Persona[];
  personasUC?: Persona[];
  tipoDocIdentificacion?: string;
  numeroDocIdentificacion?: string;
  edad?: number;
  telefono1?: string;
  telefono2?: string;
  centroAtencion?: string;
  datosProfesional?: string;
  constructor(
    public idUsuario: string,
    public nombre: string,
    public apellido1: string,
    public apellido2: string
  ) {}
}

export class UsuarioDocumentacion {
  idUsuario: string;
  titol: string;
  dataCreacio: string;
  tipus: string;
  pujatPer: string;
  descripcio: string;
  idFile?: string;
  file?: File;
}

export class UsuarioFiltersDoc {
  dataCreacio: string;
  dataModificacio: string;
  tipus: string;
  pujatPer: string;
}

export class UserSearchParams {
  idProvider?: number;
  idIncidence?: number;
}

export class AtencioOberta {
  tipo: string;
  fecha: number;
}
////////////////////////////// PRUEBAS CON SERVICIO /////////////////////////////

export class PersonaRelacion {
  cognom1: string;
  cognom2: string;
  dataNaixement: string;
  document: string;
  expedientId: string;
  genereDid: number;
  nom: string;
  telefon1: string;
  tipusDocumentDid: number;
  relacioDid?: number;
}

export interface ResponsePutUsuario {
  expedientId: string;
}

export interface UsuarioPruebaServicio {
  expedientId: string;
  blocBasiques: BlocUsuBasiquesDTO;
  blocComplementaries: BlocUsuComplementariesDTO;
  blocEconomiques: BlocUsuEconomiquesDTO;
  blocSalut: BlocUsuSalutDTO;
  blocEIA: {
    ubicacioEaiaDid: number;
    canalEntradaDid: number;
    dataCreacio: number;
    dataModificacio: number;
    usuariCreacio: string;
    usuariModificacio: string;
    centreCreacio: string;
    centreModificacio: string;
    actiu: boolean;
  };
  blocUsuari: BlocUsuarioDTO;
  blocExpedient?: BlocUsuarioDTO; // chapu de cintraos, al ahcer PUT hay que cambiar blocUsuari por blocExpedient
  blocPU: BlocUsuPUDTO;
  listBlocExpedientUbicacio?: BlocExpedientUbicacioDTO[];
  blocTestPfeiffer?: BlocTestPfeifferDTO;
  blocTestBarthel?: BlocTestBarthelDTO;
  blocHabitatge?: BlocHabitatgeDTO;
  // listBlocBancaries: [];
}

export interface BlocUsuEconomiquesDTO {
  ingressosMensuals: number;
  viaPercepcio1Did: number;
  viaPercepcio2Did: number;
  dataCreacio: number;
  dataModificacio: number;
  usuariCreacio: string;
  usuariModificacio: string;
  centreCreacio: string;
  centreModificacio: string;
  actiu: string;
}

export interface BlocTestPfeifferDTO {
  testId?: number;
  expedientId?: string;
  dataRealitzacio?: number;
  puntuacio?: number;
  tipusTestDid?: number;
  preguntes?: PreguntaDTO[];
}

export interface PreguntaDTO {
  preguntaId?: number;
  testId?: number;
  preguntaDid: number;
  respostaDid?: number;
}

export interface BlocTestBarthelDTO {
  testId?: number;
  expedientId?: string;
  dataRealitzacio?: number;
  puntuacio?: number;
  tipusTestDid?: number;
  preguntes?: PreguntaDTO[];
}

export interface BlocHabitatgeDTO {
  estatEconomicHabitatgeDid: number; //2018000
  expedientId: string;
  quantitat: number;
  tipusHabitatgeDid: number; // 10110
  tipusPropietariHabitatgeDid: number; // 2017000
}

export interface UsuariCercadesRDTO {
  blocBasiques: BlocUsuBasiquesDTO;
  blocUsuari: BlocUsuarioDTO;
}

export interface BlocUsuarioDTO {
  actiu: boolean;
  aplicacioAlta: number;
  centre: string;
  centreAlta: string;
  centreCreacio: string;
  centreModificacio: string;
  centreTancament: string;
  dataCreacio: number;
  dataModificacio: number;
  dataTancament: number;
  estatIntervencioDid: number;
  expedientId: string;
  habilitat: boolean;
  motiuTancamentDid: number;
  responsableId: string;
  serveiIntervencioDid: number;
  tipusExpedient: string;
  tipusNfcDid: number;
  ultimEpisodiId: number;
  usuariCreacio: string;
  usuariModificacio: string;
  usuariTancament: string;
}

export interface BlocUsuBasiquesDTO {
  expedientId: string;
  nom: string;
  cognom1: string;
  cognom2: string;
  genereDid: number;
  tipusDocumentDid: number;
  document: string;
  telefon1: number;
  telefon2: number;
  numSeguretatSocial: number;
  nacionalitatDid: number;
  paisNaixementDid: number;
  provNaixementDid: number;
  situacioLegalDid: number;
  canalEntradaDid: number;
  dataNaixement: number;
  observacions: string;
  anyArribada: number;
  alies: string;
  teAlias: boolean;
  teAdreca: boolean;
  teTelefon: boolean;
  foraTerritori: boolean;
  pendentRevisio: boolean;
  modificarPendentRevisio: boolean;
  requereixSms: boolean;
  canalEntrada2Did: number;
  codiMibPersona: number;
  codiMibPadro: number;
  codiMibNegoci: number;
  nomN: string;
  cognom2N: string;
  cognom1N: string;
  telefon3: number;
  telefon4: number;
  descripcioTelefon1: string;
  descripcioTelefon2: string;
  descripcioTelefon3: string;
  descripcioTelefon4: string;
  tipusTelefon1Did: number;
  tipusTelefon2Did: number;
  tipusTelefon3Did: number;
  tipusTelefon4Did: number;
  teConsentiment: boolean;
  dataConsentimentLopd: string;
  email: string;
  teConsentimentDona: boolean;
  dataConsentimentDona: string;
  teConsentimentImd: boolean;
  dataConsentimentImd: string;
  tipusIoImss: string;
  tipusIoImd: string;
  tipusIoQvie: string;
  teConsentimentFamiliar: string;
  teConsentimentDonaFamiliar: string;
  teConsentimentImdFamiliar: boolean;
  actiu: true;
  dataTancament: string;
  motiuTancamentDid: number;
  dataCreacio: string;
  dataModificacio: string;
  usuariCreacio: string;
  usuariModificacio: string;
  centreAlta: string;
  centreModificacio: string;
}

export interface BlocUsuSalutDTO {
  actiu: boolean;
  ambulatoriRefrenciaDid: number;
  antecedentsPsiq: string;
  atesEquipDid: number;
  baremDependencia: boolean;
  baremMobilitat: boolean;
  cadiraRodesDid: number;
  casReferencia: string;
  casReferenciaActual: string;
  centreCreacio: string;
  centreModificacio: string;
  centreTractamentTox: string;
  crossesDid: number;
  dataCreacio: string;
  dataEfecte: string;
  dataModificacio: string;
  dataVenciment: string;
  discapacitat1Did: number;
  discapacitat2Did: number;
  discapacitat3Did: number;
  esmDataDiagnostic: string;
  esmDiagnostic: string;
  esmInstitucio: string;
  esmPassatTractament: string;
  esmProfessional: string;
  esmTipusTractament: string;
  estaEnTractament: boolean;
  estaTractamentTox: boolean;
  estatCertificatDid: number;
  expedientId: string;
  grauDiscapacitat: number;
  grupGrauDiscapacitatDid: number;
  malaltiesCroniques: string;
  malaltiesInfeccioses: string;
  malaltiaMentalDid: number;
  malaltiaMentalObservacions: string;
  malaltiaInfecciosaDid: number;
  malaltiaInfecciosaObservacions: string;
  malaltiaCronicaDid: number;
  malaltiaCronicaObservacions: string;
  necessitaAcompanyant: boolean;
  numTargetaSalut: string;
  observacions: string;
  psmNumingresos: number;
  psmTempsIngressat: number;
  taxiAdaptat: boolean;
  teAntecedentsPsiq: boolean;
  teAntecentsTox: boolean;
  teDiscapacitat: boolean;
  teMalaltiesCroniques: boolean;
  teMalatiesInfeccioses: boolean;
  teTuberculosi: boolean;
  tipusCoberturaDid: number;
  toxicomaniaDid: number;
  toxicomaniaTipusDid: number;
  toxicomaniaTipusAltres: string;
  toxicomania1Did: number;
  toxicomania2Did: number;
  toxicomania3Did: number;
  usuariCreacio: string;
  usuariModificacio: string;
  validesaReconeixementDid: number;
}

export interface BlocUsuPUDTO {
  numeroRegistre: number;
  tipusResolucioDid: number;
  numeroResolucio: number;
  diagnosticCas: string;
  dataCreacio: number;
  dataModificacio: number;
  usuariCreacio: number;
  usuariModificacio: number;
  centreCreacio: number;
  centreModificacio: number;
  actiu: boolean;
  informacio: string;
  novolRebreInformacio: boolean;
  dataCaducitat: string;
}

export interface BlocUsuComplementariesDTO {
  situacioLaboralDid?: number;
  professio?: string;
  estaEscolaritzat?: boolean;
  escolaDid?: number;
  situacioEscolarDid?: number;
  nivellInstruccioDid?: number;
  enProcesIncapacitat?: string;
  estatProcesIncapacitatDid?: number;
  tutorLegal?: string;
  estatCivilDid?: number;
  observacions?: string;
  esNouvingut?: string;
  dataNouvingut?: string;
  hiHaMotiuConsulta?: string;
  motiuConsulta?: string;
  necessitaTraductor?: string;
  idiomaDid?: number;
  relacioAmbServeisMunicipals?: string;
  dataCreacio?: string;
  dataModificacio?: string;
  usuariCreacio?: string;
  usuariModificacio?: string;
  centreCreacio?: string;
  centreModificacio?: string;
  actiu?: string;
  dataEstatIncapacitat?: string;
  sectorDid?: number;
  professioComboDid?: number;
  fillsMenorsHome?: string;
  fillsMenorsDona?: string;
  fillsMenorsDesc?: string;
  fillsMenorsTotal?: string;
  fillsTotalHome?: string;
  fillsTotalDona?: string;
  fillsTotalDesc?: string;
  fillsTotalTotal?: string;
}

export interface PlanTrabajo {
  aspectoEmocional: string;
  propuestaPlanTrabajo: string;
}

export interface ActividadBasica {
  idTest: string;
  alimentacio: string;
  vestir: string;
  deambolar: string;
  toaleta: string;
  trasllat: string;
}

export interface DatosBancarios {
  iban: string;
  swift: string;
}

export interface PriorizacionDependencia {
  solicitante: string;
  dataSolicitud: Date;
  acuseRecibo: string;
  detalles: string;
}

export interface PEV {
  expedientId?: string;
  pevDataEfectes: number;
  pevDataResolucio: number;
  pevDataSollicitut: number;
  pevImportRebut: number;
  pevGrauDid: number;
  pevNumeroDeGrau: string;
  pevPuntuacio: number;
  usuariGGId: number;
}

export interface PersonaDatosEconomicos {
  id?: string;
  tipoUsuario: string;
  nombre: string;
  apellido1: string;
  apellido2: string;
  dni: string;
  informacionVinculadaDependencia: string;
  ingresos: number;
  ahorros: number;
  rendimientos: number;
}

export interface SituacionVivienda {
  tipoVivienda: string; // en propiedad, alquiler, etc
  titular: string;
  estado: string;
  cantidad: number; // cuota alquiler, etc
}

export interface IncapacidadLegal {
  tutorFundacion: string;
  fechaSolicitud: Date;
  fechaSentencia: Date;
  direccion: Direccion;
  telefono: number;
  email: string;
  detalles: string;
}

export interface PIAActiva {
  datos: DatosPia;
  estados: EstadoPIA[];
}

export interface DatosPia {
  nombreProfesional: string;
  servicio: string;
  grado: string;
  pia: string;
  fechaSolicitud: Date;
  fechaResolucion: Date;
}

export interface EstadoPIA {
  fecha: Date;
  detalle: string;
}

export interface RevisionPia {
  fechaInicioTramite: Date;
  fechaEnvio: Date;
}

export interface RevisionGrado {
  fechaSolicitud: Date;
  fechaValoracion: Date;
  resolucion: string;
  grado: string;
}

export interface SituacionPersonal {
  id: string;
  personaSolicitante: string;
  hechoDesencadenante: string;
  ingresoVoluntario: boolean;
  personas: Persona[];
}

export interface Ingresos {
  rentaFAT: number;
  rentaNoTributa: number;
  rendimientoCapital: number;
  total: number;
}

export interface Gastos {
  hipotecaAlquiler: string;
  hipotecaAlquilerUsuari: string;
  total: string;
}

export interface Copago {
  totalAutomatico: number;
  dataTotalAuto: number;
  dataCalculo: number;
  dataAcuerdo: number;
}

export interface CopagoGastos {
  ingresos: Ingresos;
  gastos?: Gastos;
  copago?: Copago;
}

export class Observacion {
  id: number;
  expedientId: string;
  professionalId: string;
  nomProfessional: string;
  tipusComentariDid: number;
  assumpte: string;
  detall: string;
  dataCreacio?: number;
}

export interface RegistroAtencion {
  accion: string;
  fechaInicio: Date;
  fechaFin: Date;
  informacion: string;
}

export interface ConsentimientoInformado {
  centreId?: string;
  consentimentId?: number;
  dataEstatConsentiment?: number;
  dataVigencia?: number;
  document?: string;
  estatConsentimentDid?: number;
  expedientId?: string;
  tractamentDid?: number;
}

export interface ParamsCercaConsentimiento {
  expedientId?: string;
  tipusRespostaDid?: number;
}

export interface ConsentimentIdRDTO {
  consentimentId: number;
}

export interface CercaRespostaResponse {
  dataFi: number;
  dataInici: number;
  dataIngres: number;
  dataSortida: number;
  ambitRecursDid?: number; // 60000
  esDisponible?: boolean;
  estatRecursDid?: number; // 90000
  expedientId?: string;
  expedientIdIntervencio?: string;
  informacioDonada?: string;
  intervencioServeiId?: number; // ??
  numRecurs?: number;
  observacions?: string;
  recursId: number;
  teUrl?: boolean;
  tipusRecursDid?: number; // pare 63000
  tipusRespostaDid?: number; // 100900 informacio, tramitació
  urgent?: boolean;
}



export class ParamsRespostaResponse {
  expedientId: string;
  estatRecursDid: number;
  tamanoPagina: number;
  numeroPagina: number;

  constructor(expedientId: string, estatRecursDid: number, tamanoPagina?: number, numeroPagina?: number) {
    this.numeroPagina = numeroPagina ? numeroPagina : 1;
    this.tamanoPagina = tamanoPagina ? tamanoPagina : 5;
    this.expedientId = expedientId;
    this.estatRecursDid = estatRecursDid;
  }
}

export interface ConsultaRespostaResponse{
  ambitRecursDid?: number;
  dataFi: number;
  dataInici: number;
  esDisponible: boolean;
  estatRecursDid: number;
  informacioDonada: string;
  numRecurs: number;
  observacions: string;
  recursId: number;
  teUrl: boolean;
  tipusRecursDid: number;
  tipusRespostaDid: number;
  urgent: boolean;
}

/* export interface ConsentimientoInformado{
  nombreTratamiento: string;
  estado: string;
  dataVigencia: Date;
  servicio: string;
  documento: string;
  check: boolean;
  requerido: boolean;
} */
/* OLD PACTE ATENCIÓ */
export interface PactoAtencionPOST {
  recursId: number;
  dataPacte: number;
  totalHores: number;
  tipusPacteDid: number; // 2038101,
  documentPacte: string; // base64 file
  nomDocumentPacte: string;
  extensioDocumentPacte: string;
}

export interface PactoAtencion {
  pacteAtencioId: number;
  recursId: number;
  dataPacte: number;
  totalHores: number;
  tipusPacteDid: number; // 2038101,
  documentPacteId: string;
  documentPacte?: string; // base64 file
}

export interface PactoAtencionPUT {
  dataPacte: number;
  totalHores: number;
  documentPacte?: string; // base64 file
  nomDocumentPacte?: string;
  extensioDocumentPacte?: string;
}

export interface PactoAtencionSearchParams {
  recursId: number;
}

/* NEW PACTE ATENCIÓ */
export interface PactoAtencionGNPOST {
  recursId: number;
  dataIniciGeriatria?: number,
  diaSetmanaGeriatria?: string,
  horariGeriatria?: string,
  frequenciaGeriatria?: string,
  dataFiGeriatria?: number,
  checkRenunciaGeriatria?: boolean,
  dataRenunciaGeriatria?: number,
  //neteja
  dataIniciNeteja?: number,
  diaSetmanaNeteja?: string,
  horariNeteja?: string,
  frequenciaNeteja?: string,
  dataFiNeteja?: number,
  checkRenunciaNeteja?: boolean,
  dataRenunciaNeteja?: number,
}

export interface PactoAtencionGN {
  pacteAtencioId: number;
  dataIniciGeriatria?: number,
  diaSetmanaGeriatria?: string,
  horariGeriatria?: string,
  frequenciaGeriatria?: string,
  checkRenunciaGeriatria?: boolean,
  dataRenunciaGeriatria?: number,
  //neteja
  dataIniciNeteja?: number,
  diaSetmanaNeteja?: string,
  horariNeteja?: string,
  frequenciaNeteja?: string,
  checkRenunciaNeteja?: boolean,
  dataRenunciaNeteja?: number,
  // documentacio
  documentPacteAtencio?: ResultatCercaDocumentRDTO;
  documentRenuncia?: ResultatCercaDocumentRDTO;
}

export interface PactoAtencionGNPUT {
  dataPacte: number;
  totalHores: number;
  documentPacte?: string; // base64 file
  nomDocumentPacte?: string;
  extensioDocumentPacte?: string;
}

export interface PactoAtencionGNSearchParams {
  recursId: number;
}

export interface PacteAtencioIdRDTO {
  pacteAtencioId: number;
}

//

export interface CercaUsuarisPlacaPublica {
  cognom1: string;
  cognom2: string;
  dataIngres: number;
  document: string;
  expedientId: string;
  genereDid: number;
  nom: string;
  lisPlacaPublicaCentre: GGPlacaPublica[];
  placaPublicaCentre1?: string;
  placaPublicaCentre2?: string;
  placaPublicaCentre3?: string;
}

export class ParamsUsuarisSauvPlacaPublica {
  placaPublicaCentre?: string;
  genereDid?: number;
  numeroPagina?: number;
  tamanyPagina?: number;

  constructor(tamanyPagina?: number, numeroPagina?: number) {
    this.numeroPagina = numeroPagina ? numeroPagina : 1;
    this.tamanyPagina = tamanyPagina ? tamanyPagina : 5;
  }
}

export interface CercaUsuarisSauvPlacaMunicipal {
  cognom1: string;
  cognom2: string;
  dataIngres: number;
  document: string;
  expedientId: string;
  genereDid: number;
  nom: string;
  placaMunicipalDid: number;
}

export class ParamsUsuarisSauvPlacaMunicipal {
  placaMunicipalDid?: number;
  genereDid?: number;
  numeroPagina?: number;
  tamanyPagina?: number;

  constructor(tamanyPagina?: number, numeroPagina?: number) {
    this.numeroPagina = numeroPagina ? numeroPagina : 1;
    this.tamanyPagina = tamanyPagina ? tamanyPagina : 5;
  }

}

// COPAGO

export interface CopagoData {
  recursId: number;
  quota1?: number;
  quota2?: number;
  quota3?: number;
  iban?: string;
  swift?: string;
  documentCopagament?: string;
  nomDocumentPacte?: string;
  extensioDocumentPacte?: string;
}

export class ParamsLlistatUsuariEquipaments {
  dataInici?: string;
  dataBaixa?: string;
  centre?: string;
  numeroPagina?: number;
  tamanyPagina?: number;

  constructor(tamanyPagina?: number, numeroPagina?: number) {
    this.numeroPagina = numeroPagina ? numeroPagina : 1;
    this.tamanyPagina = tamanyPagina ? tamanyPagina : 5;
  }
}

export interface ResultatCercaUsuarisEquipaments {
	nomEquipament: string;
	nomComplet: string;
	document: string;
	expedientId: string;
	dataNaixement: Date;
	telefon: number;
	observacionsDomicili: string;
	dataIngres: Date;
	dataBaixa: Date;
	motiuSortidaDid: number;
}
