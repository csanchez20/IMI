export interface Paginacion<T> {
  count?: number;
  pageNumber?: number;
  pageSize?: number;
  total: number;
  content: T[];
}

export class FiltersPaginacion {
  tamanyPagina?: number;
  numeroPagina?: number;

  constructor(tamanyPagina?: number, numeroPagina?: number) {
    this.numeroPagina = numeroPagina ? numeroPagina : 1;
    this.tamanyPagina = tamanyPagina ? tamanyPagina : 5;
  }
  
}

export enum Mode {
  CREATE = 0,
  EDIT = 1,
  VIEW = 2,
  ENABLE = 3,
  DISABLE = 4
}

export interface ResultatGeneraDocumentRDTO {
  document: string;
}
