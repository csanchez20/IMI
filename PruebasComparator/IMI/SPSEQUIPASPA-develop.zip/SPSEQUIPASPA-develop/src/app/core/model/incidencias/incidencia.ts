export class ParamsCercaIncidencies {
    tipusRespostaDid: number;
    tipusEntitatDid: number;
    tipusIncidenciaDid?: number;
    dataInici?: number;
    dataFi?: number;
    numeroPagina: number
    tamanoPagina: number;

    constructor(
        tipusRespostaDid: number,
        tipusEntitatDid: number,
        tamanoPagina?: number, 
        numeroPagina?: number
    ) {
        this.tipusRespostaDid = tipusRespostaDid;
        this.tipusEntitatDid = tipusEntitatDid;
        this.numeroPagina = numeroPagina ? numeroPagina : 1;
        this.tamanoPagina = tamanoPagina ? tamanoPagina : 5;
    }
}

export interface CercaIncidenciesRDTO {
    id: number;
    entitatId: string; // expedientId o centreId
    nom: string;
    cogNom1: string;
    cogNom2: string;
    nomEquipament: string;
    dataInici: number;
    dataFi: number;
    tipusEntitatDid: number;
    tipusIncidenciaDid: number;
    usuariCreacio: string;
    portaAssociada: boolean;
}

export interface IncidenciaRDTO {
    id: number;
    nom: string;
    cogNom1: string;
    cogNom2: string;
    entitatId: string; // expedientId o centreId
    gravetatIncidenciaDid: number;
    nomEquipament: string;
    nomProveidor: string;
    dataCreacio: number;
    dataInici: number;
    dataFi: number;
    descripcio: string;
    tipusEntitatDid: number;
    tipusRespostaDid: number;
    tipusIncidenciaDid: number;
    observacions: string;
    portaAssociada: boolean;
    usuariCreacio: string;
}

export interface AltaIncidencia {
    entitatId: string; // expedientId o centreId
    gravetatIncidenciaDid: number; //
    dataInici: number; //
    dataFi: number; //
    descripcio: string;
    tipusEntitatDid: number; // Equipaments o Usuaris
    tipusRespostaDid: number; //
    tipusIncidenciaDid: number; //
    observacions: string; //
    portaAssociadaTasca?: boolean; // back por defecto lo pone a false, no hace falta enviarlo
    nomProveidor: string; //
}

export interface ModificaIncidencia {
    dataInici: number;
    dataFi: number;
    descripcio: string;
    gravetatIncidenciaDid: number;
    observacions: string;
    tipusEntitatDid: number;
    tipusIncidenciaDid: number;
}

export interface ResponseIncidencia {
    id: number;
}