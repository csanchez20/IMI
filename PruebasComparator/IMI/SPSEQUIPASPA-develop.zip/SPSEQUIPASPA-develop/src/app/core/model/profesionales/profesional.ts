export class Profesional {
	id: string;
  nombre: string;
	email: string;
	telefono1: number;
	telefono2: number;
	comentario: string;
}