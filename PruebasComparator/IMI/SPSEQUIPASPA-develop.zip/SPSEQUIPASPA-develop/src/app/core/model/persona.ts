export interface ParamsPersona {
    tipusVista?: string;
}

export interface ParamsPersonaPerDoc extends ParamsPersona {
    tipusDocumentDid?: string;
    document?: string;
    numTargetaSalut?: string;
    codiMibPadro?: string;
}

export interface ParamsCercaAtencio {
    expedientId?: string;
    serveiDid?: string;
}

export interface ParamsCentroReferencia {
    ubicacioId?: string;
    codiServei?: string;
}

export interface AtencioPersonaSolicitud {
    dataInici: string;
    dataFi: string;
}
  
export interface PersonaConsultadesRDTO {
    blocBasiques?: BlocBasiquesDTO;
    blocComplementaries?: BlocComplementariesDTO;
    blocEIA?: BlocEIADTO;
    blocEconomiques?: BlocEconomiquesDTO;
    blocHabitatge?: BlocHabitatgeDTO;
    blocPU?: BlocPUDTO;
    blocSalut?: BlocSalutDTO;
    blocTestPfeiffer?: BlocTestsRDTO;
    blocTestBarthel?: BlocTestsRDTO;
    expedientId?: string;
    listBlocBancaries?: BlocBancariesDTO[];
    listBlocExpedientUbicacio?: BlocExpedientUbicacioDTO[];
}

export interface BlocBasiquesDTO {
    actiu: boolean;
    alies: string;
    anyArribada: number;
    canalEntrada2Did:  number;
    canalEntradaDid: number;
    centreAlta: string;
    centreModificacio: string;
    codiMibNegoci: string;
    codiMibPadro:  string;
    codiMibPersona:  string;
    cognom1: string;
    cognom1N: string;
    cognom2: string;
    cognom2N: string;
    dataConsentimentDona: string;
    dataConsentimentImd: string;
    dataConsentimentLopd: string;
    dataCreacio: string;
    dataModificacio: string;
    dataNaixement: number;
    dataTancament: string;
    descripcioTelefon1: string;
    descripcioTelefon2: string;
    descripcioTelefon3: string;
    descripcioTelefon4: string;
    document: string;
    email: string;
    expedientId: string;
    foraTerritori: boolean;
    genereDid: number;
    modificarPendentRevisio: boolean;
    motiuTancamentDid: number;
    nacionalitatDid: number;
    nom: string;
    nomN: string;
    numSeguretatSocial: string;
    observacions: string;
    paisNaixementDid: number;
    pendentRevisio: boolean;
    provNaixementDid: number;
    requereixSms: boolean;
    situacioLegalDid: number;
    teAdreca: boolean;
    teAlias: boolean;
    teConsentiment: boolean;
    teConsentimentDona: boolean;
    teConsentimentDonaFamiliar: string;
    teConsentimentFamiliar: string;
    teConsentimentImd: boolean;
    teConsentimentImdFamiliar: string;
    teTelefon: boolean;
    telefon1: string;
    telefon2: string;
    telefon3: string;
    telefon4: string;
    tipusDocumentDid: number;
    tipusIoImd: string;
    tipusIoImss: string;
    tipusIoQvie: string;
    tipusTelefon1Did: number;
    tipusTelefon2Did: number;
    tipusTelefon3Did: number;
    tipusTelefon4Did: number;
    usuariCreacio: string;
    usuariModificacio: string;
}

export interface BlocTestsRDTO {
    testId?: number;
    expedientId?: string;
    dataRealitzacio?: number;
    puntuacio?: number;
    tipusTestDid?: number;
    preguntes?: BlocTestsPreguntaRDTO[];
}

export interface BlocTestsPreguntaRDTO {
    preguntaId: number;
    testId: number;
    preguntaDid: number;
    respostaDid: number;
}

export interface BlocUsuarioDTO{
    actiu: boolean;
    aplicacioAlta: number;
    centre: string;
    centreAlta: string;
    centreCreacio: string;
    centreModificacio: string;
    centreTancament: string;
    dataCreacio: number;
    dataModificacio: number;
    dataTancament: number;
    estatIntervencioDid: number;
    expedientId: string;
    habilitat: boolean;
    motiuTancamentDid: number;
    responsableId: string;
    serveiIntervencioDid: number;
    tipusExpedient: string;
    tipusNfcDid: number;
    ultimEpisodiId: number
    usuariCreacio: string;
    usuariModificacio: string;
    usuariTancament: string;
  }

export interface BlocExpedientDTO{
    actiu: boolean;
    aplicacioAlta: number;
    centre: string;
    centreAlta: string;
    centreCreacio: string;
    centreModificacio: string;
    centreTancament: string;
    dataCreacio: number;
    dataModificacio: number;
    dataTancament: number;
    estatIntervencioDid: number;
    expedientId: string;
    habilitat: boolean;
    motiuTancamentDid: number;
    responsableId: string;
    serveiIntervencioDid: number;
    tipusExpedient: string;
    tipusNfcDid: number;
    ultimEpisodiId: number
    usuariCreacio: string;
    usuariModificacio: string;
    usuariTancament: string;
  }

export interface BlocComplementariesDTO {
    actiu: boolean; 
    centreCreacio: string;
    centreModificacio: string;
    dataCreacio: string;
    dataEstatIncapacitat: string;
    dataModificacio: string;
    dataNouvingut: string;
    enProcesIncapacitat: boolean;
    esNouvingut: boolean;
    escolaDid: number;
    estaEscolaritzat: boolean;
    estatCivilDid: number;
    estatProcesIncapacitatDid: number;
    fillsMenorsDesc: string;
    fillsMenorsDona: string;
    fillsMenorsHome: string;
    fillsMenorsTotal: string;
    fillsTotalDesc: string;
    fillsTotalDona: string;
    fillsTotalHome: string;
    fillsTotalTotal: string;
    hiHaMotiuConsulta: boolean;
    idiomaDid: number;
    motiuConsulta: string;
    necessitaTraductor: boolean;
    nivellInstruccioDid: number;
    observacions: string;
    professio: string;
    professioComboDid: number;
    relacioAmbServeisMunicipals: number;
    sectorDid: number;
    situacioEscolarDid: number;
    situacioLaboralDid: number;
    tutorLegal: string;
    usuariCreacio: string;
    usuariModificacio: string;
}

export interface BlocEIADTO {
    actiu: boolean;
    canalEntradaDid: number;
    centreCreacio: string;
    centreModificacio: string;
    dataCreacio: string;
    dataModificacio: string;
    ubicacioEaiaDid: number;
    usuariCreacio: string;
    usuariModificacio: string;
}

export interface BlocEconomiquesDTO {
    actiu: boolean;
    centreCreacio: string;
    centreModificacio: string;
    dataCreacio: string;
    dataModificacio: string;
    ingressosMensuals: number;
    usuariCreacio: string;
    usuariModificacio: string;
    viaPercepcio1Did: number;
    viaPercepcio2Did: number;
}

export interface BlocPUDTO {
    actiu: boolean;
    centreCreacio: string;
    centreModificacio: string;
    dataCaducitat: string;
    dataCreacio: string;
    dataModificacio: string;
    diagnosticCas: string;
    expedientId: string;
    habilitat: boolean;
    informacio: string;
    novolRebreInformacio: boolean;
    numeroRegistre: number;
    numeroResolucio: string;
    tipusResolucioDid: number;
    usuariCreacio: string;
    usuariModificacio: string;
}

export interface BlocSalutDTO {
    actiu: boolean;
    ambulatoriRefrenciaDid: number;
    antecedentsPsiq: string;
    atesEquipDid: number;
    baremDependencia: boolean;
    baremMobilitat: boolean;
    cadiraRodesDid: number;
    casReferencia: string;
    casReferenciaActual: string;
    centreCreacio: string;
    centreModificacio: string;
    centreTractamentTox: string;
    crossesDid: number;
    dataCreacio: string;
    dataEfecte: string;
    dataModificacio: string;
    dataVenciment: string;
    discapacitat1Did: number;
    discapacitat2Did: number;
    discapacitat3Did: number;
    esmDataDiagnostic: string;
    esmDiagnostic: string;
    esmInstitucio: string;
    esmPassatTractament: string;
    esmProfessional: string;
    esmTipusTractament: string;
    estaEnTractament: boolean;
    estaTractamentTox: boolean;
    estatCertificatDid: number;
    expedientId: string;
    grauDiscapacitat: number;
    grupGrauDiscapacitatDid: number;
    malaltiesCroniques: string;
    malaltiesInfeccioses: string;
    necessitaAcompanyant: boolean;
    numTargetaSalut: string;
    observacions: string;
    psmNumingresos: number;
    psmTempsIngressat: number;
    taxiAdaptat: boolean;
    teAntecedentsPsiq: boolean;
    teAntecentsTox: boolean;
    teDiscapacitat: boolean;
    teMalaltiesCroniques: boolean;
    teMalatiesInfeccioses: boolean;
    teTuberculosi: boolean;
    tipusCoberturaDid: number;
    toxicomania1Did: number;
    toxicomania2Did: number;
    toxicomania3Did: number;
    usuariCreacio: string;
    usuariModificacio: string;
    validesaReconeixementDid: number;
}

export interface BlocBancariesDTO {
    actiu: boolean;
    centreCreacio: string;
    centreModificacio: string;
    compteId: number;
    compteNombre: string;
    compteTipusDid: number;
    dataCreacio: string;
    dataModificacio: string;
    entitatDid: number;
    expedientId: string;
    habilitat: boolean;
    iban: string;
    swift: string;
    usuariCreacio: string;
    usuariModificacio: string;
}

export interface BlocExpedientUbicacioDTO {
    centreCreacio?: string;
    centreModificacio?: string;
    dataCreacio?: string;
    dataFinalUbicacio?: string;
    dataIniciUbicacio?: number;
    dataModificacio?: string;
    expedientId: string;
    habilitat: boolean;
    tipusAdrecaDid: number;
    tipusTinencaDid?: number;
    ubicacioId: number;
    usuariCreacio?: string;
    usuariModificacio?: string;
    usuariUbicacioId?: number;
    vigent: boolean;
}

export interface BlocHabitatgeDTO {
    estatEconomicHabitatgeDid?: number;
    expedientId?: string;
    quantitat?: number;
    tipusHabitatgeDid?: number;
    tipusPropietariHabitatgeDid?: number;
}

export interface CSSReferenciaRespuesta {
    centre: string;
}