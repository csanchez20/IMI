export class ParamsAvisos {
  dataFiNotificacio?: string;
  dataNotificacio?: string;
  estatNotificacioDid?: number;
  expedientId?: string;
  grupId?: string;
  llegit?: boolean;
  perfilId?: string;
  professionalId?: string;
  text?: string;
  tipusNotificacioDid?: number;
  url?: string;
}

export class ParamsAvisosPaginado extends ParamsAvisos {
  numeroPagina: number;
  tamanoPagina: number;

  constructor(tamanyPagina?: number, numeroPagina?: number) {
    super();
    this.numeroPagina = numeroPagina ? numeroPagina : 1;
    this.tamanoPagina = tamanyPagina ? tamanyPagina : 5;
  }
}

export class AvisRDTO {
  variables: string;
  dataCreacio: number;
  dataFiNotificacio: number;
  dataModificacio: number;
  dataNotificacio: number;
  estatNotificacioDid: number; // 101801
  expedientId: string;
  grupId: string;
  habilitat: boolean;
  llegit: boolean;
  notificacioId: number;
  perfilId: string;
  professionalId: string;
  text: string;
  tipusNotificacioDid: number; // 2990010
  url: string;
  usuariCreacio: string;
  usuariModificacio: string;
}

export class AvisosPaginatsRDTO {
  totalRegistres: number;
  llistaAvisTotalDTO: AvisRDTO[];
}

export interface AvisResponseId {
  avisId?: number
}
