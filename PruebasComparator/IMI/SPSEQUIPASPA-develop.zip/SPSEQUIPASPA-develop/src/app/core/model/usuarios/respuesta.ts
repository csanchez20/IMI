import { Direccion } from './direccion';
import { Usuario } from './usuario';

export enum RespuestasEstados {
  APROBADO = 90004,
  CERRADO = 90006
}

export class Traslado {
  fecha_solicitud: Date;
  estado: string;
  dir_origen: Direccion;
  dir_destino: Direccion;
  fecha_planificada: Date;
  fecha_real: Date;
  autorizador: Usuario;
  fecha_autorizacion: Date;
  unidades_operario: number;
  unidades_camion: number;
}

export class Salida {
  observacion: string;
}

export class SalidaParcial extends Salida {
  fecha_salida: Date;
  usuario_recogida: Usuario;
  valor_final: number;
  m3_usados: number;
}

export class SalidaResiduos extends Salida {
  fecha_prescripcion: Date;
  estado: string;
  prescriptor: Usuario;
  css: string;
  autorizador: Usuario;
  fecha_autorizacion: Date;
  fecha_realizacion: Date;
  fecha_publicacion_boe: Date;
}

export class Guardamuebles {
  fecha_entrada: Date;
  fecha_fin: Date;
  m3_ocupados_inicio: number;
  m3_ocupados_actual: number;
  estado: string;
  usuarios_autorizados: Usuario[];
}

export class Country {
  name: string;
  value: string;
}

export class Recurso {
  idUsuario: string;
  idSolicitud: string;
  label: string;
  fechaSolicitud: string;
  estadoSolicitud?: string;
  fechaIngreso: string;
  fechaInicio: string;
  fechaFinal: string;
  estado: EstadoRecurso;
  residencia: Residencia;
  nombrePersona: string;
  centroProcedencia: string;
}

export interface Interrupcion {
  fechaIni: Date;
  fechaPrevistaFin: Date;
  fechaFin: Date;
  motivo: string;
  informacion?: string;
}

export interface SalidaVoluntaria {
  fechaIni: Date;
  fechaFin: Date;
  motivo: string;
  informacion?: string;
  autorizacionServicio?: boolean;
}
export interface PlanSalida {
  gestionMunicipal: string;
  otros: string;
  recursoPrivado: string;
  recursosSalida: RecursoSalida[];
  tipo: string[];
}

export interface RecursoSalida {
  placaPublicaCentre: string;
  placaPublicaPosicio: number;
  placaPublicaDataAcces: number;
  //placaPublicaDataModificacio1": null,--NO SE ENVIA
  placaPublicaPeticionariDid: number; // 2031101
  placaPublicaSeleccionada: boolean;
  placaPublicaObservacions: string;
}
export interface BajaServicio {
  fechaBaja: Date;
  motivo: string;
  tipoRecurso?: string;
  nombreRecurso?: string;
  informacion?: string;
}

export class Residencia {
  nombreResidencia: string;
  nombreResponsable: string;
  nombreTS: string;
}

export enum EstadoRecurso {
  activo = 'Actiu',
  finalizado = 'Finalitzat',
  cancelado = 'Cancel·lat'
}

export interface InstanciaRecurso {
  instanciaId: number;
  estatIdDesti: number,
  observacions: string,
  dataTransicio: number
}
