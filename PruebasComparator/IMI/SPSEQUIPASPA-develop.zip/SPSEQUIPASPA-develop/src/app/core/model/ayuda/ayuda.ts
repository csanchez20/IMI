export interface PreguntaFAQ {
    categoria: string;
    subcategoria: string;
    fecha: Date;
    pregunta: string;
    respuesta: string;
}