import { Profesional } from "../profesionales";
import { Proveedor } from "../proveedores";

export class ParamListadoTasca {
  dataFiNotificacio: number;
  dataNotificacio: number;
  estatNotificacioDid: number;
  expedientId: string;
  grupId: string;
  llegit: boolean;
  numeroPagina: string;
  perfilId: string;
  professionalId: string;
  tamanoPagina: string;
  text: string;
  tipusNotificacioDid: number;
  url: string;
}

export interface TascaRDTO {
  dataCreacio?: number;
  dataFiNotificacio?: number;
  dataModificacio?: number;
  dataNotificacio?: number;
  estatNotificacioDid?: number;
  expedientId?: string;
  grupId?: string;
  habilitat?: number;
  llegit?: boolean;
  notificacioId: number;
  perfilId?: string;
  professionalId?: string;
  text?: string;
  tipusNotificacioDid?: number;
  url?: string;
  usuariCreacio?: string;
  usuariModificacio?: string;
}

export class TareaLite {
  id: number;
  servicio: string;
  tarea: string;
  titulo: string;
  descripcion: string;
  fecha: string;
  fechaVencimientoTimestamp?: number;
}

export class Tarea extends TareaLite {
  creador: string;
  categoria: string;
  listaProfesionales: Array<Profesional>;
  proveedor: Proveedor;
  observaciones: string;
  importante: boolean;
  fechaCreacion: string;
  fechaVencimiento: string;
  identificacion: string;
  estado: string;
  idSIAS: string;
}

export class IndicadorHome {
  nombre: string;
  numero: number;
}
