export interface FiltrosAlbaranes {
  dataInici: Date;
  dataFi: Date;
  empresa: number;
  teIncidencia: boolean;
}
export interface FiltrosEmpremtas {
  tipusRespostaDid: number;
  // dataInici: Date;
  // dataFi: Date;
  // campGoogle: string;
  expedientId: string;
  nomComplet: string;
  document: string;
  tipusServeiDid: string;
  teIncidencia: boolean;
}

export interface EmpresaGestoraOutput {
  nom: string;
  empresaGestoraId: number;
}

//Back
//Request
export interface ConsultaAlbaranes {
  dataInici?: string;
  dataFi?: string;
  empresaGestoraId?: number;
  teIncidencia?: boolean;
  teRegularitzacio?: boolean;
  teFacturaProforma?: boolean;
  tipusRespostaDid: number;
  facturaProformaId?: number;
  tamanoPagina?: number;
  numeroPagina?: number;
}

export interface ConsultaEmpremtes {
  tipusRespostaDid: number;
  estatEmpremtaDid: number;
  // dataInici?: string;
  // dataFi?: string;
  // campGoogle?: string;
  expedientId?: string;
  nomComplet?: string;
  document?: string;
  tipusServeiDid?: string;
  teIncidencia?: boolean;
  tamanoPagina?: number;
  numeroPagina?: number;
}

export interface RegularitzaEmpremta {
  costRegularitzar: number;
  costProveidor: number;
  costAjuntament: number;
}

export interface respostaAltaEmpremta {
  listEmpremtesId: number[];
}

export interface AltaEmpremta {
  
  regularitzacio: boolean;
  importRegularitzar: number; 
  empremtaId: number;

}

export interface ResultRegularitzarAlbara {
  albaraId: number;
}

//Response
export interface ResultadoCercaAlbaranes {
  totalRegistres: number;
  llistaCercaAlbarans: ItemCercaAlbaran[];
}

export interface ResultadoCercaAlbaranesTable {
  totalRegistres: number;
  llistaCercaAlbarans: ItemCercaAlbaraTable[];
}

export interface ItemCercaAlbaran {
  albaraId: number;
  dataInici: number;
  dataFi: number;
  contracteId: number;
  tipusRespostaDid: number;
  pressupostServeiId: number;
  empresaGestoraId: number;
  nomEmpresaGestora: string;
  albaraCentreId: string;
  nomAlbaraCentre: string;
  obert: boolean;
  indicadors: Indicadores;
}

export interface Indicadores {
  importFinalAmbIva: number;
  importFinalSenseIva: number;
  importPrevistAmbIva: number;
  importPrevistSenseIva: number;
  incidenciesTotals: number;
  unitatsPrevistes: number;
  unitatsRealitzades: number;
  usuarisTotals: number;
  usuarisRevisar: number;
}

export interface ItemCercaAlbaraTable extends ItemCercaAlbaran{
  unitatsPrevistes: number;
  importFinalAmbIva: number;
  importFinalSenseIva: number;
}

export interface ResultadoConsultaAlbaran {
  albaraId: number;
  dataInici: number;
  dataFi: number;
  contracteId: number;
  tipusRespostaDid: number;
  pressupostServeiId: number;
  empresaGestoraId: number;
  nomEmpresaGestora: string;
  albaraCentreId: string;
  nomAlbaraCentre: string;
  usuarisTotals: number;
  usuarisRevisar: number;
  incidenciesTotals: number;
  unitatsPrevistes: number;
  unitatsRealitzades: number;
  costPrevist: number;
  costFinal: number;
  obert: boolean;
}

export interface ResultadoConsultaEmpremta {
  totalRegistres: number;
  llistaResultatsCercaEmpremtaRDTO: ResultatItemEmpremta[];
}

export interface ResultatItemEmpremta {
  empremtaId: number;
  nom: string;
  cognom1: string;
  cognom2: string;
  expedientId: string;
  tipusServeiDid: string;
  teIncidencia: boolean;
  esRegularitzacio: boolean;
  numUnitats: number;
  iva: number;
  importTotal: number;
}

export interface ItemEmpremta {
  empremtaId: number;
  nomComplet: string;
  expedientId: string;
  tipusServeiDid: string;
  teIncidencia: boolean;
  esRegularitzacio: boolean;
  numUnitats: number;
  importTotal: number;
  importSenseIva: number;
}
