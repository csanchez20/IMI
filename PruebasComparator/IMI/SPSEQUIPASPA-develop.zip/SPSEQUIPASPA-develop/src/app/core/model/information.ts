import { Usuario } from '.';
import { Direccion } from './usuarios/direccion';
import { Message } from 'primeng/api';

export class Servicio {
  label: string;
  icon?: string;
  disabled?: boolean;
}

export class Perfil {
  nombre: string;
  apellido1: string;
  apellido2: string;
  identificador: string;
  situacion: string;
  centroAtencion: string;
  datosProfesional: string;
  icon: string;
}

export class Persona {
  id: string;
  tipoDocumento?: string;
  documento?: string;
  nombre?: string;
  apellido1?: string;
  apellido2?: string;
  nombrePreferencia?: string;
  genero?: string;
  nacionalidad?: string;
  pais?: string;
  estadoCivil?: string;
  tarjetSanitaria?: number;
  numSegSocial?: number;
  telefono?: string;
  telefono2?: string;
  telefono3?: string;
  email?: string;
  email2?: string;
  ubicacion?: string;
  descripcion?: string;
  listaDirecciones?: Direccion;
  relacion?: string;
  fechaNacimiento?: Date;
}

export interface PersonaMibPadroResDTO {
  adrecaFiscal?: string;
  apartat?: string;
  bisFi?: string;
  bisIni?: string;
  canal?: string;
  codiPostal?: string;
  cognom1?: string;
  cognom2?: string;
  dataAltaPadro?: string;
  dataDefunDiss?: string;
  dataNaixConst?: string;
  descCanal?: string;
  descEstat?: string;
  descIdioma?: string;
  descNacionalitat?: string;
  descSegNacionalitat?: string;
  descTipDocument?: string;
  descTipPersona?: string;
  descripcioAdreca?: string;
  districte?: string;
  docId?: string;
  escala?: string;
  estat?: string;
  icolisio?: string;
  iconsolidat?: string;
  idioma?: string;
  lletraFi?: string;
  lletraIni?: string;
  nacionalitat?: string;
  nom?: string;
  nomVia?: string;
  numContrib?: string;
  numFi?: string;
  numIni?: string;
  numPadro?: string;
  numPersUnif?: string;
  numPersona?: string;
  origen?: string;
  pais?: string;
  partCognom1?: string;
  partCognom2?: string;
  partEntreCognoms?: string;
  pis?: string;
  poblacio?: string;
  porta?: string;
  raoSocial?: string;
  segNacionalitat?: string;
  tipDocument?: string;
  tipPersona?: string;
  tipusVia?: string;
  tractament?: string;
}

export interface ObtenirAdrecesParams {
  adrLletra1?: string;
  adrLletra2?: string;
  adrNomCarrer: string;
  adrNum1?: string;
  adrNum2?: string;
  adrTipusVia?: string;
}

export interface ObtenirAdrecesResponseRDTO {
  listDirpost: GbgDirPostRDTO[];
}

export interface GbgDirPostRDTO {
  codi: string;
  codiIne: string;
  codiDgc: string;
  tipusVia: string;
  nom18: string;
  nom27: string;
  nomComplet: string;
  nomOrdenar: string;
  sequencia: string;
  aprovacio: string;
  dataAprov: string;
  codiCarr: string;
  numpostI: string;
  llepostI: string;
  numpostF: string;
  llepostF: string;
  tipusnum: string;
  districte: string;
  codiIlla: string;
  codiParc: string;
  solar: string;
  xnumPost: string;
  ynumPost: string;
  angle: string;
  distPost: string;
  seccCens: string;
  seccEst: string;
  barri: string;
}

export interface ConsultaGrupDiccionariResponseRDTO {
  comarques?: GbgCodificadorsVO;
  municipis?: GbgCodificadorsVO;
  paisos?: GbgCodificadorsVO;
  provincies?: GbgCodificadorsVO;
  tipusVia?: GbgCodificadorsVO;
  variables?: Object;
  variantComarca?: string;
  variantComarcaProvincia?: string;
  variantMunicipi?: string;
  variantMunicipiComarca?: string;
  variantMunicipiComarcaProvincia?: string;
  variantPaisos?: string;
  variantProvincies?: string;
}

export interface GbgCodificadorsVO {
  list?: any[];
}

export class InfoCard {
  titulo: string;
  icon?: string;
  descripcion: string;
}

export class Factura {
  id: number;
  numFactura: number;
  fechaFactura: Date;
  fechaOperacion: Date;
  periodoFacturacion: string;
  estado: string;
  total: number;
}

export class Facturacion {
  usuario: Usuario;
  fechaInicio: Date;
  CSSProcedencia: string;
  tipo: string;
  cantidad: number;
  precioUnitario: number;
  numIncidencias: number;
  total: number;
  previsto: number;
}

export class FacturaFilters {
  fechaOperacion: Date;
  fechaInicio: Date;
  fechaFin: Date;
  estado: string;
  total: string;
}

export class Registro {
  label: string;
  descripcion: string;
}

export class Movimiento {
  tipoMovimiento: string;
  residencia: string;
  posicion: number;
  observaciones: string;
  fecha?: string;
}

export class TableData {
  rows?: Object[];
  cols: InfoItem[];
  numeroTotalResultados?: number;
  numRowsPerPage?: number;
  loading?: boolean;
  error?: Message[];
}

export interface InfoPaginator {
  numeroPagina?: number;
  tamanyPagina?: number;
}

export interface InfoItem {
  header?: string;
  headerToolip?: string;
  field?: string;
  label?: string;
  icon?: string;
  type?: string;
  typeKey?: string;
  show?: boolean;
  hideWhenServiceIn?: string[]; // ['Sauv'],'
  command?: (event?: any) => void;
  routerLink?: any;
  actionIcons?: InfoItem[];
  action?: string; // Possiblities: {'edit', 'delete', 'download', 'add', 'export'}
  fieldIdOwner?: string;
  formatDate?: string; // 'DD/MM/YY'
  buttons?: InfoItem[] | InfoItem[][];
}

export class Test {
  testTitle?: string;
  puntuationValue?: number;
  puntuationLabel?: string;
  statusValue?: string;
  statusLabel?: string;
  dateLabel?: string;
}

export interface IndicePfeiffer {
  idTest?: string;
  dataActual: boolean;
  diaActual: boolean;
  lugar: boolean;
  telefonoDireccion: boolean;
  edad: boolean;
  fechaNacimiento: boolean;
  nombrePresidente: boolean;
  nombrePresidenteAnterior: boolean;
  apellidosMadre: boolean;
  resta: boolean;
  puntuacion?: number;
}

export interface Dual {
  key: string;
  value: string;
}

export interface ValorDiccionariResultsRDTO {
  mestreId: number;
  nom: string;
  descripcio: string;
  nivell: number;
  ordre: number;
  seleccionable: number;
  pareId: number;
  dataCreacio: string;
  dataModificacio: string;
  usuariCreaci: string;
  usuariModificacio: string;
  habilitat: number;
  mestreIdExtern: number;
  descripcioExtern: string;
  tipusExtern: string;
}

export interface ConsultaXarxesRelacioResponse {
  nucliConvicencias: ConsultaNucliConvivenciaDTO[];
  nucliFamiliarConvivencias: ConsultaNucliFamiliarConvicenciaDTO[];
  nucliFamiliars: ConsultaNucliFamiliarDTO[];
}

export interface ConsultaNucliConvivenciaDTO {
  expedientId?: string;
  ubicacioId?: number;
  // dates extra per mi
  nom?: string;
  cognom1?: string;
  cognom2?: string;
  dataNaixement?: number;
  document?: string;
  telefon1?: number;
  tipusDocumentDid?: number;
  genereDid?: number;
  estatProcesIncapacitatDid?: number;
  ingressosMensuals?: number;
}

export interface ConsultaNucliFamiliarConvicenciaDTO {
  expedientId?: string;
  ubicacioId?: number;
  relacioDid?: number;
  vincle?: ConsultaXarxaRelacioParentiuResponse;
  vincleIdReciproc?: number;
}

export interface ConsultaXarxaRelacioParentiuResponse {
  actiu?: boolean;
  centreCreacio?: string;
  centreModificacio?: string;
  dataCreacio?: number;
  dataModificacio?: number;
  expedientPrincipalId?: string;
  expedientSecundariId?: string;
  relacioDid?: number;
  usuariCreacio?: string;
  usuariModificacio?: string;
  vincleId?: number;
  // dates extra per mi
  nom?: string;
  cognom1?: string;
  cognom2?: string;
  dataNaixement?: number;
  document?: string;
  telefon1?: number;
  tipusDocumentDid?: number;
  genereDid?: number;
  estatProcesIncapacitatDid?: number;
  ingressosMensuals?: number;
}

export interface ConsultaNucliFamiliarDTO {
  expedientId?: string;
  vincle?: ConsultaXarxaRelacioParentiuResponse;
  // dates extra per mi
  nom?: string;
  cognom1?: string;
  cognom2?: string;
  dataNaixement?: number;
  document?: string;
  telefon1?: number;
  tipusDocumentDid?: number;
  genereDid?: number;
  estatProcesIncapacitatDid?: number;
  ingressosMensuals?: number;
}

export interface FamiliarUnitatCohabitacio {
  expedientId?: string;
  relacioDid?: number;
  nom?: string;
  cognom1?: string;
  cognom2?: string;
  dataNaixement?: number;
  telefon1?: number;
  tipusDocumentDid?: number;
  document?: string;
  dataEntrada?: number;
  dataSortida?: number;
  observacions?: string;
  documentAdjunt?: String; 
  nomDocumentAdjunt?: String; 
  extensioDocumentAdjunt?: String; 
}

export interface ConsultaPadroConviventMibPadroResRDTO {
  indMesReg: string;
  llistaErrors: any[];
  llistaPadro: LlistaConviventMibPadroResDTO[];
  missatgeMib: string;
  numRegistres: string;
}

export interface LlistaConviventMibPadroResDTO {
  codiCarrer?: string;
  cognom1?: string;
  cognom2?: string;
  dataNaixement?: string;
  docId?: string;
  escala?: string;
  lletraFi?: string;
  lletraIni?: string;
  nom?: string;
  nomVia?: string;
  numFi?: string;
  numIni?: string;
  partCognom1?: string;
  partCognom2?: string;
  pis?: string;
  porta?: string;
  rfl?: string;
  tipDocument?: string;
  tipusVia?: string;
}

export interface ParamsPadroConviventMibPadroRes {
  docId: string;
  tipDocument: string;
}

export interface UnidadEconomicaConvivenciaInterface {
  document?: string;
  nomComplet?: string;
  relacioDid?: number;
}

export interface WrapperUnidadEconomica {
  [expedientId: number]: UnidadEconomicaConvivenciaInterface;
}

