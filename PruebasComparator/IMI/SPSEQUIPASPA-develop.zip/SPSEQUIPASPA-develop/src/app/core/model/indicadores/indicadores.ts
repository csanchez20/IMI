export interface Indicador {
  id: number;
  nom: string;
  valor: string;
  data: number;
}