/* [OP-NEG-EGG01-06] Cerca Centres Gent Gran */
export class ParamListadoEquipament {
  campGoogle?: string;
  codiEquipament?: string;
  estat?: boolean = true;
  nom?: string;
  nomEmpresa?: string;
  numeroPagina?: number;
  tamanyPagina?: number;
  tipusRespostaDid?: number;

  constructor(tipusRespostaDid?: number, tamanyPagina?: number, numeroPagina?: number) {
    if (tipusRespostaDid) {
      this.tipusRespostaDid = tipusRespostaDid;
    }
    this.numeroPagina = numeroPagina ? numeroPagina : 1;
    this.tamanyPagina = tamanyPagina ? tamanyPagina : 5;
  }
}

export interface CentreggCercadesRDTO {
  nom?: string;
  nomEmpresa?: string;
  centreId?: string;
  estat?: boolean;
  codiEquipament?: string;
}

/* Cintraos -> 2.61. Cerca d’un Centre */
export interface CentroDTO {
  centre: string;
  nom: string;
  serveiDid: number;
  telefon: string;
  horari: string;
  fax: string;
  email: string;
  directorId: string;
  ubicacioId: number;
  compt: number;
  dataCreacio: string;
  dataModificacio: string;
  usuariCreacio: string;
  usuariModificacio: string;
  habilitat: boolean;
  url: string;
  sistema: string;
  dataMigracio: string;
  centreId: string;
  districteId: string;
  organGestor: string;
}

export interface CentreggRDTO {
  actiu: boolean;
  caracteristiques: number[];
  centreId: string;
  codiReferencia: string; // aplica nomes a centres tipus residencia
  dataModificacio: Date;
  placesLliures: number;
  placesLliuresHome: number; // aplica nomes a SAUV
  placesLliuresDona: number; // aplica nomes a SAUV
  placesLliuresIndiferent: number; // aplica nomes a SAUV
  placesTotal: number;
  previsioPlacesLliuresHome: number; // aplica nomes a SAUV
  previsioPlacesLliuresDona: number; // aplica nomes a SAUV
  previsioPlacesLliuresIndiferent: number; // aplica nomes a SAUV
  prioritat: number; // aplica nomes a SAUV
  respostaDid: number;
}

export interface CentreggIdRDTO {
  centreggId: string;
}

/* Param In ->
  [OP-NEG-EGG01-16] Cerca Persones de Contacte
  [OP-NEG-EGG01-22] Cerca Inspeccions
  [OP-NEG-EGG01-28] Cerca Auditories
                    Cerca Documentacion
*/
export interface ParamInEquipament {
  centreId: number;
  numeroPagina?: number;
  tamanyPagina?: number;
  tots?: number;
}
