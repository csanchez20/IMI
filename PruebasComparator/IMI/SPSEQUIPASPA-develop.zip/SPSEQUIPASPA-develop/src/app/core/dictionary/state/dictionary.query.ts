import { Injectable } from '@angular/core';
import { Query } from '@datorama/akita';

import { DictionaryItem, DictionaryState, DictionaryStore } from './dictionary.store';

@Injectable({
  providedIn: 'root'
})
export class DictionaryQuery extends Query<DictionaryState> {
  caracteristicas$ = this.select('caracteristicas');

  constructor(protected store: DictionaryStore) {
    super(store);
  }

  getCatalogItem(itemValue: number): string {
    const catalogoKey = 'catalogo';
    const table = this.getValue().hasOwnProperty(catalogoKey)
      ? this.getValue()[catalogoKey]
      : [];
    return this._returnItem(itemValue, table);
  }

  getItemDictionaryByKey(
    itemValue: number | string,
    key: string,
    content: string = 'label'
  ) {
    const table = this.getValue().hasOwnProperty(key)
      ? this.getValue()[key]
      : [];

    if (!table.length) {
      return null;
    }
    return this._returnItem(itemValue, table, content);
  }

  getDictionaryKey(key: string) {
    return this._existKey(key) ? this.getValue()[key] : [];
  }

  getDictionaryKeyByDisabled(key: string) {
    return this._existKey(key) 
      ? this.getValue()[key].filter(val => val.disabled === false) 
      : [];
  }
  
  private _existKey(key: string): boolean {
    return this.getValue().hasOwnProperty(key);
  }

  private _returnItem(
    itemValue: number | string,
    table: DictionaryItem[],
    content: string = 'label'
  ): string {
    if (!table) {
      return null;
    }
    const result = table
      .filter(item => ''+item.value === ''+itemValue)
      .map(item => (item.hasOwnProperty(content) ? item[content] : null));
    return result.length ? result[0] : null;
  }
  
  
  private _returnAllItem(
    itemValue: number | string,
    table: DictionaryItem[]
  ): any {
    if (!table) {
      return null;
    }
    const result = table
      .filter(item => ''+item.value === ''+itemValue);
    return result.length ? result[0] : null;
  }

  getAllItemDictionaryByKey(
    itemValue: number | string,
    key: string
  ) {
    const table = this.getValue().hasOwnProperty(key)
      ? this.getValue()[key]
      : [];

    if (!table.length) {
      return null;
    }
    return this._returnAllItem(itemValue, table);
  }
}
