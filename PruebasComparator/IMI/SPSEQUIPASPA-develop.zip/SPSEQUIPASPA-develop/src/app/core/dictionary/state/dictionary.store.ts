import { Store, StoreConfig, transaction } from '@datorama/akita';
import { Injectable } from '@angular/core';

export interface DictionaryItem {
  value: number;
  label: string;
  descr?: string;
}

export interface DictionaryState {
  [key: string]: any[];
}

export function createInitialState(): DictionaryState {
  return {};
}

@Injectable({
  providedIn: 'root'
})
@StoreConfig({
  name: 'dictionary',
  // cada dia akita invalida la cache del dictionary
  /* cache: {
    ttl: 1000 * 60 * 60 * 24
  } */
})
export class DictionaryStore extends Store<DictionaryState> {

  constructor() {
    super(createInitialState());
  }

}


