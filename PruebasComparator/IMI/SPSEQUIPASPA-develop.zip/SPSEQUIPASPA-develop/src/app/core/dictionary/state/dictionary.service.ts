import { Injectable, OnDestroy } from '@angular/core';
import { SessionQuery, UbicacionUI } from '@app/core/auth';
import { ValorDiccionariResultsRDTO } from '@app/core/model/information';
import { DireccionService } from '@app/servicios/direccion/direccion.service';
import {
  CODE_TIPO_DOCUMENTO_DNI,
  CODE_TIPO_DOCUMENTO_NIE
} from '@app/servicios/personas/personas.service';
import { SolicitudesService } from '@app/servicios/solicitudes/solicitudes.service';
import { RecursosService } from '@app/servicios/usuarios/recursos.service';
import { Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { DictionaryDataService } from './dictionary.dataservice';
import { DictionaryQuery } from './dictionary.query';
import { DictionaryStore } from './dictionary.store';


export const CODE_INITIAL_DISTRITOS_ID = 80110;
export const NUM_MAX_LENGTH_DISTRITO_ID = 2;

export enum DiccionarioKey {
  CARACTERISTICAS = 'caracteristicas',
  TIPO_INSPECCIONES = 'tipo_inspecciones',
  // Datos basicos usuario
  GENERO = 'generos',
  ESTADOCIVIL = 'estados_civiles',
  PAIS = 'paises',
  TIPO_DOCUMENTOS = 'tipo_documentos',
  IDIOMA = 'idiomas',
  // Direccion usuario
  PBA = 'pba',
  DISTRICTES = 'distritos',
  BARRIOS = 'barrios',
  TIPOS_VIA = 'tipos_via',

  TIPO_RESPUESTAS = 'respuestas_tipo',
  ESTADO_RECURSOS = 'respuestas_estado_recursos',
  // Consentimiento informado
  ESTADOS_CONSENTIMIENTO = 'estados_consentimiento',
  TIPOS_TRATAMIENTO = 'tipos_tratamiento',
  // Test Barthel
  PREGUNTAS_TEST_BARTHEL = 'preguntas_test_barthel',
  RESPUESTAS_TEST_BARTHEL = 'respuestas_test_barthel',
  // Test Pfeiffer
  PREGUNTAS_TEST_PFEIFFER = 'preguntas_test_pfeiffer',
  RESPUESTAS_TEST_PFEIFFER = 'respuestas_test_pfeiffer',

  PEV_GRADOS = 'pev_grados',
  ESTADOS_INCAPACITACION = 'estados_incapacitacion',
  RELACIONES_FAMILIARES = 'relacions_familiares',
  // Situación urgencia
  HECHOS_PRECIP_SIT_URG = 'hecho_prec_sit_urg',
  MOT_DEMANDA_SIT_URG = 'motiivo_demanda_sit_urg',
  QUIEN_PLANTEA_SIT_URG = 'quien_plantea_sit_urg',
  SANITARIO_ATIENDE_SIT_URG = 'sanitario_atiende_sit_urg',
  PERFIL_USUARIO_SIT_URG = 'perfil_usuario_sit_urg',
  ON_TROVA_USUARI_PARE = 'on_es_trova_usuari_pare',
  ON_TROVA_USUARI_DOMICILI = 'on_es_trova_usuari_domicili',
  ON_TROVA_USUARI_SALUT = 'on_es_trova_usuari_salut',
  // Servicios prestados
  TIPOS_SERVICIOS_PRESTADOS = 'tipos_servicios_prestados',
  SERVICIOS_PRESTADOS = 'servicios_prestados',
  // Solicitudes
  ESTADOS_SOLICITUD_SAUV = 'solicitud_estados_sauv',
  ESTADOS_SOLICITUD_RESPIR = 'solicitud_estados_respir',
  ESTADOS_SOLICITUD_RESPIRPLUS = 'solicitud_estados_respirplus',
  ESTADOS_FACTURA_RESPIRPLUS = 'factura_estados_respirplus',
  ESTADOS_SOLICITUD_GUARDAMOBLES = 'solicitud_estados_guardamobles',

  // Pagaments
  FORMA_PAGAMENT_RESPIRPLUS = 'forma_pagament_respirplus',
  TIPUS_PAGAMENT_RESPIRPLUS = 'tipus_pagament_respirplus',
  CONCEPTE_GENERAL_PAGAMENT_RESPIRPLUS = 'concepte_general_pagament_respirplus',
  CONCEPTE_ESPECIFIC_PAGAMENT_RESPIRPLUS = 'concepte_especific_pagament_respirplus',

  // Centres

  CENTRES_SALUT = 'centre_salut',
  MOT_DEMANDA_SOLICITUD_RESPIR = 'motivo_demanda_sol_respir',
  MOT_RECHAZO_FACTURA_RESPIRPLUS = 'motivo_rechazo_fac_respirplus',
  RELACIONES_FAMILIARES_RESPIR = 'relaciones_familiares_respir',
  VIVIENDA_ESTADOS_ECONOMICO = 'vivienda_estados_economico',
  VIVIENDA_TIPOS_VIVIENDA = 'vivienda_tipos_vivienda',
  VIVIENDA_TIPOS_PROPIETARIO = 'vivienda_tipos_propietario',
  TIPO_TAREA = 'tipo_tarea',
  ESTADO_CONTRATO = 'estado_contrato',
  TIPO_CONTRATO = 'tipo_contrato',
  TIPO_UNIDADES = 'tipo_unidades',
  TIPO_PLAZAS = 'tipo_plazas',

  RECURSO_MOTIVO_INTERRUPCION = 'recurso_motivo_interrupcion',
  RECURSO_MOTIVO_SALIDAVOL = 'recurso_motivo_salida_voluntaria',
  RECURSO_TIPO_INTERRUPCION = 'recurso_tipo_interrupcion',
  RECURSO_MOTIVOS_CAMBIO = 'recurso_motivos_cambio',
  RECURSO_PLAZAS_MUNICIPALES = 'recurso_plazas_municipales',
  RECURSO_PETICIONARIOS = 'recurso_peticionarios',
  RECURSO_MOTIVOS_BAJA = 'recurso_motivos_baja',
  RECURSO_TIPO_SALIDA = 'recurso_tipo_salida',
  RECURSO_TIPO_COMENTARIO = 'recurso_tipo_comentario',

  TIPO_RECURSO = 'tipo_recurso',

  RESPUESTAS_OTROS_DATOS_SALUT = 'respuestas_otros_datos_salut',
  TIPO_TOXICOMANIA = 'tipo_toxicomania',

  TIPO_ACOMPANYAMENT = 'tipo_acompanyament',

  RESIDENCIAS_PUBLICAS = 'residencias_publicas',

  // tipos documentos
  // TIPO_DOCUMENTOS_ADJUNTOS = 'tipo_documentos_adjuntos',
  TIPO_DOCUMENTOS_ADJUNTOS_HABITATGES = 'tipo_documentos_adjuntos_habitatges',
  TIPO_DOCUMENTOS_ADJUNTOS_RESPIR = 'tipo_documentos_adjuntos_respir',
  TIPO_DOCUMENTOS_ADJUNTOS_RESPIR_PLUS = 'tipo_documentos_adjuntos_respir_plus',
  TIPO_DOCUMENTOS_ADJUNTOS_GUARDAMOBLES = 'tipo_documentos_adjuntos_guardamobles',
  TIPO_DOCUMENTOS_ADJUNTOS_SAUV = 'tipo_documentos_adjuntos_sauv',
  TIPO_DOCUMENTOS_ADJUNTOS_CONTRACTE = 'tipo_documentos_adjuntos_contracte',
  TIPO_DOCUMENTOS_ADJUNTOS_EQUIPAMENTS = 'tipo_documentos_adjuntos_equipaments',
  TIPO_DOCUMENTOS_ADJUNTOS_INCIDENCIES_USUARI = 'tipo_documentos_adjuntos_incidencies_usuari',
  TIPO_DOCUMENTOS_ADJUNTOS_INCIDENCIES_EQUIPAMENTS = 'tipo_documentos_adjuntos_incidencies_equipaments',


  GRADO_DISCAPACIDAD = 'grado_discapacidad',

  NUM_PERSONAS_PERCEPTORAS = 'num_personas_perceptoras',

  TIPO_INCIDENCIAS_USUARIO = 'tipo_incidencias_usuario',
  TIPO_INCIDENCIAS_EQUIPAMENT = 'tipo_incidencias_equipament',

  GRAVEDAD_INCIDENCIA = 'gravedad_incidencias',

  ESTADOS_RESIDUSOS_GM = 'estado_residuos_gm',

  TIPUS_PETICIO_TRASLLAT = 'tipus_peticio_trasllat',

  ESTADOS_SOLICITUD_PRORROGUES_GUARDAMOBLES = 'estados_solicitud_prorrogues_guardamobles',
  ESTADOS_SALIDAS_GUARDAMOBLES = 'estados_salida_guardamobles',
  MOTIU_SOLLICITUD_GUARDAMOBLES = 'motiu_sollicitud_guardamobles',

  //Presupuestos
  PERIODOS_FACTURACION_PRESUPUESTARIOS = 'periodos_facturacion_presupuestarios',
  CAPITULOS_PRESUPUESTARIOS = 'capitulos_presupuestarios',
  TERRITORIOS_PRESUPUESTO = 'territorios_presupuesto',
  //PAI
  TIPUS_FREQUENCIA_PAI = 'tipo_frequencias'
}

enum DiccionarioPareId {
  CARACTERISTICAS = '2001000',
  TIPO_INSPECCIONES = '2002000',
  // Datos basicos usuario
  GENERO = '71010',
  ESTADOCIVIL = '71040',
  PAIS = '73100',
  TIPO_DOCUMENTOS = '100000',
  IDIOMA = '76100',
  // Direccion usuario
  PBA = '100474',
  DISTRICTES = '80100',

  TIPO_RESPUESTAS = '100900',
  ESTADO_RECURSOS = '90000',
  // Consentimiento informado
  ESTADOS_CONSENTIMIENTO = '2004000',
  TIPOS_TRATAMIENTO = '2003000',
  // Test Barthel
  PREGUNTAS_TEST_BARTHEL = '2012000',
  RESPUESTAS_TEST_BARTHEL = '2013000',
  // Test Pfeiffer
  PREGUNTAS_TEST_PFEIFFER = '2014000',
  RESPUESTAS_TEST_PFEIFFER = '2015000',

  PEV_GRADOS = '2016000',
  ESTADOS_INCAPACITACION = '100080',
  RELACIONES_FAMILIARES = '75200',
  // Situación urgencia
  HECHOS_PRECIP_SIT_URG = '2005000',
  MOT_DEMANDA_SIT_URG = '2006000',
  QUIEN_PLANTEA_SIT_URG = '2007000',
  SANITARIO_ATIENDE_SIT_URG = '2008000',
  ON_TROVA_USUARI_PARE = '2083000',
  ON_TROVA_USUARI_DOMICILI = '2083100',
  ON_TROVA_USUARI_SALUT = '2083200',
  PERFIL_USUARIO_SIT_URG = '2010000',
  // Servicios prestados
  TIPOS_SERVICIOS_PRESTADOS = '2019100',
  SERVICIOS_PRESTADOS = '2019200',

  CENTRES_SALUT = '2020000',

  MOT_DEMANDA_SOLICITUD_RESPIR = '2027000',
  RELACIONES_FAMILIARES_RESPIR = '71030',
  MOT_RECHAZO_FACTURA_RESPIRPLUS = '2037000',
  VIVIENDA_ESTADOS_ECONOMICO = '2018000',
  VIVIENDA_TIPOS_VIVIENDA = '10110',
  VIVIENDA_TIPOS_PROPIETARIO = '2017000',
  TIPO_TAREA = '100422',
  ESTADO_CONTRATO = '2023100',
  TIPO_CONTRATO = '2023200',
  TIPO_UNIDADES = '2019500',
  TIPO_PLAZAS = '2025000',

  RECURSO_MOTIVO_INTERRUPCION = '2021000',
  RECURSO_MOTIVO_SALIDAVOL = '2024000',
  RECURSO_TIPO_INTERRUPCION = '2022000',
  RECURSO_MOTIVOS_CAMBIO = '2026000',
  RECURSO_PLAZAS_MUNICIPALES = '2032000',
  RECURSO_PETICIONARIOS = '2031000',
  RECURSO_MOTIVOS_BAJA = '2029000',
  RECURSO_TIPO_SALIDA = '2030000',
  RECURSO_TIPO_COMENTARIO = '2033000',

  TIPO_RECURSO = '63000',

  RESPUESTAS_OTROS_DATOS_SALUT = '2040000',
  TIPO_TOXICOMANIA = '100110',

  TIPO_ACOMPANYAMENT = '2050000',

  RESIDENCIAS_PUBLICAS = '2060000',

  //tipos documentos
  TIPO_DOCUMENTOS_ADJUNTOS_HABITATGES = '2070000',
  TIPO_DOCUMENTOS_ADJUNTOS_RESPIR = '2071000',
  TIPO_DOCUMENTOS_ADJUNTOS_RESPIR_PLUS = '2072000',
  TIPO_DOCUMENTOS_ADJUNTOS_GUARDAMOBLES = '2073000',
  TIPO_DOCUMENTOS_ADJUNTOS_SAUV = '2074000',
  TIPO_DOCUMENTOS_ADJUNTOS_CONTRACTE = '2078000',
  TIPO_DOCUMENTOS_ADJUNTOS_EQUIPAMENTS = '2079000',
  TIPO_DOCUMENTOS_ADJUNTOS_INCIDENCIES_USUARI = '2081000',
  TIPO_DOCUMENTOS_ADJUNTOS_INCIDENCIES_EQUIPAMENTS = '2082000',

  GRADO_DISCAPACIDAD = '72300',
  FORMA_PAGAMENT_RESPIRPLUS_PARE = '1034500',
  TIPUS_PAGAMENT_RESPIRPLUS_PARE = '1034400',
  CONCEPTE_GENERAL_PAGAMENT_RESPIRPLUS_PARE = '1034600',
  CONCEPTE_ESPECIFIC_PAGAMENT_RESPIRPLUS_PARE = '1034700',

  NUM_PERSONAS_PERCEPTORAS = '2080000',

  TIPO_INCIDENCIAS_USUARIO = '2090000',
  TIPO_INCIDENCIAS_EQUIPAMENT = '2091000',
  GRAVEDAD_INCIDENCIA = '2092000',

  TIPUS_PETICIO_TRASLLAT = '2034000',
  ESTADOS_SALIDAS_GUARDAMOBLES = '2990200',
  MOTIU_SOLLICITUD_GUARDAMOBLES = '2035000',

  //Presupuestos
  PERIODOS_FACTURACION_PRESUPUESTARIOS = '2990500',
  CAPITULOS_PRESUPUESTARIOS = '2990400',
  TERRITORIOS_PRESUPUESTO = '2990300',
  
  TIPUS_FREQUENCIA_PAI = '2019300',
}

export function mapDictionary(key: string) {
  return (input$) =>
    input$.pipe(
      map((carac: ValorDiccionariResultsRDTO[]) => {
        return {
          [key]: carac.map((c) => mapDependingOnkey(c, key)),
        };
      })
    );
}

function mapDependingOnkey(carac: ValorDiccionariResultsRDTO, key: string) {
  switch (key) {
    case DiccionarioKey.DISTRICTES: {
      // fix para los valores de los distritos
      return {
        value: String(carac.mestreId - CODE_INITIAL_DISTRITOS_ID).padStart(
          NUM_MAX_LENGTH_DISTRITO_ID,
          '0'
        ),
        label: carac.nom,
        order: carac.ordre ? carac.ordre : 0,
        disabled: carac.seleccionable 
      };
    }
    case DiccionarioKey.PBA: {
      return {
        value: carac.nom,
        label:
          carac.descripcio[0] + carac.descripcio.substr(1).toLocaleLowerCase(),
         order: carac.ordre ? carac.ordre : 0,
         disabled: carac.seleccionable 
      };
    }
    case DiccionarioKey.TIPO_DOCUMENTOS: {
      return {
        value: carac.mestreId,
        label:
          carac.mestreId !== CODE_TIPO_DOCUMENTO_DNI &&
          carac.mestreId !== CODE_TIPO_DOCUMENTO_NIE
            ? carac.nom[0] + carac.nom.substr(1).toLocaleLowerCase()
            : carac.nom,
          order: carac.ordre ? carac.ordre : 0,
          disabled: carac.seleccionable 
      };
    }
    case DiccionarioKey.PEV_GRADOS: {
      return {
        value: carac.mestreId,
        label: carac.descripcio.includes(' I')
          ? carac.descripcio[0] +
            carac.descripcio.substr(1, 3).toLocaleLowerCase() +
            carac.descripcio.substr(4)
          : carac.descripcio[0] +
            carac.descripcio.substr(1).toLocaleLowerCase(),
        order: carac.ordre ? carac.ordre : 0,
        disabled: carac.seleccionable 
      };
    }
    default: {
      return {
        value: carac.mestreId,
        label:
          carac.descripcio[0] + carac.descripcio.substr(1).toLocaleLowerCase(),
        order: carac.ordre ? carac.ordre : 0,
        disabled: !carac.seleccionable 
      };
    }
  }
}


@Injectable({
  providedIn: 'root',
})
export class DictionaryService implements OnDestroy {
  constructor(
    private dictionaryStore: DictionaryStore,
    private dictionaryDataservice: DictionaryDataService,
    private dictionaryQuery: DictionaryQuery,
    private direccionService: DireccionService,
    private solicitudService: SolicitudesService,
    private recursosService: RecursosService,
    private sessionQuery: SessionQuery
  ) {}

  getCaracteristicas() {
    return this._getByKeyAndPareId(
      DiccionarioKey.CARACTERISTICAS,
      DiccionarioPareId.CARACTERISTICAS
    );
  }

  getTipoInspecciones() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPO_INSPECCIONES,
      DiccionarioPareId.TIPO_INSPECCIONES
    );
  }

  getTipoRespuestas() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPO_RESPUESTAS,
      DiccionarioPareId.TIPO_RESPUESTAS
    );
  }

  getTipoDocumentos() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPO_DOCUMENTOS,
      DiccionarioPareId.TIPO_DOCUMENTOS
    );
  }

  getGeneros() {
    return this._getByKeyAndPareId(
      DiccionarioKey.GENERO,
      DiccionarioPareId.GENERO
    );
  }

  getPaises() {
    return this._getByKeyAndPareId(DiccionarioKey.PAIS, DiccionarioPareId.PAIS);
  }

  getEstadosCiviles() {
    return this._getByKeyAndPareId(
      DiccionarioKey.ESTADOCIVIL,
      DiccionarioPareId.ESTADOCIVIL
    );
  }

  getIdiomas() {
    return this._getByKeyAndPareId(
      DiccionarioKey.IDIOMA,
      DiccionarioPareId.IDIOMA
    );
  }

  getDistrictes() {
    return this._getByKeyAndPareId(
      DiccionarioKey.DISTRICTES,
      DiccionarioPareId.DISTRICTES
    );
  }

  getPBA() {
    return this._getByKeyAndPareId(DiccionarioKey.PBA, DiccionarioPareId.PBA);
  }

  getEstadosConsentimiento() {
    return this._getByKeyAndPareId(
      DiccionarioKey.ESTADOS_CONSENTIMIENTO,
      DiccionarioPareId.ESTADOS_CONSENTIMIENTO
    );
  }

  getTiposTratamiento() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPOS_TRATAMIENTO,
      DiccionarioPareId.TIPOS_TRATAMIENTO
    );
  }

  getRelacionesFamiliares() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RELACIONES_FAMILIARES,
      DiccionarioPareId.RELACIONES_FAMILIARES
    );
  }

  getPreguntasTestBarthel() {
    return this._getByKeyAndPareId(
      DiccionarioKey.PREGUNTAS_TEST_BARTHEL,
      DiccionarioPareId.PREGUNTAS_TEST_BARTHEL
    );
  }

  getRespuestasTestBarthel() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RESPUESTAS_TEST_BARTHEL,
      DiccionarioPareId.RESPUESTAS_TEST_BARTHEL
    );
  }

  getRespuestasTestPfeiffer() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RESPUESTAS_TEST_PFEIFFER,
      DiccionarioPareId.RESPUESTAS_TEST_PFEIFFER
    );
  }

  getPreguntasTestPfeiffer() {
    return this._getByKeyAndPareId(
      DiccionarioKey.PREGUNTAS_TEST_PFEIFFER,
      DiccionarioPareId.PREGUNTAS_TEST_PFEIFFER
    );
  }

  getGradosPev() {
    return this._getByKeyAndPareId(
      DiccionarioKey.PEV_GRADOS,
      DiccionarioPareId.PEV_GRADOS
    );
  }

  getEstadosIncapacitacion() {
    return this._getByKeyAndPareId(
      DiccionarioKey.ESTADOS_INCAPACITACION,
      DiccionarioPareId.ESTADOS_INCAPACITACION
    );
  }

  getHechoPrecipitanteSituaUrgencia() {
    return this._getByKeyAndPareId(
      DiccionarioKey.HECHOS_PRECIP_SIT_URG,
      DiccionarioPareId.HECHOS_PRECIP_SIT_URG
    );
  }

  getMotivoDemandaSituaUrgencia() {
    return this._getByKeyAndPareId(
      DiccionarioKey.MOT_DEMANDA_SIT_URG,
      DiccionarioPareId.MOT_DEMANDA_SIT_URG
    );
  }

  getQuienPlanteaSituaUrgencia() {
    return this._getByKeyAndPareId(
      DiccionarioKey.QUIEN_PLANTEA_SIT_URG,
      DiccionarioPareId.QUIEN_PLANTEA_SIT_URG
    );
  }

  getUbicacionUsuarioSituaUrgenciaPare() {
    return this._getByKeyAndPareId(
      DiccionarioKey.ON_TROVA_USUARI_PARE,
      DiccionarioPareId.ON_TROVA_USUARI_PARE
    );
  }

  getUbicacionUsuarioSituaUrgenciaDomicili() {
    return this._getByKeyAndPareId(
      DiccionarioKey.ON_TROVA_USUARI_DOMICILI,
      DiccionarioPareId.ON_TROVA_USUARI_DOMICILI
    );
  }

  getUbicacionUsuarioSituaUrgenciaSalut() {
    return this._getByKeyAndPareId(
      DiccionarioKey.ON_TROVA_USUARI_SALUT,
      DiccionarioPareId.ON_TROVA_USUARI_SALUT
    );
  }

  getSanitarioAtieneSituaUrgencia() {
    return this._getByKeyAndPareId(
      DiccionarioKey.SANITARIO_ATIENDE_SIT_URG,
      DiccionarioPareId.SANITARIO_ATIENDE_SIT_URG
    );
  }

  getPerfilUsuarioSituaUrgencia() {
    return this._getByKeyAndPareId(
      DiccionarioKey.PERFIL_USUARIO_SIT_URG,
      DiccionarioPareId.PERFIL_USUARIO_SIT_URG
    );
  }

  getViviendaEstadosEconomicos() {
    return this._getByKeyAndPareId(
      DiccionarioKey.VIVIENDA_ESTADOS_ECONOMICO,
      DiccionarioPareId.VIVIENDA_ESTADOS_ECONOMICO
    );
  }

  getViviendaTiposVivienda() {
    return this._getByKeyAndPareId(
      DiccionarioKey.VIVIENDA_TIPOS_VIVIENDA,
      DiccionarioPareId.VIVIENDA_TIPOS_VIVIENDA
    );
  }

  getViviendaTiposPropietario() {
    return this._getByKeyAndPareId(
      DiccionarioKey.VIVIENDA_TIPOS_PROPIETARIO,
      DiccionarioPareId.VIVIENDA_TIPOS_PROPIETARIO
    );
  }

  getTiposServiciosPrestados() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPOS_SERVICIOS_PRESTADOS,
      DiccionarioPareId.TIPOS_SERVICIOS_PRESTADOS
    );
  }

  getServiciosPrestados() {
    return this._getByKeyAndPareId(
      DiccionarioKey.SERVICIOS_PRESTADOS,
      DiccionarioPareId.SERVICIOS_PRESTADOS
    );
  }

  getEstadosContrato() {
    return this._getByKeyAndPareId(
      DiccionarioKey.ESTADO_CONTRATO,
      DiccionarioPareId.ESTADO_CONTRATO
    );
  }

  getTiposContrato() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPO_CONTRATO,
      DiccionarioPareId.TIPO_CONTRATO
    );
  }

  getTiposTareas() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPO_TAREA,
      DiccionarioPareId.TIPO_TAREA
    );
  }

  getTipoPlazas() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPO_PLAZAS,
      DiccionarioPareId.TIPO_PLAZAS
    );
  }

  getTipoUnidades() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPO_UNIDADES,
      DiccionarioPareId.TIPO_UNIDADES
    );
  }

  getPlazasMunicipales() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RECURSO_PLAZAS_MUNICIPALES,
      DiccionarioPareId.RECURSO_PLAZAS_MUNICIPALES
    );
  }

  getPeticionarios() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RECURSO_PETICIONARIOS,
      DiccionarioPareId.RECURSO_PETICIONARIOS
    );
  }

  getRespuestasEstadoRecursos() {
    return this._getByKeyAndPareId(
      DiccionarioKey.ESTADO_RECURSOS,
      DiccionarioPareId.ESTADO_RECURSOS
    );
  }

  getRecursoMotivosInterrupcion() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RECURSO_MOTIVO_INTERRUPCION,
      DiccionarioPareId.RECURSO_MOTIVO_INTERRUPCION
    );
  }

  getRecursoMotivosSalidaVoluntaria() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RECURSO_MOTIVO_SALIDAVOL,
      DiccionarioPareId.RECURSO_MOTIVO_SALIDAVOL
    );
  }

  getRecursoTiposInterrupcion() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RECURSO_TIPO_INTERRUPCION,
      DiccionarioPareId.RECURSO_TIPO_INTERRUPCION
    );
  }

  getRecursosMotivosCambios() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RECURSO_MOTIVOS_CAMBIO,
      DiccionarioPareId.RECURSO_MOTIVOS_CAMBIO
    );
  }

  getRecursosMotivosBaja() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RECURSO_MOTIVOS_BAJA,
      DiccionarioPareId.RECURSO_MOTIVOS_BAJA
    );
  }

  getRecursosTiposSalida() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RECURSO_TIPO_SALIDA,
      DiccionarioPareId.RECURSO_TIPO_SALIDA
    );
  }

  getMotivosDemandaSolRespir() {
    return this._getByKeyAndPareId(
      DiccionarioKey.MOT_DEMANDA_SOLICITUD_RESPIR,
      DiccionarioPareId.MOT_DEMANDA_SOLICITUD_RESPIR
    );
  }

  getMotivosRechazoFacturaRespirplus() {
    return this._getByKeyAndPareId(
      DiccionarioKey.MOT_RECHAZO_FACTURA_RESPIRPLUS,
      DiccionarioPareId.MOT_RECHAZO_FACTURA_RESPIRPLUS
    );
  }

  getRelacionesFamiliaresRespir() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RELACIONES_FAMILIARES_RESPIR,
      DiccionarioPareId.RELACIONES_FAMILIARES_RESPIR
    );
  }

  getRecursoTiposComentarios() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RECURSO_TIPO_COMENTARIO,
      DiccionarioPareId.RECURSO_TIPO_COMENTARIO
    );
  }

  getCentrosSalut() {
    return this._getByKeyAndPareId(
      DiccionarioKey.CENTRES_SALUT,
      DiccionarioPareId.CENTRES_SALUT
    );
  }

  getTipoRecursos() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPO_RECURSO,
      DiccionarioPareId.TIPO_RECURSO
    );
  }

  getRespuestasOtrosDatosSalut() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RESPUESTAS_OTROS_DATOS_SALUT,
      DiccionarioPareId.RESPUESTAS_OTROS_DATOS_SALUT
    );
  }

  getTipoToxicomania() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPO_TOXICOMANIA,
      DiccionarioPareId.TIPO_TOXICOMANIA
    );
  }

  getTipoAcompanyament() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPO_ACOMPANYAMENT,
      DiccionarioPareId.TIPO_ACOMPANYAMENT
    );
  }

  getResidenciasPublicas() {
    return this._getByKeyAndPareId(
      DiccionarioKey.RESIDENCIAS_PUBLICAS,
      DiccionarioPareId.RESIDENCIAS_PUBLICAS
    );
  }

  getGradoDiscapacidad() {
    return this._getByKeyAndPareId(
      DiccionarioKey.GRADO_DISCAPACIDAD,
      DiccionarioPareId.GRADO_DISCAPACIDAD
    );
  }

  getTipoDocumentosAdjuntos() {
    const ubicacionUI: UbicacionUI = this.sessionQuery.getUbicacionUI();
    switch (ubicacionUI) {
      default: return of(null);
      case UbicacionUI.CONTRACTES:
        return this._getByKeyAndPareId(
          DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_CONTRACTE,
          DiccionarioPareId.TIPO_DOCUMENTOS_ADJUNTOS_CONTRACTE
        );
      case UbicacionUI.EQUIPAMENTS:
        return this._getByKeyAndPareId(
          DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_EQUIPAMENTS,
          DiccionarioPareId.TIPO_DOCUMENTOS_ADJUNTOS_EQUIPAMENTS
        );
      case UbicacionUI.INCIDENCIA_EQUIPAMENTS:
        return this._getByKeyAndPareId(
          DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_INCIDENCIES_EQUIPAMENTS,
          DiccionarioPareId.TIPO_DOCUMENTOS_ADJUNTOS_INCIDENCIES_EQUIPAMENTS
        );
      case UbicacionUI.INCIDENCIA_USUARI:
        return this._getByKeyAndPareId(
          DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_INCIDENCIES_USUARI,
          DiccionarioPareId.TIPO_DOCUMENTOS_ADJUNTOS_INCIDENCIES_USUARI
        );
      case UbicacionUI.FITXA_USUARI:
        if(this.sessionQuery.isServiceViviendas()){
          return this._getByKeyAndPareId(
            DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_HABITATGES,
            DiccionarioPareId.TIPO_DOCUMENTOS_ADJUNTOS_HABITATGES
          );
        }
        else if(this.sessionQuery.isServiceRespir()) {
          return this._getByKeyAndPareId(
            DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR,
            DiccionarioPareId.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR
          );
        }
        else if(this.sessionQuery.isServiceRespirPlus()) {
          return this._getByKeyAndPareId(
            DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR_PLUS,
            DiccionarioPareId.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR_PLUS
          );
        }
        else if(this.sessionQuery.isServiceGuardamuebles()) {
          return this._getByKeyAndPareId(
            DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_GUARDAMOBLES,
            DiccionarioPareId.TIPO_DOCUMENTOS_ADJUNTOS_GUARDAMOBLES
          );
        }
        else if(this.sessionQuery.isServiceSAUV()) {
          return this._getByKeyAndPareId(
            DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_SAUV,
            DiccionarioPareId.TIPO_DOCUMENTOS_ADJUNTOS_SAUV
          );
        }
    }
  }

  getKeyTipoAdjuntos(): string {
    const ubicacionUI: UbicacionUI = this.sessionQuery.getUbicacionUI();
    switch (ubicacionUI) {
      case UbicacionUI.CONTRACTES:
        return DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_CONTRACTE
      case UbicacionUI.EQUIPAMENTS:
        return DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_EQUIPAMENTS
      case UbicacionUI.INCIDENCIA_EQUIPAMENTS:
        return DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_INCIDENCIES_EQUIPAMENTS
      case UbicacionUI.INCIDENCIA_USUARI:
        return DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_INCIDENCIES_USUARI
      case UbicacionUI.FITXA_USUARI:
        if(this.sessionQuery.isServiceViviendas()){
          return DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_HABITATGES
        }
        else if(this.sessionQuery.isServiceRespir()) {
          return DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR
        }
        else if(this.sessionQuery.isServiceRespirPlus()) {
          return DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR_PLUS
        }
        else if(this.sessionQuery.isServiceGuardamuebles()) {
          return DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_GUARDAMOBLES
        }
        else if(this.sessionQuery.isServiceSAUV()) {
          return DiccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_SAUV
        } 
    }
  }

  getFormaPagamentRespirPlus() {
    return this._getByKeyAndPareId(
      DiccionarioKey.FORMA_PAGAMENT_RESPIRPLUS,
      DiccionarioPareId.FORMA_PAGAMENT_RESPIRPLUS_PARE
    );
  }

  getTipusPagamentRespirPlus() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPUS_PAGAMENT_RESPIRPLUS,
      DiccionarioPareId.TIPUS_PAGAMENT_RESPIRPLUS_PARE
    );
  }

  getConcepteGeneral() {
    return this._getByKeyAndPareId(
      DiccionarioKey.CONCEPTE_GENERAL_PAGAMENT_RESPIRPLUS,
      DiccionarioPareId.CONCEPTE_GENERAL_PAGAMENT_RESPIRPLUS_PARE
    );
  }

  getConcepteEspecific() {
    return this._getByKeyAndPareId(
      DiccionarioKey.CONCEPTE_ESPECIFIC_PAGAMENT_RESPIRPLUS,
      DiccionarioPareId.CONCEPTE_ESPECIFIC_PAGAMENT_RESPIRPLUS_PARE
    );
  }

  getNumPersonasPerceptoras() {
    return this._getByKeyAndPareId(
      DiccionarioKey.NUM_PERSONAS_PERCEPTORAS,
      DiccionarioPareId.NUM_PERSONAS_PERCEPTORAS
    );
  }

  getTipoIncidenciasUsuario() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPO_INCIDENCIAS_USUARIO,
      DiccionarioPareId.TIPO_INCIDENCIAS_USUARIO
    );
  }

  getTipoIncidenciasEquipament() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPO_INCIDENCIAS_EQUIPAMENT,
      DiccionarioPareId.TIPO_INCIDENCIAS_EQUIPAMENT
    );
  }

  getGravedadIncidencias() {
    return this._getByKeyAndPareId(
      DiccionarioKey.GRAVEDAD_INCIDENCIA,
      DiccionarioPareId.GRAVEDAD_INCIDENCIA
    );
  }

  getTipusPeticioTrasllatsGM() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPUS_PETICIO_TRASLLAT,
      DiccionarioPareId.TIPUS_PETICIO_TRASLLAT
    );
  }
  getTipusSalidasGM() {
    return this._getByKeyAndPareId(
      DiccionarioKey.ESTADOS_SALIDAS_GUARDAMOBLES,
      DiccionarioPareId.ESTADOS_SALIDAS_GUARDAMOBLES
    );
  }
  getTipusMotiuSollicitudGM() {
    return this._getByKeyAndPareId(
      DiccionarioKey.MOTIU_SOLLICITUD_GUARDAMOBLES,
      DiccionarioPareId.MOTIU_SOLLICITUD_GUARDAMOBLES
    );
  }
  getTipusFrequenciaPAI() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TIPUS_FREQUENCIA_PAI,
      DiccionarioPareId.TIPUS_FREQUENCIA_PAI
    );
  }

  getCapitulosPresupuestarios() {
    return this._getByKeyAndPareId(
      DiccionarioKey.CAPITULOS_PRESUPUESTARIOS,
      DiccionarioPareId.CAPITULOS_PRESUPUESTARIOS
    );
  }

  getPeriodosPresupuestarios() {
    return this._getByKeyAndPareId(
      DiccionarioKey.PERIODOS_FACTURACION_PRESUPUESTARIOS,
      DiccionarioPareId.PERIODOS_FACTURACION_PRESUPUESTARIOS
    );
  }

  getTerritorios() {
    return this._getByKeyAndPareId(
      DiccionarioKey.TERRITORIOS_PRESUPUESTO,
      DiccionarioPareId.TERRITORIOS_PRESUPUESTO
    );
  }

  getEstadosSolicitud_SAUV() {
    if (
      this.dictionaryQuery.getDictionaryKey(
        DiccionarioKey.ESTADOS_SOLICITUD_SAUV
      ).length === 0
    ) {
      return this.solicitudService.getEstadosSolicitudSAUV().pipe(
        map((res) => {
          return {
            [DiccionarioKey.ESTADOS_SOLICITUD_SAUV]: res,
          };
        }),
        tap((dictionary) => this.dictionaryStore.update(dictionary))
      );
    }
    return of(null);
  }

  getEstadosSolicitud_RESPIR() {
    if (
      this.dictionaryQuery.getDictionaryKey(
        DiccionarioKey.ESTADOS_SOLICITUD_RESPIR
      ).length === 0
    ) {
      return this.solicitudService.getEstadosSolicitudRESPIR().pipe(
        map((res) => {
          return {
            [DiccionarioKey.ESTADOS_SOLICITUD_RESPIR]: res,
          };
        }),
        tap((dictionary) => this.dictionaryStore.update(dictionary))
      );
    }
    return of(null);
  }

  getEstadosSolicitud_RESPIRPLUS() {
    if (
      this.dictionaryQuery.getDictionaryKey(
        DiccionarioKey.ESTADOS_SOLICITUD_RESPIRPLUS
      ).length === 0
    ) {
      return this.solicitudService.getEstadosSolicitudRESPIRPLUS().pipe(
        map((res) => {
          return {
            [DiccionarioKey.ESTADOS_SOLICITUD_RESPIRPLUS]: res,
          };
        }),
        tap((dictionary) => this.dictionaryStore.update(dictionary))
      );
    }
    return of(null);
  }

  getEstadosFactura_RESPIRPLUS() {
    if (
      this.dictionaryQuery.getDictionaryKey(
        DiccionarioKey.ESTADOS_FACTURA_RESPIRPLUS
      ).length === 0
    ) {
      return this.solicitudService.getEstadosFacturaRESPIRPLUS().pipe(
        map((res) => {
          return {
            [DiccionarioKey.ESTADOS_FACTURA_RESPIRPLUS]: res,
          };
        }),
        tap((dictionary) => this.dictionaryStore.update(dictionary))
      );
    }
    return of(null);
  }

  // getTipusPagament_RESPIRPLUS() {
  //   if (
  //     this.dictionaryQuery.getDictionaryKey(
  //       DiccionarioKey.TIPO_PAGAMENTS_RESPIRPLUS
  //     ).length === 0
  //   ) {
  //     return this.solicitudService.getTipusPagamentRESPIRPLUS().pipe(
  //       map(res => {
  //         return {
  //           [DiccionarioKey.TIPO_PAGAMENTS_RESPIRPLUS]: res
  //         };
  //       }),
  //       tap(dictionary => this.dictionaryStore.update(dictionary))
  //     );
  //   }
  //   return of(null);
  // }

  getEstadosSolicitud_GUARDAMOBLES() {
    if (
      this.dictionaryQuery.getDictionaryKey(
        DiccionarioKey.ESTADOS_SOLICITUD_GUARDAMOBLES
      ).length === 0
    ) {
      return this.solicitudService.getEstadosSolicitudGUARDAMOBLES().pipe(
        map((res) => {
          return {
            [DiccionarioKey.ESTADOS_SOLICITUD_GUARDAMOBLES]: res,
          };
        }),
        tap((dictionary) => this.dictionaryStore.update(dictionary))
      );
    }
    return of(null);
  }

  getEstadosSolicitudProrrogues_GUARDAMOBLES() {
    if (
      this.dictionaryQuery.getDictionaryKey(
        DiccionarioKey.ESTADOS_SOLICITUD_PRORROGUES_GUARDAMOBLES
      ).length === 0
    ) {
      return this.solicitudService
        .getEstadosSolicitudProrrogaGUARDAMOBLES()
        .pipe(
          map((res) => {
            return {
              [DiccionarioKey.ESTADOS_SOLICITUD_PRORROGUES_GUARDAMOBLES]: res,
            };
          }),
          tap((dictionary) => this.dictionaryStore.update(dictionary))
        );
    }
    return of(null);
  }

  getEstadosResiduos_GUARDAMOBLES() {
    if (
      this.dictionaryQuery.getDictionaryKey(DiccionarioKey.ESTADOS_RESIDUSOS_GM)
        .length === 0
    ) {
      return this.recursosService.getEstadosResiduosGUARDAMOBLES().pipe(
        map((res) => {
          return {
            [DiccionarioKey.ESTADOS_RESIDUSOS_GM]: res,
          };
        }),
        tap((dictionary) => this.dictionaryStore.update(dictionary))
      );
    }
    return of(null);
  }

  getTiposVia() {
    const key = DiccionarioKey.TIPOS_VIA;

    if (this.dictionaryQuery.getDictionaryKey(key).length === 0) {
      return this.direccionService.getTiposVia().pipe(
        map((res) => {
          return {
            [key]: res,
          };
        }),
        tap((dictionary) => this.dictionaryStore.update(dictionary))
      );
    }
    return of(null);
  }

  getDictionaries() {
    const request$ = this.dictionaryDataservice
      .getDictionaries()
      .pipe(
        tap((dictionaries: any) => this.dictionaryStore.update(dictionaries))
      );

    return this.dictionaryQuery.getHasCache() ? of() : request$;
  }

  getDictionaryByMestreId(mestreId: number): Observable<ValorDiccionariResultsRDTO> {
    return this.dictionaryDataservice.getDiccionarioByMestreId(mestreId).pipe(
      map(val => {
        return val;
      })
    )
  }

  private _getByKeyAndPareId(key: string, pareID: string): Observable<any> {
    // Si no está en la store llamamos al servicio y guardamos
    if (this.dictionaryQuery.getDictionaryKey(key).length === 0) {
      return this.dictionaryDataservice.getDiccionarioByParent(pareID).pipe(
        mapDictionary(key),
        tap((dictionary) => {
          dictionary[key] = dictionary[key].sort((a, b) => a.order - b.order); // Ordenamos la lista segun orden ascendente
          this.dictionaryStore.update(dictionary)
        })
      );
    }
    return of(null);
  }

  ngOnDestroy() {}
}
