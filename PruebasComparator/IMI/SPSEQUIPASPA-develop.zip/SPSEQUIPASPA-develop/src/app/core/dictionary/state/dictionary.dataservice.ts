import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ValorDiccionariResultsRDTO } from '@app/core/model/information';
import { HttpRestClientCintraosService } from '@app/core/services/http-rest-client-cintraos.service';
import { environment } from '@env/environment';
import { Cacheable } from 'ngx-cacheable';
import { Observable, of } from 'rxjs';

import { DictionaryState } from './dictionary.store';

@Injectable({
  providedIn: 'root'
})
export class DictionaryDataService {

  constructor(public httpClient: HttpRestClientCintraosService) {}

  @Cacheable()
  getDiccionarioByParent(
    pareId: string
  ): Observable<ValorDiccionariResultsRDTO[]> {
    const url = `diccionari/consultagrup`;
    const params = new HttpParams().set('pareId', pareId);
    return this.httpClient.get<ValorDiccionariResultsRDTO[]>(url, {
      params: params
    });
  }

  getDiccionarioByMestreId(mestreId: number): Observable<ValorDiccionariResultsRDTO> {
    const url = `diccionari/${mestreId}`;
    return this.httpClient.get<ValorDiccionariResultsRDTO>(url);
  }

  getDictionaries(): Observable<DictionaryState> {
    return of({
      estados: [{ id: 1, label: 'Actiu' }, { id: 0, label: 'No actiu' }],
      municipios: [
        { value: 'Alella', label: 'Alella' },
        { value: 'Badalona', label: 'Badalona' },
        { value: 'Castellolí', label: 'Castellolí' },
        { value: 'Igualada', label: 'Igualada' },
        { value: 'Cerdanyola del Vallés', label: 'Cerdanyola del Vallés' }
      ],
      categoriasFAQ: [
        { value: 'Categoria 1', label: 'Categoria 1' },
        { value: 'Categoria 2', label: 'Categoria 2' },
        { value: 'Categoria 3', label: 'Categoria 3' },
        { value: 'Categoria 4', label: 'Categoria 4' },
        { value: 'Categoria 5', label: 'Categoria 5' }
      ],
      unidades: [
        { value: 1, label: 'unidad1' },
        { value: 2, label: 'unidad2' },
        { value: 3, label: 'unidad3' },
        { value: 4, label: 'unidad4' },
        { value: 5, label: 'unidad5' }
      ],
      tiposTrasladoGM: [
        { label: 'Trasllat de domicili a domicili', value: 1 },
        { label: 'Trasllat de domicili a guardamobles', value: 2 },
        { label: 'Trasllat de guardamobles a domicili', value: 3 }
      ],
      estadosGuardamueblesGM: [
        { label: 'Planificat', value: 1 },
        { label: 'Actiu', value: 2 },
        { label: 'Finalitzat', value: 3 },
        { label: 'Cancel·lat', value: 4 }
      ],
      tiposSalida: [
        { label: 'a residus', value: 1 },
        { label: 'parcial', value: 2 }
      ],
      estadosSalidasGM: [
        { label: 'Pendent publicació', value: 1 },
        { label: 'Pendent autoritzar', value: 2 },
        { label: 'Planificat', value: 3 },
        { label: 'Realitzat', value: 4 },
        { label: 'Cancel·lat', value: 5 }
      ],
      estadosTrasladoGM: [
        { label: 'Pendent autoritzar', value: 1 },
        { label: 'Planificat', value: 2 },
        { label: 'Realitzat', value: 3 },
        { label: 'Cancel·lat', value: 4 }
      ]
      /* NO BORRAR A PARTIR DE AQUI ABAJO */
      /*   servicios: [
        { value: SERVICIO_RESPIR, label: 'Respir' },
        { value: SERVICIO_SAUV, label: 'Sauv' }
      ] */
    });
  }
}
