import { ErrorHandler, Injectable } from '@angular/core';

@Injectable()
export class GlobalErrorHandler extends ErrorHandler {

    handleError(error: any): void {

        const chunkFailedMessage = /Loading chunk [\d]+ failed/;

        if (chunkFailedMessage.test(error.message || "")) {

            // Sometimes with new deployments old chunks are not valid anymore 
            // but the browser still has them in cache which causes Loading chunk failed error.
            // This method force hard reload and clean browser cache

            this.handleHardReload(window.location.href);

        } else {

            super.handleError(error);
        }
    }

    private async handleHardReload(url) {

        // force hard reload and clean browser cache
        // first ask the server for last site's version 
        // then update browser's cache and reload the page
        // see fetch cache options: https://developer.mozilla.org/en-US/docs/Web/API/Request/cache

        fetch(url, { cache: "reload" }).then(() => window.location.reload()).catch(() => console.log("error in handler"));
    }


}