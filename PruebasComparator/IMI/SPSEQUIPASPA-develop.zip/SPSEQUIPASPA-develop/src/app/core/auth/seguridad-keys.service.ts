import { SeguridadKey } from './map-url-seguridad';
export class SeguridadKeysService {

  urlMap: Map<RegExp, number> = new Map();
  URL_KEY_PATTERN = /([\s\w\/])(\{[\w]+\})/;
  URL_REPLACE_KEY_PATTERN = "$1+[a-zA-Z0-9\-]*";

  constructor(urlServicio: SeguridadKey) { 
    this._initUrlMap(urlServicio);
  }

  public getIdMapUrlSeguridadByKey(key: string): string {
    return this._findKey(key) != null ? this._findKey(key).toString() : '9999';
  }

  private _findKey(key: string): number {
    let match = null;    
    this.urlMap.forEach((value: number, keyMap: RegExp) => {
      if (keyMap.test(key)) {
        match = value;
        return;
      }
    });
    return match;
  }

  private _initUrlMap(urlServicio: SeguridadKey) {
    Object.keys(urlServicio).map(key => {
      const keyPattern = key.replace(this.URL_KEY_PATTERN, this.URL_REPLACE_KEY_PATTERN);
      const expReg = new RegExp(keyPattern);
      this.urlMap.set(expReg, urlServicio[key]);
    });
  }

}
