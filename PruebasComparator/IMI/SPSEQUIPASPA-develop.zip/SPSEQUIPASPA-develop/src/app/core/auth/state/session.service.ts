import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ParametreResultsRDTO } from '@app/core/model/parametres-globals/parametres-globals';
import { resetStores } from '@datorama/akita';
import { SelectItem } from 'primeng/api';
import { Observable } from 'rxjs';
import { AuthUser, ImiAuthorization, ImiSpsInfo } from '../model';
import { SessionDataService } from './session.dataservice';
import { IncidenciaType, SessionStore, UbicacionUI } from './session.store';


@Injectable({
  providedIn: 'root'
})
export class SessionService {
  constructor(
    private authStore: SessionStore,
    private authDataService: SessionDataService,
    private http: HttpClient
  ) {}

  setLanguage(language: string): void {
    this.authStore.setLanguage(language);
  }

  setService(service: number): void {
    this.authStore.setService(service);
  }

  updateFichaUsuarioTab(tab: number) {
    this.authStore.updateFichaUsuarioTab(tab);
  }

  updateFichaUsuarioDatosComp(menu: string) {
    this.authStore.updateFichaUsuarioDatosComp(menu);
  }

  updateFichaUsuarioBloqSeg(menu: string) {
    this.authStore.updateFichaUsuarioBloqSeg(menu);
  }

  updateFichaUsuarioRecursos(menu: string) {
    this.authStore.updateFichaUsuarioRecursos(menu);
  }

  login(authUser: AuthUser) {
    const sessionState: any = {
      authUser: authUser
    }
    this.authStore.login(sessionState);
  }

  loginMock(id: string) {
    this.authStore.login(this.authDataService.getUser(id));
  }

  mockUsersLogin() {
    return Object.keys(this.authDataService.getUsers());
  }

  callSessionInfo(): Observable<ImiAuthorization> {
    const url = '/session/info';
    return this.http.get<ImiAuthorization>(url);
  }

  logout() {
    resetStores({
      // exclude: ['storeName']
    });
    // this.authStore.logout();
  }

  setPlacesSauv(equipaments: SelectItem[]) {
    this.authStore.setPlacesSauv(equipaments);
  }

  setPlacesViviendas(equipaments: SelectItem[]) {
    this.authStore.setPlacesViviendas(equipaments);
  }

  updatePGlobalServeisPrestats(pGlobalServeisPrestats: ParametreResultsRDTO[]) {
    this.authStore.updatePGlobalServeisPrestats(pGlobalServeisPrestats);
  }

  updateParametreGlobalRespirPlus(parametreGlobal: ParametreResultsRDTO[] ) {
    this.authStore.updateParametreGlobalRespirPlus(parametreGlobal);
  }

  resetParametresGlobalsRespirPlus() {
    this.authStore.resetParametresGlobalsRespirPlus();
  }

  setIncidenciaType(type: IncidenciaType) {
    this.authStore.setIncidenciaType(type);
  }

  setAuthUser(infoUserSecurity: AuthUser) {
    this.authStore.setAuthUser(infoUserSecurity);
  }

  updateImiSpsInfo(imiSpsInfo: ImiSpsInfo) {
    this.authStore.updateImiSpsInfo(imiSpsInfo);
  }

  setUbicacionUI(ubicacionUI: UbicacionUI) {
    this.authStore.setUbicacionUI(ubicacionUI);
  }

  resetUbicacionUI() {
    this.authStore.resetUbicacionUI();
  }

  setFiltroEstadoSolicitud(filtroEstadoSolicitud: number) {
    this.authStore.setFiltroEstadoSolicitud(filtroEstadoSolicitud);
  }

  resetFiltroEstadoSolicitud() {
    this.authStore.resetFiltroEstadoSolicitud();
  }
}

// export const sessionService = new SessionService(sessionStore);
