import { Injectable } from '@angular/core';
import {
  CanActivate, ActivatedRouteSnapshot, Router,
  CanActivateChild, UrlTree
} from '@angular/router';
import { SessionQuery } from '..';
import { DataRoutingGuard } from '../model';

@Injectable({
  providedIn: 'root'
})
export class AuthUserGuard implements CanActivate, CanActivateChild {

  constructor(private sessionQuery: SessionQuery, private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot): boolean | UrlTree {
    const data: DataRoutingGuard = new DataRoutingGuard(
      next.data.serviceRequired,
      next.data.imiSpsInfoRequired,
      next.data.urlToRedirect,
      next.data.inverse
    );
    let hasValues: boolean;
    if (data.serviceRequired === true) {
      hasValues = this.sessionQuery.getServiceActiveValue() !== null;
    } else {
      hasValues = this.sessionQuery.hasImiSpsInfoValueByKeys(data.imiSpsInfoRequired);
    }
    const activate = hasValues === !data.inverse;
    if (!activate && data.urlToRedirect) {
      return this.router.parseUrl(data.urlToRedirect);
    }
    return activate;
  }

  canActivateChild(next: ActivatedRouteSnapshot): boolean | UrlTree  {
    return this.canActivate(next);
  }
}
