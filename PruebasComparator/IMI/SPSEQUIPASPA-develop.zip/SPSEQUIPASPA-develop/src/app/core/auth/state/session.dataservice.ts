import { Injectable } from '@angular/core';
import { ServiciosIMI } from '@app/core/model/servicio';
import { Observable, of } from 'rxjs';
import { MOCK_AUTH_USERS } from '../model';

import { RolesUser, RolesUserIds } from './session.store';

@Injectable({
  providedIn: 'root',
})
export class SessionDataService {
  login(creds): Observable<any> {
    return of({
      token: 'token',
      user: {
        nom: 'Estel Ventura Llopart',
        grupId: '',
        perfilId: '',
        professionalId: 'ESVELL',
        role: {
          id: RolesUserIds.Tecnico,
          label: RolesUser.Tecnico,
        },
        email: 'esvenllo@bcn.cat',
      },
      service: { label: 'Habitatges amb serveis', value: ServiciosIMI.VIVIENDAS}
      // service: { label: 'Sauv', value: ServiciosIMI.SAUV }
      // service: { label: 'Respir', value: ServiciosIMI.RESPIR }
      // service: { label: 'Respir+', value: ServiciosIMI.RESPIRPLUS }
      // service: { label: 'Guardamobles', value: ServiciosIMI.GUARDAMUEBLES },
    });
  }

  getUser(id: string): any {
    return {
      authUser: MOCK_AUTH_USERS[id]
    }
  }

  getUsers() {
    return MOCK_AUTH_USERS;
  }
}
