import { Injectable } from '@angular/core';
import { ParametreResultsRDTO } from '@app/core/model/parametres-globals/parametres-globals';
import { ServiciosIMI } from '@app/core/model/servicio';
import { ID, Store, StoreConfig } from '@datorama/akita';
import { SelectItem } from 'primeng/api';
import { AuthUser, ImiSpsInfo } from '../model';

export enum RolesUser {
  Admin = 'Administrador',
  Tecnico = 'Tècnic'
}

export enum RolesUserIds {
  Admin = 1,
  Tecnico = 2
}

export interface RoleUser {
  id: ID;
  label: string;
}

export enum IncidenciaType {
  USUARIO = 'usuario',
  EQUIPAMENT = 'equipament'
}

export enum UbicacionUI {
  CONTRACTES = 'contractes',
  EQUIPAMENTS = 'equipaments',
  INCIDENCIA_USUARI = 'incidencia_usuari',
  INCIDENCIA_EQUIPAMENTS = 'incidencia_equipaments',
  FITXA_USUARI = 'fitxa_usuari',
  SOLICITUD = 'solicitud'
}

export interface SessionState {
  authUser: AuthUser | null;
  service: number;
  language: string | null; // ca, es
  updated?: Date;
  ui: {
    fichaUsuarioTab: number;
    fichaUsuarioDatosComp: string;
    fichaUsuarioBloqSeg: string;
    fichaUsuarioRecursos: string;
  };
  placesSauv?: SelectItem[];
  placesViviendas?: SelectItem[];
  parametresGlobals: {
    serveisPrestats: ParametreResultsRDTO[];
    respirPlusParams: ParametreResultsRDTO[];
  };
  incidenciaType?: IncidenciaType;
  ubicacionUI?: UbicacionUI;
  filtroEstadoSolicitud: number;
}

export function createInitialSessionState(): SessionState {
  return {
    authUser: null,
    service: null,
    language: null,
    ui: {
      fichaUsuarioTab: 0,
      fichaUsuarioDatosComp: 'situacion',
      fichaUsuarioBloqSeg: 'observaciones',
      fichaUsuarioRecursos: 'gestionRecurso'
    },
    placesSauv: null,
    placesViviendas: null,
    parametresGlobals: {
      respirPlusParams: [],
      serveisPrestats: []
    },
    incidenciaType: null,
    filtroEstadoSolicitud: null
  };
}

@Injectable({
  providedIn: 'root'
})
@StoreConfig({ name: 'session' })
export class SessionStore extends Store<SessionState> {
  constructor() {
    super(createInitialSessionState());
  }

  setLanguage(language: string) {
    this.update(session => {
      return {
        ...session,
        language: language
      };
    });
  }

  setService(service: number) {
    this.update(session => {
      return {
        ...session,
        service: service
      };
    });
    this._fixDatosCompl();
  }

  setPlacesSauv(places: SelectItem[]) {
    this.update(state => {
      return {
        ...state,
        placesSauv: places
      };
    });
  }

  setPlacesViviendas(places: SelectItem[]) {
    this.update(state => {
      return {
        ...state,
        placesViviendas: places
      };
    });
  }

  setIncidenciaType(type: IncidenciaType) {
    this.update(state => {
      return {
        ...state,
        incidenciaType: type
      }
    })
  }

  updatePGlobalServeisPrestats(pGlobalServeisPrestats: ParametreResultsRDTO[]) {
    this.update(session => {
      return {
        ...session,
        parametresGlobals: {
          ...session.parametresGlobals,
          serveisPrestats: [
            ...session.parametresGlobals.serveisPrestats, 
            ...pGlobalServeisPrestats
          ]
        }
      }
    })
  }

  updateParametreGlobalRespirPlus(respirPlusParam: ParametreResultsRDTO[]) {
    this.update (session => {
      return {
        ...session,
        parametresGlobals: {
          ...session.parametresGlobals,
          respirPlusParams: [
            ...session.parametresGlobals.respirPlusParams,
            ...respirPlusParam
          ]
        }
      }
    })
  }


  resetParametresGlobalsRespirPlus() {
    this.update (session => {
      return {
        ...session,
        parametresGlobals: {
          ...session.parametresGlobals,
          respirPlusParams: []
        }
      }
    })
  }
  

  updateFichaUsuarioTab(tab: number) {
    this.update(session => {
      return {
        ...session,
        ui: {
          ...session.ui,
          fichaUsuarioTab: tab
        }
      };
    });
  }

  updateFichaUsuarioDatosComp(menu: string) {
    this.update(session => {
      return {
        ...session,
        ui: {
          ...session.ui,
          fichaUsuarioDatosComp: menu
        }
      };
    });
  }

  updateFichaUsuarioBloqSeg(menu: string) {
    this.update(session => {
      return {
        ...session,
        ui: {
          ...session.ui,
          fichaUsuarioBloqSeg: menu
        }
      };
    });
  }

  updateFichaUsuarioRecursos(menu: string) {
    this.update(session => {
      return {
        ...session,
        ui: {
          ...session.ui,
          fichaUsuarioRecursos: menu
        }
      };
    });
  }

  private _fixDatosCompl() {
    this.update(session => {
      return {
        ...session,
      updated: new Date(),
      ui: {
        ...session.ui,
        fichaUsuarioDatosComp:
        session.service !== ServiciosIMI.SAUV &&
        session.service !== ServiciosIMI.RESPIRPLUS &&
        session.service !== ServiciosIMI.VIVIENDAS
          ? 'situacion'
          : session.ui.fichaUsuarioDatosComp
      }
      }
    })
  }

  login(session: SessionState) {
    this.update(session);
  }

  logout() {
    this.update(createInitialSessionState());
  }

  setAuthUser(authUser: AuthUser) {
    this.update(state => {
      return {
        ...state,
        authUser: authUser
      };
    });
  }

  updateImiSpsInfo(imiSpsInfo: ImiSpsInfo) {
    this.update(state => {
      return {
        ...state,
        authUser: {
          ...state.authUser,
          imiSpsInfo: {
            ...state.authUser.imiSpsInfo,
            ...imiSpsInfo
          }
        }
      };
    });
  }

  setUbicacionUI(ubicacionUI: UbicacionUI) {
    this.update(state => {  
      return {
        ...state,
        ubicacionUI: ubicacionUI
      }
    })
  }

  resetUbicacionUI() {
    this.update(state => {  
      return {
        ...state,
        ubicacionUI: null
      }
    })
  }

  setFiltroEstadoSolicitud(filtroEstadoSolicitud: number) {
    this.update(state => {
      return {
        ...state,
        filtroEstadoSolicitud: filtroEstadoSolicitud
      }
    })
  }

  resetFiltroEstadoSolicitud() {
    this.update(state => {
      return {
        ...state,
        filtroEstadoSolicitud: null
      }
    })
  }
}
