import { ViewportScroller } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, NavigationStart, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { SessionService } from './core/auth';
import { DictionaryService } from './core/dictionary/state';
import { HttpStatusService } from './core/interceptors';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnDestroy, OnInit {
  title = 'Equipaments';
  subs: Subscription;
  subs2: Subscription;
  constructor(
    readonly dictionaryService: DictionaryService,
    readonly router: Router,
    readonly viewportScroller: ViewportScroller,
    readonly httpStatusService: HttpStatusService,
    readonly sessionService: SessionService
  ) {
    this.subs2 = router.events
      //.pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(event => {
        if (event instanceof NavigationEnd) {
          // Angular v7+
          this.viewportScroller.scrollToPosition([0, 0]);
          httpStatusService.loading = false;
        } else if (event instanceof NavigationStart) {
          httpStatusService.loading = true;
        }
      });
    // this.sessionService.login({}).subscribe();
    this.subs = this.dictionaryService.getDictionaries().subscribe();
  }

  ngOnInit() {
    this.router.navigate([''])
    this.sessionService.resetUbicacionUI();
  }

  ngOnDestroy() {
    if (this.subs) {
      this.subs.unsubscribe();
    }
    if (this.subs2) {
      this.subs2.unsubscribe();
    }
  }
}
