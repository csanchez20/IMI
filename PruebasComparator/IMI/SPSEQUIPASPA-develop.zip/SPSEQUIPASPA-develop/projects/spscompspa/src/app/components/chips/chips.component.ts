import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { text } from '@angular/core/src/render3';
import { DictionaryQuery } from '@app/core/dictionary/state';
import { FormatterService } from '@app/core/services/formatter.service';

interface Item {
  key: string;
  value: string;
}

@Component({
  selector: 'sps-chips',
  templateUrl: './chips.component.html',
  styleUrls: ['./chips.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChipsComponent implements OnInit {
  @Input() labels: any[];
  @Input() controls: any[];

  @Output() closeChip: EventEmitter<Item> = new EventEmitter<Item>();

  labelsMapped = [];

  constructor(
    public dictionaryQuery: DictionaryQuery,
    private formatterService: FormatterService
  ) { }

  ngOnInit() {
    this.labelsMapped = this.labels;
    // if (this.labels) {
    //   this.labels.map(label => {
    //     this.labelsMapped = [
    //       ...this.labelsMapped,
    //       label['dictionaryKey']
    //         ? label['label']
    //         : label
    //     ];
    //   });
    // }
  }

  isDate(value) {
    return Object.prototype.toString.call(value) === "[object Date]";
  }

  isBoolean(value) {
    return (value === true || value === false);
  }

  isDictionaryValue(value) {
    return this.labels[value]['dictionaryKey']
      ? true
      : false;
  }

  textBoolean(value){
    return FormatterService.textBoolean(value);
  }
}
