import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { DiccionarioKey, DictionaryQuery } from '@app/core/dictionary/state';
import { ConsultaAdrecaRDTO } from '@app/core/model';

export class DireccionLabels {
  adrTipusVia?: string;
  adrNomCarrer?: string;
  adrNum1?: string;
  adrLletra1?: string;
  adrNum2?: string;
  adrLletra2?: string;
  adrPortal?: string;
  adrEscala?: string;
  adrAP: string;
  adrPPis: string;
  adrDistricte: string;
  adrPPorta: string;
  adrBarri: string;
  adrCP: string;
  adrMunicipi: string;
}

@Component({
  selector: 'app-direccion-consulta',
  templateUrl: './direccion-consulta.component.html',
  styleUrls: ['./direccion-consulta.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DireccionConsultaComponent implements OnInit {
  @Input() direccion: ConsultaAdrecaRDTO;
  @Input() direccionLabels: DireccionLabels = {
    adrTipusVia: 'Tipus via',
    adrNomCarrer: 'Carrer',
    adrNum1: 'N.1',
    adrLletra1: 'L1',
    adrNum2: 'N.2',
    adrLletra2: 'L2',
    adrPortal: 'Portal',
    adrEscala: 'Esc',
    adrAP: 'A/P',
    adrPPis: 'Pis',
    adrPPorta: 'Porta',
    adrDistricte: 'Districte',
    adrBarri: 'Barri',
    adrCP: 'Codi Postal',
    adrMunicipi: 'Municipi'
  };

  diccionarioKey = DiccionarioKey;

  constructor(public dictionaryQuery: DictionaryQuery) {}

  ngOnInit() {}
}
