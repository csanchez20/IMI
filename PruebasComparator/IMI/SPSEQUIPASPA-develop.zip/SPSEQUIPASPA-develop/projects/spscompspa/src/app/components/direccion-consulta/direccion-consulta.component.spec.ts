// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { ButtonModule } from 'primeng/button';
// import { SplitButtonModule } from 'primeng/splitbutton';
// import { CardModule } from 'primeng/card';
// import { MenuModule } from 'primeng/menu';
// import { GrowlModule } from 'primeng/growl';
// import { DireccionConsultaComponent } from './direccion-consulta.component';

// describe('DireccionConsultaComponent', () => {
//   let component: DireccionConsultaComponent;  
//   let fixture: ComponentFixture<DireccionConsultaComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       imports: [
//         ButtonModule,
//         SplitButtonModule,
//         CardModule,
//         MenuModule,
//         GrowlModule,
//       ],      
//       declarations: [ DireccionConsultaComponent ]
//     })
//     .compileComponents();
//     // router = TestBed.get(Router);
//     fixture = TestBed.createComponent(DireccionConsultaComponent);
//     component = fixture.componentInstance;
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DireccionConsultaComponent);
//     component = fixture.componentInstance;
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
  
// });
