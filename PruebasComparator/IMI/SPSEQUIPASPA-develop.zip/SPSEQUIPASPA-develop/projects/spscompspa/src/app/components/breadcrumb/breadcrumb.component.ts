import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { ActivatedRoute, NavigationEnd, Params, Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { I18n } from '@ngx-translate/i18n-polyfill';

export interface IBreadcrumb {
  label: string;
  params?: Params;
  routerLink: string;
}
/**
 * Componente Breadcrumb. Se basa en la ruta actual para localizar los tags 'breadcrumb' ingluídos en los archivos de
 * routing y generar los niveles del hilo, según este árbol de rutas.
 */
@Component({
  selector: 'sps-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss'],
})
export class BreadcrumbComponent implements OnInit {

  /** Punto inicial del breadcrumb -> HOME */
  home: MenuItem = { icon: 'pi pi-home', routerLink: '/' };
  /** Lista con los valores a mostrar en el breadcrumb por cada nivel según ruta */
  breadcrumbs;

  /**
   * Constructor
   */
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private i18n: I18n
  ) { }

  /**
   * Análisis de la ruta actual al iniciar el componente.
   */
  ngOnInit(): void {
    // Subscribe routing events breadcumb
    this.breadcrumbs = [];
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd))
      .subscribe(_ => {
        // set breadcrumbs
        this.breadcrumbs = this.getBreadcrumbs(this.activatedRoute.root);
      });

    // Caso recarga pagina
    if (this.breadcrumbs) {
      this.breadcrumbs = this.getBreadcrumbs(this.activatedRoute.root);
    }
  }

  /**
   * @param ActivatedRoute route Ruta actual
   * @returns Conjunto de valores de cada nivel de la ruta.
   * Obtención de los valores a indicar en el breadcrumb tras analizar los niveles
   * de la ruta actual. .
   */
  getBreadcrumbs(route: ActivatedRoute, url = '', breadcrumbs: Array<IBreadcrumb> = []): Array<IBreadcrumb> {
    const ROUTE_DATA_BREADCRUMB = 'breadcrumb';

    // Obtenemos la rutas child
    const children: Array<ActivatedRoute> = route.children;
    // Si no hay mas rutas -> caso limite
    if (children.length === 0) {
      return breadcrumbs;
    }

    for (const child of children) {
      // Obtener URL segment
      const routeURL: string = child.snapshot.url.map(segment => segment.path).join('/');

      // Añadir route URL to URL
      if (routeURL !== '') {
        url += `/${routeURL}`;
      }

      // Verificamos si el parametro breadcrum está en cada ruta
      if (child.snapshot.data.hasOwnProperty(ROUTE_DATA_BREADCRUMB) && routeURL !== '') {
        const id = child.snapshot.params['id'];
        const bread = child.snapshot.data['breadcrumb'];
        const translateBread = this.i18n({ id: bread, value: '???' + bread });

        const breadcrumb: IBreadcrumb = {
          // label: routeURL,
          label: translateBread,
          params: child.snapshot.params,
          routerLink: url
        };
        breadcrumbs.push(breadcrumb);
      }
      // recursive
      const bc = this.getBreadcrumbs(child, url, breadcrumbs);
      return bc;
    }

    // we should never get here, but just in case
    return breadcrumbs;
  }

}
