import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { RangeDatePickerComponent } from './range-date-picker.component';
import { CalendarModule } from 'primeng/calendar';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

describe('RangeDatePickerComponent', () => {
  const labelInicio = "Data d'inici";
  const labelFin = 'Data fi';
  function setup() {
    const fixture: ComponentFixture<RangeDatePickerComponent> = TestBed.createComponent(
      RangeDatePickerComponent
    );
    const component: RangeDatePickerComponent = fixture.debugElement.componentInstance;
    // const userService = fixture.debugElement.injector.get(UserService);
    return { fixture, component };
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RangeDatePickerComponent],
      imports: [CalendarModule, ReactiveFormsModule]
    }).compileComponents();
  }));

  it('should create', () => {
    const { component } = setup();
    expect(component).toBeTruthy();
  });

  it('should check changes', () => {
    const { component, fixture } = setup();
    component.labelInicio = labelInicio;
    component.labelFin = labelFin;
    fixture.detectChanges();
    const calendars = fixture.debugElement.queryAll(By.css('p-calendar'));
    expect(calendars.length).toBe(2);
    const labels = fixture.debugElement.queryAll(By.css('.labels'));
    expect(labels[0].nativeElement.textContent).toContain(labelInicio);
    expect(labels[1].nativeElement.textContent).toContain(labelFin);

    /*expect(component.labelInicio).toBe(labelInicio);
    expect(component.labelFin).toBe(labelFin);
      expect(component.startDate).toBeNull();
     expect(component.startDateMax).toBeNull();
     expect(component.endDate).toBeNull();
     expect(component.endDateMin).toBeNull(); */
  });

  it('should set greater StartDateMax and lower EndDateMin', () => {
    const { component, fixture } = setup();
    component.startDate = new Date();
    component.onStartSelected(component.startDate);
    fixture.detectChanges();

    component.endDate = new Date();
    component.onEndSelected(component.endDate);
    expect(component.startDateMax.getTime()).toBeGreaterThan(component.startDate.getTime());
    expect(component.endDateMin.getTime()).toBeLessThan(component.endDate.getTime());
  });

  it('should set Dates to Null when on close Date Picker', () => {
    const { component, fixture } = setup();
    component.startDate = null;
    component.endDate = null;
    component.onCloseStartDate(component.startDate);
    component.onCloseEndDate(component.endDate);
    fixture.detectChanges();
    expect(component.startDateMax).toBeNull();
    expect(component.endDateMin).toBeNull();
  });
});
