import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CardModule } from 'primeng/card';
import { BreadcrumbComponent } from './breadcrumb.component';
import { BreadcrumbModule as BreadcrumbPrime } from 'primeng/breadcrumb';

@NgModule({
  declarations: [BreadcrumbComponent],
  imports: [CommonModule, CardModule, BreadcrumbPrime],
  exports: [BreadcrumbComponent]
})
export class BreadcrumbModule {}
