# Desarrollo en Entorno Local

Tabla de contenidos
- [Desarrollo en Entorno Local](#desarrollo-en-entorno-local)
    - [Software necesario](#software-necesario)
    - [Instalación](#instalacion)
        - [Instalar NodeJs 10.x](#instalar-nodejs-10x)
        - [Instalar Angular CLI](#instalar-angular-cli)
    - [Usar Angular CLI](#usar-angular-cli)
        - [Proyecto en marcha](#proyecto-en-marcha)
        - [Servidor de desarrollo](#servidor-de-desarrollo)
        - [Generación del código de los elementos](#generacion-del-codigo-de-los-elementos)
        - [Build](#build)
        - [Test unitarios](#test-unitarios)
        - [Pruebas de integración](#pruebas-de-integracion)
    - [Librerias](#librerias)
        - [Configurar conexion con nexus](#configurar-conexion-con-nexus)    
        - [Crear librerias](#crear-librerias)
        - [Build de librería](#build-de-libreria)
        - [Publicación de librerías](#publicacion-de-librerias)
        - [Instalación de librerías](#instalacion-de-librerias)
    - [Trabajar con git ](#trabajar-con-git)
        - [Descargar el proyecto](#descargar-el-proyecto)
        - [Hacer merge](#hacer-merge)


## Software necesario

 Software necesario para trabajar en local

- NodeJS 8.x
- Angular CLI
- Editor de Codigo fuente (Visual Studio Code, Atom, ...)

## Instalación

### Instalar NodeJs 10.x

https://nodejs.org/es/download/package-manager/#distribuciones-de-linux-basadas-en-debian-y-ubuntu

```sh
curl -sL https://deb.nodesource.com/setup_10.x | sudo -E bash -
sudo apt-get install -y nodejs
```

Incluye "npm" para la gestión de la instalación de los paquetes.

### Instalar Angular CLI

Usando npm:

```sh
npm install -g @angular/cli
```

En Ubuntu es necesario ejecutar la instalación con "sudo"

## Usar Angular CLI

### Proyecto en marcha

Descargar el proyecto en el git.

Para descargarte todas las dependencias se debe ejecutar:

```sh
npm install
```

### Servidor de desarrollo

Aunque el ejecutable final de la aplicación serán binarios estáticos que se publicarán eun servidor web (html, js, img, etc), para facilitar el desarrollo, Angular CLI proporciona un servidor basado en Nodejs.

Una de las propiedades más interesantes de este servidor es el modo escucha (watch) el cual produce la recarga de la página en el navegador cuando se detectan cambios en el código fuente.

Para arrancar el servidor de desarrollo ejecutar:

```sh
npm run start
```

La aplicación estará disponible para probarla con el navegador (se aconseja usar Chrome) en la url `http://localhost:4200/`

### Generación del código de los elementos

Angular CLI proporciona una serie de comandos para ir generando la estructura de la aplicación.

Se pueden crear los siguientes tipos de elementos:
- component
- directive
- pipe
- service
- class
- guard
- interface
- enum
- module
- library
- serviceWorker
- application

Para generarlos ejecutar:

```sh
ng generate component [component-name]`
```

El component-name puede incluir el path donde queramos que se cree el elemento.

### Build

Para crear los binarios de la aplicación se dbe ejecutar:

```sh
ng build [librería] [--prod]
```

Los ficheros se generarán en el directorio /dist del espacio de trabajo.

### Test unitarios

Angular CLI integra el stack de Jasmine/Karma para las pruebas unitarias de la aplicación.

Con la generación de cada elemento de la aplicación se crea automáticamente el test de cada uno.
Para ejecutar las pruebas:

```sh
ng test
```

Las pruebas se ejecutan de forma continuada, de manera que al ir modificando el código fuente, Angular CLI detecta los cambios y vuelve a pasar todas las pruebas.

También se genera información del code-coverage de las pruebas.

Para saber más: [Karma](https://karma-runner.github.io).

### Pruebas de integración

Par ahacer pruebas de integración (end-to-end), disponemos de Protractor.

Al crear el proyecto se crea un directorio con el esqueleto para empezar a desarrollar las pruebas:

\e2e

Para ejecutar las pruebas:

```sh
ng e2e
```

Este comando arranca un servidor similar al de **ng serve** que ejecuta las pruebas de integración a medida que se modifica el código de la aplicación.

Saber más: [Protractor](http://www.protractortest.org/)

## Librerias

### Configurar conexion con nexus
A partir de la versión 6.0.0 de @angular/cli es posible crear librerías y publicarlas en un servidor compatible con npm.

Disponemos de un servidor Nexus 3.0 que soporta npm. Para configurar el acceso al repositorio de npm añadir las siguientes líneas al ~/.npmrc


```sh
no-proxy=npmjs.org,npmjs.com,github.com
proxy=http://user:password@proxy:8080/
https-proxy=http://user:password@proxy:8080/
@cbk:registry=http://adress:8081/nexus/repository/npm-private/
strict-ssl=false
```

### Crear librerias

```sh
ng generate library @cbk/(nombre de la librería que desas crear)
```
Esto nos creara una nueva carpeta dentro de "/projects/cbk".


### Build de librería

Para poder visualizar los cambios realizados en una librería, es necesario hacer el build de dicha librería previamente. Para ello, basta con ejecutar el siguiente comando: "build:lib:name_app".

Ejemplo: Ejecutar "npm run build:lib:name_app".

"build:lib:name_app": "npm run build:prod @cbk/name_app && cd ./projects/cbk/name_app && npm version prerelease && cd ../../.. && cd dist/cbk/name_app && npm version prerelease && npm pack"

Esto genera un build en la libreria con formato x.y.z-k, cada vez que se hace un build, "k" aumenta en 1. Es decir, si estabamos en x.y.z-1 pasaremos a x.y.z-2, y así sucesivamente, hasta que deseemos consolidar la libreria (ver siguiente apartado).


### Publicación de librerías

Para 'consolidar' una librería, es decir, publicar una librería para que pueda ser accesible desde otros proyectos, es necesario:

a. Estar loggado con nexus. 

npm login --registry http://adress/nexus/repository/npm-private/ (adress = ubicacion del nexus)

** se necesitará de un usuario (user/password), así como permisos de escritura en nexus.

b. Ejecución de publish. Ejecutar comando "publish:lib:name_app".

Ejemplo: Ejecutar "npm run publish:lib:name_app".

"publish:lib:name_app": "npm run build:prod @cbk/name_app && cd ./projects/cbk/name_app && npm version patch && cd ../../.. && cd dist/cbk/name_app && npm version patch && npm pack && npm publish"  

Esto genera un build en la libreria con formato x.y.z, cada vez que se hace un publish, "z" aumenta en 1. Es decir, si estabamos en x.y.1-z pasaremos a x.y.2 después del publish, y quedará publicado en el respositorio Nexus, consolidando así la versión.


### Instalación de librerías

Para instalar una librería de nexus en un proyecto, es necesario:

a. Estar loggado con nexus. 

npm login --registry http://adress/nexus/repository/npm-private/ (adress = ubicacion del nexus)

** se necesitará de un usuario (user/password), así como permisos de escritura en nexus.

b. Referencia de la libreria en el archivo package.json.

"update:lib:name-app": "npm run update:lib @cbk/name-app",

c. Ejecutar "npm run update:lib:name-app"

También podemos descargar la libreria con un npm install.

** Es necesario no tener el directorio node_modules abierto.
** Validar que la versión instalada es la ultima publicada (tag:latest).
** La versión instalada estará en: node_modules/@cbk y "name-app"


## Trabajar con git 

### Descargar el proyecto

Para trabajar con el git se requiere:
https://git-scm.com/download/win
https://www.sourcetreeapp.com/

Ir a https://gitlab.com/drets-socials/spscompdemospa ir al proyecto que te desas descargar. Seleccionar SSH y copiar la url que aparce.

En la consola poner git clone y la url copiada anteriormente

Crear una rama desde la rama master 

"git checkout -b feature/myfeature master" (myfeature será el nombre de tu rama)

### Hacer merge

Los compandos para hacerlo son los siguientes:


---Ir a tu rama (myfeature)
Para ver el estado total de como esta el proyecto:
"git status"
Subir los cambios
"git add ."
Poner comentario:
"git commit -m "descripcion del commit"" (con comillas)

---Ir a la rama master (utilizar el sourcetree para los cambios de rama)
"git pull --rebase origin master" (esto nunca debería tener conflictos)

---Volver a tu rama (myfeature)
Ejecutar el rebase desde nuestra rama feature una vez todos los cambios bajo "comiteados":
"git rebase master"
Aquí verás los conflictos con tu proyecto, modifica los cambias necesarios!
git status para ver los archivos que has modificado y se deberían volver a subir.
"git add ."
"git rebase --continue"
Podrían continuar saliendo conflictos, irlos solventado y haciendo los ultimos 2 pasos, git add . cuando los hayas solventado y git "rebase --continue"

Una vez no te salgan más errores
"git push origin feature/myfeature" (myfeature es el nombre de tu rama)

-La propia ejecución del push de la rama feature a origin nos genera un shortcut para poder crear rápidamente un 
merge request:

Accedes al link y eliges a alguien para que lo valide.