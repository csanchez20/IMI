import { ValidatorFn, FormGroup, ValidationErrors } from '@angular/forms';

export const AltaUsuariValidator: ValidatorFn = (control: FormGroup): ValidationErrors | null => {
    Object.keys(control.value).forEach((key) => (control.value[key] === '') && control.get(key).setValue(null));
    const tipusDocumentDid = control.get('tipusDocumentDid').value;
    const document = control.get('document').value;
    const numTargetaSalut = control.get('numTargetaSalut').value;
    const dataNaixementNumber = control.get('dataNaixementNumber').value;
    const codiPrealta = control.get('codiPreAlta').value;
    const nom = control.get('nom').value;
    const cognom = control.get('cognom1').value;
    const realitzarAlta = control.get('realitzarAlta').value;
    const realitzarPrealta = control.get('realitzarPrealta').value;
    const expedientId = control.get('expedientId').value;
    const adreces = control.get('adreces').value as any[];

    let errors = {};

    if (dataNaixementNumber && dataNaixementNumber > new Date()) {
        errors = {
            ...errors,
            dataNaixementNumber: true 
        };
    }
    if (codiPrealta || expedientId) {
        if (!tipusDocumentDid) {
            errors = {
                ...errors,
                tipusDocumentDid: true
            };
        }
        if (!nom) {
            errors = {
                ...errors,
                nom: true
            };
        }
        if (!cognom) {
            errors = {
                ...errors,
                cognom1: true
            };
        }
        if (tipusDocumentDid === 100004 && !(cognom && nom && dataNaixementNumber)) {
            if (!nom) {
                errors = {
                    ...errors,
                    nom: true
                };
            }
            if (!cognom) {
                errors = {
                    ...errors,
                    cognom1: true
                };
            }
            if (!dataNaixementNumber) {
                errors = {
                    ...errors,
                    dataNaixementNumber: true
                };
            }
        }
        if (tipusDocumentDid === 101705) {
            if (!nom) {
                errors = {
                    ...errors,
                    nom: true
                };
            }
            if (!cognom) {
                errors = {
                    ...errors,
                    cognom1: true
                };
            }
            if (!dataNaixementNumber || (new Date().getTime() - dataNaixementNumber.getTime()) > (3600000 * 24 * 365 * 18)) {
                errors = {
                    ...errors,
                    dataNaixementNumber: true
                };
            }
            // TODO: fer no obligatori quan estiga el correctiu en cintraos
            if (!numTargetaSalut) {
                errors = {
                    ...errors,
                    numTargetaSalut: true
                };
            }
        }
        if (adreces && adreces.length > 0) {
            if (!adreces.some(adreca => adreca.tipusAdreca === 100061)) {
                errors = {
                    ...errors,
                    adrecaTipusHabitual: true
                };
            }
            const tipusAdreca = adreces.map(adreca => adreca.tipusAdreca);
            const tipusAdrecaUnics = new Set(tipusAdreca);
            if (tipusAdreca.length !== tipusAdrecaUnics.size) {
                errors = {
                    ...errors,
                    adrecaTipusRepetit: true
                };
            }
        }
    } else {
        if (tipusDocumentDid != null) {
            if ((tipusDocumentDid === 100001 || tipusDocumentDid === 100002 || tipusDocumentDid === 100003) && !document) {
                errors = {
                    ...errors,
                    document: true
                };
            }
            if (tipusDocumentDid === 101705) {
                if (!nom) {
                    errors = {
                        ...errors,
                        nom: true
                    };
                }
                if (!cognom) {
                    errors = {
                        ...errors,
                        cognom1: true
                    };
                }
                // if (!dataNaixementNumber || (new Date().getTime() - dataNaixementNumber.getTime()) > (3600000 * 24 * 365 * 18)) {
                //     errors = {
                //         ...errors,
                //         dataNaixementNumber: true
                //     };
                // }
                // if (!numTargetaSalut) {
                //     errors = {
                //         ...errors,
                //         numTargetaSalut: true
                //     };
                // }
            }
            if (tipusDocumentDid === 100004 && !(cognom && nom && dataNaixementNumber)) {
                if (!nom) {
                    errors = {
                        ...errors,
                        nom: true
                    };
                }
                if (!cognom) {
                    errors = {
                        ...errors,
                        cognom1: true
                    };
                }
                // if (!dataNaixementNumber) {
                //     errors = {
                //         ...errors,
                //         dataNaixementNumber: true
                //     };
                // }

            }
        } else {
            if (!nom) {
                errors = {
                    ...errors,
                    nom: true
                };
            }
            if (!cognom) {
                errors = {
                    ...errors,
                    cognom1: true
                };
            }
        }
    }

    if (realitzarAlta === true) {
        if (realitzarPrealta === false) {
            errors = {
                ...errors,
                realitzarPrealta: true
            };
        }
    }
    return errors ? errors : null;
};
