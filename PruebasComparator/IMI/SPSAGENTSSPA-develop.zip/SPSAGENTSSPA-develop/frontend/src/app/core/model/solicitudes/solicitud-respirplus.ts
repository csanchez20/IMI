export interface PaginacionCercaRESPIRPLUS {
  content?: ResultatCercaRespirPlusRDTO[];
  pageNumber?: number;
  pageSize?: number;
  total?: number;
  count?: number;
}

export interface ResultatCercaRespirPlusRDTO {
  centre?: string;
  cognom1?: string;
  cognom2?: string;
  nom?: string;
  dataCreacio?: Date;
  estatSollicitud?: number;
  expedientId?: string;
  numeroDocumentIdentitat?: string;
  periodeSollicitat?: string;
  sollicitudId?: string;
}

export interface ResultatSimulacioRespirPlusRDTO {
  dni?: string;
  idExpedient?: string;
  nomCognoms?: string;
  requisitEdat: boolean;
  requisitResideixBarcelona: boolean;
}

export class ModificaEstatRespirPlusRDTO {
  entitatExternaId: number;
  estatIdDesti: number;
  instanciaId: number;
  observacions?: string;
}

export interface ResultatConsultaRespirPlusRDTO {
  sollicitudId?: string;
  instanciaFluxId?: number;
  dadesSollicitudOriginal?: string;
  usuariCognom1?: string;
  usuariCognom2?: string;
  usuariNom?: string;
  usuariDataNaixement?: Date;
  usuariDocument?: string;
  usuariTipusDocument?: number;
  expedientId?: string;
  dataSollicitud?: Date;
  estatSollicitud?: number;
  motiuEstatSollicitudRespir?: string;
  dataActualitzacioEstat?: Date;
  centreCss?: string;
  periodeSollicitat?: number;
  periodeAtorgat?: number; //dies Atorgats
  preuPerDia?: number;
  importTotal?: number;
  estatSollicitudRespir?: string;
  dataSollicitudRespir?: Date;
  periodesSollicitatsRespir?: RespirPlusDadesPeriodesRDTO;
  cuidador?: RespirPlusDadesCuidadorRDTO;
}

export interface RespirPlusDadesCuidadorRDTO {
  expedient: string;
  nom: string;
  cognoms: string;
  tipusDocumentDid: number;
  document: string;
  parentiuDid?: number;
  edat?: number;
  genereDid?: number;
  telefon: string;
  adreca?: string;
  email: string;
  poblacioAdreca: string;
  convivencia: boolean;
  codiPostalAdreca?: string;
  comunicacionsCorreuPostal?: boolean;
}

export interface RespirPlusDadesEfectesComunicacioRDTO {
  nom: string;
  cognoms: string;
  parentiuDid?: number;
  sexe?: number;
  telefon: string;
  adreca?: string;
  poblacioAdreca: string;
  codiPostalAdreca?: string;
}

export interface RespirPlusDadesPeriodesRDTO {
  dataInici: Date;
  dataFi: Date;
}

export interface CalculRespirPlusRDTO {
  periodeAtorgat: number;
  preuPerDia: number;
  importTotal: number;
}

export interface ResultatAltaRespirPlusRDTO {
  sollicitudId: number;
}

export interface AltaRespirPlusRDTO {
  dadesCuidador: AltaRespirPlusDadesCuidadorRDTO;
  dadesDiscapacitat: AltaRespirPlusDadesDiscapacitatRDTO;
  dadesEfectesComunicacio: AltaRespirPlusDadesEfectesComunicacioRDTO;
  dadesIngressos: AltaRespirPlusDadesIngresosRDTO;
  dadesPersonaRespirPlus: AltaRespirPlusDadesPersonaRespirPlus; //
  dadesPersonesCarrec: AltaRespirPlusPersonaCarrecRDTO[];
  grauDid: number;
  periodeSollicitat: number;
}

export interface AltaRespirPlusDadesDiscapacitatRDTO {
  grauDid?: Array<number>;
  nucliConvivenciaDiscapacitat: boolean;
  quantsMembres?: number;
  quinMembre?: Array<number>;
}

export interface AltaRespirPlusDadesCuidadorRDTO {
  cognoms: string;
  grauDid: number;
  nom: string;
  adreca: string;
  codiPostalAdreca: string;
  comunicacionsCorreuPostal: boolean;
  convivencia: boolean;
  dataNaixement: string;
  document: string;
  edat: number;
  email: string;
  genereDid: number;
  numAdreca: string;
  parentiuDid: number;
  pisAdreca: string;
  poblacioAdreca: string;
  telefon: string;
  tipusDocumentDid: number;
}

export interface AltaRespirPlusDadesEfectesComunicacioRDTO {
  adreca: string;
  altresTelefons: string;
  codiPostalAdreca: string;
  cognoms: string;
  dataNaixement: string;
  genereDid: number;
  nom: string;
  numAdreca: string;
  parentiuDid: number;
  pisAdreca: string;
  poblacioAdreca: string;
  telefon: string;
}

export interface AltaRespirPlusDadesIngresosRDTO {
  altres: RespirPlusEstructuraIngressosRDTO;
  importTotal: number;
  pensioCompensatoria: boolean;
  pensioIcass: RespirPlusEstructuraIngressosRDTO;
  pensioInss: RespirPlusEstructuraIngressosRDTO;
  pensioLapad: RespirPlusEstructuraIngressosRDTO;
}

export interface RespirPlusEstructuraIngressosRDTO {
  importMensual: number;
  importTotalAnual: number;
  nombrePagues: number;
}

export interface AltaRespirPlusDadesPersonaRespirPlus {
  altresTelefons?: string;
  codiPostalDomicili: string;
  cognoms: string;
  dataNaixement: string;
  document: string;
  domiciliActual: string;
  edat: number;
  genereDid: number;
  nom: string;
  numDomicili: string;
  pisDomicili: string;
  poblacioDomicili: string;
  telefonDomicili: string;
  tipusDocumentDid: number;
}

export interface AltaRespirPlusPersonaCarrecRDTO {
  cognoms: string;
  dataNaixement: string;
  document: string;
  grauDid: number;
  nom: string;
  parentiuDid: number;
}

export interface ResultatAltaRespirPlusRDTO {
  sollicitudId: number;
}
