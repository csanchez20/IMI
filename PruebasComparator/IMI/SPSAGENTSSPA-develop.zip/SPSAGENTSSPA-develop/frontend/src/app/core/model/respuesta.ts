
export enum RespuestasEstados {
  APROBADO = 90004,
  CERRADO = 90006
}

export class Country {
  name: string;
  value: string;
}

export interface InstanciaRecurso {
  instanciaId: number;
  estatIdDesti: number,
  observacions: string,
  dataTransicio: number
}