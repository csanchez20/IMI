export interface CrearDocumentGDSERequestDTO {
    fileDocType: string;
	fileName: string;
}

export interface DocumentIdGDSEResponseRDTO {
    documentId: string;
}

export interface DocumentGDSEResponseRDTO {
    content: string;
    contentType: string;
    fileName: string;
}