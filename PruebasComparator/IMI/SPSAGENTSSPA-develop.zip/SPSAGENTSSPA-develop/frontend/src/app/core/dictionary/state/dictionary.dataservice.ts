import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ValorDiccionariResultsRDTO } from '@app/core/model/information';
import { SERVICIO_RESPIR, SERVICIO_SAUV } from '@app/core/model/servicio';
import { HttpRestClientCintraosService } from '@app/core/services/http-rest-client-cintraos.service';
import { environment } from '@env/environment';
import { Cacheable } from 'ngx-cacheable';
import { Observable, of } from 'rxjs';

import { DictionaryState } from './dictionary.store';

@Injectable({
  providedIn: 'root'
})
export class DictionaryDataService {

  constructor(public httpClient: HttpRestClientCintraosService) {}

  @Cacheable()
  getDiccionarioByParent(
    pareId: string
  ) {
    const url = `diccionari/consultagrup`;
    const params = new HttpParams().set('pareId', pareId);
    return this.httpClient.get<ValorDiccionariResultsRDTO[]>(url, {
      params: params
    });
  }

  getDiccionarioByMestreId(mestreId: number) {
    const url = `diccionari/${mestreId}`;
    return this.httpClient.get<ValorDiccionariResultsRDTO>(url);
  }

  getDictionaries(): Observable<DictionaryState> {
    return of({
      catalogo: [
        { id: 1, label: 'Llave 1' },
        { id: 2, label: 'Llave 2 del catalogo' }
      ],
      estados: [{ id: 1, label: 'Actiu' }, { id: 0, label: 'No actiu' }],
      centros: [
        { id: 1, label: 'Centro 1', otro: 'param' },
        { id: 2, label: 'Centro 2', otro: 'param 2' }
      ],
      municipios: [
        { value: 'Alella', label: 'Alella' },
        { value: 'Badalona', label: 'Badalona' },
        { value: 'Castellolí', label: 'Castellolí' },
        { value: 'Igualada', label: 'Igualada' },
        { value: 'Cerdanyola del Vallés', label: 'Cerdanyola del Vallés' }
      ],
      categoriasFAQ: [
        { value: 'Categoria 1', label: 'Categoria 1' },
        { value: 'Categoria 2', label: 'Categoria 2' },
        { value: 'Categoria 3', label: 'Categoria 3' },
        { value: 'Categoria 4', label: 'Categoria 4' },
        { value: 'Categoria 5', label: 'Categoria 5' }
      ],
      // estadosSolicitud: [
      //   { value: 1001, label: 'Pendent'},
      //   { value: 1002, label: 'Pendent de documentació'},
      //   { value: 1003, label: 'Cancel·lada'},
      //   { value: 1004, label: 'Denegada'},
      //   { value: 1005, label: 'Aprovada'}
      // ],
      ubicacionBcn: [
        { value: 1, label: 'Barcelona' },
        { value: 2, label: 'Fora de Barcelona' }
      ],
      conceptos: [
        { value: 1, label: 'concepto1' },
        { value: 2, label: 'concepto2' },
        { value: 3, label: 'concepto3' },
        { value: 4, label: 'concepto4' },
        { value: 5, label: 'concepto5' }
      ],
      unidades: [
        { value: 1, label: 'unidad1' },
        { value: 2, label: 'unidad2' },
        { value: 3, label: 'unidad3' },
        { value: 4, label: 'unidad4' },
        { value: 5, label: 'unidad5' }
      ],
      // tiposTraslado: [
      //   { label: 'Pendent autoritzar', value: 1 },
      //   { label: 'Pendent autoritzar', value: 2 }
      // ],
      tiposTrasladoGM: [
        { label: 'De domicili a domicili', value: 1 },
        { label: 'De domicili a guardamobles', value: 2 },
        { label: 'De guardamobles a domicili', value: 3 }
      ],
      estadosGuardamueblesGM: [
        { label: 'Planificat', value: 1 },
        { label: 'Actiu', value: 2 },
        { label: 'Finalitzat', value: 3 },
        { label: 'Cancel·lat', value: 4 }
      ],
      tiposSalida: [
        { label: 'a residus', value: 1 },
        { label: 'parcial', value: 2 }
      ],
      estadosSalidasGM: [
        { label: 'Pendent publicació', value: 1 },
        { label: 'Pendent autoritzar', value: 2 },
        { label: 'Planificat', value: 3 },
        { label: 'Realitzat', value: 4 },
        { label: 'Cancel·lat', value: 5 }
      ],
      estadosTrasladoGM: [
        { label: 'Pendent autoritzar', value: 1 },
        { label: 'Planificat', value: 2 },
        { label: 'Realitzat', value: 3 },
        { label: 'Cancel·lat', value: 4 }
      ],
      /* NO BORRAR A PARTIR DE AQUI ABAJO */
      servicios: [
        { value: SERVICIO_RESPIR, label: 'Respir' },
        { value: SERVICIO_SAUV, label: 'Sauv' }
      ]
    });
  }
}
