export const SERVICIO_SAUV = 68041;
export const SERVICIO_RESPIR = 69106;
export const SERVICIO_RESPIRPLUS = 61100;
export const SERVICIO_GUARDAMUEBLES = 61121;
export const SERVICIO_VIVIENDAS = 63600; // 63600; // Habitatges amb serveis

export const SERVICIO_KEY_HAB = 'SRV_HAB';
export const SERVICIO_KEY_SAUV = 'SRV_SAUV';
export const SERVICIO_KEY_RES = 'SRV_RES';
export const SERVICIO_KEY_RESPLUS = 'SRV_RES+';
export const SERVICIO_KEY_GM = 'SRV_GM';

export enum ServiciosIMI {
  SAUV = SERVICIO_SAUV,
  RESPIR = SERVICIO_RESPIR,
  RESPIRPLUS = SERVICIO_RESPIRPLUS,
  GUARDAMUEBLES = SERVICIO_GUARDAMUEBLES,
  VIVIENDAS = SERVICIO_VIVIENDAS
}

export enum Servicios {
  Guardamuebles = 'Guardamobles',
  SAUV = 'Sauv',
  Respir = 'Respir',
  RespirPlus = 'Respir +',
  Viviendas = 'Habitatges amb serveis'
  /*   Apartamentos = 'Apartaments tutelats',
  Recidencias = 'Residencies',
  Centros = 'Centres de dia' */
}

// export interface Servicio {
//   label:
//     | Servicios.Guardamuebles
//     | Servicios.SAUV
//     | Servicios.Respir
//     | Servicios.RespirPlus;
//   value: number;
// }

export class PersonaServicio {
  nombre: string;
  departamento: string;
  email: string;
}

export class Mes {
  periodo: string;
  presupuesto: number;
  comprometido: number;
  facturado: number;
  acumulado: number;
}

export class Ano {
  id: number;
  meses: Mes[];
}
