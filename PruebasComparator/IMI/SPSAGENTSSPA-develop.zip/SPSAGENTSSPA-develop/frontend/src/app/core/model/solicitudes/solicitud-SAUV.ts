import { FormatterService } from '@app/core/services/formatter.service';
import { Direccion, EdicionAdrecaRDTO } from '..';
import { ResultatCercaDocumentRDTO } from '../equipaments';
import { PersonaConsultadesRDTO } from '../persona';

/*********************  CERCA SOLICITUD  *************************/
export class CercaSauvRDTO {
  campGoogle?: string;
  cognom1Usuari?: string;
  cognom2Usuari?: string;
  dataFiSollicitud?: Date;
  dataIniciSollicitud?: Date;
  estatSollicitud?: number;
  nomUsuari?: string;
  numeroPagina?: number;
  tamanyPagina?: number;

  constructor() {
    if (!this.numeroPagina) {
      this.numeroPagina = 1;
    }

    if (!this.tamanyPagina) {
      this.tamanyPagina = 5;
    }
  }
}

export class ResultatCercaSauvRDTO {
  centreRegistre: string;
  cognom1: string;
  cognom2: string;
  dataCreacio: Date;
  estatSollicitud: number;
  expedientId: string;
  nom: string;
  origen: string;
  sollicitudId: number;
}

export interface PaginacionCercaSAUV {
  content: ResultatCercaSauvRDTO[];
  pageNumber: number;
  pageSize: number;
  total: number;
  count: number;
}

/*****************************************************************/

export interface DatosUsuario {
  nombre: string;
  apellido1: string;
  apellido2: string;
  dni: string;
  tsanitaria: string;
  genero: string;
  nacimiento: string;
  edad: string;
  incapacidadLegal: string;
  direccion: Direccion;
  telefono1: string;
  telefono2: string;
}

export interface Reclamacion {
  estado: boolean;
  motivo: string;
}

export interface RequisitosSimuladorSAUV {
  nomCognoms: string;
  dni: string;
  requisitEdat: boolean;
  requisitResideixBarcelona: boolean;
  requisitsEconomics: boolean;
  importCopagamentMinim: number;
  importCopagamentMaxim: number;
}

export interface Plaza {
  nombreResidencia: string;
  libresHombre: number;
  libresMujer: number;
  libresInd: number;
  previsionHombres: number;
  previsionMujeres: number;
  previsionInd: number;
  prioridad: number;
  costeDia: number;
}

// SIMULACION SAUV
export interface SimulacioSauvRDTO {
  idExpedient: string;
}

export interface SimulacioRespirPlusRDTO {
  idExpedient: string;
}

export interface ResultatSimulacioSauvRDTO {
  dni?: string;
  idExpedient?: string;
  nomCognoms?: string;
  requisitEdat: boolean;
  requisitResideixBarcelona: boolean;
  requisitsEconomics: boolean;
}

export class CalculIngressosEstalvisRDTO {
  hipotecaAnual: number; // Negativo o 0
  interessosLlibreta1: number; // Positivo o 0
  interessosLlibreta2: number; // Positivo o 0
  lloguerAnual: number; // Negativo o 0
  numPersonesUnitatFamiliar: number;
  pensioCompensatoria: number; // Negativo o 0

  constructor(ahorros: CalculIngressosEstalvisRDTO) {
    this.hipotecaAnual = FormatterService.toNegative(ahorros.hipotecaAnual);
    this.interessosLlibreta1 = ahorros.interessosLlibreta1;
    this.interessosLlibreta2 = ahorros.interessosLlibreta2;
    this.lloguerAnual = FormatterService.toNegative(ahorros.lloguerAnual);
    this.numPersonesUnitatFamiliar = ahorros.numPersonesUnitatFamiliar;
    this.pensioCompensatoria = FormatterService.toNegative(
      ahorros.pensioCompensatoria
    );
  }
}

export interface ResultatCalculIngressosEstalvisRDTO {
  discriminantEconomicEstalvis: boolean;
  totalReduccions: number;
  totalRendaNeta: number;
  totalRendesUFPerEstalvis: number;
}

export class CalculIngressosRendesRDTO {
  hipotecaAnual: number; // Negativo o 0
  lloguerAnual: number; // Negativo o 0
  numPersonesUnitatFamiliar: number;
  pensioAnualPrimeraPersonaACarrec: number; // Positivo o 0
  pensioAnualSegonaPersonaACarrecSeg: number; // Positivo o 0
  pensioAnualUsuari: number; // Positivo o 0
  pensioCompensatoria: number; // Negativo o 0

  constructor(ingresos: CalculIngressosRendesRDTO) {
    this.hipotecaAnual = FormatterService.toNegative(ingresos.hipotecaAnual);
    this.lloguerAnual = FormatterService.toNegative(ingresos.lloguerAnual);
    this.numPersonesUnitatFamiliar = ingresos.numPersonesUnitatFamiliar;
    this.pensioAnualPrimeraPersonaACarrec = ingresos.pensioAnualPrimeraPersonaACarrec
      ? ingresos.pensioAnualPrimeraPersonaACarrec
      : 0;
    this.pensioAnualSegonaPersonaACarrecSeg = ingresos.pensioAnualSegonaPersonaACarrecSeg
      ? ingresos.pensioAnualSegonaPersonaACarrecSeg
      : 0;
    this.pensioAnualUsuari = ingresos.pensioAnualUsuari;
    this.pensioCompensatoria = FormatterService.toNegative(
      ingresos.pensioCompensatoria
    );
  }
}

export interface ResultatCalculIngressosRendesRDTO {
  discriminantEconomicRendes: boolean;
  totalReduccions: number;
  totalRendaNeta: number;
  totalRendesUFPerRetribucio: number;
}

/**************************** SOLICITUD SAUV ****************************/

export interface SolicitudSauv {
  actualitzaPersonaCintraos: boolean;
  actualitzaAdrecaPersonaCintraos: boolean;
  dadesAdrecaPersona: EdicionAdrecaRDTO;
  dadesContext: DatosContextoSolicitudSauv;
  dadesDependencia: DatosDependenciaSauv;
  dadesPersona: PersonaConsultadesRDTO;
  dadesServei: DatosServicioSolicitudSauv;
  dadesUrgencia: DatosUrgenciaSolicitudSauv;
  importCopagament: number;
  requisitEdat: boolean;
  requisitEmpadronament: boolean;
  requisitsEconomics: boolean;
  tipusAlta: number;
  justificacioFile1: string;
  justificacioFile2: string;
  justificacioFile3: string;
}

export interface DatosContextoSolicitudSauv {
  acompanyamentEmocional: string;
  animalsCompanyia: string;
  dadesSocioFamiliars: string;
  deixaAnimalsCompanyia: boolean;
  indicisMaltractament: boolean;
  indicisMaltractamentObservacions: string;
  informacioRellevant: string;
}

export interface DatosDependenciaSauv {
  dataEfecte: Date;
  dataResolucio: Date;
  grauDid: number;
  numeroDependencia: string;
}

export interface DatosServicioSolicitudSauv {
  altresInterventors?: string;
  centre: string;
  centrePrescriptor: string;
  centreSalut?: number;
  director: string;
  emailDirector: string;
  emailReferent: string;
  professionalPrescriptor: string;
  referent: string;
  telefonReferent: string;
}

export interface DatosUrgenciaSolicitudSauv {
  fetPrecipitantDid: number;
  fetPrecipitantObservacions: string;
  ingresInvoluntari: boolean;
  motiuDemandaDid: number;
  onEsTrobaUsuariDid: number;
  perfilUsuariDid: number;
  perfilUsuariAltres: string;
  quiPlantejaDid: number;
  quinSociosanitariDid: number;
}

export interface SolicitudSauvRespuesta {
  sollicitudId: number;
}

export interface ResultatConsultaSauvRDTO {
  ctxAcompanyamentEmocional: string;
  ctxDadesSocioFamiliars: string;
  ctxDeixaAnimals: boolean;
  ctxDeixaAnimalsObs: string;
  ctxIndicisMaltractamentAbus: boolean;
  ctxIndicisMaltractamentObs: string;
  ctxInformacioRellevant: string;
  dadesSollicitudOriginal: string;
  dataActualitzacioEstat: Date;
  dataSollicitud: Date;
  documentCartaServeis: ResultatCercaDocumentRDTO;
  documentFullConsentimentIngres: ResultatCercaDocumentRDTO;
  documentInformeMedic: ResultatCercaDocumentRDTO;
  documentSentenciaJudicialAutoritzacio: ResultatCercaDocumentRDTO;
  documentSentenciaJudicialIncapacitacio: ResultatCercaDocumentRDTO;
  estatSollicitud: number;
  expedientId: string;
  ingresAcceptat: boolean;
  instanciaFluxId: number;
  motiuEstat: string;
  sollicitudId: number;
  urgFetPrecipitantDid: number;
  urgFetPrecipitantObs: string;
  urgIngresInvoluntari: boolean;
  urgMotiuDemanda: number;
  urgPerfilUsuariAltres: string;
  urgPerfilUsuariDid: number;
  urgQuiPlantejaDid: number;
  urgSociosanitariDid: number;
  urgUbicacioActualDid: number;
  usuariCognom1: string;
  usuariCognom2: string;
  usuariNom: string;
  usuariCreacio: string;
}

export class ModificaEstatSauvRDTO {
  entitatExternaId: number;
  estatIdDesti: number;
  instanciaId: number;
  observacions: string;
}

export interface ResultatModificaEstatSauvRDTO {
  instanciaId: number;
}

export interface SimulacioRespirPlusRDTO {
  idExpedient: string;
}
