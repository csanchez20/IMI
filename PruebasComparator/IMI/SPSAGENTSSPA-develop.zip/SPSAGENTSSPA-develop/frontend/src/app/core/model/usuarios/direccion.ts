export class Direccion {
  id: string;
  tipoVia: string;
  calle: string;
  n1: string;
  n1L: string;
  n2: string;
  n2L: string;
  portal: string;
  escalera: string;
  AP: string;
  APnum?: string;
  piso: string;
  puerta: string;
  distrito: string;
  barrio: string;
  municipio?: string;
  codigoPostal: string;
  ciudad: string;
}

export interface EdicionAdrecaRDTO {
  ubicacioId?: number;
  adrANumero?: string;
  adrAP?: string;
  adrCP?: string;
  adrCodiCarrer?: string;
  adrDistricte: string;
  adrBarri?: string;
  adrEscala?: string;
  adrLletra1?: string;
  adrLletra2?: string;
  adrMunicipi?: string;
  adrNomCarrer: string;
  adrNum1: string;
  adrNum2?: string;
  adrPPis?: string;
  adrPPorta?: string;
  adrPortal?: string;
  adrTipusVia: string;
  barriDesc?: string;
  esForaBarcelona?: boolean;
  tipusHabitatgeDid?: number; // Referencia a SIAS_DM_DICCIONARI → PARE_ID : 100053
}

export interface ResponseAdrecaRDTO {
  ubicacioId: number;
}

export interface ConsultaAdrecaRDTO {
  ubicacioId?: number;
  adrTipusVia: string;
  adrNomCarrer: string;
  adrCodiCarrer?: string;
  adrNum1: string;
  adrLletra1?: string;
  adrNum2?: string;
  adrLletra2?: string;
  adrPortal?: string;
  adrEscala?: string;
  adrAP?: string;
  adrPPis?: string;
  adrPPorta?: string;
  adrANumero?: string;
  adrDistricte?: string;
  adrBarri?: string;
  adrCP?: string;
  adrMunicipi?: string;
  tipusHabitatgeDid?: number;
  observacions?: string;
  validaGeocod?: boolean;
  dataCreacio?: string;
  dataModificacio?: string;
  usuariCreacio?: string;
  usuariModificacio?: string;
  habilitat?: boolean;
  esForaBarcelona: boolean;
  adrZonaPetita?: string;
  adrZonaGran?: string;
  adrXPost?: number;
  adrYPost?: number;
  adrAeb?: string;
  distrDesc?: string;
  barriDesc?: string;
  adrAPDescr?: string;
}
