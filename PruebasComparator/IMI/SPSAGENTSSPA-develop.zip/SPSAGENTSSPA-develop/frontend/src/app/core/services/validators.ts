import { AbstractControl, ValidatorFn, Validator, ValidationErrors } from '@angular/forms';

import { PreguntaDTO } from '../model';

export function dniValidator(
  control: AbstractControl
): { [key: string]: boolean } | null {
  const validChars = 'trwagmyfpdxbnjzsqvhlcket';
  const dniRexp = /^[0-9]{8}[trwagmyfpdxbnjzsqvhlcket]{1}$/i;
  const nieRexp = /^[XY]{1}[0-9]{7}[trwagmyfpdxbnjzsqvhlcket]{1}$/i;
  const string = (control.value == null ? '' : control.value)
    .toString()
    .toLowerCase();

  if (!dniRexp.test(string) && !nieRexp.test(string)) {
    return { dni: true };
  }

  const nie = string.replace(/^[x]/, '0').replace(/^[y]/, '1');

  const letter = string.substr(-1);
  const charIndex = parseInt(nie.slice(0, -1), 10) % 23;
  if (validChars.charAt(charIndex) === letter) {
    return null;
  }
  return { dni: true };
}

export function validateRange(controlNameFechaInicio: string, controlNameFechaFinal: string): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    const dataIniciVigencia = control.get(controlNameFechaInicio).value as Date;
    const dataFiVigencia = control.get(controlNameFechaFinal).value as Date;
    if (dataIniciVigencia && dataFiVigencia) {
      return (dataIniciVigencia <= dataFiVigencia) ? null : { ilegalRange: true }
    }
  }
}

export function validateAIfBEqualsValue(control:AbstractControl, controlNameA: string, controlNameB: string, value: any, validators: ValidatorFn[]): void {
  const a = control.get(controlNameA);
  const b = control.get(controlNameB).value;
  if (b === value) {
    a.setValidators(validators);
    a.updateValueAndValidity();
  } else {
    a.clearValidators();
    a.updateValueAndValidity();
  }
}

export function testDone(
  control: AbstractControl
): { [key: string]: boolean } | null {
  let valid = true;
  let done = false;
  let notDone = false;
  const preguntas = control.value as PreguntaDTO[];
  preguntas.map(pregunta => {
    if (!done && pregunta.respostaDid) {
      done = true;
    } else if (!notDone && !pregunta.respostaDid) {
      notDone = true;
    }
    if (done && notDone) {
      valid = false;
      return;
    }
  });
  return valid ? null : { wholeTestNotCompleted: true };
}

export function arrayEmpty(control: AbstractControl): { [key: string]: boolean } | null {
  return (control.value == null || control.value.length === 0)
    ? {'arrayEmpty': true}
    : null;
}

export const TelefonValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  if (control) {
      const telf = control.value;
      if (telf) {
          if (/^\d{9}$/.test(telf)) {
              return null;
          } else {
              return { invalid: true };
          }
      }

  }
}

export const DniValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const tipusDocumentDid = control.get('tipusDocumentDid').value;
  const dni = control.get('document').value;
  let errors = {};
  if (tipusDocumentDid === 100001) {
      const lletresDni = 'TRWAGMYFPDXBNJZSQVHLCKE';
      if (dni) {
          const lletra = lletresDni.charAt(parseInt(dni, 10) % 23);

          if (lletra !== dni.charAt(8)) {
              errors = {
                  ...errors,
                  document: true
              };
          }
          return errors ? errors : null;

      }
  }
}

export const EmailValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  if (control) {
      const mail = control.value;
      if (mail) {
          if (/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(mail)) {
              return null;
          } else {
              return { invalid: true };
          }
      }
  }
}
