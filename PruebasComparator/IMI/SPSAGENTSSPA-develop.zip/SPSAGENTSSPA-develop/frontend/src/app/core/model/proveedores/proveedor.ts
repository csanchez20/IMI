export class Proveedor {
    raoSocial: string;
	cif: string;
	numClient: string;
	AdreçaProv: string;
	dataInici: string;
	dataFi: string;
}

export interface ParamsCercaEmpresaGestora {
    contracteId?: number;
    empresaGestoraId?: number;
    nomComercial?: string;
}

export interface EmpresaGestoraCercadesRDTO {
    cif: string;
    empresaGestoraId: number;
    nomComercial: string;
}

export interface EmpresaGestoraRDTO extends EmpresaGestoraCercadesRDTO {
    raoSocial: string;
    adreca: string;
    telefon: string;
    fax: string;
    personaContacte: string;
    observacions: string;
}

export interface EmpresaGestoraIdRDTO {
    empresaGestoraId: number;
}

export interface EmpresaGestoraCentresCercadesRDTO {
    centreId: string;
    nom: string;
}

export interface EmpresaGestoraServeisCentresCercadesRDTO {
    centreId: string;
    contracteId: number;
    dataFiVigencia: string;
    dataIniciVigencia: string;
    iva: number;
    preuPublicUnitari: number;
    preuUnitari: number;
    serveiContrCentreId?: number;
    tipusPlanificacioDid: number;
    tipusRespostaDid: number;
    tipusServeiDid: number;
    unitatDid: number;
}

export interface ServeiCentreEmpresaGestoraIdRDTO {
    serveiContrCentreId: number;
}

