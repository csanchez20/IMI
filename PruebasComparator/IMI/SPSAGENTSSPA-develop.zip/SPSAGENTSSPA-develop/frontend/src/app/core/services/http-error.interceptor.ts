import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpResponse,
  HttpErrorResponse
} from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export class HttpErrorInterceptor implements HttpInterceptor {

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request)
      .pipe(
        // retry(1),
        catchError((error: HttpErrorResponse) => {
          console.log("TCL: HttpErrorInterceptor -> error", error)
          let errorMessage = '';
          if (error.error instanceof ErrorEvent) {
            // client-side error
            errorMessage = `Error: ${error.error.message}`;
          } else {
            // server-side error
            switch (error.status) {
              case 0: {
                errorMessage = `API connection unreachable`;
                break;
              }
              case 401: {
                errorMessage = `API connection unreachable`;
                break;
              }
              case 404: {
                errorMessage = `Epp 404: ${error.message}`;
                break;
              }
              default: {
                errorMessage = `Codi error: ${error.status}\nMissatge: ${error.message}`;
              }
            }
          }
          window.alert(errorMessage);
          return throwError(errorMessage);
        })
      );
  }
}
