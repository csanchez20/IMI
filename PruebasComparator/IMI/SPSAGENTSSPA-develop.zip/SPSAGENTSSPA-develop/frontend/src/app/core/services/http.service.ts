import { Injectable } from '@angular/core';

export const CODE_STATUS_ERROR_400 = 400;
export const CODE_STATUS_ERROR_404 = 404;

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor() { }

  /**
   * A partir de un objeto te lo devuelve en formato QueryParams
   * @param obj
   */
  public getQueryParamsByObject(obj: Object): {} {
    const queryParams = {};
    Object.keys(obj).map(key => {
      queryParams[key] = obj[key];
    });
    return queryParams;
  }

}
