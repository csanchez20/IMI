import { AuthUser } from "./auth-user";

export interface DiccionarioMockUsers {
    [id: string]: AuthUser;
}

export const MOCK_AUTH_USERS: DiccionarioMockUsers = {
    'ESVELL': {
        clientId: '',
        imiSpsInfo: null,
        imiAuthorization: {
            version: "1",
            user: "ESVELL",
            acces: [
                "EQUIPA#PAT",
                "PAT"
            ],
            fun: null,
            grp: [
                "SRV_SAUV",
                "SRV_RES",
                "SRV_RES+"
            ],
            sub: "Estel Ventura Llopart",
            dept: "A dep",
            distr: "A dist",
            div: "A div",
            optun: "A unit",
            cat: "A cat",
            dni: "30",
            email: "esvenllo@bcn.cat",
            tipusUsuari: null,
            dependencia: null,
            commandament: null,
            cooper: null,
            iss: "Institut Municipal Informatica",
            app: 'agentsexternsApp'
        }
    },
    'V649333': {
        clientId: '',
        imiSpsInfo: null,
        imiAuthorization: {
            version: "1",
            user: "V649333",
            acces: [
                "EQUIPA#ADS",
                "ADS"
            ],
            fun: null,
            grp: [
                "SRV_HAB",
                "SRV_SAUV",
                "SRV_RES",
                "SRV_RES+"
            ],
            sub: "Fernando",
            dept: "A dep",
            distr: "A dist",
            div: "A div",
            optun: "A unit",
            cat: "A cat",
            dni: "Y1649333V",
            email: "fernando@getronics.com",
            tipusUsuari: null,
            dependencia: null,
            commandament: null,
            cooper: null,
            iss: "Institut Municipal Informatica",
            app: 'agentsexternsApp'
        }
    },
    'DX9077': {
        clientId: '',
        imiSpsInfo: null,
        imiAuthorization: {
            version: "1",
            user: "DX9077",
            acces: [
                "EQUIPA#TP",
                "TP"
            ],
            fun: null,
            grp: [
                "HAB-CSS99ZA",
                "SAUV-CSS99XA",
                "RESP-CSS99YA",
            ],
            sub: "Marià Camuñez",
            dept: "A dep",
            distr: "A dist",
            div: "A div",
            optun: "A unit",
            cat: "A cat",
            dni: "DX9077",
            email: "maria.camunez@getronics.com",
            tipusUsuari: null,
            dependencia: null,
            commandament: null,
            cooper: null,
            iss: "Institut Municipal Informatica",
            app: 'agentsexternsApp'
        }
    },
    'GE02108': {
        clientId: '',
        imiSpsInfo: null,
        imiAuthorization: {
            version: "1",
            user: "GE02108",
            acces: [
                "EQUIPA#PAT",
                "PAT"
            ],
            fun: null,
            grp: [
                "SRV_HAB",
                "SRV_SAUV",
                "SRV_RES",
                "SRV_RES+"
            ],
            sub: "GE02108",
            dept: "A dep",
            distr: "A dist",
            div: "A div",
            optun: "A unit",
            cat: "A cat",
            dni: "GE02108",
            email: "GE02108@getronics.com",
            tipusUsuari: null,
            dependencia: null,
            commandament: null,
            cooper: null,
            iss: "Institut Municipal Informatica",
            app: 'agentsexternsApp'
        }
    }
}