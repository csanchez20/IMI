export interface AuthUser {
    imiSpsInfo: ImiSpsInfo;
    clientId: string;
    imiAuthorization: ImiAuthorization;
}

export interface ImiAuthorization {
    acces?: string[];        
    app?: string;        
    cat?: string;        
    commandament?: string;        
    cooper?: string;        
    dependencia?: string;        
    dept?: string;        
    distr?: string;        
    div?: string;        
    dni?: string;        
    email?: string;        
    fun?: string;        
    grp?: string[];     
    iss?: string;        
    optun?: string;        
    sub?: string;        
    tipusUsuari?: string;        
    user?: string;        
    version?: string;        
}

export interface ParamsImiSpsInfo {
    expedientId: string;
}
export interface ImiSpsInfo {
    centro?: string;
    servicio?: string;
    params?: ParamsImiSpsInfo;
}

export class DataRoutingGuard {
    serviceRequired: boolean;
    imiSpsInfoRequired: string[];
    urlToRedirect: string;
    inverse?: boolean;

    constructor(
        serviceRequired: boolean,
        imiSpsInfoRequired: string[],
        urlToRedirect: string,
        inverse?: boolean
    ) {
        this.serviceRequired = serviceRequired;
        this.imiSpsInfoRequired = imiSpsInfoRequired;
        this.urlToRedirect = urlToRedirect;
        this.inverse = inverse ? inverse : false;
    }
}

// Roles del Usuario
export interface RolesUser {
    [id: string]: string
}

export const ROLE_ADMIN_SISTEMA = 'ADS';
export const ROLE_DIR_ACC_SOC = 'DAS';
export const ROLE_DIR_SER = 'DS';
export const ROLE_RESP_DEP = 'RD';
export const ROLE_DIR_TERR_DISTR = 'DT';
export const ROLE_PROF_AT = 'PAT';
export const ROLE_PROF_ADMN = 'PA';
export const ROLE_SER_JURD = 'SJ';
export const ROLE_TECNIC = 'TA';
export const ROLE_AREA_ECON = 'AE';
export const ROLE_PROF_CUESB = 'PCUE';
export const ROLE_RESP_SERV = 'RS';
export const ROLE_CAP_TORN = 'CT';
export const ROLE_RESP_CONTR = 'RC';
export const ROLE_RESP_EQUIPA = 'RE';
export const ROLE_TREB_PROV = 'TP';

// Roles agentes: Proveidor(TP)(listado grupos carol (99__, ...)), prescriptor (PAT)(sauv, respir, respir+)(grupos carol)
export const ROLES_USER: RolesUser = {
    'ADS': 'Administrador del sistema',
    // 'DAS': 'Direcció d\'Acció Social',
    // 'DS': 'Director del servei',
    // 'RD': 'Responsable Departament',
    // 'DT': 'Director territorial del districte',
    'PAT': 'Professional d\'atenció',
    // 'PA': 'Professional administratiu',
    // 'SJ': 'Serveis jurídics',
    // 'AE': 'Àrea econòmica',
    // 'TA': 'Tècnic',
    // 'PCUE': 'Professional CUESB',
    // 'RS': 'Responsable del Servei',
    // 'CT': 'Cap de torn',
    // 'RC': 'Responsable contracte',
    // 'RE': 'Responsable equipament',
    'TP': 'Treballador proveïdor'
}

// Constantes de las cabeceras de seguridad
export const HEADER_INFO = 'x-imi-sps-info';
export const HEADER_CLIENT_ID = 'x-ibm-client-id';
export const HEADER_AUTHORIZATON = 'x-imi-authorization';



