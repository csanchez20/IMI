import { Direccion } from '../usuarios/direccion';

export class Accion {
  tipo: string;
  direccion: Direccion;
  fecha: string;
  hora: string;
}

export interface DatosBasicosSolicitud {
  // Datos de la solicitud
  apodo: string;
  nombre: string;
  apellido1: string;
  apellido2: string;
  identificacion: string;
  localizacion: string;
  fechaSolicitud: Date;
  prescriptor: string;
  enManosDe: string;

  // Resumen de documentación
  tipo: string;
  documentos: Documento[];

  // Estado de la solicitud
  estadoDocumentacion: string;
  motivo: string;
  fechaActualizacionEstado: Date;
}

export interface Documento {
  idFile?: number;
  nombreDocumento?: string;
  estadoDocumento?: string;
  nameFile?: string;
  obligatorio?: boolean;
  justificacion?: string;
  reclamacion?: string;
}

export interface PeriodoSolicitado {
  fechaInicio: string;
  fechaFin: string;
  numDias: number;
  dni: string;
  numTarjetaSanitaria: string;
}

export interface Derivacion {
  motivoDerivacion: string;
}

export interface CambioEstado {
  idEstado: number;
  motivo?: string;
}
