import { ResultatConsultaGuardamoblesRDTO } from '../solicitudes/solicitud-guardamobles';
import { ResultatConsultaRespirRDTO } from '../solicitudes';
import { ResultatConsultaRespirPlusRDTO } from '../solicitudes/solicitud-respirplus';
import { FormatterService } from '@app/core/services/formatter.service';

export interface RecursoTraslado {
  tipusTrasllatDid: number;
  dataSolicitut: number;
  estatDid: number;
  dataPlanificada: number;
  dataReal?: number;
  direccioOrigen?: string;
  direccioDesti?: string;
  direccioDesti2?: string;
  horesOperari?: number;
  horesCamio?: number;
}

export interface RecursoSalidaGM {
  idSolicitudSalidas: string;
  tipusSortidaDid: number;
  dataSortida: number;
  estat?: number;
  valorInicialBens?: number;
  volumOcupatDespres?: number;
}

export class GGRespuestaSauv {
  sollicitudId: number;
  recursId: number;
  estatSollicitud: number;
  dataSollicitud: number;
  estatRespostaDid: number;
  expedientId: string;
  respostaGG?: GGRespuestaGG;
  listInterrupcioServei?: GGInterrupcionServicio[];
  centre?: GGCentro;
  listDefinicioServei?: GGDefinicionServicio[];
}

export interface GGRespuestaRespir {
  sollicitudId: number;
  expedientId: string;
  recursId: number;
  dataSollicitud: number;
  estatSollicitud: number;
  estatRespostaDid: number;
  solicitudRespirDTO: number; // provisional
  solicitudRespirPlusDTO: SolicitudRespirPlusDTO;
  respostaGG?: GGRespuestaGG;
  listDefinicioServei?: GGDefinicionServicio[];
}

export interface GGRespuestaGuardamobles {
  sollicitudId: number;
  expedientId: string;
  recursId: number;
  dataSollicitud: number;
  estatSollicitud: number;
  estatRespostaDid: number;
  sollicitudGuardamoblesDTO: ResultatConsultaGuardamoblesRDTO;
}

export interface GGRespuestaRespirplus {
  sollicitudId: number;
  recursId: number;
  estatSollicitud: number;
  dataSollicitud: number;
  estatRespostaDid: number;
  estatRespostaRespirDid: number;
  estatRespostaRespirPlusDid: number;
  expedientId: string;
  listDefinicioServei?: GGDefinicionServicio[];
  listaFacturas?: FacturaRespirPlus[];
  ajut?: Ajut;
  dadesPagament?: DatosPago;
  listaPagamentsEmesos?: PagoEmitido[];
  // adaptation to back
  solicitudRespirDTO?: ResultatConsultaRespirRDTO
  solicitudRespirPlusDTO?: ResultatConsultaRespirPlusRDTO
  importRestant: number;
  calculRespirPlusDTO: CalculRespirPlusDTO;
}

export interface GGRespuestaViviendas {
  recursId: number;
  comentarisIngres?: string;
  centre?: GGCentro;
  expedientId: string;
  estatRespostaDid: number;
  respostaGG?: GGRespuestaGG;
  listDefinicioServei?: GGDefinicionServicio[];
}

export interface CalculRespirPlusDTO {
  importTotal: number;
  periodeAtorgat: number;
  preuPerDia: number;
}

export interface SolicitudRespirPlusDTO {
  dataActualitzacioEstat: number;
  estatSollicitud: number;
  instanciaFluxId: number;
  sollicitudId: number;
}

export interface DatosPago {
  bossa: string;
  formaPagamentDid: number;
  iban: string;
  concepteGeneralDid: number;
  concepteEspecificDid: number;
  tipusPagamentDid: number;
  receptorPagament: string;
}

export interface PostPagamentRespirplus extends DatosPago {
  sollicitudId: number;
  recursId: number;
  // Dades Pagament 
  dataPagament: number;
  importTotal: number;
  districteId: string;
  centreId: string;
}

export interface PagoEmitido {
  dataPagament: number;
  bossa: string;
  formaPagamentDid: number;
  iban: string;
  concepteGeneralDid: number;
  concepteEspecificDid: number;
  tipusPagmentDid: number;
  importTotal: number;
}

export interface FacturaGGSearchParams {
  recursId?: number;
  estatFacturaDid: number;
}

export interface FacturaGGCercadesRDTO {
  facturaId: number;
  recursId: number;
  estatFacturaDid: number;
  dataFactura: number;
  numRegResidencia: string;
}

export interface FacturaRespirPlus {
  facturaId: number,
  dataFactura: number;
  estatFacturaDid: number;
  dataInici: number;
  dataFi: number;
  dies: number;
  preuPerDia: number;
  importTotal: number;
  comentaris: string;
  // Mail info
  correuElectronicRebuig: string;
  motiuRebuigDid: number;
  motiuRebuig: string | number;
  expedientId: string;
  recursId: number;
  document: string;
  nomComplet: string;
  
  // Extra info
  nomResidencia: string;
  adrecaResidencia: string;
  numRegResidencia: string;
  comboNumRegDataFactura: string;
  // Document Info
  docFactOriginal: string; // base 64 file
  docFactOriginalId: string;
  docFullTransfer: string; // base 64 file
  docFullTransferId: string;
  docJustificacio: string; // base 64 file
  docJustificacioId: string;
}

export interface RecamarFactura {
  email: string;
  motiu: string;
}

export interface Ajut {
  dies?: number;
  preuDia?: number;
  import?: number;
  importRestant?: number;
}

export interface GGRespuestaGG {
  recursId: number;
  // ingreso
  comentarisIngres: string;
  dataIngres?: number;
  // baja
  comentarisSortida?: string
  dataSortida?: number;
  motiuSortidaDid?: number;
  nomRecursSortida?: string;
  tipusSortidaDid?: number;

  trasllats: GGTraslados[];
  plaSortida: GGPlanSalida;
  pacteEconomic: GGPactoEconomicoRDTO;
}

export interface GGTraslados {
  recursId: number;
  definicioServeiId: number;
  motiuTrasllatDid: number;
  comentarisTrasllat: string;
  autoritzacioServei: boolean;
}

export interface GGTrasladoFullInfo extends GGTraslados {
  centreId: string;
  centreNom?: string;
  dataFinal: number;
  dataInici: number;
}

export interface GGPlanTrabajo {
  aspectes: string;
  proposta: string;
}

export interface GGPlacaPublica {
  id?: number;
  recursId?: number;
  placaPublicaCentreDid?: number;
  placaPublicaPosicio?: number;
  placaPublicaDataAcces?: number | Date;
  dataModificacio?: number;
  placaPublicaPeticionariDid?: number;
  placaPublicaSeleccionada?: boolean;
  placaPublicaObservacions?: string;
  placaPublicaDesestimada?: boolean;
}

export interface GGPlanSalida {
  dataModificacio?: number;
  recursId?: number;
  tipusSortidaDid: number; //2030000
  tipusSortidaMunicipalDid?: number; // 2032101
  nomRecursSortida?: string;
  placesPubliques?: GGPlacaPublica[];
}

export interface GGPactoEconomicoRDTO {
  aportAjuntamentCostResiden: number;
  aportAjuntamentPreuPublic: number;
  recursId: number;
  numPersonasUnitatFamiliar: number;
  pensioAnualUsuari: number;
  pensioAnualPersona1Carrec: number;
  pensioAnualPersona2Carrec: number;
  interessosLlibreta1: number;
  interessosLlibreta2: number;
  capitalMobiliari: number;
  totalRendesUnitatFamiliar: number;
  despesesPersonals: number;
  carregaFamiliarPersona1: number;
  carregaFamiliarPersona2: number;
  lloguerAnual: number;
  hipotecaAnual: number;
  pensioCompensatoria: number;
  totalReduccDerivatsPensions: number;
  estalvisGaraRendesMobiliari: number;
  estalvisDispoAportacioRESID: number;
  numMesosAport100Per100: number;
  numPersonesACarrecUEC: number;
  pensioAnual1: number;
  pensioAnual2: number;
  pensioAnual3: number;
  interessosLlibreta1UEC: number;
  interessosLlibreta2UEC: number;
  capitalMobiliariUEC: number;
  capitalInmobiliari: number;
  altresIngressos: number;
  totalRendesUEC: number;
  carregaFamiliarPersona1UEC: number;
  carregaFamiliarPersona2UEC: number;
  pensioCompensatoriaUEC: number;
  totalReduccionsUEC: number;
  totalCapacitatEconomicaUEC: number;
  costResidencia: number;
  importCapacitatEconomicaMes: number;
  importReduccionsMes: number;
  copagamentUsuari: number;
  usuariAportTotalPreuPublic: number;
  porcentatgeCoberturaUsuari: number;
  porcentatgeSubvenAjuntament: number;
  preuPublic: number;
  preuResidencia: number;
  dataModificacio: number;
}

export class GGDefinicionServicio {
  definicioServeiId: number;
  serveiContracteCentreId: number;
  centreId: string;
  recursId: number;
  dataInici: number;
  dataFinal: number;
  dataIniciPrevist: number;
  dataFinalPrevist: number;
  tipusPeriodicitatDid: number;
  numUnitats: number;
  prestacioFestius: boolean;
  habilitat: boolean;
  informacioAddicional: string;
  tipusPlacaDid: number;
  tipusRespostaDid: number; // 68041
  tipusServeiDid: number; // 2019205
  tipusPlanificacioDid: number; // 2019101
  unitatDid: number; // 2019501
  centreNom?: string;
}

export interface GGCentro {
  centre: string;
  nom: string;
  serveiDid: number;
  telefon: string;
  horari?: any;
  fax: string;
  email: string;
  directorId: string;
  ubicacioId: number;
  compt: number;
  dataCreacio: number;
  dataModificacio: number;
  usuariCreacio: string;
  usuariModificacio: string;
  habilitat: boolean;
  url?: string;
  sistema: string;
  dataMigracio: number;
  centreId: string;
  districteId: string;
  organGestor?: any;
}

export interface GGInterrupcionServicio {
  autoritzacioServei?: boolean;
  autoritzacioResidencia?: boolean;
  dataInici?: number;
  dataPrevistaFi: number;
  dataFi?: number;
  expedientId?: string;
  informacioAdicional?: string;
  interrupcioId?: number;
  motiuInterrupcioDid?: number;
  recursId?: number;
  tipusInterrupcioDid?: number;
}

export interface RecursoGuardamueble {
  dataEntrada: number;
  dataFi?: number;
  estat: number;
  metresCubicsInicials?: number;
  metresCubicsActuals?: number;
  personesAutoritzades?: PersonaAutoritzada[];
}

export interface PersonaAutoritzada {
  nom: string;
  cognom1: string;
  cognom2: string;
  tipusDocumentIdent: string;
  numDocumentIdent: string;
}

export interface PutRecursoDTO {
  recursId?: number;
  tipusServeiDid: number;
  dataIngres: number;
  centre?: string;
  comentarisIngres?: string;
  expedientId: string;
}

export interface PostRecursoDTO {
  tipusServeiDid: number;
  recursId: number;
  dataIngres: number;
  dataPrevistaFi?: number;
  sollicitudId: number;
  centre?: string;
  kitAcollida?: boolean;
  kitAcollidaComentaris?: string;
  tipusPlacaSauv?: number;
  comentarisIngres?: string;
}

export interface PutCambioCentroDTO {
  motiuTrasllatDid: number;
  dataTrasllat: number;
  informacioAddicionalTrasllat: string;
  centreId: string;
  autoritzacioServei: boolean;
}

export class PutSalidaServicioDTO {
  motiuBaixaDid: number; // 2029101
  dataFi: number;
  informacioAddicionalFinalitzacio: string;
  tipusRecursSortidaDid?: number; // 2030101
  recursSortida?: string;
  tipusServeiDid: number;
  constructor () {
    
  }
}

export interface InformacioAddicionalProgramacioSauv {
  accesDomicili: string;
  aspectesRellevantsIngres: string;
  deambulaIndependentment: boolean;
  enllitat: boolean;
  esAcompanyatProvesCUAB: boolean;
  necessitaSuportIngres: boolean;
  necessitatPlacaBarcelona: string;
  recursId: number;
  requereixCadiraRodes: boolean;
  tipusAcompanyamentDid: number;
}

export interface ResultatPreguntesSauvRDTO {
  recursId: number;
}

export class CalculCopagamentRDTO {
  numPersonasUnitatFamiliar?: number;
  pensioAnualUsuari?: number;
  pensioAnualPersona1Carrec?: number;
  pensioAnualPersona2Carrec?: number;
  interessosLlibreta1?: number;
  interessosLlibreta2?: number;
  lloguerAnual?: number;
  hipotecaAnual?: number;
  pensioCompensatoria?: number;
  numPersonesACarrecUEC?: number;
  pensioAnual1?: number;
  pensioAnual2?: number;
  pensioAnual3?: number;
  interessosLlibreta1UEC?: number;
  interessosLlibreta2UEC?: number;
  capitalInmobiliari?: number;
  altresIngressos?: number;
  pensioCompensatoriaUEC?: number;

  constructor(pactoEconomico: CalculCopagamentRDTO) {
    this.numPersonasUnitatFamiliar = pactoEconomico.numPersonasUnitatFamiliar;
    this.pensioAnualUsuari = pactoEconomico.pensioAnualUsuari;
    this.pensioAnualPersona1Carrec = pactoEconomico.pensioAnualPersona1Carrec
      ? pactoEconomico.pensioAnualPersona1Carrec
      : 0;
    this.pensioAnualPersona2Carrec = pactoEconomico.pensioAnualPersona2Carrec
      ? pactoEconomico.pensioAnualPersona2Carrec
      : 0;
    this.interessosLlibreta1 = pactoEconomico.interessosLlibreta1;
    this.interessosLlibreta2 = pactoEconomico.interessosLlibreta2;
    this.lloguerAnual = FormatterService.toNegative(pactoEconomico.lloguerAnual);
    this.hipotecaAnual = FormatterService.toNegative(pactoEconomico.hipotecaAnual);
    this.pensioCompensatoria = FormatterService.toNegative(pactoEconomico.pensioCompensatoria);
    this.numPersonesACarrecUEC = pactoEconomico.numPersonesACarrecUEC;
    this.pensioAnual1 = pactoEconomico.pensioAnual1
      ? pactoEconomico.pensioAnual1
      : 0;
    this.pensioAnual2 = pactoEconomico.pensioAnual2
      ? pactoEconomico.pensioAnual2
      : 0;
    this.pensioAnual3 = pactoEconomico.pensioAnual3
      ? pactoEconomico.pensioAnual3
      : 0;
    this.interessosLlibreta1UEC = pactoEconomico.interessosLlibreta1UEC
      ? pactoEconomico.interessosLlibreta1UEC
      : 0;
    this.interessosLlibreta2UEC = pactoEconomico.interessosLlibreta2UEC
      ? pactoEconomico.interessosLlibreta2UEC
      : 0;
    this.capitalInmobiliari = pactoEconomico.capitalInmobiliari
      ? pactoEconomico.capitalInmobiliari
      : 0;
    this.altresIngressos = pactoEconomico.altresIngressos
      ? pactoEconomico.altresIngressos
      : 0;
    this.pensioCompensatoriaUEC = pactoEconomico.pensioCompensatoriaUEC
      ? FormatterService.toNegative(pactoEconomico.pensioCompensatoriaUEC)
      : 0
  }
  
}

