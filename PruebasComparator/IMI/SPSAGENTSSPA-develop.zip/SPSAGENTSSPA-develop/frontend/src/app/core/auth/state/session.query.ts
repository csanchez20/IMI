import { Injectable } from '@angular/core';
import { ParametreResultsRDTO } from '@app/core/model/parametres-globals/parametres-globals';
import { ServiciosIMI, SERVICIO_GUARDAMUEBLES, SERVICIO_KEY_GM, SERVICIO_KEY_HAB, SERVICIO_KEY_RES, SERVICIO_KEY_RESPLUS, SERVICIO_KEY_SAUV, SERVICIO_RESPIR, SERVICIO_RESPIRPLUS, SERVICIO_SAUV, SERVICIO_VIVIENDAS } from '@app/core/model/servicio';
import { Query, toBoolean } from '@datorama/akita';
import { SelectItem } from 'primeng/api';
import { AuthUser, ImiSpsInfo, ROLES_USER } from '../model';
import { AltaPersonaSolicitud, IncidenciaType, SessionState, SessionStore, UbicacionUI } from './session.store';



@Injectable({
  providedIn: 'root'
})
export class SessionQuery extends Query<SessionState> {
  isLoggedIn$ = this.select(s => toBoolean(s.authUser? s.authUser.clientId : false));
  service$ = this.select('service');
  language$ = this.select('language');
  user$ = this.select(s => s.authUser);
  selectFichaUsuarioTab$ = this.select(s => s.ui.fichaUsuarioTab);
  selectFichaUsuarioDatosComp$ = this.select(s => s.ui.fichaUsuarioDatosComp);
  selectFichaUsuarioBloqSeg$ = this.select(s => s.ui.fichaUsuarioBloqSeg);
  selectFichaUsuarioRecursos$ = this.select(s => s.ui.fichaUsuarioRecursos);
  placesSauv$ = this.select('placesSauv');
  
  constructor(protected store: SessionStore) {
    super(store);
  }

  getFichaUsuarioDatosComp(): string {
    return this.getValue().ui.fichaUsuarioDatosComp;
  }

  getFichaUsuarioBloqSeg(): string {
    return this.getValue().ui.fichaUsuarioBloqSeg;
  }

  getFichaUsuarioRecursos(): string {
    return this.getValue().ui.fichaUsuarioRecursos;
  }

  getUserLoggedId(): string {
    return this.getValue().authUser.imiAuthorization.user;
  }

  getServiceActiveValue(): number {
    return this.getValue().service;
  }

  isServiceGuardamuebles() {
    return toBoolean(
      this.getValue().service === ServiciosIMI.GUARDAMUEBLES
    );
  }

  isServiceSAUV() {
    return toBoolean(this.getValue().service === ServiciosIMI.SAUV);
  }

  isServiceRespir() {
    return toBoolean(this.getValue().service === ServiciosIMI.RESPIR);
  }

  isServiceRespirPlus() {
    return toBoolean(
      this.getValue().service &&
        this.getValue().service === ServiciosIMI.RESPIRPLUS
    );
  }

  isServiceViviendas() {
    return toBoolean(this.getValue().service === ServiciosIMI.VIVIENDAS);
  }

  isServiceIn(services: number[]) {
    return services.includes(this.getValue().service);
  }

  // si es Sauv, Respir/Plus o guardamobles
  isBig4Service() {
    const big4 = [
      ServiciosIMI.SAUV,
      ServiciosIMI.RESPIR,
      ServiciosIMI.RESPIRPLUS,
      ServiciosIMI.GUARDAMUEBLES,
      ServiciosIMI.VIVIENDAS
    ];
    return big4.includes(this.getValue().service);
  }

  isServiceWithProfAtencio() {
    const services = [
      ServiciosIMI.SAUV,
      ServiciosIMI.RESPIR
    ];
    return services.includes(this.getValue().service);
  }

  getPlacesSauv(): SelectItem[] {
    return this.getValue().placesSauv;
  }

  getPlacesViviendas(): SelectItem[] {
    return this.getValue().placesViviendas;
  }
  
  getPGlobalServeisPrestats(): ParametreResultsRDTO[] {
    return this.getValue().parametresGlobals.serveisPrestats;
  }

  getIncidenciaType(): IncidenciaType {
    return this.getValue().incidenciaType;
  }

  getAltaPersonaSol(): AltaPersonaSolicitud {
    return this.getValue().altaPersonaSolicitud;
  }
  
  getAuthUser(): AuthUser {
    return this.getValue().authUser;
  }

  hasImiSpsInfoValueByKeys(keys: string[]): boolean {
    const imiSpsInfo: ImiSpsInfo = this.getAuthUser() ? this.getAuthUser().imiSpsInfo : null;
    const hasValue = imiSpsInfo !== null
      ? keys.every(key => imiSpsInfo[key] !== null)
      : false;
    return hasValue;
  }

  getRoleUser(): string {
    let roleUser: string = '';
    this.getAuthUser().imiAuthorization.acces.map(idRol => {
      if (ROLES_USER[idRol] !== null && ROLES_USER[idRol] !== undefined) {
        roleUser = ROLES_USER[idRol];
        return;
      }
    })
    return roleUser;
  }

  getRoleUserId(): string {
    let roleUserId: string = null;
    this.getAuthUser().imiAuthorization.acces.map(idRol => {
      if (ROLES_USER[idRol] !== null && ROLES_USER[idRol] !== undefined) {
        roleUserId = idRol;
        return;
      }
    });
    return roleUserId;
  }

  isUserRoleById(roleId: string): boolean {
    return this.getRoleUserId() === roleId;
  }

  getDadesCentreUsuari() {
    return this.getValue().dadesCentreUsuari;
  }

  getUbicacionUI(): UbicacionUI {
    return this.getValue().ubicacionUI;
  }

  getUserGrup(): string {
    const service = this.getValue().service;
    let grup: string;
    if (this.getDadesCentreUsuari() !== null) {
      grup = this.getDadesCentreUsuari().centreId;
    } else {
      switch (service) {
        case SERVICIO_GUARDAMUEBLES:
          grup = SERVICIO_KEY_GM;
          break;
        case SERVICIO_VIVIENDAS:
          grup =  SERVICIO_KEY_HAB;
          break;
        case SERVICIO_SAUV:
          grup = SERVICIO_KEY_SAUV;
          break;
        case SERVICIO_RESPIR:
          grup = SERVICIO_KEY_RES;
          break;
        case SERVICIO_RESPIRPLUS:
          grup = SERVICIO_KEY_RESPLUS;
          break;
      }
    }
    return grup;
  }

}
