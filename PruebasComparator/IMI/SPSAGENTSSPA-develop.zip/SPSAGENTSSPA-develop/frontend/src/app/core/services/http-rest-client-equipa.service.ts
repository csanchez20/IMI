import { Injectable } from '@angular/core';
import { HttpRestClientService } from './http-rest-client.service';
import { environment } from '@env/environment';
import { HttpClient } from '@angular/common/http';
import { SeguridadKeysService } from '../auth/seguridad-keys.service';
import { MAP_URL_SEGURIDAD_EQUIPAMENTS } from '../auth/map-url-seguridad';
import { SessionQuery, SessionService } from '../auth';


@Injectable({
  providedIn: 'root'
})
export class HttpRestClientEquipaService extends HttpRestClientService {

  constructor(
    public httpClient: HttpClient,
    public sessionQuery: SessionQuery
  ) { 
    super(
      httpClient, 
      environment.equipaments, 
      new SeguridadKeysService(MAP_URL_SEGURIDAD_EQUIPAMENTS),
      sessionQuery
    )
  }

}
