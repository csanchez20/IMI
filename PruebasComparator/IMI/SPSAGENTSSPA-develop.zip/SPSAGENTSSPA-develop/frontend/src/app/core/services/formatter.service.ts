import { Injectable } from '@angular/core';

import { SessionQuery } from '../auth';
import { DictionaryQuery } from '../dictionary/state/dictionary.query';
import { DiccionarioKey } from '../dictionary/state/dictionary.service';
import { ConsultaAdrecaRDTO } from '../model/usuarios/direccion';
export const SPECIAL_KEYS: Array<string> = ['Backspace', 'Tab', 'End', 'Home', '-', 'ArrowLeft', 'ArrowRight', 'Del', 'Delete'];

@Injectable({
  providedIn: 'root'
})
export class FormatterService {
  
  diccionarioKey = DiccionarioKey;

  constructor(
    private sessionQuery: SessionQuery,
    private dictionaryQuery: DictionaryQuery
  ) { }

  static toNegative(value: number) {
    return value !== 0
      ? -Math.abs(value)
      : value
  }

  /**
   * Retorna la fusion de dos objetos. Se toma como referencia el objRef, al que se 
   * le sobreescriben aquellas propiedades comunes con el objToMerge.
   * @param objRef Objeto a retornar, que será fusionado.
   * @param objToMerge Objeto que se fusionará
   */
  static mergeObjectCommonKeys(objRef: Object, objToMerge: Object) {
    Object.keys(objToMerge).filter(key => key in objRef).forEach(key => {
      objRef[key] = objToMerge[key];
    });
    return objRef;
  }

  /**
   * Mapea un objeto de forma que todos aquellos campos que no tienen valor sean null
   * @param obj Objeto a mapear
   */
  public static mapEmptyFieldsToNull(obj: Object): Object {
    let objMapped = {}
    Object.keys(obj).map(key => {
      objMapped = {
        ...objMapped,
        [key]: (obj[key] || obj[key] === false) ? obj[key] : null
      }
    });
    return objMapped;
  }

  public static getUTCTimeFromDates(object: object): object {
    for (const key in object) {
      if (key.includes('data') && key !== 'data') {
        if (object[key] !== null && object[key] !== 0) {
          const date = new Date(object[key]);
          object[key]
            = new Date(
              date.getUTCFullYear(),
              date.getUTCMonth(),
              date.getUTCDate(),
              date.getUTCHours(),
              date.getUTCMinutes(),
              date.getUTCSeconds()
            );
        } else {
          object[key] = null;
        }
      } else if (typeof object[key] === 'object') {
        object[key] = this.getUTCTimeFromDates(object[key]);
      }
    }
    return object;
  }


  static textBoolean(value: boolean) {
    if (value === true) {
      return 'Sí';
    } else if (value === false) {
      return 'No';
    }
  }
  
  static ageFromDateOfBirthday(dateOfBirth: any): number {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    return age;
  }
  
  getDateLastDayMonth(date: Date): Date {
    return date ? new Date(date.getFullYear(), date.getMonth() + 1, 0) : null;
  }


  getCentroDescr(centreId: string) {
    const centros = this.sessionQuery.getPlacesSauv();
    const found = centros && centros.filter(el => el.value === centreId);
    if (found && found.length === 1) {
      return found[0]['label'];
    }
    return 'No trobat';
  }

  getAdrecaToString(direccion: ConsultaAdrecaRDTO) {
    let direccionFormatted: string;
    if (direccion) {
      if (direccion.adrDistricte) {
        direccion.distrDesc = this.dictionaryQuery.getItemDictionaryByKey(direccion.adrDistricte, this.diccionarioKey.DISTRICTES)
      }
      direccionFormatted = 
        this.dictionaryQuery.getItemDictionaryByKey(
          direccion.adrTipusVia,
          this.diccionarioKey.TIPOS_VIA
        ) 
        + ' ' +
        direccion.adrNomCarrer + ', ' +
        direccion.adrNum1 +
        (direccion.adrNum2 && direccion.adrNum2.length > 0 ? '-' + direccion.adrNum2 + ', ' : ', ') +
        (direccion.adrLletra1 && direccion.adrLletra1.length > 0 ? ' ' + direccion.adrLletra1 + ', ' : '') +
        (direccion.adrLletra2 && direccion.adrLletra2.length > 0 ? direccion.adrLletra2 + ', ' : '') +
        (direccion.adrPortal && direccion.adrPortal.length > 0 ? direccion.adrPortal + ', ' : '') +
        (direccion.adrEscala && direccion.adrEscala.length > 0 ? direccion.adrEscala + ', ' : '') +
        (direccion.adrAPDescr && direccion.adrAPDescr.length > 0 ? direccion.adrAPDescr + ', ' : '') +
        (direccion.adrPPis && direccion.adrPPis.length > 0 ? direccion.adrPPis + ', ' : '') +
        (direccion.adrPPorta && direccion.adrPPorta.length > 0 ? direccion.adrPPorta + ', ' : '') +
        (direccion.distrDesc && direccion.distrDesc.length > 0 ? direccion.distrDesc + ', ' : '') +
        (direccion.barriDesc && direccion.barriDesc.length > 0 ? direccion.barriDesc + ', ' : '') +
        (direccion.adrMunicipi && direccion.adrMunicipi.length > 0 ? direccion.adrMunicipi + ', ' : '') +
        (direccion.adrCP && direccion.adrCP.length> 0 ? direccion.adrCP : '') +
        '.';

    }
    return direccionFormatted;
  }

  

}
