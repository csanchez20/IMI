import { DatePipe } from '@angular/common';
import { FormGroup } from '@angular/forms';
import { OptionsDateRange } from '../model/filtros';

const STARTDATE = 'startDate';
const ENDDATE = 'endDate';

export class FiltersService {
  whenActivateFilters(form: FormGroup): any[] {
    return Object.keys(form.controls).map(key => {
      if (form.controls[key].value !== null) {
        const valor =
          form.controls[key].value.value !== undefined
            ? form.controls[key].value.value
            : form.controls[key].value;
        return { [key]: valor };
      } else {
        return { [key]: null };
      }
    });
  }

  whenActivateFiltersToAppliedFilters(form: FormGroup): any[] {
    return Object.keys(form.controls).map(key => {
      if (form.controls[key].value !== null) {
        const valor =
          form.controls[key].value.label !== undefined
            ? form.controls[key].value.label
            : form.controls[key].value;
        return { [key]: valor };
      } else {
        return { [key]: null };
      }
    });
  }

  whenSetFields(form: FormGroup, data: any) {
    const key = Object.keys(data)[0];
    if (this.isDateRange(key)) {
      if (key === STARTDATE) {
        form.get('dates').patchValue({
          start: '',
          end: form.get('dates').value['end']
        });
        form.get('datesPeriode').patchValue({
          start: '',
          end: form.get('datesPeriode').value['end']
        });
      } else {
        form.get('dates').patchValue({
          start: form.get('dates').value['start'],
          end: ''
        });
        form.get('datesPeriode').patchValue({
          start: form.get('datesPeriode').value['start'],
          end: ''
        });
      }
    } else {
      form.patchValue(data);
    }
  }

  whenSetResetFields(form: FormGroup) {
    form.reset();
    if (form.get('dates')) {
      form.get('dates').patchValue({
        start: '',
        end: ''
      });
    }
    if (form.get('datesPeriode')) {
      form.get('datesPeriode').patchValue({
        start: '',
        end: ''
      });
    }
    if (form.get('estat')) {
      form.get('estat').patchValue(true);
    }
  }
  
  parseToParams(data: any[], keyStart?: string, keyEnd?: string) {
    const datepipe = new DatePipe('ca');
    let params = {};
    data.map(d => {
      Object.keys(d).map(key => {
        if (key === 'dates' && d[key]) {
          if (d[key].start) {
            params = {
              ...params,
              [keyStart]: datepipe.transform(
                new Date(d[key].start),
                'dd/MM/yyyy'
              )
            };
          }
          if (d[key].end) {
            params = {
              ...params,
              [keyEnd]: datepipe.transform(
                new Date(
                  d[key].end.getFullYear(),
                  d[key].end.getMonth(),
                  d[key].end.getDate()
                ),
                'dd/MM/yyyy'
              )
            };
          }
        } else if (typeof d[key] === 'boolean') {
          params = {
            ...params,
            [key]: d[key]
          };
        } else if (d[key]) {
          params = {
            ...params,
            [key]: String(d[key]).toLocaleUpperCase()
          };
        }
      });
    });
    return params;
  }

  parseToParamsAux(data: any[], dateRangeOptions: OptionsDateRange[]) {
    const datepipe = new DatePipe('ca');
    let params = {};
    data.map(d => {
      Object.keys(d).map(key => {
        // if(dateRangeOptions) {
          const dateRange = dateRangeOptions.find(o => key === o.formControlName && d[key]);
          if(dateRange) {
            if(d[key].start) {
              params = {
                ...params,
                [dateRange.keyStart]: datepipe.transform(
                  new Date(d[key].start),
                  'dd/MM/yyyy'
                ) 
              };
            }
            if(d[key].end) {
              params = {
                ...params,
                [dateRange.keyEnd]: datepipe.transform(
                  new Date(
                    d[key].end.getFullYear(),
                    d[key].end.getMonth(),
                    d[key].end.getDate()
                  ),
                  'dd/MM/yyyy'
                )
              };
            }
          }
        // }
        
         if (typeof d[key] === 'boolean') {
          params = {
            ...params,
            [key]: d[key]
          };
        } else if(d[key]) {
          params = {
            ...params,
            [key]: String(d[key]).toLocaleUpperCase()
          };
        }
      });
    });
    delete params['dates'];
    delete params['datesPeriode'];
    return params;
  }

  private isDateRange(key: any) {
    return key === STARTDATE || key === ENDDATE;
  }
}
