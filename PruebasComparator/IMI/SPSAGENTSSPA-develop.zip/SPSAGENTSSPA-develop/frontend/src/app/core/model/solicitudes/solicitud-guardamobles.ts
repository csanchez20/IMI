export interface ModificaEstatGuardamoblesRDTO {
  entitatExternaId: number;
  estatIdDesti: number;
  instanciaId: number;
  observacions?: string; 
}

export interface ResultatModificaEstatGuardamobles {
  instanciaId: number;
}

export interface ResultatConsultaGuardamoblesRDTO {
  adrecaDescarrega1: ModificacioAdrecaRDTO;
  adrecaDescarrega2: ModificacioAdrecaRDTO;
  adrecaRecollida: ModificacioAdrecaRDTO;
  centreCss: string;
  dadesSollicitudOriginal: string;
  dataActualitzacioEstat: Date;
  dataDesnonament: Date;
  dataRecollida: Date;
  dataSollicitud: Date;
  detallsTrasllat: string;
  estatSollicitud: number;
  expedientId: string;
  instanciaFluxId: number;
  motiuAltres: string;
  motiuEstat: string;
  motiuSollicitud: number;
  professionalPrescriptor: string;
  relacioBens: string;
  sollicitudId: number;
  sollicitudsProrroga: ResultatConsultaGuardamoblesProrrogaRDTO[];
  sollicitudsResidus: ResultatConsultaGuardamoblesResidusRDTO[];
  tipusPeticio: number;
  usuariCognom1: string;
  usuariCognom2: string;
  usuariDataNaixement: Date;
  usuariDocument: string;
  usuariNom: string;
  usuariTipusDocument: number;
  usuariValidat: string;
  valoracioEconomica: number;
}

export interface ModificacioAdrecaRDTO {
  adrANumero: string;
  adrAP: string;
  adrCP: string;
  adrEscala: string;
  adrLletra1: string;
  adrLletra2: string;
  adrMunicipi: string;
  adrNomCarrer: string;
  adrNum1: string;
  adrNum2: string;
  adrPPis: string;
  adrPPorta: string;
  adrPortal: string;
  adrTipusVia: string;
  esForaBarcelona: boolean;
  tipusHabitatgeDid: number;
}

export interface ResultatConsultaGuardamoblesProrrogaRDTO {
  centreCss: string;
  dadesSollicitudOriginal: string;
  dataActualitzacioEstat: Date;
  dataSollicitud: Date;
  estatSollicitud: number;
  expedientId: string;
  instanciaFluxId: number;
  mesosAddicionals: number;
  motiu: string;
  motiuEstat: string;
  solGuardamoblesId: number;
  sollicitudId: number;
  usuariCognom1: string;
  usuariCognom2: string;
  usuariDataNaixement: Date;
  usuariDocument: string;
  usuariNom: string;
  usuariTipusDocument: number;
}

export interface ResultatConsultaGuardamoblesResidusRDTO {
  centreCss: string;
  dadesSollicitudOriginal: string;
  dataActualitzacioEstat: Date;
  dataBOE: Date;
  dataSollicitud: string;
  estatSollicitud: number;
  expedientId: string;
  instanciaFluxId: number;
  motiuEstat: string;
  solGuardamoblesId: number;
  sollicitudId: number;
  usuariCognom1: string;
  usuariCognom2: string;
  usuariDataNaixement: Date;
  usuariDocument: string;
  usuariLocalitzat: boolean;
  usuariNom: string;
  usuariTipusDocument: number;
}

export interface AltaGuardamoblesProrrogaRDTO {
  mesosAddicionals: number;
  motiu: string;
}

export interface ResultatAltaGuardamoblesRDTO {
  sollicitudId: number;
}