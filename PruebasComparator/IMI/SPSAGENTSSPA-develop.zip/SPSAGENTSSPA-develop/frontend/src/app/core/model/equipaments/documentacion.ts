export interface CercaDocumentRDTO {
  dataFi?: string, 
  dataInici?: string;
  entitatId: string;
  numeroPagina?: number;
  tamanyPagina?: number;
  tipusDocumentDid?: number;
  tipusEntitatDid: number;
  tipusRespostaDid?: number;
  titolDocument?: string;
}

export interface ResultatCercaDocumentRDTO {
  dataCreacio: string;
  descripcioDocument: string;
  documentacioEntitatId: number;
  entitatId: string;
  tipusDocumentDid:number;
  tipusEntitatDid:number;
  tipusRespostaDid: number;
  titolDocument: string;
  justificacio: string;
}

export interface AltaDocumentRDTO {
  descripcioDocument?: string;
  document?;
  entitatId: string;
  tipusDocumentDid: number;
  tipusEntitatDid: number;
  tipusRespostaDid: number;
  titolDocument?: string;
  justificacio?: string;
}

export interface ResultatAltaEsborraDocumentRDTO {
  documentacioEntitatId: number;
}

export interface ResultatConsultaDocumentRDTO extends AltaDocumentRDTO {
  documentacioEntitatId: number;
}

export interface FiltrosDocumentacionUsuario {
  dates: {
    start: string;
    end: string;
  };
  pujatForm: number;
  tipusForm: {
    value: number,
    label: string,
    order: number,
    disabled: boolean
  };
}


