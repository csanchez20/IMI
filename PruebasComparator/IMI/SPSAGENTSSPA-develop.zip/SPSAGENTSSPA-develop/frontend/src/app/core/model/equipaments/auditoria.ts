export interface AuditoriaCercadesRDTO {
  id: number;
  tipus: TipoAuditoria;
  dataAuditoria: number;
  idProfessionalDocument: string;
  nomProfessionalDocument: string;
  document: string; 
  actiu: boolean;
}

export interface AuditoriaRDTO extends AuditoriaCercadesRDTO {
  comentaris: string;
}

export interface AuditoriaIdRDTO {
  auditoriaId: number;
}

export enum TipoAuditoria { 
  INTERN = 'Intern',
  EXTERN = 'Extern'
}