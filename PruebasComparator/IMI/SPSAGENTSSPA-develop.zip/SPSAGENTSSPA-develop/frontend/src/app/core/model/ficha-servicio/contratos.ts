export class ParamsCercaContracte {
    contracteId?: number;
    dataFinal?: string;
    dataInici?: string;
    estatDid?: number;
    nomComercial?: string;
    numeroExpedient?: number;
    numeroPagina?: number;
    tamanoPagina?: number;
    tipusRespostaDid?: number;

    constructor(tipusRespostaDid?: number) {
        if (tipusRespostaDid) {
            this.tipusRespostaDid = tipusRespostaDid;
        }
    }
}

export interface ContracteCercadesRDTO {
    contracteId: number;
    dataFinal: string;
    dataInici: string;
    empresaGestoraId: number;
    estatDid: number;
    nomComercial: string;
    numeroExpedient: number;
}

export interface ModificaContracteRDTO {
    dataFinal: string;
    dataInici: string;
    durada: number;
    importAmbIva: number;
    importSenseIva: number;
    numeroExpedient: number;
    tipologiaContracteDid: number;
}

export interface ContracteRDTO extends ModificaContracteRDTO { 
    contracteId?: number; 
    empresaGestoraId: number;
    estatDid: number;    
    prioritat?: number;
    tipusRespostaDid: number;
}

export interface ContracteIdRDTO {
    contracteId: number;
}