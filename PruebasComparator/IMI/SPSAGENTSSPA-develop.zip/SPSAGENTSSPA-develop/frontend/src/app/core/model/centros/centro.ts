export interface CentreRDTO {
    actiu: boolean;
    centre: string;
    centreId: string;
    compt: number;
    dataCreacio: Date;
    dataMigracio: Date;
    dataModificacio: Date;
    directorId: string;
    districteId: string;
    email: string;
    fax: string;
    habilitat: boolean;
    horari: string;
    nom: string;
    organGestor: string;
    serveiDid: number;
    sistema: string;
    telefon: string;
    ubicacioId: number;
    url: string;
    usuariCreacio: string;
    usuariModificacio: string;
}

export interface CercaCentreRDTO {
    centre?: string;
    nom?: string;
    serveiDid: string;
    telefon?: string;
    email?: string;
    directorId?: string;
    ubicacioId?: number;
    centreId?: string;
    districteId?: string;
    tamanoPagina?: number;
    numeroPagina?: number;
}