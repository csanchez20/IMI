import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ParametreResultsRDTO } from '@app/core/model/parametres-globals/parametres-globals';
import { resetStores } from '@datorama/akita';
import { SelectItem } from 'primeng/api';
import { Observable } from 'rxjs';
import { AuthUser, ImiAuthorization, ImiSpsInfo } from '../model';
import { SessionDataService } from './session.dataservice';
import { AltaPersonaSolicitud, DadesCentreUsuari, IncidenciaType, SessionStore, UbicacionUI } from './session.store';



@Injectable({
  providedIn: 'root'
})
export class SessionService {
  constructor(
    private authStore: SessionStore,
    private authDataService: SessionDataService,
    private http: HttpClient
  ) {}

  setLanguage(language: string): void {
    this.authStore.setLanguage(language);
  }

  setService(service: number): void {
    // this.authStore.setService(this._getSelectItemByServiceValue(service));
    this.authStore.setService(service);
  }

  updateFichaUsuarioTab(tab: number) {
    this.authStore.updateFichaUsuarioTab(tab);
  }

  updateFichaUsuarioDatosComp(menu: string) {
    this.authStore.updateFichaUsuarioDatosComp(menu);
  }

  updateFichaUsuarioBloqSeg(menu: string) {
    this.authStore.updateFichaUsuarioBloqSeg(menu);
  }

  updateFichaUsuarioRecursos(menu: string) {
    this.authStore.updateFichaUsuarioRecursos(menu);
  }

  login(authUser: AuthUser) {
    const sessionState: any = {
      authUser: authUser
    }
    this.authStore.login(sessionState);
  }
  
  loginMock(id: string) {
    this.authStore.login(this.authDataService.getUser(id));
  }

  mockUsersLogin() {
    return Object.keys(this.authDataService.getUsers());
  }

  callSessionInfo(): Observable<ImiAuthorization> {
    const url = '/session/info';
    return this.http.get<ImiAuthorization>(url);
  }

  logout() {
    resetStores({
      // exclude: ['storeName']
    });
    // this.authStore.logout();
  }

  setPlacesSauv(equipaments: SelectItem[]) {
    this.authStore.setPlacesSauv(equipaments);
  }

  setPlacesViviendas(equipaments: SelectItem[]) {
    this.authStore.setPlacesViviendas(equipaments);
  }
  
  setPGlobalServeisPrestats(pGlobalServeisPrestats: ParametreResultsRDTO[]) {
    this.authStore.setPGlobalServeisPrestats(pGlobalServeisPrestats);
  }

  setIncidenciaType(type: IncidenciaType) {
    this.authStore.setIncidenciaType(type);
  }

  setAltaPersonaSol(value: AltaPersonaSolicitud) {
    this.authStore.setAltaPersonaSol(value);
  }

  resetAltaPersonaSol() {
    this.authStore.resetAltaPersonaSol();
  }

  setAuthUser(infoUserSecurity: AuthUser) {
    this.authStore.setAuthUser(infoUserSecurity);
  }

  updateImiSpsInfo(imiSpsInfo: ImiSpsInfo) {
    this.authStore.updateImiSpsInfo(imiSpsInfo);
  }

  setDadesCentreUsuari(dadesCentreUsuari: DadesCentreUsuari) {
    this.authStore.setDadesCentreUsuari(dadesCentreUsuari);
  }

  setUbicacionUI(ubicacionUI: UbicacionUI) {
    this.authStore.setUbicacionUI(ubicacionUI);
  }

  resetUbicacionUI() {
    this.authStore.resetUbicacionUI();
  }

  // private _getSelectItemByServiceValue(service: number): SelectItem {
  //   switch (service) {
  //     // case ServiciosIMI.GUARDAMUEBLES:  // Agents externs no ofrece servicio de Guardamobles
  //     //   break;
  //     case ServiciosIMI.SAUV:
  //       return { label: Servicios.SAUV, value: ServiciosIMI.SAUV };
  //     case ServiciosIMI.RESPIR:
  //       return { label: Servicios.Respir, value: ServiciosIMI.RESPIR };
  //     case ServiciosIMI.RESPIRPLUS:
  //       return { label: Servicios.RespirPlus, value: ServiciosIMI.RESPIRPLUS };
  //     case ServiciosIMI.VIVIENDAS:
  //       return { label: Servicios.Viviendas, value: ServiciosIMI.VIVIENDAS };
  //   }
  // }
}

// export const sessionService = new SessionService(sessionStore);
