export interface ParamsPersona {
    tipusVista?: string;
}

export interface ParamsPersonaPerDoc extends ParamsPersona {
    tipusDocumentDid?: string;
    document?: string;
    numTargetaSalut?: string;
    codiMibPadro?: string;
}

export interface ParamsCercaAtencio {
    expedientId?: string;
    serveiDid?: string;
    noTancat?: boolean;
}

export interface ParamsCentroReferencia {
    ubicacioId?: string;
    codiServei?: string;
}

export interface AtencioPersonaSolicitud {
    intervencioServeiId: number;
    episodiId: number;
    estatIntervencioDid: number;
    motiuTancamentDid: number;
    dataInici: number;
    dataFi: number;
    centreId: string;
    professionalId: string;
    dataCreacio: number;
    dataModificacio: number;
    usuariCreacio: string;
    usuariModificacio: string;
    habilitat: boolean;
    centreCreacio: string;
    centreModificacio: string;
    capcalera: boolean;
    foraTerritori: boolean;
    canalentrada1: number;
}
  
export interface PersonaConsultadesRDTO {
    blocBasiques?: BlocBasiquesDTO;
    blocComplementaries?: BlocComplementariesDTO;
    blocEIA?: BlocEIADTO;
    blocEconomiques?: BlocEconomiquesDTO;
    blocHabitatge?: BlocHabitatgeDTO;
    blocPU?: BlocPUDTO;
    blocSalut?: BlocSalutDTO;
    blocTestPfeiffer?: BlocTestsRDTO;
    blocTestBarthel?: BlocTestsRDTO;
    expedientId?: string;
    listBlocBancaries?: BlocBancariesDTO[];
    listBlocExpedientUbicacio?: BlocExpedientUbicacioDTO[];
}

export interface BlocBasiquesDTO {
    actiu: boolean;
    alies: string;
    anyArribada: number;
    canalEntrada2Did:  number;
    canalEntradaDid: number;
    centreAlta: string;
    centreModificacio: string;
    codiMibNegoci: string;
    codiMibPadro:  string;
    codiMibPersona:  string;
    cognom1: string;
    cognom1N: string;
    cognom2: string;
    cognom2N: string;
    dataConsentimentDona: string;
    dataConsentimentImd: string;
    dataConsentimentLopd: string;
    dataCreacio: string;
    dataModificacio: string;
    dataNaixement: number;
    dataTancament: string;
    descripcioTelefon1: string;
    descripcioTelefon2: string;
    descripcioTelefon3: string;
    descripcioTelefon4: string;
    document: string;
    email: string;
    expedientId: string;
    foraTerritori: boolean;
    genereDid: number;
    modificarPendentRevisio: boolean;
    motiuTancamentDid: number;
    nacionalitatDid: number;
    nom: string;
    nomN: string;
    numTargetaSalut: string;
    numSeguretatSocial: string;
    observacions: string;
    paisNaixementDid: number;
    pendentRevisio: boolean;
    provNaixementDid: number;
    requereixSms: boolean;
    situacioLegalDid: number;
    teAdreca: boolean;
    teAlias: boolean;
    teConsentiment: boolean;
    teConsentimentDona: boolean;
    teConsentimentDonaFamiliar: string;
    teConsentimentFamiliar: string;
    teConsentimentImd: boolean;
    teConsentimentImdFamiliar: string;
    teTelefon: boolean;
    telefon1: string;
    telefon2: string;
    telefon3: string;
    telefon4: string;
    tipusDocumentDid: number;
    tipusIoImd: string;
    tipusIoImss: string;
    tipusIoQvie: string;
    tipusTelefon1Did: number;
    tipusTelefon2Did: number;
    tipusTelefon3Did: number;
    tipusTelefon4Did: number;
    usuariCreacio: string;
    usuariModificacio: string;
}

export interface BlocTestsRDTO {
    testId?: number;
    expedientId?: string;
    dataRealitzacio?: number;
    puntuacio?: number;
    tipusTestDid?: number;
    preguntes?: BlocTestsPreguntaRDTO[];
}

export interface BlocTestsPreguntaRDTO {
    preguntaId: number;
    testId: number;
    preguntaDid: number;
    respostaDid: number;
}

export interface BlocUsuarioDTO{
    actiu: boolean;
    aplicacioAlta: number;
    centre: string;
    centreAlta: string;
    centreCreacio: string;
    centreModificacio: string;
    centreTancament: string;
    dataCreacio: number;
    dataModificacio: number;
    dataTancament: number;
    estatIntervencioDid: number;
    expedientId: string;
    habilitat: boolean;
    motiuTancamentDid: number;
    responsableId: string;
    serveiIntervencioDid: number;
    tipusExpedient: string;
    tipusNfcDid: number;
    ultimEpisodiId: number
    usuariCreacio: string;
    usuariModificacio: string;
    usuariTancament: string;
  }

export interface BlocExpedientDTO{
    actiu: boolean;
    aplicacioAlta: number;
    centre: string;
    centreAlta: string;
    centreCreacio: string;
    centreModificacio: string;
    centreTancament: string;
    dataCreacio: number;
    dataModificacio: number;
    dataTancament: number;
    estatIntervencioDid: number;
    expedientId: string;
    habilitat: boolean;
    motiuTancamentDid: number;
    responsableId: string;
    serveiIntervencioDid: number;
    tipusExpedient: string;
    tipusNfcDid: number;
    ultimEpisodiId: number
    usuariCreacio: string;
    usuariModificacio: string;
    usuariTancament: string;
  }

export interface BlocComplementariesDTO {
    actiu: boolean; 
    centreCreacio: string;
    centreModificacio: string;
    dataCreacio: string;
    dataEstatIncapacitat: string;
    dataModificacio: string;
    dataNouvingut: string;
    enProcesIncapacitat: boolean;
    esNouvingut: boolean;
    escolaDid: number;
    estaEscolaritzat: boolean;
    estatCivilDid: number;
    estatProcesIncapacitatDid: number;
    fillsMenorsDesc: string;
    fillsMenorsDona: string;
    fillsMenorsHome: string;
    fillsMenorsTotal: string;
    fillsTotalDesc: string;
    fillsTotalDona: string;
    fillsTotalHome: string;
    fillsTotalTotal: string;
    hiHaMotiuConsulta: boolean;
    idiomaDid: number;
    motiuConsulta: string;
    necessitaTraductor: boolean;
    nivellInstruccioDid: number;
    observacions: string;
    professio: string;
    professioComboDid: number;
    relacioAmbServeisMunicipals: number;
    sectorDid: number;
    situacioEscolarDid: number;
    situacioLaboralDid: number;
    tutorLegal: string;
    usuariCreacio: string;
    usuariModificacio: string;
}

export interface BlocEIADTO {
    actiu: boolean;
    canalEntradaDid: number;
    centreCreacio: string;
    centreModificacio: string;
    dataCreacio: string;
    dataModificacio: string;
    ubicacioEaiaDid: number;
    usuariCreacio: string;
    usuariModificacio: string;
}

export interface BlocEconomiquesDTO {
    actiu: boolean;
    centreCreacio: string;
    centreModificacio: string;
    dataCreacio: string;
    dataModificacio: string;
    ingressosMensuals: number;
    usuariCreacio: string;
    usuariModificacio: string;
    viaPercepcio1Did: number;
    viaPercepcio2Did: number;
}

export interface BlocPUDTO {
    actiu: boolean;
    centreCreacio: string;
    centreModificacio: string;
    dataCaducitat: string;
    dataCreacio: string;
    dataModificacio: string;
    diagnosticCas: string;
    expedientId: string;
    habilitat: boolean;
    informacio: string;
    novolRebreInformacio: boolean;
    numeroRegistre: number;
    numeroResolucio: string;
    tipusResolucioDid: number;
    usuariCreacio: string;
    usuariModificacio: string;
}

export interface BlocSalutDTO {
    actiu: boolean;
    ambulatoriRefrenciaDid: number;
    antecedentsPsiq: string;
    atesEquipDid: number;
    baremDependencia: boolean;
    baremMobilitat: boolean;
    cadiraRodesDid: number;
    casReferencia: string;
    casReferenciaActual: string;
    centreCreacio: string;
    centreModificacio: string;
    centreTractamentTox: string;
    crossesDid: number;
    dataCreacio: string;
    dataEfecte: string;
    dataModificacio: string;
    dataVenciment: string;
    discapacitat1Did: number;
    discapacitat2Did: number;
    discapacitat3Did: number;
    esmDataDiagnostic: string;
    esmDiagnostic: string;
    esmInstitucio: string;
    esmPassatTractament: string;
    esmProfessional: string;
    esmTipusTractament: string;
    estaEnTractament: boolean;
    estaTractamentTox: boolean;
    estatCertificatDid: number;
    expedientId: string;
    grauDiscapacitat: number;
    grupGrauDiscapacitatDid: number;
    malaltiesCroniques: string;
    malaltiesInfeccioses: string;
    malaltiaMentalDid: number;
    malaltiaMentalObservacions: string;
    malaltiaInfecciosaDid: number;
    malaltiaInfecciosaObservacions: string;
    malaltiaCronicaDid: number;
    malaltiaCronicaObservacions: string;
    necessitaAcompanyant: boolean;
    numTargetaSalut: string;
    observacions: string;
    psmNumingresos: number;
    psmTempsIngressat: number;
    taxiAdaptat: boolean;
    teAntecedentsPsiq: boolean;
    teAntecentsTox: boolean;
    teDiscapacitat: boolean;
    teMalaltiesCroniques: boolean;
    teMalatiesInfeccioses: boolean;
    teTuberculosi: boolean;
    tipusCoberturaDid: number;
    toxicomaniaDid: number;
    toxicomaniaTipusDid: number;
    toxicomaniaTipusAltres: string;
    toxicomania1Did: number;
    toxicomania2Did: number;
    toxicomania3Did: number;
    usuariCreacio: string;
    usuariModificacio: string;
    validesaReconeixementDid: number;
}

export interface BlocBancariesDTO {
    actiu: boolean;
    centreCreacio: string;
    centreModificacio: string;
    compteId: number;
    compteNombre: string;
    compteTipusDid: number;
    dataCreacio: string;
    dataModificacio: string;
    entitatDid: number;
    expedientId: string;
    habilitat: boolean;
    iban: string;
    swift: string;
    usuariCreacio: string;
    usuariModificacio: string;
}

export interface BlocExpedientUbicacioDTO {
    centreCreacio?: string;
    centreModificacio?: string;
    dataCreacio?: string;
    dataFinalUbicacio?: string;
    dataIniciUbicacio?: number;
    dataModificacio?: string;
    expedientId: string;
    habilitat: boolean;
    tipusAdrecaDid: number;
    tipusTinencaDid?: number;
    ubicacioId: number;
    usuariCreacio?: string;
    usuariModificacio?: string;
    usuariUbicacioId?: number;
    vigent: boolean;
}

export class BlocExpedientUbicacio {
    centreCreacio?: string;
    centreModificacio?: string;
    dataCreacio?: string;
    dataFinalUbicacio?: string;
    dataIniciUbicacio?: number;
    dataModificacio?: string;
    expedientId: string;
    habilitat: boolean;
    tipusAdrecaDid: number;
    tipusTinencaDid?: number;
    ubicacioId: number;
    usuariCreacio?: string;
    usuariModificacio?: string;
    usuariUbicacioId?: number;
    vigent: boolean;

    constructor(tipusAdrecaDid: number, ubicacioId: number) {
        this.centreCreacio = null;
        this.centreModificacio = null;
        this.dataCreacio = null;
        this.dataFinalUbicacio = null;
        this.dataIniciUbicacio = new Date().getTime();
        this.dataModificacio = null;
        this.expedientId = null;
        this.habilitat = null;
        this.tipusAdrecaDid = tipusAdrecaDid;
        this.tipusTinencaDid = null;
        this.ubicacioId = ubicacioId;
        this.usuariCreacio = null;
        this.usuariModificacio = null;
        this.usuariUbicacioId = null;
        this.vigent = true;
    }
}

export class BlocSalut {
    actiu: boolean;
    ambulatoriRefrenciaDid: number;
    antecedentsPsiq: string;
    atesEquipDid: number;
    baremDependencia: boolean;
    baremMobilitat: boolean;
    cadiraRodesDid: number;
    casReferencia: string;
    casReferenciaActual: string;
    centreCreacio: string;
    centreModificacio: string;
    centreTractamentTox: string;
    crossesDid: number;
    dataCreacio: string;
    dataEfecte: string;
    dataModificacio: string;
    dataVenciment: string;
    discapacitat1Did: number;
    discapacitat2Did: number;
    discapacitat3Did: number;
    esmDataDiagnostic: string;
    esmDiagnostic: string;
    esmInstitucio: string;
    esmPassatTractament: string;
    esmProfessional: string;
    esmTipusTractament: string;
    estaEnTractament: boolean;
    estaTractamentTox: boolean;
    estatCertificatDid: number;
    expedientId: string;
    grauDiscapacitat: number;
    grupGrauDiscapacitatDid: number;
    malaltiesCroniques: string;
    malaltiesInfeccioses: string;
    malaltiaMentalDid: number;
    malaltiaMentalObservacions: string;
    malaltiaInfecciosaDid: number;
    malaltiaInfecciosaObservacions: string;
    malaltiaCronicaDid: number;
    malaltiaCronicaObservacions: string;
    necessitaAcompanyant: boolean;
    numTargetaSalut: string;
    observacions: string;
    psmNumingresos: number;
    psmTempsIngressat: number;
    taxiAdaptat: boolean;
    teAntecedentsPsiq: boolean;
    teAntecentsTox: boolean;
    teDiscapacitat: boolean;
    teMalaltiesCroniques: boolean;
    teMalatiesInfeccioses: boolean;
    teTuberculosi: boolean;
    tipusCoberturaDid: number;
    toxicomaniaDid: number;
    toxicomaniaTipusDid: number;
    toxicomaniaTipusAltres: string;
    toxicomania1Did: number;
    toxicomania2Did: number;
    toxicomania3Did: number;
    usuariCreacio: string;
    usuariModificacio: string;
    validesaReconeixementDid: number;

    constructor(numTargetaSalut: string) {
        this.actiu = null;
        this.ambulatoriRefrenciaDid = null;
        this.antecedentsPsiq = null;
        this.atesEquipDid = null;
        this.baremDependencia = null;
        this.baremMobilitat = null;
        this.cadiraRodesDid = null;
        this.casReferencia = null;
        this.casReferenciaActual = null;
        this.centreCreacio = null;
        this.centreModificacio = null;
        this.centreTractamentTox = null;
        this.crossesDid = null;
        this.dataCreacio = null;
        this.dataEfecte = null;
        this.dataModificacio = null;
        this.dataVenciment = null;
        this.discapacitat1Did = null;
        this.discapacitat2Did = null;
        this.discapacitat3Did = null;
        this.esmDataDiagnostic = null;
        this.esmDiagnostic = null;
        this.esmInstitucio = null;
        this.esmPassatTractament = null;
        this.esmProfessional = null;
        this.esmTipusTractament = null;
        this.estaEnTractament = null;
        this.estaTractamentTox = null;
        this.estatCertificatDid = null;
        this.expedientId = null;
        this.grauDiscapacitat = null;
        this.grupGrauDiscapacitatDid = null;
        this.malaltiesCroniques = null;
        this.malaltiesInfeccioses = null;
        this.malaltiaMentalDid = null;
        this.malaltiaMentalObservacions = null;
        this.malaltiaInfecciosaDid = null;
        this.malaltiaInfecciosaObservacions = null;
        this.malaltiaCronicaDid = null;
        this.malaltiaCronicaObservacions = null;
        this.necessitaAcompanyant = null;
        this.numTargetaSalut = numTargetaSalut;
        this.observacions = null;
        this.psmNumingresos = null;
        this.psmTempsIngressat = null;
        this.taxiAdaptat = null;
        this.teAntecedentsPsiq = null;
        this.teAntecentsTox = null;
        this.teDiscapacitat = null;
        this.teMalaltiesCroniques = null;
        this.teMalatiesInfeccioses = null;
        this.teTuberculosi = null;
        this.tipusCoberturaDid = null;
        this.toxicomaniaDid = null;
        this.toxicomaniaTipusDid = null;
        this.toxicomaniaTipusAltres = null;
        this.toxicomania1Did = null;
        this.toxicomania2Did = null;
        this.toxicomania3Did = null;
        this.usuariCreacio = null;
        this.usuariModificacio = null;
        this.validesaReconeixementDid = null;
    }
}

export class BlocBasiques {
    expedientId: string;
    nom: string;
    cognom1: string;
    cognom2: string;
    genereDid: number;
    tipusDocumentDid: number;
    document: string;
    telefon1: number;
    telefon2: number;
    numSeguretatSocial: number;
    nacionalitatDid: number;
    paisNaixementDid: number;
    provNaixementDid: number;
    situacioLegalDid: number;
    canalEntradaDid: number;
    dataNaixement: number;
    observacions: string;
    anyArribada: number;
    alies: string;
    teAlias: boolean;
    teAdreca: boolean;
    teTelefon: boolean;
    foraTerritori: boolean;
    pendentRevisio: boolean;
    modificarPendentRevisio: boolean;
    requereixSms: boolean;
    canalEntrada2Did: number;
    codiMibPersona: number;
    codiMibPadro: number;
    codiMibNegoci: number;
    nomN: string;
    cognom2N: string;
    cognom1N: string;
    telefon3: number;
    telefon4: number;
    descripcioTelefon1: string;
    descripcioTelefon2: string;
    descripcioTelefon3: string;
    descripcioTelefon4: string;
    tipusTelefon1Did: number;
    tipusTelefon2Did: number;
    tipusTelefon3Did: number;
    tipusTelefon4Did: number;
    teConsentiment: boolean;
    dataConsentimentLopd: string;
    email: string;
    teConsentimentDona: boolean;
    dataConsentimentDona: string;
    teConsentimentImd: boolean;
    dataConsentimentImd: string;
    tipusIoImss: string;
    tipusIoImd: string;
    tipusIoQvie: string;
    teConsentimentFamiliar: string;
    teConsentimentDonaFamiliar: string;
    teConsentimentImdFamiliar: boolean;
    actiu: true;
    dataTancament: string;
    motiuTancamentDid: number;
    dataCreacio: string;
    dataModificacio: string;
    usuariCreacio: string;
    usuariModificacio: string;
    centreAlta: string;
    centreModificacio: string;

    constructor(dades: BlocBasiques = {} as BlocBasiques) {
        const {
            expedientId = null,
            nom = null,
            cognom1 = null,
            cognom2 = null,
            genereDid = null,
            tipusDocumentDid = null,
            document = null,
            telefon1 = null,
            telefon2 = null,
            numSeguretatSocial = null,
            nacionalitatDid = null,
            paisNaixementDid = null,
            provNaixementDid = null,
            situacioLegalDid = null,
            canalEntradaDid = null,
            dataNaixement = null,
            observacions = null,
            anyArribada = null,
            alies = null,
            teAlias = null,
            teAdreca = null,
            teTelefon = null,
            foraTerritori = null,
            pendentRevisio = null,
            modificarPendentRevisio = null,
            requereixSms = null,
            canalEntrada2Did = null, 
            codiMibPadro = null,
            codiMibNegoci = null,
            nomN = null,
            cognom2N = null,
            cognom1N = null,
            telefon3 = null,
            telefon4 = null,
            descripcioTelefon1 = null,
            descripcioTelefon2 = null,
            descripcioTelefon3 = null,
            descripcioTelefon4 = null,
            tipusTelefon1Did = null,
            tipusTelefon2Did = null,
            tipusTelefon3Did = null,
            tipusTelefon4Did = null,
            teConsentiment = null,
            dataConsentimentLopd = null,
            email = null,
            teConsentimentDona = null,
            dataConsentimentDona = null,
            teConsentimentImd = null,
            dataConsentimentImd = null,
            tipusIoImss = null,
            tipusIoImd = null,
            tipusIoQvie = null,
            teConsentimentFamiliar = null,
            teConsentimentDonaFamiliar = null,
            teConsentimentImdFamiliar = null,
            actiu = true,
            dataTancament = null,
            motiuTancamentDid = null,
            dataCreacio = null,
            dataModificacio = null,
            usuariCreacio = null,
            usuariModificacio = null,
            centreAlta = null,
            centreModificacio = null,
            codiMibPersona = null
        } = dades;
        this.expedientId = expedientId;
        this.nom = nom;
        this.cognom1 = cognom1;
        this.cognom2 = cognom2;
        this.genereDid = genereDid;
        this.tipusDocumentDid = tipusDocumentDid;
        this.document = document;
        this.telefon1 = telefon1;
        this.telefon2 = telefon2;
        this.numSeguretatSocial = numSeguretatSocial;
        this.nacionalitatDid = nacionalitatDid;
        this.paisNaixementDid = paisNaixementDid;
        this.provNaixementDid = provNaixementDid;
        this.situacioLegalDid = situacioLegalDid;
        this.canalEntradaDid = canalEntradaDid;
        this.dataNaixement = dataNaixement;
        this.observacions = observacions;
        this.anyArribada = anyArribada;
        this.alies = alies;
        this.teAlias = teAlias;
        this.teAdreca = teAdreca;
        this.teTelefon = teTelefon;
        this.foraTerritori = foraTerritori;
        this.pendentRevisio = pendentRevisio;
        this.modificarPendentRevisio = modificarPendentRevisio;
        this.requereixSms = requereixSms;
        this.canalEntrada2Did = canalEntrada2Did; 
        this.codiMibPadro = codiMibPadro;
        this.codiMibNegoci = codiMibNegoci;
        this.nomN = nomN;
        this.cognom2N = cognom2N;
        this.cognom1N = cognom1N;
        this.telefon3 = telefon3;
        this.telefon4 = telefon4;
        this.descripcioTelefon1 = descripcioTelefon1;
        this.descripcioTelefon2 = descripcioTelefon2;
        this.descripcioTelefon3 = descripcioTelefon3;
        this.descripcioTelefon4 = descripcioTelefon4;
        this.tipusTelefon1Did = tipusTelefon1Did;
        this.tipusTelefon2Did = tipusTelefon2Did;
        this.tipusTelefon3Did = tipusTelefon3Did;
        this.tipusTelefon4Did = tipusTelefon4Did;
        this.teConsentiment = teConsentiment;
        this.dataConsentimentLopd = dataConsentimentLopd;
        this.email = email;
        this.teConsentimentDona = teConsentimentDona;
        this.dataConsentimentDona = dataConsentimentDona;
        this.teConsentimentImd = teConsentimentImd;
        this.dataConsentimentImd = dataConsentimentImd;
        this.tipusIoImss = tipusIoImss;
        this.tipusIoImd = tipusIoImd;
        this.tipusIoQvie = tipusIoQvie;
        this.teConsentimentFamiliar = teConsentimentFamiliar;
        this.teConsentimentDonaFamiliar = teConsentimentDonaFamiliar;
        this.teConsentimentImdFamiliar = teConsentimentImdFamiliar;
        this.actiu = actiu;
        this.dataTancament = dataTancament;
        this.motiuTancamentDid = motiuTancamentDid;
        this.dataCreacio = dataCreacio;
        this.dataModificacio = dataModificacio;
        this.usuariCreacio = usuariCreacio;
        this.usuariModificacio = usuariModificacio;
        this.centreAlta = centreAlta;
        this.centreModificacio = centreModificacio;
        this.codiMibPersona = codiMibPersona;
    }
}

export class BlocComplementaries {
    situacioLaboralDid?: number;
    professio?: string;
    estaEscolaritzat?: boolean;
    escolaDid?: number;
    situacioEscolarDid?: number;
    nivellInstruccioDid?: number;
    enProcesIncapacitat?: string;
    estatProcesIncapacitatDid?: number;
    tutorLegal?: string;
    estatCivilDid?: number;
    observacions?: string;
    esNouvingut?: string;
    dataNouvingut?: string;
    hiHaMotiuConsulta?: string;
    motiuConsulta?: string;
    necessitaTraductor?: string;
    idiomaDid?: number;
    relacioAmbServeisMunicipals?: string;
    dataCreacio?: string;
    dataModificacio?: string;
    usuariCreacio?: string;
    usuariModificacio?: string;
    centreCreacio?: string;
    centreModificacio?: string;
    actiu?: string;
    dataEstatIncapacitat?: string;
    sectorDid?: number;
    professioComboDid?: number;
    fillsMenorsHome?: string;
    fillsMenorsDona?: string;
    fillsMenorsDesc?: string;
    fillsMenorsTotal?: string;
    fillsTotalHome?: string;
    fillsTotalDona?: string;
    fillsTotalDesc?: string;
    fillsTotalTotal?: string;

    constructor(dades: BlocComplementaries = {} as BlocComplementaries) {
        const {
            necessitaTraductor = null,
            relacioAmbServeisMunicipals = null,
            estatCivilDid = null,
            idiomaDid = null
        } = dades;
        this.situacioLaboralDid = null;
        this.professio = null;
        this.estaEscolaritzat = null;
        this.escolaDid = null;
        this.situacioEscolarDid = null;
        this.nivellInstruccioDid = null;
        this.enProcesIncapacitat = null;
        this.estatProcesIncapacitatDid = null;
        this.tutorLegal = null;
        this.estatCivilDid = estatCivilDid;
        this.observacions = null;
        this.esNouvingut = null;
        this.dataNouvingut = null;
        this.hiHaMotiuConsulta = null;
        this.motiuConsulta = null;
        this.necessitaTraductor = necessitaTraductor;
        this.idiomaDid = idiomaDid;
        this.relacioAmbServeisMunicipals = relacioAmbServeisMunicipals;
        this.dataCreacio = null;
        this.dataModificacio = null;
        this.usuariCreacio = null;
        this.usuariModificacio = null;
        this.centreCreacio = null;
        this.centreModificacio = null;
        this.actiu = null;
        this.dataEstatIncapacitat = null;
        this.sectorDid = null;
        this.professioComboDid = null;
        this.fillsMenorsHome = null;
        this.fillsMenorsDona = null;
        this.fillsMenorsDesc = null;
        this.fillsMenorsTotal = null;
        this.fillsTotalHome = null;
        this.fillsTotalDona = null;
        this.fillsTotalDesc = null;
        this.fillsTotalTotal = null;
    }
}


export interface BlocHabitatgeDTO {
    estatEconomicHabitatgeDid?: number;
    expedientId?: string;
    quantitat?: number;
    tipusHabitatgeDid?: number;
    tipusPropietariHabitatgeDid?: number;
}

export interface CSSReferenciaRespuesta {
    centre: string;
}