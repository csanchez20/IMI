export interface ResultatConsultaPlacesSauvRDTO {
  centreId: string;
  costDiari: number;
  lliuresDones: number;
  lliuresHomes: number;
  lliuresIndiferent: number;
  nom: string;
  previsioLliuresDones: number;
  previsioLliuresHomes: number;
  previsioLliuresIndiferent: number;
  prioritat: number;
}

export interface ConsultaPlacesSauvRDTO {
  caracteristica?: number;
  empresaGestora?: number;
  numeroPagina?: number;
  tamanyPagina?: number;
  tipusPlaces?: number;
}

export interface AssignaPlacaSauvRDTO {
  centre: string;
  dataPrevistaIngres: Date;
  sollicitudId: number;
  tipusPlacaSauv: number;
}

export interface DesassignaPlacaSauvRDTO {
  sollicitudId: number;
  tipusPlacaDid: number;
}

export interface ResultatAssignaPlacaSauvRDTO {
  definicioServeiId: number;
  resultatActualitzacioPlacesLliures: number;
}
