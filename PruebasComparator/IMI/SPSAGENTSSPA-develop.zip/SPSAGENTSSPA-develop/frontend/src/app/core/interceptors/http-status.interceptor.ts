import { HttpErrorResponse, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NEVER, Observable, throwError } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { HttpStatusService } from './http-status.service';

interface myError {
  message: string;
  status: number
}
@Injectable({
  providedIn: 'root'
})
export class HttpStatusInterceptor implements HttpInterceptor {
  private loadingCalls = 0;
  private actingCalls = 0;
  private tokenExpired: boolean;

  constructor(
    private httpStatusService: HttpStatusService
    ) {
      this.tokenExpired = false;
    }

  private changeStatus(v: boolean, method: string): void {
    if (['POST', 'PUT', 'DELETE', 'PATCH'].indexOf(method) > -1) {
      v ? this.actingCalls++ : this.actingCalls--;
      this.httpStatusService.acting = this.actingCalls > 0;
    } else if (method === 'GET') {
      v ? this.loadingCalls++ : this.loadingCalls--;
      this.httpStatusService.loading = this.loadingCalls > 0;
    }
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<any> {
    this.changeStatus(true, req.method);
    return next.handle(req.clone()).pipe(
      // retry(1),
      catchError((error: HttpErrorResponse) => {
        let myError: myError;
        if (error.error instanceof ErrorEvent) {
          // client-side error
          myError.message = `Error: ${error.error.message}`;
        } else {
          // server-side error
          switch (error.status) {
            case 0: {
              myError = {
                status: error.status,
                message: `Impossible connectar amb els serveis`
              }
              break;
            }
            case 400: {
              myError = this.getError(error);
              return throwError(myError);
            }
            case 401: {
              // Caduca sesion
              if (this.tokenExpired === false) {
                myError = {
                  status: error.status,
                  message: `La seva sessió ha finalitzat. ` // navigate to some url?
                };
                this.httpStatusService.tokenExpired();
                this.tokenExpired = true;
                break;
              }
            }
            case 403: {
              myError = {
                status: error.status,
                message: `Accés denegat.`
              }
              break;
            }
            case 404: {
              myError = this.getError(error);
              return throwError(myError);
            }
            case 500: {
              myError = {
                status: error.status,
                message: `Error desconegut: ${error.message}`
              }
              return throwError(myError);
            }
            default: {
              myError = this.getError(error);
            }
          }
          if (req.method === 'GET') {
            this.loadingCalls--;
            this.httpStatusService.loading = this.loadingCalls > 0;
          } else {
            this.actingCalls--;
            this.httpStatusService.acting = this.actingCalls > 0;
          }
        }
        this.httpStatusService.validationErrors = myError;
        return NEVER;
        // if (error.status === 400) {
        //   this.httpStatusService.validationErrors = e.message;
        //   return NEVER;
        // }
        // return throwError(error);
      }),
      finalize(() => {
        this.changeStatus(false, req.method);
      })
    );
  }

  private getError(error: HttpErrorResponse): myError {
    let myError = {
      status: error.status,
      message: error.statusText
    };

    if (error.error) {
      if (Array.isArray(error.error) && error.error.length > 0) {
        const calculateError = error.error.filter(e => e.field);
        if (calculateError.length > 0) {
          myError.message = calculateError[0].message;
        } else {
          myError.message = error.error[0].message;
        }
      } else if (error.error.errorMessage) {
        myError.message = error.error.errorMessage;
      } else if (error.error.error) {
        myError.message = error.error.error;
      }
    }
    return myError;
  }

}
