export * from './proveedor';

