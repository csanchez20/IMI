import { EdicionAdrecaRDTO } from "..";
import { ResultatCercaDocumentRDTO } from "../equipaments";
import { PersonaConsultadesRDTO } from "../persona";

export class CercaRespirRDTO {
    campGoogle?:string;
    cognom1Usuari?: string;
    cognom2Usuari?: string;
    nomUsuari?: string;
    dataIniciSollicitud?: Date; 
    dataFiSollicitud?: Date;  
    estatSollicitud?: number;
    idSollicitud?: number;
    periodePreferent?: number;
    numeroPagina?: number;
    tamanyPagina?: number;

    constructor() {
      if (!this.numeroPagina) {
        this.numeroPagina = 1;
      }
  
      if (!this.tamanyPagina) {
        this.tamanyPagina = 5;
      }
    }
  }

  export interface ResultatCercaRespirRDTO {
      centre?: string;
      cognom1?: string;
      cognom2?: string;
      nom?: string;
      dataCreacio?: Date;
      estatSollicitud?: number;
      expedientId?: string;
      numeroDocumentIdentitat?: string;
      periodeConcedit?: string;
      sollicitudId?: string;
  }

  export interface PaginacionCercaRESPIR {
    content?: ResultatCercaRespirRDTO[];
    pageNumber?: number;
    pageSize?:number;
    total?: number;
    count?: number;
  }

  export interface ResultatConsultaRespirRDTO{
    sollicitudId?: number;
    instanciaFluxId?: number;
    dadesSollicitudOriginal?: string;

    //Datos basicos
    usuariCognom1?: string;
    usuariCognom2?: string;
    usuariNom?: string;
    usuariDataNaixement?: Date; 
    usuariDocument?: string;
    expedientId?: string;
    dataSollicitud?: Date;
    estatSollicitud?: number;
    estatSollicitudRespir?: number;
    motiuEstat?: string;
    dataActualitzacioEstat?: Date;
    estatSollicitudRespirPlus?: string; 
    dataSollicitudRespirPlus?: Date;
    motiuEstatSollicitudRespirPlus?: String;
    centreCss?: string;
    periodeConcedit?: RespirDadesPeriodesRDTO;

    //Datos solicitud
    //Derivacion
    motiuDerivacio?: number;
    motiuAltres?: string;
    //Periodo solicitud
    periodeDisponible: boolean,
    periodePendentDates: boolean,
    periodesSollicitats?: RespirDadesPeriodesRDTO[];
    //Datos cuidador
    cuidador?: RespirDadesCuidadorRDTO;
    //Documentos Adjuntos
    documentDni: ResultatCercaDocumentRDTO;
    documentInformeMedic: ResultatCercaDocumentRDTO;
    documentInformeSocial: ResultatCercaDocumentRDTO;
    documentPerfilSollicitant: ResultatCercaDocumentRDTO;
    documentTargetaSanitaria: ResultatCercaDocumentRDTO;
  }

  export interface RespirDadesCuidadorRDTO{
      expedient: string;
      nom: string;
      cognom1: string;
      cognom2: string;
      tipusDocument: number;
      document: string;
      parentiu?: number;
      dataNaixement?: number;
      telefon: string;
      altresTelefons?: string;
      adreca?: string;
      email: string;
      poblacio: string;
      codiPostal?: string;
      comunicacioSMS: boolean;
  }

  export interface RespirDadesPeriodesRDTO{
    dataInici: number;
    dataFi: number;
  }

  export interface ResultatModificaEstatRespirRDTO {
    instanciaId: number;
  }

  export interface ResultatAltaRespirRDTO {
    sollicitudId: number;
  }

  export class ModificaEstatRespirRDTO {
    entitatExternaId: number;
    estatIdDesti: number;
    instanciaId: number;
    observacions?: string; 
  }

  
  export interface SolicitudRespir {
    actualitzaPersonaCintraos: boolean;
    actualitzaAdrecaPersonaCintraos: boolean;
    dadesPersona: PersonaConsultadesRDTO;
    dadesAdrecaPersona: EdicionAdrecaRDTO;
    dadesTrebSocial: AltaRespirDadesTrebSocialRDTO;
    dadesCuidador: RespirDadesCuidadorRDTO;
    dadesIngresConjunt?: AltaRespirDadesIngresConjuntRDTO;
    dadesPersonaRef?: AltaRespirDadesPersonaRefRDTO
    dadesServei: AltaRespirDadesServeiRDTO;
    motiuAltres?: string;
    motiuSollicitud: number;
    periodeSolicitatPendentDates?: boolean;
    periodeSolicitatQuanDisponible?: boolean;
    dadesPeriodes?: RespirDadesPeriodesRDTO[];
    justificacioFile1: string;
    justificacioFile2: string;
    justificacioFile3: string;
    justificacioFile4: string;
  }

  export interface AltaRespirDadesServeiRDTO {
    altresInterventors?: string;
    centre: string;
    centrePrescriptor: string;
    director: string;
    emailDirector: string;
    emailReferent: string;
    professionalPrescriptor: string;
    referent: string;
    telefonReferent: string;
  }

  export interface AltaRespirDadesPersonaRefRDTO {
    nom: string;
    cognom1: string;
    cognom2: string;
    tipusDocument: number;
    document: string;
    email: string;
    parentiu: string;
    telefon: string;
    altresTelefons: string[];
  }

  export interface AltaRespirDadesTrebSocialRDTO {
    centre: number;
    nom: string;
    cognom1: string;
    cognom2: string;
    telefon: number;
    municipi: string;
    consellComarcal: string;
    email: string;
  }

  export interface AltaRespirDadesIngresConjuntRDTO {
    nom: string;
    cognom1: string;
    cognom2: string;
    dataNaixement?: Date;
    parentiu: string;
    telefon: string;
    altresTelefons: string[];
  }

  export interface DatosServicioSolicitudRespir {
    altresInterventors?: string;
    centre: string;
    centrePrescriptor: string;
    centreSalut?: number;
    director: string;
    emailDirector: string;
    emailReferent: string;
    professionalPrescriptor: string;
    referent: string;
    telefonReferent: string;
  }

