export interface FacturaRDTO {
    documentId: string;
    dataFactura: string;
    dataInici: string;
    dataFi: string;
    numRegResidencia: string;
    comentaris: string;
    dies: number;
    preuPerDia: number;
    importTotal: number;
    docFactOriginal: string;
    docFullTransfer: string;
    docJustificacio: string
}

export interface FacturaGGIdRDTO {
    facturaId: number;
}