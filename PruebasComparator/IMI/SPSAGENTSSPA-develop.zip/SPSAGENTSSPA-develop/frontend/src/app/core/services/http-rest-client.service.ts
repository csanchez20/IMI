import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SessionQuery } from '../auth';
import { HEADER_AUTHORIZATON, HEADER_CLIENT_ID, HEADER_INFO, ImiSpsInfo } from '../auth/model/auth-user';
import { SeguridadKeysService } from '../auth/seguridad-keys.service';

export abstract class HttpRestClientService {

  constructor(
    public httpClient: HttpClient,
    private urlBase: string,
    public seguridadKeysService: SeguridadKeysService,
    public sessionQuery: SessionQuery
    ) { 
      urlBase = urlBase.replace(/\/*$/, '');
    }

  public get<T>(url: string, options: any = {}): Observable<T> {
    const urlCompleta = this._getUrlCompleta(url);
    const _options = this._getCabecerasSeguridad('GET', url, options);
    return this.httpClient.get<T>(urlCompleta, _options).pipe((res: any) => res);
  }

  public post<T>(url: string, body: any | null, options: any = {}): Observable<T> {
    const urlCompleta = this._getUrlCompleta(url);
    const _options = this._getCabecerasSeguridad('POST', url, options);
    return this.httpClient.post<T>(urlCompleta, body, _options).pipe((res: any) => res);
  }

  public put<T>(url: string, body: any | null, options: any = {}): Observable<T> {
    const urlCompleta = this._getUrlCompleta(url);
    const _options = this._getCabecerasSeguridad('PUT', url, options);
    return this.httpClient.put<T>(urlCompleta, body, _options).pipe((res: any) => res);
  }

  public delete<T>(url: string, options: any = {}): Observable<T> {
    const urlCompleta = this._getUrlCompleta(url);
    const _options = this._getCabecerasSeguridad('DELETE', url, options);
    return this.httpClient.delete<T>(urlCompleta, _options).pipe((res: any) => res);
  }

  private _getUrlCompleta(url: string): string {
    return [this.urlBase, this._mapUrl(url)].join('/');
  }

  private _getValueSeguridad(type: string, url: string): string {
    return this.seguridadKeysService.getIdMapUrlSeguridadByKey(type + ' ' + url);
  }

  private _getCabecerasSeguridad(type: string, url: string, options: any = {}) {
    url = this._mapUrl(url);
    const valueSeguridad = this._getValueSeguridad(type, url);
    const urlSeguridad = type + ' ' + url + ' ' + valueSeguridad;
    let httpHeaders: HttpHeaders = this._getHeaders(valueSeguridad);
    return {
      ...options,
      headers: httpHeaders
    }
  }

  private _getHeaders(valueSeguridad: string) {
    let httpHeaders: HttpHeaders = new HttpHeaders();
    const authUser = this.sessionQuery.getAuthUser();
    const imiSpsInfo: ImiSpsInfo = {
      ...authUser.imiSpsInfo,
      servicio: valueSeguridad
    }
    httpHeaders = httpHeaders.set(HEADER_INFO, JSON.stringify(imiSpsInfo));
    if (authUser.clientId !== '') {
      httpHeaders = httpHeaders.set(HEADER_CLIENT_ID, authUser.clientId);
    } else {
      httpHeaders = httpHeaders.set(HEADER_AUTHORIZATON, JSON.stringify(authUser.imiAuthorization));
    }
    return httpHeaders;
  }

  private _mapUrl(url: string): string {
    if (url[0] === '/') url = url.substr(1, url.length);
    return url;
  }
}
