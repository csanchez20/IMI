import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from './modulos-funcionales/componentes/page-not-found/page-not-found.component';

const routes: Routes = [
  {
    path: '',
    loadChildren: './modulos-funcionales/acc-social-agents.module#AccSocialAgentsModule'
  },
  {
    path: '**',
    component: PageNotFoundComponent,
    data: {
      breadcrumb: 'Pàgina no trobada'
    }
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
