import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DocumentacionSauvComponent } from './documentacion-sauv.component';
import { BotonMultifuncionGestionDocumentosModule } from '@app/shared/agrupaciones/boton-multifuncion-gestion-documentos/boton-multifuncion-gestion-documentos.module';
import { PanelModule } from 'primeng/primeng';

@NgModule({
  declarations: [DocumentacionSauvComponent],
  imports: [
    CommonModule,
    PanelModule,
    BotonMultifuncionGestionDocumentosModule
  ],
  exports: [DocumentacionSauvComponent]
})
export class DocumentacionSauvModule { }
