import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogFormulariAdrecaComponent } from './dialog-formulari-adreca.component';

describe('DialogFormulariAdrecaComponent', () => {
  let component: DialogFormulariAdrecaComponent;
  let fixture: ComponentFixture<DialogFormulariAdrecaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogFormulariAdrecaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogFormulariAdrecaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
