import { Component, OnInit, ChangeDetectionStrategy, EventEmitter, Output, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { FiltersService } from '@app/core/services';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';

@AutoUnsubscribe()
@Component({
  selector: 'app-filtro-listado-equipaments',
  templateUrl: './filtro-listado-equipaments.component.html',
  styleUrls: ['./filtro-listado-equipaments.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FiltroListadoEquipamentsComponent extends FiltersService implements OnInit, OnDestroy {

  @Output() selectedFilters: EventEmitter<any> = new EventEmitter<any>();
  dataOutput: any[] = [];
  dataToAppliedFilters: any[] = []; // Objeto para enviar al componente applied-filters (con labels)

  formGroup: FormGroup = this.fb.group({
    nom: [''],
    nomEmpresa: [''],
    codiEquipament: [''],
    estat: [true]
  });

  labels: string[] = [
    this.i18n({ id: 'nombreEquipamiento', value: 'Nom equipament' }),
    this.i18n({ id: 'nombreEmpresaGestora', value: 'Nom empresa gestora' }),
    this.i18n({ id: 'numRegistro', value: 'Número de registre' }),
    this.i18n({ id: 'estadoActivo', value: 'Estat actiu' })
  ];

  constructor(
    private fb: FormBuilder,
    private i18n: I18n
  ) { super(); }

  ngOnInit() {}

  onActivateFilters() {
    this.dataOutput = this.whenActivateFilters(this.formGroup);
    this.dataToAppliedFilters = this.whenActivateFiltersToAppliedFilters(this.formGroup);
    this.selectedFilters.emit(this.parseToParams(this.dataOutput));
  }

  setFields(outputData: any) {
    this.whenSetFields(this.formGroup, outputData);
  }

  setResetFilters() {
    this.whenSetResetFields(this.formGroup);
  }

  ngOnDestroy() { }

}


