import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DocumentosConsultaIncidenciaComponent } from './documentos-consulta-incidencia.component';
import { PanelModule } from 'primeng/panel';
import { DocumentacionGeneralModule } from '@app/shared/agrupaciones/documentacion-general/documentacion-general.module';

@NgModule({
  declarations: [
    DocumentosConsultaIncidenciaComponent
  ],
  imports: [
    CommonModule,
    PanelModule,
    DocumentacionGeneralModule
  ],
  exports: [
    DocumentosConsultaIncidenciaComponent
  ]
})
export class DocumentosConsultaIncidenciaModule { }
