import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { DiccionarioKey, DictionaryQuery } from '@app/core/dictionary/state';
import { ResultatConsultaSauvRDTO } from '@app/core/model';
import { SolicitudesService } from '@app/servicios';
import { ButonGestionDocumental } from '@app/shared/agrupaciones/boton-multifuncion-gestion-documentos/boton-multifuncion-gestion-documentos.component';
import { TIPUS_ENTIDAD_RECURS } from '@app/shared/agrupaciones/documentacion-general/documentacion-general.component';
const TIPUS_DOCUMENT_CARTA_SERVEIS = 2074116;
const TIPUS_DOCUMENT_CONSENTIMENT_INGRES = 2074110;
const TIPUS_DOCUMENT_INFORME_MEDIC = 2074105;
const TIPUS_DOCUMENT_SENTENCIA_JUD_INC = 2074111;
const TIPUS_DOCUMENT_SENTENCIA_JUD_AUT = 2074106;
@Component({
  selector: 'app-documentacion-sauv',
  templateUrl: './documentacion-sauv.component.html',
  styleUrls: ['./documentacion-sauv.component.scss']
})
export class DocumentacionSauvComponent implements OnInit {

  @Input() detalleSolSauv: ResultatConsultaSauvRDTO;

  cartaServicios: ButonGestionDocumental;
  consentimientoIngreso: ButonGestionDocumental;
  informeMedico: ButonGestionDocumental;
  sentenciaJudIncap: ButonGestionDocumental;
  sentenciaJudAutIn: ButonGestionDocumental;

  diccionarioKey = DiccionarioKey;

  constructor(
    private dictionaryQuery: DictionaryQuery,
    public solicitudService: SolicitudesService,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this._loadDocuments();
  }

  updateDocuments() {
    this.solicitudService.getDetalleSolicitudSAUV(""+this.detalleSolSauv.sollicitudId).subscribe(res => {
      this.detalleSolSauv = res;
      this._loadDocuments();
      this.cd.markForCheck();
    })
  }

  private _loadDocuments() {
    this.cartaServicios = {
      documentId: this.detalleSolSauv.documentCartaServeis ?
        this.detalleSolSauv.documentCartaServeis.documentacioEntitatId
        : null,
      justificacio: this.detalleSolSauv.documentCartaServeis ?
        this.detalleSolSauv.documentCartaServeis.justificacio
        : null,
      dataPostDocument: {
        ...this.detalleSolSauv.documentCartaServeis,
        tipusDocumentDid: TIPUS_DOCUMENT_CARTA_SERVEIS,
        tipusEntitatDid: TIPUS_ENTIDAD_RECURS,
        entitatId: ""+this.detalleSolSauv.sollicitudId,
        titolDocument: this.dictionaryQuery.getItemDictionaryByKey(TIPUS_DOCUMENT_CARTA_SERVEIS, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_SAUV),
        tipusDocumentDidForm: this.dictionaryQuery.getAllItemDictionaryByKey(TIPUS_DOCUMENT_CARTA_SERVEIS, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_SAUV)
      }
    }
    this.consentimientoIngreso = {
      documentId: this.detalleSolSauv.documentFullConsentimentIngres ?
        this.detalleSolSauv.documentFullConsentimentIngres.documentacioEntitatId
        : null,
      justificacio: this.detalleSolSauv.documentFullConsentimentIngres ?
        this.detalleSolSauv.documentFullConsentimentIngres.justificacio
        : null,
      dataPostDocument: {
        ...this.detalleSolSauv.documentFullConsentimentIngres,
        tipusDocumentDid: TIPUS_DOCUMENT_CONSENTIMENT_INGRES,
        tipusEntitatDid: TIPUS_ENTIDAD_RECURS,
        entitatId: ""+this.detalleSolSauv.sollicitudId,
        titolDocument: this.dictionaryQuery.getItemDictionaryByKey(TIPUS_DOCUMENT_CONSENTIMENT_INGRES, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_SAUV),
        tipusDocumentDidForm: this.dictionaryQuery.getAllItemDictionaryByKey(TIPUS_DOCUMENT_CONSENTIMENT_INGRES, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_SAUV)
      }
    }
    this.informeMedico = {
      documentId: this.detalleSolSauv.documentInformeMedic ?
        this.detalleSolSauv.documentInformeMedic.documentacioEntitatId
        : null,
      justificacio: this.detalleSolSauv.documentInformeMedic ?
        this.detalleSolSauv.documentInformeMedic.justificacio
        : null,
      dataPostDocument: {
        ...this.detalleSolSauv.documentInformeMedic,
        tipusDocumentDid: TIPUS_DOCUMENT_INFORME_MEDIC,
        tipusEntitatDid: TIPUS_ENTIDAD_RECURS,
        entitatId: ""+this.detalleSolSauv.sollicitudId,
        titolDocument: this.dictionaryQuery.getItemDictionaryByKey(TIPUS_DOCUMENT_INFORME_MEDIC, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_SAUV),
        tipusDocumentDidForm: this.dictionaryQuery.getAllItemDictionaryByKey(TIPUS_DOCUMENT_INFORME_MEDIC, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_SAUV)
      }
    }
    this.sentenciaJudIncap = {
      documentId: this.detalleSolSauv.documentSentenciaJudicialIncapacitacio ?
        this.detalleSolSauv.documentSentenciaJudicialIncapacitacio.documentacioEntitatId
        : null,
      justificacio: this.detalleSolSauv.documentSentenciaJudicialIncapacitacio ?
        this.detalleSolSauv.documentSentenciaJudicialIncapacitacio.justificacio
        : null,
      dataPostDocument: {
        ...this.detalleSolSauv.documentSentenciaJudicialIncapacitacio,
        tipusDocumentDid: TIPUS_DOCUMENT_SENTENCIA_JUD_INC,
        tipusEntitatDid: TIPUS_ENTIDAD_RECURS,
        entitatId: ""+this.detalleSolSauv.sollicitudId,
        titolDocument: this.dictionaryQuery.getItemDictionaryByKey(TIPUS_DOCUMENT_SENTENCIA_JUD_INC, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_SAUV),
        tipusDocumentDidForm: this.dictionaryQuery.getAllItemDictionaryByKey(TIPUS_DOCUMENT_SENTENCIA_JUD_INC, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_SAUV)
      }
    }
    this.sentenciaJudAutIn = {
      documentId: this.detalleSolSauv.documentSentenciaJudicialAutoritzacio ?
        this.detalleSolSauv.documentSentenciaJudicialAutoritzacio.documentacioEntitatId
        : null,
      justificacio: this.detalleSolSauv.documentSentenciaJudicialAutoritzacio ?
        this.detalleSolSauv.documentSentenciaJudicialAutoritzacio.justificacio
        : null,
      dataPostDocument: {
        ...this.detalleSolSauv.documentSentenciaJudicialAutoritzacio,
        tipusDocumentDid: TIPUS_DOCUMENT_SENTENCIA_JUD_AUT,
        tipusEntitatDid: TIPUS_ENTIDAD_RECURS,
        entitatId: ""+this.detalleSolSauv.sollicitudId,
        titolDocument: this.dictionaryQuery.getItemDictionaryByKey(TIPUS_DOCUMENT_SENTENCIA_JUD_AUT, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_SAUV),
        tipusDocumentDidForm: this.dictionaryQuery.getAllItemDictionaryByKey(TIPUS_DOCUMENT_SENTENCIA_JUD_AUT, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_SAUV)
      }
    }
  }


}
