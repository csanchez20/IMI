import { Component, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';

@Component({
  selector: 'app-dialog-llistat-usuaris-sias',
  templateUrl: './dialog-llistat-usuaris-sias.component.html',
  styleUrls: ['./dialog-llistat-usuaris-sias.component.scss']
})
export class DialogLlistatUsuarisSiasComponent implements OnInit {

   // TODO tipus objecte
  // Contingut del dialeg
  usuaris;

  // Columnes de la taula
  cols: any[];

  // Persona seleccionada del pop up
  seleccionat: boolean = false;

  // Persona per ser retornada del dialog
  persona;

  constructor(
    public config: DynamicDialogConfig,
    private ref: DynamicDialogRef,
    private i18n: I18n
  ) { }

  ngOnInit() {
    this.obtenirDades();
    this.inicialitzarDades();
  }


  /**
   * Mètode per a rebre les dades necessàries
   */
  obtenirDades() {
    this.usuaris = this.config.data.usuaris;
  }

  inicialitzarDades() {
    this.cols = [
      { field: '', header: '', class: 'columna-icona' },
      { field: 'expedientId', header: this.i18n({ id: ' ', value: 'Nº Expedient' }) },
      { field: 'nom', header: this.i18n({ id: ' ', value: 'Nom' }) },
      { field: 'cognom1', header: this.i18n({ id: ' ', value: 'Primer cognom' }) },
      { field: 'cognom2', header: this.i18n({ id: ' ', value: 'Segon cognom' }) },
      { field: 'document', header: this.i18n({ id: ' ', value: 'Document identificatiu' }) },
      { field: 'telefon', header: this.i18n({ id: ' ', value: 'Telefon' }) },
      { field: 'dataNaixement', header: this.i18n({ id: ' ', value: 'Data de naixement' }), data: true },
    ];
  }

  seleccionarPersona(data) {
    this.seleccionat = true;
    this.persona = data;
  }

  /*
  *Cancel.lar la seleccio de persones
  */
  cancelar() {
    this.ref.close('cancelar');
  }

  /**
   * Mètode per a tancar la modal del test
   */
  tancarModal() {
    this.ref.close(this.persona);
  }

}
