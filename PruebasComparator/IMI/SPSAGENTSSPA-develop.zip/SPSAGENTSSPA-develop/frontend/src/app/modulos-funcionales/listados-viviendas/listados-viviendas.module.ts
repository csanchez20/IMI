import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { SharedModule } from '@app/shared/shared.module';
import { ButtonModule, DropdownModule, MessagesModule } from 'primeng/primeng';
import { AppliedFiltersModule, RangeDatePickerModule } from '../../../../projects/spscompspa/src/public_api';
import { FiltroListadoViviendasComponent } from './filtro-listado-viviendas/filtro-listado-viviendas.component';
import { ListadosViviendasRoutingModule } from './listados-viviendas-routing.module';
import { ListadosViviendasComponent } from './listados-viviendas.component';


@NgModule({
  declarations: [ListadosViviendasComponent, FiltroListadoViviendasComponent],
  imports: [
    CommonModule,
    ListadosViviendasRoutingModule,
    DatatableListModule,
    ButtonModule,
    AppliedFiltersModule,
    ReactiveFormsModule,
    DropdownModule,
    SharedModule,
    RangeDatePickerModule,
    MessagesModule
  ],
  exports: [ListadosViviendasComponent]
})
export class ListadosViviendasModule { }
