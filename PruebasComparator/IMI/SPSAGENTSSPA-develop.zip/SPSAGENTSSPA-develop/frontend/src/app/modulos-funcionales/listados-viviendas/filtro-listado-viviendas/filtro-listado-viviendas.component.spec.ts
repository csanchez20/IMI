import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroListadoViviendasComponent } from './filtro-listado-viviendas.component';

describe('FiltroListadoViviendasComponent', () => {
  let component: FiltroListadoViviendasComponent;
  let fixture: ComponentFixture<FiltroListadoViviendasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiltroListadoViviendasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltroListadoViviendasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
