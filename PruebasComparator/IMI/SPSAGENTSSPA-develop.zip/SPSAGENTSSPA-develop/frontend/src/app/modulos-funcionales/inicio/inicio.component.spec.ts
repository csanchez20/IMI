/* import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InicioEquipamentsComponent } from './inicio.component';
import { PanelModule } from 'primeng/panel';
import { ButtonModule } from 'primeng/button';
import { DropdownModule, CardModule, TabMenuModule, CheckboxModule, DialogModule } from 'primeng/primeng';
import { TableModule } from 'primeng/table';
import { RouterTestingModule } from '@angular/router/testing';
import { InicioGuardamueblesService } from '@app/servicios/equipaments/guardamuebles';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('InicioEquipamentsComponent', () => {
  let component: InicioEquipamentsComponent;
  let fixture: ComponentFixture<InicioEquipamentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        InicioEquipamentsComponent
      ],
      imports: [
        BrowserAnimationsModule,
        PanelModule,
        ButtonModule,
        DropdownModule,
        CardModule,
        TabMenuModule,
        TableModule,
        CheckboxModule,
        DialogModule,
        RouterTestingModule,
        HttpClientTestingModule
      ],
      providers: [
        InicioGuardamueblesService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InicioEquipamentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
 */