import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionQuery } from '@app/core/auth';
import { DiccionarioKey, DictionaryQuery, DictionaryService } from '@app/core/dictionary/state';
import { HttpStatusService } from '@app/core/interceptors';
import { InfoItem, TableData } from '@app/core/model/information';
import { SolicitudesService } from '@app/servicios';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { EMPTY, forkJoin, Subscription, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { CercaSauvRDTO, FiltersPaginacion, ServiciosIMI } from '@app/core/model';
import { FormatterService } from '@app/core/services/formatter.service';
import { PlazasService } from '@app/servicios/solicitudes/plazas.service';
import moment from 'moment';
import { Message } from 'primeng/api';
import { ROLE_PROF_AT, ROLE_TREB_PROV } from '@app/core/auth/model';

@AutoUnsubscribe()
@Component({
  selector: 'app-listado-solicitudes',
  templateUrl: './listado-solicitudes.component.html',
  styleUrls: ['./listado-solicitudes.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ListadoSolicitudesComponent implements OnInit, OnDestroy {
  dictionaryEstadosSol: any;
  infoSolicitudes: InfoItem[];
  dataSolicitudes: TableData;
  showFilters = false;
  
  estados_key;
  diccionarioKey = DiccionarioKey;
  isServiceSAUV = this.sessionQuery.isServiceSAUV();
  isServiceRespirPlus = this.sessionQuery.isServiceRespirPlus();
  isServiceRespir = this.sessionQuery.isServiceRespir();

  tableButtons: InfoItem[] = [
    { 
      action: 'export', 
      label: 
        moment(new Date()).format('DD/MM/YYYY') 
        + '_Llistat_sollicituds'
    },
    { 
      label: this.i18n({ id: 'nuevaSollicitud', value: 'Nova sol·licitud' }), 
      action: 'add',
      show: this._showButtonNovaSollicitud()
    }

  ];

  filtersApplied: any = {};
  msgs: Message[];
  
  private sub: Subscription;
  private sub2: Subscription;
  private sub3: Subscription;
  private sub4: Subscription;
  private sub5: Subscription;
  private sub6: Subscription;
  constructor(
    public router: Router,
    public route: ActivatedRoute,
    private solicitudService: SolicitudesService,
    private i18n: I18n,
    public sessionQuery: SessionQuery,
    public dictionaryQuery: DictionaryQuery,
    private dictionaryService: DictionaryService,
    private httpStatusService: HttpStatusService,
    private cd: ChangeDetectorRef,
    private formatterService: FormatterService,
    private plazasService: PlazasService
  ) {}

  ngOnInit(): void {
    this._resetFilters();
    if (this.isServiceSAUV) {
      this.sub6 = this.plazasService.getPlazasLite().subscribe(() => {
        this.sub2 = forkJoin([
          this.dictionaryService.getEstadosSolicitud_SAUV(),
          this.dictionaryService.getCentrosSalut()
        ]).subscribe();
      })
      this.estados_key = this.diccionarioKey.ESTADOS_SOLICITUD_SAUV;
    } else if (this.isServiceRespir) {
      this.sub3 = this.dictionaryService
        .getEstadosSolicitud_RESPIR()
        .subscribe();
      this.sub4 = this.dictionaryService
        .getEstadosSolicitud_RESPIRPLUS()
        .subscribe();
      this.estados_key = this.diccionarioKey.ESTADOS_SOLICITUD_RESPIR;
    } else if (this.isServiceRespirPlus) {
      this.router.navigate([
        '/sol·licituds/nueva/'
      ]);
    }

    this.infoSolicitudes = [
      {
        field: 'nom',
        header: this.i18n({ id: 'nombreUsuario', value: 'Nom usuari' })
      },
      {
        field: 'dataCreacio',
        header: this.i18n({ id: 'fechaCreacion', value: 'Data creació' }),
        type: 'timestamp'
      },
      {
        field: 'estatSollicitud',
        header: this.i18n({ id: 'estado', value: 'Estat' }),
        type: 'dictionary',
        typeKey: this.estados_key
      },
      {
        field: 'centreNom',
        header: this.i18n({ id: 'centro', value: 'Centre' }),
        show: this.isServiceSAUV
      },
      {
        field: 'periodeConcedit',
        header: this.i18n({ id: 'periodo', value: 'Període' }),
        type: 'periodDates',
        show: this.isServiceRespir
      },
      {
        field: 'periodeSollicitat',
        header: this.i18n({ id: 'numDias', value: 'Número de dies' }),
        show: this.isServiceRespirPlus
      }
    ];

    this._saveSolicitudesToTable(null);
  }

  getSolicitudes(params) {
    this._setLoading(true);
    this.sub = this.solicitudService
      .getSolicitudes(params)
      .pipe(
        catchError(err => {
          this._setLoading(false);
          if (err.status === 404) {
            this._saveSolicitudesToTable({ content: [] });
            this.cd.markForCheck();
            return EMPTY;
          } else if(err.status === 400) {
            this._setError(err.message)
            this.cd.markForCheck();
            return of();
          } else {
            this.httpStatusService.validationErrors = err;
          }
        }),
        map(solicitudes => {
          this._saveSolicitudesToTable(solicitudes);
          this.cd.markForCheck();
        })
      )
      .subscribe(() => {});
  }

  _saveSolicitudesToTable(solicitudes: any) {
    this.httpStatusService.loading = false; //  Evitar la carga loading, forzarlo debido al lazy-af
    let solicitudesMapeadas;
    if (solicitudes && solicitudes.content) {
      solicitudesMapeadas = solicitudes.content.map(solicitud => {
        return {
          ...solicitud,
          nom: solicitud.cognom2 ? 
            solicitud.nom + ' ' + solicitud.cognom1 + ' ' + solicitud.cognom2 :
            solicitud.nom + ' ' + solicitud.cognom1,
          centreNom: this.formatterService.getCentroDescr(solicitud.centreCss)     
        };
      });
    }
    this.dataSolicitudes = {
      rows: solicitudesMapeadas ? solicitudesMapeadas : null,
      cols: this.infoSolicitudes,
      numeroTotalResultados: solicitudes ? solicitudes.total : null,
      numRowsPerPage: solicitudes ? solicitudes.pageSize : null,
      loading: false
    };
  }

  handleSelectedRow(event) {
    this.router.navigate([event.data.sollicitudId], { relativeTo: this.route });
  }

  searchByIndex(value: string) {
    this._clearMsgs();
    if (value.length >= 3) {
      this._resetFilters();
      this.getSolicitudes(
        this.setParams({
          campGoogle: value ? value.toLocaleUpperCase() : ''
        })
      );
    } else {
      this.msgs = [
        {
          severity: 'error', 
          detail: this.i18n({ 
            id: 'minimo3Caracteres', 
            value: 'El filtre ha de tenir tres caràcters o més' 
          }),
          summary: this.i18n({
            id: 'atencion',
            value: 'ATENCIÓ'
          })
        }
      ];
    }
  }

  handleFilters(data) {
    this._resetFilters();
    this.getSolicitudes(this.setParams(data));
  }


  paginator(event) {
    this.dataSolicitudes.numRowsPerPage = event.tamanyPagina;
    this.getSolicitudes(this.setParams(event));
  }

  onLazyLoad(event) {
    if (event && event.tamanyPagina) {
      this.getSolicitudes({
        ...this.setParams(event)
      });
    }
  }
  
  nuevaSolicitud() {
    this.router.navigate(['nueva'], { relativeTo: this.route });
  }

  setParams(params: CercaSauvRDTO) {
    this.filtersApplied = {
      ...this.filtersApplied,
      ...params
    }
    return this.filtersApplied;
  }

  private _resetFilters() {
    this.filtersApplied = {
      ...new FiltersPaginacion(
        this.filtersApplied.tamanyPagina
      )
    }
  }

  private _setLoading(loading: boolean) {
    this.dataSolicitudes = {
      ...this.dataSolicitudes,
      loading: loading,
      rows: null
    }
  }

  private _clearMsgs() {
    this.msgs = [];
  }

  private _setError(error: string) {
    this.dataSolicitudes = {
      ...this.dataSolicitudes,
      loading: false,
      rows: null,
      error: [
        {
          severity: 'error', 
          detail: error,
          summary: this.i18n({
            id: 'atencion',
            value: 'ATENCIÓ'
          }),
          closable: false
        }
      ]
    }
  }

  private _showButtonNovaSollicitud(): boolean {
    return !(this.sessionQuery.isServiceWithProfAtencio() 
      && this.sessionQuery.isUserRoleById(ROLE_TREB_PROV));
  }

  ngOnDestroy() {}
}
