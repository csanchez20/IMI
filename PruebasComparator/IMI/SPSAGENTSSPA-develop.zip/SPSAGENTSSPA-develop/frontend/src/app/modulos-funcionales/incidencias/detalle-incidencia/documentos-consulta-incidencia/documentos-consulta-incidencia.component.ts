import { Component, Input, OnInit } from '@angular/core';
import { DataDocumentacionEntidad } from '@app/shared/agrupaciones/documentacion-general/documentacion-general.component';

@Component({
  selector: 'app-documentos-consulta-incidencia',
  templateUrl: './documentos-consulta-incidencia.component.html',
  styleUrls: ['./documentos-consulta-incidencia.component.scss']
})
export class DocumentosConsultaIncidenciaComponent implements OnInit {

  @Input() dataDocEntidad: DataDocumentacionEntidad;

  constructor() { }

  ngOnInit() {
  }

}
