import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { DiccionarioKey, DictionaryQuery, DictionaryService } from '@app/core/dictionary/state';
import { ResultatConsultaSauvRDTO } from '@app/core/model/solicitudes/solicitud-SAUV';
import { SelectItem } from 'primeng/api';
import { forkJoin, Observable } from 'rxjs';

@Component({
  selector: 'app-situacion-urgencia',
  templateUrl: './situacion-urgencia.component.html',
  styleUrls: ['./situacion-urgencia.component.scss']
})
export class SituacionUrgenciaComponent implements OnInit {

  @Input() datosBasicosSolicitud: ResultatConsultaSauvRDTO;
  
  diccionarioKey = DiccionarioKey;

  results$: Observable<any>;
  loadedResults = false;

  onEsTrobaUsuariDiccionaris: SelectItem[] = [];

  constructor(
    public dictionaryQuery: DictionaryQuery,
    private dictionaryService: DictionaryService,
    private cd: ChangeDetectorRef
  ) { }

  ngOnInit() { 
    // Obtener diccionarios necesarios
    this.results$ = forkJoin([
      this.dictionaryService.getHechoPrecipitanteSituaUrgencia(),
      this.dictionaryService.getMotivoDemandaSituaUrgencia(),
      this.dictionaryService.getQuienPlanteaSituaUrgencia(),
      this.dictionaryService.getSanitarioAtieneSituaUrgencia(),
      this.dictionaryService.getUbicacionUsuarioSituaUrgenciaSalut(),
      this.dictionaryService.getUbicacionUsuarioSituaUrgenciaDomicili(),
      this.dictionaryService.getPerfilUsuarioSituaUrgencia()
    ]);

    this.results$.subscribe(() => {
      this.loadedResults = true;
      this.onEsTrobaUsuariDiccionaris = [
        ...this.dictionaryQuery.getDictionaryKey(this.diccionarioKey.ON_TROVA_USUARI_DOMICILI),
        ...this.dictionaryQuery.getDictionaryKey(this.diccionarioKey.ON_TROVA_USUARI_SALUT)
      ];
      this.cd.markForCheck();
    });
  }

  translateOnEsTrobaUsuari(onEsTrobaUsuariDid: number): string {
    const _traduccio = this.onEsTrobaUsuariDiccionaris.find(val => val.value === onEsTrobaUsuariDid);
    if (_traduccio) {      
      return _traduccio.label;
    } else {
      return 'No s\'ha trobat';
    }
  }

}
