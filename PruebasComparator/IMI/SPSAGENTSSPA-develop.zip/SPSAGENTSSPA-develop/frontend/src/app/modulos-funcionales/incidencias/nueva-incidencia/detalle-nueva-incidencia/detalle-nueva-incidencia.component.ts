import { Component, OnInit, Input } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';
import { FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-detalle-nueva-incidencia',
  templateUrl: './detalle-nueva-incidencia.component.html',
  styleUrls: ['./detalle-nueva-incidencia.component.scss']
})
export class DetalleNuevaIncidenciaComponent implements OnInit {

  @Input() form: FormGroup;
  @Input() optTipoIncidencias: SelectItem[];

  validators = Validators.required;
  diccionarioKey = DiccionarioKey;

  constructor(
    public dictionaryQuery: DictionaryQuery
  ) { }

  ngOnInit() {

  }

}
