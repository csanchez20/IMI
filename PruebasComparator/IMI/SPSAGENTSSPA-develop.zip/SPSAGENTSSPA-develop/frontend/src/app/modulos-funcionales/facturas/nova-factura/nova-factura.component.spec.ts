import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NovaFacturaComponent } from './nova-factura.component';

describe('NovaFacturaComponent', () => {
  let component: NovaFacturaComponent;
  let fixture: ComponentFixture<NovaFacturaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NovaFacturaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NovaFacturaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
