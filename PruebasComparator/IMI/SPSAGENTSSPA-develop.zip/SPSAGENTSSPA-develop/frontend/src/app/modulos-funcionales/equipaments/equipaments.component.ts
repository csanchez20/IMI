import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DadesCentreUsuari, SessionQuery, SessionService, UbicacionUI } from '@app/core/auth';
import { ParamListadoEquipament } from '@app/core/model';
import { EquipamentsService } from '@app/servicios';

@Component({
  selector: 'app-equipaments',
  templateUrl: './equipaments.component.html',
  styleUrls: ['./equipaments.component.scss']
})
export class EquipamentsComponent implements OnInit {

  loading = true;

  constructor(
    private sessionQuery: SessionQuery,
    private sessionService: SessionService,
    private router: Router,
    private route: ActivatedRoute,
    private equipamentService: EquipamentsService
  ) {}

  ngOnInit() {
    this._setUbicacionUI();
    const dadesCentreUsuari = this.sessionQuery.getDadesCentreUsuari();
    if (dadesCentreUsuari) {
      this._findDataEquipament(dadesCentreUsuari);
    } else {
      this.loading = false;
    }
  }

  get isLoading() {
    return this.loading;
  }

  private _setUbicacionUI() {
    this.sessionService.setUbicacionUI(UbicacionUI.EQUIPAMENTS);
  }

  private _findDataEquipament(dadesCentreUsuari: DadesCentreUsuari) {
    let params: ParamListadoEquipament = {
      ...new ParamListadoEquipament(
        this.sessionQuery.getServiceActiveValue()
      ),
      codiEquipament: dadesCentreUsuari.codiReferencia
    }
    this.equipamentService.getEquipaments(params).subscribe(res => {
      if (res && res.content.length === 1) {
        this.router.navigate([dadesCentreUsuari.centreId], { relativeTo: this.route, state: {empresa: res.content[0].nomEmpresa}});
      }
    })
  }

}
