import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentosConsultaIncidenciaComponent } from './documentos-consulta-incidencia.component';

describe('DocumentosConsultaIncidenciaComponent', () => {
  let component: DocumentosConsultaIncidenciaComponent;
  let fixture: ComponentFixture<DocumentosConsultaIncidenciaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentosConsultaIncidenciaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentosConsultaIncidenciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
