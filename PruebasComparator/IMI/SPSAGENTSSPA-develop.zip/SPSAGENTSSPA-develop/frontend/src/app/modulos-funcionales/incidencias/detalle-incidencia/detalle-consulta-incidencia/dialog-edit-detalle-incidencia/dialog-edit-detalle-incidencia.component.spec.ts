import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogEditDetalleIncidenciaComponent } from './dialog-edit-detalle-incidencia.component';

describe('DialogEditDetalleIncidenciaComponent', () => {
  let component: DialogEditDetalleIncidenciaComponent;
  let fixture: ComponentFixture<DialogEditDetalleIncidenciaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogEditDetalleIncidenciaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogEditDetalleIncidenciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
