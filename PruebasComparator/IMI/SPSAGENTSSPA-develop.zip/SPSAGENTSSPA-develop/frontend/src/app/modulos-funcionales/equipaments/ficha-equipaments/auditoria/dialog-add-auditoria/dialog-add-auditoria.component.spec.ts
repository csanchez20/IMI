import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogAddAuditoriaComponent } from './dialog-add-auditoria.component';

describe('DialogAddAuditoriaComponent', () => {
  let component: DialogAddAuditoriaComponent;
  let fixture: ComponentFixture<DialogAddAuditoriaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogAddAuditoriaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogAddAuditoriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
