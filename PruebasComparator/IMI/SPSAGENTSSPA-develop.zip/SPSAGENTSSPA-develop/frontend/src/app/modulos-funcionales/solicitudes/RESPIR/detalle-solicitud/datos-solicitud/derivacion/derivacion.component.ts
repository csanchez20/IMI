import { Component, OnInit, Input, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Derivacion } from '@app/core/model/solicitudes';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { ResultatConsultaRespirRDTO } from '@app/core/model/solicitudes/solicitud-RESPIR';
import { DictionaryService, DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';

@AutoUnsubscribe()
@Component({
  selector: 'app-derivacion',
  templateUrl: './derivacion.component.html',
  styleUrls: ['./derivacion.component.scss']
})
export class DerivacionComponent implements OnInit, OnDestroy {

  @Input() detalleSolRESPIR: ResultatConsultaRespirRDTO;

  diccionarioKey = DiccionarioKey;

  loadedResults = false;

  constructor(
    public dictionaryQuery: DictionaryQuery,
    private dictionaryService: DictionaryService,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.dictionaryService.getMotivosDemandaSolRespir().subscribe( () => {
      this.loadedResults = true;
      this.cd.markForCheck();
    })
  }

  ngOnDestroy() {}

}
