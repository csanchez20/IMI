import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ListadoIncidenciasService } from '@app/servicios/incidencias/listado-incidencias.service';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { HttpStatusService } from '@app/core/interceptors';
import { Message } from 'primeng/api';
import { Router, ActivatedRoute } from '@angular/router';
import { SessionService, IncidenciaType, SessionQuery } from '@app/core/auth';
import { CercaIncidenciesRDTO, ParamsCercaIncidencies } from '@app/core/model';
import { DiccionarioKey } from '@app/core/dictionary/state';
import { TIPO_INCIDENCIA_USUARIO, IncidenciasService, PaginacionIncidencias } from '@app/servicios/incidencias/incidencias.service';

@Component({
  selector: 'app-listado-incidencias-usuario',
  templateUrl: './listado-incidencias-usuario.component.html',
  styleUrls: ['./listado-incidencias-usuario.component.scss']
})
export class ListadoIncidenciasUsuarioComponent extends ListadoIncidenciasService {

  msgs: Message[];

  tipoIncidenciasKey = DiccionarioKey.TIPO_INCIDENCIAS_USUARIO;
  tipusEntitatDid = TIPO_INCIDENCIA_USUARIO;

  constructor(
    i18n: I18n,
    cd: ChangeDetectorRef,
    incidenciasService: IncidenciasService,
    httpStatusService: HttpStatusService,
    router: Router,
    route: ActivatedRoute,
    sessionQuery: SessionQuery,
    private sessionService: SessionService
  ) {
    super(i18n, cd, incidenciasService, httpStatusService, router, route, sessionQuery);
  }

  protected _saveIncidenciasToTable(incidencias: PaginacionIncidencias) {
    this.httpStatusService.loading = false; //  Evitar la carga loading, forzarlo debido al lazy-af
    let incidenciasMapeadas;
    if (incidencias && incidencias.llistaIncidenciaCercadesTotalRDTO) {
      incidenciasMapeadas = incidencias.llistaIncidenciaCercadesTotalRDTO.map(incidencia => {
        return {
          ...incidencia,
          nomEntitatPrimaria: incidencia.cogNom2 ? 
            incidencia.nom + ' ' + incidencia.cogNom1 + ' ' + incidencia.cogNom2 :
            incidencia.nom + ' ' + incidencia.cogNom1    
        };
      });
    }
    this.dataIncidencias = {
      rows: incidenciasMapeadas ? incidenciasMapeadas : null,
      cols: this.colsIncidencias,
      numeroTotalResultados: incidencias ? incidencias.totalRegistres : null,
      numRowsPerPage: this.numRows,
      loading: false
    };
  }

  searchByIndex(value: string) {
    this._clearMsgs();
    if (value.length >= 3) {
      this._resetFilters();
      this.getIncidencias(
        this.setParams({
          campGoogle: value ? value.toLocaleUpperCase() : ''
        })
      );
    } else {
      this.msgs = [
        {
          severity: 'error', 
          detail: this.i18n({ 
            id: 'minimo3Caracteres', 
            value: 'El filtre ha de tenir tres caràcters o més' 
          }),
          summary: this.i18n({
            id: 'atencion',
            value: 'ATENCIÓ'
          })
        }
      ];
    }
  }

  handleFiltersIncidencias(data: ParamsCercaIncidencies) {
    this.handleFilters(data);
  }

  nuevaIncidenciaUsuario() {
    this._setIncidenciaType();
    this.nuevaIncidencia();
  }

  handleSelectedRowUsuario(incidencia: CercaIncidenciesRDTO) {
    this._setIncidenciaType();
    this.handleSelectedRow(incidencia);
  }

  private _setIncidenciaType() {
    this.sessionService.setIncidenciaType(IncidenciaType.USUARIO);
  }

  private _clearMsgs() {
    this.msgs = [];
  }


}
