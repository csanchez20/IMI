import { Component, OnInit, ChangeDetectorRef, Output, EventEmitter, OnDestroy } from '@angular/core';
import { Message, DialogService } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { UsuarioLiteFiltros, UsuarioLite } from '@app/core/model';
import { Subscription } from 'rxjs';
import { DialogCercaUsuarioComponent } from '../dialog-cerca-usuario/dialog-cerca-usuario.component';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { SessionQuery } from '@app/core/auth';

@AutoUnsubscribe()
@Component({
  selector: 'app-cabecera-usuario-nueva-incidencia',
  templateUrl: './cabecera-usuario-nueva-incidencia.component.html',
  styleUrls: ['./cabecera-usuario-nueva-incidencia.component.scss']
})
export class CabeceraUsuarioNuevaIncidenciaComponent implements OnInit, OnDestroy {

  @Output() usuarioSelectedEmitter: EventEmitter<UsuarioLite> = new EventEmitter<UsuarioLite>();
  
  msgs: Message[];
  usuarioSelected: UsuarioLite;

  private sub: Subscription;
  
  constructor(
    private i18n: I18n,
    private cd: ChangeDetectorRef,
    private dialogService: DialogService,
    private sessionQuery: SessionQuery
  ) { }

  ngOnInit() {}

  openDialog(params: UsuarioLiteFiltros) {
    const ref = this.dialogService.open(
      DialogCercaUsuarioComponent,
      {
        data: params,
        header: this.i18n({
          id: 'seleccionarUsuario',
          value: 'Seleccionar usuari'
        }),
        width: '50%'
      }
    );

    this.sub = ref.onClose.subscribe(data => {
      if (data) {
        this.usuarioSelected = data;
        this.usuarioSelectedEmitter.emit(this.usuarioSelected);
        this.cd.markForCheck();
      }
    });
  }

  searchByIndex(value: string) {
    this._clearMsgs();
    if (value.length >= 3) {
      let params: UsuarioLiteFiltros;
      const dadesCentreUsuari = this.sessionQuery.getDadesCentreUsuari();
      if (dadesCentreUsuari) {
        params = {
          campGoogle: value.toLocaleUpperCase(),
          centre: dadesCentreUsuari.centreId
        }
      } else {
        params = {
          campGoogle: value.toLocaleUpperCase()
        }
      }
      
      this.openDialog(params);
    } else {
      this.msgs = [
        {
          severity: 'error', 
          detail: this.i18n({ 
            id: 'minimo3Caracteres', 
            value: 'El filtre ha de tenir tres caràcters o més' 
          }),
          summary: this.i18n({
            id: 'atencion',
            value: 'ATENCIÓ'
          })
        }
      ];
    }
  }
  
  private _clearMsgs() {
    this.msgs = [];
  }

  ngOnDestroy() {}

}
