import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleNuevaIncidenciaComponent } from './detalle-nueva-incidencia.component';

describe('DetalleNuevaIncidenciaComponent', () => {
  let component: DetalleNuevaIncidenciaComponent;
  let fixture: ComponentFixture<DetalleNuevaIncidenciaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalleNuevaIncidenciaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalleNuevaIncidenciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
