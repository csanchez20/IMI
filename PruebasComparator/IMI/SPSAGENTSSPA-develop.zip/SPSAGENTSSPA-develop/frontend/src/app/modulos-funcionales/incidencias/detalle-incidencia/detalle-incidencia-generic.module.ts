import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DetalleIncidenciaGenericComponent } from './detalle-incidencia-generic.component';
import { LazyModule } from '@herodevs/lazy-af';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', component: DetalleIncidenciaGenericComponent }
];

@NgModule({
  declarations: [DetalleIncidenciaGenericComponent],
  imports: [
    CommonModule,
    LazyModule,
    RouterModule.forChild(routes)
  ],
  bootstrap: [DetalleIncidenciaGenericComponent]
})
export class DetalleIncidenciaGenericModule { }
