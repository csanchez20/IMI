import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuditoriaComponent } from './auditoria.component';
import { DialogAddAuditoriaComponent } from './dialog-add-auditoria/dialog-add-auditoria.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { DynamicDialogModule } from 'primeng/components/dynamicdialog/dynamicdialog';
import { DropdownModule, FileUploadModule, CalendarModule, ButtonModule, InputTextareaModule, InputTextModule, MessageModule } from 'primeng/primeng';
import { SharedModule } from '@app/shared/shared.module';
import { DialogDetalleAuditoriaComponent } from './dialog-detalle-auditoria/dialog-detalle-auditoria.component';
import { MomentModule } from 'ngx-moment';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { BotonMultifuncionGestionDocumentosModule } from '@app/shared/agrupaciones/boton-multifuncion-gestion-documentos/boton-multifuncion-gestion-documentos.module';

@NgModule({
  declarations: [
    AuditoriaComponent,
    DialogAddAuditoriaComponent,
    DialogDetalleAuditoriaComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DialogModule,
    DynamicDialogModule,
    DropdownModule,
    FileUploadModule,
    InputTextModule,
    InputTextareaModule,
    CalendarModule,
    ButtonModule,
    MomentModule,
    DatatableListModule,
    SharedModule,
    MessageModule,
    BotonMultifuncionGestionDocumentosModule
  ],
  exports: [
    AuditoriaComponent,
    DialogAddAuditoriaComponent
  ],
  entryComponents: [
    DialogAddAuditoriaComponent,
    DialogDetalleAuditoriaComponent
  ]
})
export class AuditoriaModule { }
