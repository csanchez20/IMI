import { Component, OnInit, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { TableData, UsuarioLiteFiltros, InfoItem } from '@app/core/model';
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/api';
import { Subscription, of } from 'rxjs';
import { UsuariosService } from '@app/servicios';
import { catchError } from 'rxjs/operators';
import { HttpStatusService } from '@app/core/interceptors';
import { SessionQuery } from '@app/core/auth';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { UsuariosEquipamentsService } from '@app/servicios/usuarios/usuarios-equipaments.service';

@Component({
  selector: 'app-dialog-cerca-usuario',
  templateUrl: './dialog-cerca-usuario.component.html',
  styleUrls: ['./dialog-cerca-usuario.component.scss']
})
export class DialogCercaUsuarioComponent implements AfterViewInit {

  tableData: TableData
  filtersApplied: UsuarioLiteFiltros = {};
  info: InfoItem[] = [
    {
      field: 'nomComplet',
      header: this.i18n({ id: 'nomUsuari', value: 'Nom usuari' })
    },
    {
      field: 'expedientId',
      header: this.i18n({
        id: 'codigoExpedienteSIAS',
        value: 'Codi expedient SIAS'
      })
    },
    {
      field: 'document',
      header: this.i18n({ id: 'documento', value: 'Document' })
    }
  ];

  private sub: Subscription;

  constructor(
    private config: DynamicDialogConfig,
    private ref: DynamicDialogRef,
    private usuariosService: UsuariosService,
    private usuariosEquipamentsService: UsuariosEquipamentsService,
    private httpStatusService: HttpStatusService,
    private sessionQuery: SessionQuery,
    private cd: ChangeDetectorRef,
    private i18n: I18n
  ) { }

  ngAfterViewInit() {
    if (this.config.data) {      
      setTimeout(() => {
        this.filtersApplied = {
          ...this.config.data,
          servei: this.sessionQuery.getServiceActiveValue(),
          numeroPagina: 1,
          tamanyPagina: 5
        }
        this._getUsuariosLite(this.filtersApplied);
      });
    }
  }

  handleSelectedRow(event) {
    this.ref.close(event.data)
  }

  paginator(event) {
    this.tableData.numRowsPerPage = event.tamanyPagina;
    this._getUsuariosLite(this._setParams(event));
  }

  onLazyLoadUsers(event) {
    if (event && event.tamanyPagina) {
      this._getUsuariosLite({
        ...this._setParams(event)
      });
    }
  }

  private _setParams(params: UsuarioLiteFiltros) {
    this.filtersApplied = {
      ...this.filtersApplied,
      ...params
    };
    return this.filtersApplied;
  }

  private _getUsuariosLite(params: UsuarioLiteFiltros) {
    this._setLoading(true);
    this.sub = this.usuariosEquipamentsService
      .getUsuariosLite(params)
      .pipe(
        catchError(err => {
          this._setLoading(false);
          if (err.status === 404) {
            return of({
              content: [],
              total: 0
            });
          } else if(err.status === 400) {
            this._setError(err.message)
            this.cd.markForCheck();
            return of();
          } else {
            this.httpStatusService.validationErrors = err;
          }
        })
      )
      .subscribe(usuarios => {
        this._saveUsersToTable(usuarios);
        this.cd.markForCheck();
      });
  }

  private _saveUsersToTable(usuarios) {
    this.tableData = {
      rows: usuarios ? usuarios.content : null,
      cols: this.info,
      numeroTotalResultados: usuarios ? usuarios.total : 0,
      numRowsPerPage: usuarios ? usuarios.pageSize : null,
      loading: false
    };
    this.cd.markForCheck();
  }

  private _setLoading(loading: boolean) {
    this.tableData = {
      ...this.tableData,
      loading: loading,
      rows: null
    }
  }

  private _setError(error: string) {
    this.tableData = {
      ...this.tableData,
      loading: false,
      rows: null,
      error: [
        {
          severity: 'error', 
          detail: error,
          summary: this.i18n({
            id: 'atencion',
            value: 'ATENCIÓ'
          }),
          closable: false
        }
      ]
    }
  }


}
