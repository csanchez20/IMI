import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ListadoIncidenciasService } from '@app/servicios/incidencias/listado-incidencias.service';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { HttpStatusService } from '@app/core/interceptors';
import { Router, ActivatedRoute } from '@angular/router';
import { SessionService, IncidenciaType, SessionQuery } from '@app/core/auth';
import { Paginacion, CercaIncidenciesRDTO, ParamsCercaIncidencies } from '@app/core/model';
import { DiccionarioKey } from '@app/core/dictionary/state';
import { TIPO_INCIDENCIA_EQUIPAMENT, IncidenciasService, PaginacionIncidencias } from '@app/servicios/incidencias/incidencias.service';

@Component({
  selector: 'app-listado-incidencias-equipament',
  templateUrl: './listado-incidencias-equipament.component.html',
  styleUrls: ['./listado-incidencias-equipament.component.scss']
})
export class ListadoIncidenciasEquipamentComponent extends ListadoIncidenciasService {

  tipoIncidenciasKey = DiccionarioKey.TIPO_INCIDENCIAS_EQUIPAMENT;
  tipusEntitatDid = TIPO_INCIDENCIA_EQUIPAMENT;

  constructor(
    i18n: I18n,
    cd: ChangeDetectorRef,
    incidenciasService: IncidenciasService,
    httpStatusService: HttpStatusService,
    router: Router,
    route: ActivatedRoute,
    sessionQuery: SessionQuery,
    private sessionService: SessionService
  ) {
    super(i18n, cd, incidenciasService, httpStatusService, router, route, sessionQuery);
  }

  protected _saveIncidenciasToTable(incidencias: PaginacionIncidencias) {
    this.httpStatusService.loading = false; //  Evitar la carga loading, forzarlo debido al lazy-af
    let incidenciasMapeadas;
    if (incidencias && incidencias.llistaIncidenciaCercadesTotalRDTO) {
      incidenciasMapeadas = incidencias.llistaIncidenciaCercadesTotalRDTO.map(incidencia => {
        return {
          ...incidencia,
          nomEntitatPrimaria: incidencia.nomEquipament   
        };
      });
    }
    this.dataIncidencias = {
      rows: incidenciasMapeadas ? incidenciasMapeadas : null,
      cols: this.colsIncidencias,
      numeroTotalResultados: incidencias ? incidencias.totalRegistres : null,
      numRowsPerPage: this.numRows,
      loading: false
    };
  }

  handleFiltersIncidencias(data: ParamsCercaIncidencies) {
    this.handleFilters(data);
  }

  nuevaIncidenciaEquipament() {
    this._setIncidenciaType();
    this.nuevaIncidencia();
  }

  handleSelectedRowEquipament(incidencia: CercaIncidenciesRDTO) {
    this._setIncidenciaType();
    this.handleSelectedRow(incidencia);
  }

  private _setIncidenciaType() {
    this.sessionService.setIncidenciaType(IncidenciaType.EQUIPAMENT);
  }

}
