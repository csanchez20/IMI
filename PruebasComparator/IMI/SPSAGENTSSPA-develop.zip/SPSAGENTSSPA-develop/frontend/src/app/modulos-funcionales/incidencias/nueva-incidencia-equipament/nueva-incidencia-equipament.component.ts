import { Component, OnInit, OnDestroy } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';
import { SessionQuery } from '@app/core/auth';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AltaIncidencia, CentreggCercadesRDTO } from '@app/core/model';
import moment from 'moment';
import { Subscription } from 'rxjs';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { IncidenciasService, TIPO_INCIDENCIA_EQUIPAMENT } from '@app/servicios/incidencias/incidencias.service';

@AutoUnsubscribe()
@Component({
  selector: 'app-nueva-incidencia-equipament',
  templateUrl: './nueva-incidencia-equipament.component.html',
  styleUrls: ['./nueva-incidencia-equipament.component.scss']
})
export class NuevaIncidenciaEquipamentComponent implements OnInit, OnDestroy {

  isSubmitted = false;
  form: FormGroup;
  formDatosEquipa: FormGroup;
  optTipoIncidencias: SelectItem[];

  private sub: Subscription;

  constructor(
    private incidenciaService: IncidenciasService,
    private dictionaryQuery: DictionaryQuery,
    private sessionQuery: SessionQuery,
    private fb: FormBuilder,
    private router: Router
  ) { }

  ngOnInit() {
    this._initForm();
    this.optTipoIncidencias = this.dictionaryQuery.getDictionaryKey(DiccionarioKey.TIPO_INCIDENCIAS_EQUIPAMENT);
  }

  equipamentSelected(equipament: CentreggCercadesRDTO) {
    if (equipament !== null) {
      this.formDatosEquipa.get('entitatId').setValue(equipament.centreId);
      this.formDatosEquipa.get('nomProveidor').setValue(equipament.nomEmpresa);
    } else {
      this.formDatosEquipa.get('entitatId').reset();
      this.formDatosEquipa.get('nomProveidor').reset();
    }
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.form.valid && this.formDatosEquipa.valid) {
      this.sub = this.incidenciaService.postIncidencia(
        this._getIncidenciaMapped()
      ).subscribe(res => {
        this.router.navigate([
          '/incidencies/' + res.id
        ]);
      });
    }
  }

  private _initForm() {
    this.form = this.fb.group({
      gravetatIncidenciaDid: ['', Validators.required],
      dates: ['', Validators.required],
      descripcio: ['', Validators.required],
      tipusEntitatDid: [TIPO_INCIDENCIA_EQUIPAMENT, Validators.required],
      tipusRespostaDid: [this.sessionQuery.getServiceActiveValue(), Validators.required],
      tipusIncidenciaDid: ['', Validators.required],
      observacions: ['', Validators.required]
    });
    this.formDatosEquipa = this.fb.group({
      entitatId: ['', Validators.required],
      nomProveidor: ['', Validators.required]
    });
  }

  private _getIncidenciaMapped(): AltaIncidencia {
    const newIncidencia: AltaIncidencia = {
      ...this.form.value,
      ...this.formDatosEquipa.value,
      dataInici: moment(this.form.get('dates').value.start).valueOf(),
      dataFi: moment(this.form.get('dates').value.end).valueOf()
    }
    delete newIncidencia['dates'];
    return newIncidencia;
  }



  ngOnDestroy() {}

}
