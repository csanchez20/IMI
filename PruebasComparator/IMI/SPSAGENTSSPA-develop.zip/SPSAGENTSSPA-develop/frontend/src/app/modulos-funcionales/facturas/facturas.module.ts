import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FacturasRoutingModule } from './facturas-routing.module';
import { NovaFacturaComponent } from './nova-factura/nova-factura.component';
import { AltaFacturaComponent } from './alta-factura/alta-factura.component';
import { DialogRecursoNoActivoComponent } from './alta-factura/dialog-recurso-no-activo/dialog-recurso-no-activo.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DropdownModule, ButtonModule, DialogModule, DialogService, MessageModule, InputTextModule, PanelModule, CalendarModule, FileUploadModule } from 'primeng/primeng';
import { SharedModule } from '@app/shared/shared.module';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { BotonMultifuncionGestionDocumentosModule } from '@app/shared/agrupaciones/boton-multifuncion-gestion-documentos/boton-multifuncion-gestion-documentos.module';

@NgModule({
  declarations: [
    NovaFacturaComponent,
    AltaFacturaComponent,
    DialogRecursoNoActivoComponent
  ],
  imports: [
    CommonModule,
    FacturasRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    DropdownModule,
    ButtonModule,
    SharedModule,
    DynamicDialogModule,
    DialogModule,
    DatatableListModule,
    MessageModule,
    InputTextModule,
    PanelModule,
    CalendarModule,
    FileUploadModule,
    ButtonModule,
    BotonMultifuncionGestionDocumentosModule
  ],
  exports: [
    NovaFacturaComponent,
    AltaFacturaComponent,
    DialogRecursoNoActivoComponent
  ],
  entryComponents: [
    DialogRecursoNoActivoComponent
  ],
  providers: [
    DialogService
  ]
})
export class FacturasModule { }
