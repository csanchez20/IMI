import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ChangeDetectionStrategy
} from '@angular/core';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import {
  FileUpload,
  DynamicDialogRef,
  DynamicDialogConfig
} from 'primeng/primeng';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { SessionQuery } from '@app/core/auth';
import {
  AuditoriaRDTO,
  AuditoriaIdRDTO,
  TipoAuditoria,
  AltaDocumentRDTO,
  CrearDocumentGDSERequestDTO
} from '@app/core/model/equipaments';
import { Observable, of, Subject } from 'rxjs';
import { InfoItem } from '@app/core/model/information';
import { AuditoriaService } from '@app/servicios/equipaments/auditoria.service';
import moment from 'moment';
import { ButonGestionDocumental } from '@app/shared/agrupaciones/boton-multifuncion-gestion-documentos/boton-multifuncion-gestion-documentos.component';
import { DocumentacionCintraosService } from '@app/servicios/equipaments/documentacion-cintraos.service';
import { I18nConfigService } from '../../../../../../../projects/spscompspa/src/app/services';

interface AddEditAuditoriaParams {
  idEquipament: string;
  auditoria: AuditoriaRDTO;
}
@AutoUnsubscribe()
@Component({
  selector: 'app-dialog-add-auditoria',
  templateUrl: './dialog-add-auditoria.component.html',
  styleUrls: ['./dialog-add-auditoria.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DialogAddAuditoriaComponent implements OnInit, OnDestroy {
  params: AddEditAuditoriaParams;
  idEquipament: string;
  mode: 'edit' | 'add';
  form: FormGroup = this.fb.group({
    tipus: ['', Validators.required],
    dataAuditoria: [new Date(), Validators.required],
    comentaris: ['']
  });

  tipusAuditoria$: Observable<InfoItem[]> = of([
    { label: TipoAuditoria.INTERN, value: TipoAuditoria.INTERN },
    { label: TipoAuditoria.EXTERN, value: TipoAuditoria.EXTERN }
  ]);

  botonGestionDocumental: ButonGestionDocumental = {};
  documentFile: File = null;

  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private fb: FormBuilder,
    private auditoriaService: AuditoriaService,
    public i18nConfig: I18nConfigService,
    public sessionQuery: SessionQuery,
    private documentacionCintraosService: DocumentacionCintraosService
  ) {}

  ngOnInit() {
    this.params = this.config.data;
    this.idEquipament = this.params.idEquipament;

    this.mode = this.params.auditoria !== undefined ? 'edit' : 'add';
    if (this.isEditMode()) {
      const auditoria = this.params.auditoria;
      this.form.patchValue({
        tipus: auditoria.tipus,
        dataAuditoria: moment(auditoria.dataAuditoria).toDate(),
        comentaris: auditoria.comentaris,
        document: auditoria.document
      });
    } else {
      this._ompleDadesButonsDocumentsAdd();
    }
  }

  onSaveAuditoria(): void {
    this._emitButonsDocuments();
    this.isEditMode() ? this.onEditAuditoria() : this.onAddAuditoria();
  }

  private _ompleDadesButonsDocumentsAdd() {
    this.botonGestionDocumental = {
      documentId: null,
      returnEmitter: new Subject<void>()
    }
  }

  private _emitButonsDocuments() {
    if (this.emitterDocument) {
      this.botonGestionDocumental.returnEmitter.next();
    }
  }

  get emitterDocument() {
    return this.botonGestionDocumental
      && this.botonGestionDocumental.returnEmitter
        && this.botonGestionDocumental.returnEmitter.asObservable();
  }

  setDocument(document: AltaDocumentRDTO) {
    this.documentFile = document.document;
  }

  private onAddAuditoria() {
    let newAuditoria: AuditoriaRDTO = {
      ...this.form.value,
      centreId: this.idEquipament,
      idProfessionalDocument: this.sessionQuery.getUserLoggedId()
    };

    if (this.documentFile !== null) {
      this.documentacionCintraosService.postDocumentacio(this.documentFile).subscribe(res => {
        if (res && res['documentId']) {
          newAuditoria = {
            ...newAuditoria,
            document: res['documentId']
          }
          this._postAuditoria(newAuditoria)
        }
      });
    } else {
      this._postAuditoria(newAuditoria);
    } 
  }

  private _postAuditoria(auditoria: AuditoriaRDTO) {
    this.auditoriaService
      .postAuditoriaEquipament(auditoria)
      .subscribe((audRes: AuditoriaIdRDTO) => {
        this.ref.close({
          ...auditoria,
          id: audRes.auditoriaId
        });
    });
  }

  private onEditAuditoria() {
    const newAuditoria: AuditoriaRDTO = {
      ...this.form.value,
      idProfessionalDocument: this.sessionQuery.getUserLoggedId(),
      document: this.params.auditoria.document
    };
    this.auditoriaService
      .putAuditoriaEquipament(this.params.auditoria.id, newAuditoria)
      .subscribe(audRes => {
        this.ref.close({
          ...newAuditoria,
          id: audRes.auditoriaId
        });
      });
  }

  closeDialog() {
    this.ref.close();
  }

  private isEditMode(): boolean {
    return this.mode === 'edit';
  }

  ngOnDestroy() {}
}
