import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogDetalleAuditoriaComponent } from './dialog-detalle-auditoria.component';

describe('DialogDetalleAuditoriaComponent', () => {
  let component: DialogDetalleAuditoriaComponent;
  let fixture: ComponentFixture<DialogDetalleAuditoriaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogDetalleAuditoriaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogDetalleAuditoriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
