import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AyudaComponent } from './ayuda.component';
import { AyudaRoutingModule } from './ayuda-routing.module';
import { CardModule } from 'primeng/card';
import { PanelModule, TabViewModule } from 'primeng/primeng';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';

@NgModule({
  declarations: [AyudaComponent],
  imports: [
    CommonModule,
    CardModule,
    PanelModule,
    TabViewModule,
    DatatableListModule,
    AyudaRoutingModule
  ],
  exports: [AyudaComponent]
})
export class AyudaModule { }
