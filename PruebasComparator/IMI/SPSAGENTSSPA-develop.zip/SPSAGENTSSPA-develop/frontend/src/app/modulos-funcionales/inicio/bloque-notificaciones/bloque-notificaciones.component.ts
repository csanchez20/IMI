import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-bloque-notificaciones',
  templateUrl: './bloque-notificaciones.component.html',
  styleUrls: ['./bloque-notificaciones.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BloqueNotificacionesComponent implements OnInit {
  @Input() change : Observable<void>;
  constructor() // private router: Router,
  {}

  ngOnInit() {}

  /* verNotificaciones() {
    this.router.navigate(['/notificaciones/']);
  } */
}
