import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { PersonaRelacion } from '@app/core/model/usuarios';
import { ResultatConsultaRespirRDTO, RespirDadesCuidadorRDTO } from '@app/core/model/solicitudes/solicitud-RESPIR';

@AutoUnsubscribe()
@Component({
  selector: 'app-datos-cuidador',
  templateUrl: './datos-cuidador.component.html',
  styleUrls: ['./datos-cuidador.component.scss']
})
export class DatosCuidadorComponent implements OnInit, OnDestroy {

  @Input() cuidador: RespirDadesCuidadorRDTO;

  constructor() {}

  ngOnInit() {}

  ngOnDestroy() {}

}
