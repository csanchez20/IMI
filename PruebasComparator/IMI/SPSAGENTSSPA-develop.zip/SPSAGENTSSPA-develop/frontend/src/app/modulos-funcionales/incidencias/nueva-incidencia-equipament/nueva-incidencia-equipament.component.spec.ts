import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NuevaIncidenciaEquipamentComponent } from './nueva-incidencia-equipament.component';

describe('NuevaIncidenciaEquipamentComponent', () => {
  let component: NuevaIncidenciaEquipamentComponent;
  let fixture: ComponentFixture<NuevaIncidenciaEquipamentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NuevaIncidenciaEquipamentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NuevaIncidenciaEquipamentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
