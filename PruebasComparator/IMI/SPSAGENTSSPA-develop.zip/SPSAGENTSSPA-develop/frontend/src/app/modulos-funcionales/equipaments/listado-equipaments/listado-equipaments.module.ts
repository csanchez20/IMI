import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CalendarModule, DropdownModule, InputTextModule, ButtonModule, TabViewModule } from 'primeng/primeng';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { FiltroListadoEquipamentsComponent } from './filtro-listado-equipaments/filtro-listado-equipaments.component';
import { ListadoEquipamentsComponent } from './listado-equipaments.component';
import { SharedModule } from '@app/shared/shared.module';
import { CheckboxModule } from 'primeng/checkbox';
import { AppliedFiltersModule } from '../../../../../projects/spscompspa/src/public_api';

@NgModule({
  imports: [
    CommonModule,
    TableModule,
    ButtonModule,
    CalendarModule,
    DropdownModule,
    FormsModule,
    InputTextModule,
    ReactiveFormsModule,
    AppliedFiltersModule,
    DatatableListModule,
    CheckboxModule,

    SharedModule
  ],
  declarations: [
    ListadoEquipamentsComponent,
    FiltroListadoEquipamentsComponent,
  ],
  exports: [
    ListadoEquipamentsComponent,
    FiltroListadoEquipamentsComponent
  ],
  providers: []
})
export class ListadoEquipamentsModule { }
