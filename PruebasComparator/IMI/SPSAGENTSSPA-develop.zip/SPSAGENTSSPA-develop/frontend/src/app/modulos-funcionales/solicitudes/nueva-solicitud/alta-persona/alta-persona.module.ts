import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AltaPersonaComponent } from './alta-persona.component';
import { Routes, RouterModule } from '@angular/router';
import { DropdownModule, PanelModule, MessageModule, CalendarModule, InputSwitchModule, ButtonModule, CheckboxModule, DialogService, ProgressBarModule, InputTextModule, DialogModule, InputTextareaModule } from 'primeng/primeng';
import { SharedModule } from '@app/shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { DireccionEdicionModule } from '@app/shared/agrupaciones/direccion-edicion/direccion-edicion.module';
import { TableModule } from 'primeng/table';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { DialogFormulariAdrecaComponent } from './dialog-formulari-adreca/dialog-formulari-adreca.component';
import { DialogLlistatUsuarisPadroComponent } from './dialog-llistat-usuaris-padro/dialog-llistat-usuaris-padro.component';
import { DialogLlistatUsuarisSiasComponent } from './dialog-llistat-usuaris-sias/dialog-llistat-usuaris-sias.component';

const routes: Routes = [
  {
    path: '',
    component: AltaPersonaComponent
  }
];

@NgModule({
  declarations: [
    AltaPersonaComponent,
    DialogFormulariAdrecaComponent, 
    DialogLlistatUsuarisPadroComponent, 
    DialogLlistatUsuarisSiasComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    DropdownModule,
    PanelModule,
    MessageModule,
    CalendarModule,
    InputSwitchModule,
    ButtonModule,
    CheckboxModule,
    SharedModule,
    ReactiveFormsModule,
    DireccionEdicionModule,
    TableModule,
    ProgressBarModule,
    InputTextModule,
    DialogModule,
    DynamicDialogModule,
    InputTextareaModule
  ],
  entryComponents: [
    DialogFormulariAdrecaComponent, 
    DialogLlistatUsuarisPadroComponent, 
    DialogLlistatUsuarisSiasComponent
  ],
  providers: [DialogService]
})
export class AltaPersonaModule { }
