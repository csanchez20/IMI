import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListadosViviendasComponent } from './listados-viviendas.component';

describe('ListadosViviendasComponent', () => {
  let component: ListadosViviendasComponent;
  let fixture: ComponentFixture<ListadosViviendasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListadosViviendasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListadosViviendasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
