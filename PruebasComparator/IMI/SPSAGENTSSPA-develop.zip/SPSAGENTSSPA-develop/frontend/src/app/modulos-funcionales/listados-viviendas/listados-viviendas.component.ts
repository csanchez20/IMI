import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { DiccionarioKey, DictionaryService } from '@app/core/dictionary/state';
import { HttpStatusService } from '@app/core/interceptors';
import { InfoItem, ParamsLlistatUsuariEquipaments, TableData } from '@app/core/model';
import { UsuariosEquipamentsService } from '@app/servicios/usuarios/usuarios-equipaments.service';
import { I18n } from '@ngx-translate/i18n-polyfill';
import moment from 'moment';
import { of, Subscription } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-listados-viviendas',
  templateUrl: './listados-viviendas.component.html',
  styleUrls: ['./listados-viviendas.component.scss']
})
export class ListadosViviendasComponent implements OnInit {

  tableData: TableData;
  tableButtons: InfoItem[] = [
    { 
      action: 'export', 
      label: 
        moment(new Date()).format('DD/MM/YYYY') 
        + '_Llistat_habitatges'
    }
  ]

  diccionarioKey = DiccionarioKey;
  showFilters = false;

  dictionary: any;

  filtersApplied: ParamsLlistatUsuariEquipaments = {};

  private sub: Subscription;
  private sub2: Subscription;

  constructor(
    private i18n: I18n,
    private httpStatusService: HttpStatusService,
    private cd: ChangeDetectorRef,
    private usuariosService: UsuariosEquipamentsService,
    private dictionaryService: DictionaryService
  ) { }

  ngOnInit() {
    this._initDictionary();
    this._saveDataToTable(null);
  }

  handleFilters(data: any) {
    this._resetFilters();
    this._loadData(this._setParams(data));
  }

  paginator(event) {
    this.tableData.numRowsPerPage = event.tamanyPagina;
    this._loadData(this._setParams(event));
  }

  onLazyLoad(event) {
    if (event && event.tamanyPagina) {
      this._loadData({
        ...this._setParams(event),
      });
    }
  }

  private _setParams(params: ParamsLlistatUsuariEquipaments) {
    this.filtersApplied = {
      ...this.filtersApplied,
      ...params,
    };
    return this.filtersApplied;
  }

  private _resetFilters() {
    this.filtersApplied = {
      ...new ParamsLlistatUsuariEquipaments(
        this.filtersApplied.tamanyPagina
      ),
    };
  }

  private _initDictionary() {
    this.sub = this.dictionaryService.getRecursosMotivosBaja().subscribe(res => {
      this.dictionary = res;
    });
  }

  private _saveDataToTable(data) {
    this.tableData = {
      rows: data ? data.content : null,
      cols: this._getCols(),
      numeroTotalResultados: data ? data.total : 0,
      numRowsPerPage: data ? data.pageSize : null,
      loading: false,
    }
  }

  private _loadData(params: ParamsLlistatUsuariEquipaments) {
    this.sub2 = this.usuariosService.getUsuariosByEquipament(params).pipe(
      catchError((err) => {
        this._setLoading(false);
        if (err.status === 404) {
          return of({
            content: [],
            total: 0,
          });
        } else {
          this.httpStatusService.validationErrors = err;
        }
      })
    )
    .subscribe((data) => {
      this._saveDataToTable(data);
      this.cd.markForCheck();
    });
  }

  private _getCols(): InfoItem[] {
    return [
      {
        field: 'nomEquipament',
        header: this.i18n({ id: 'nomEquipament', value: 'Nom equipament' })
      },
      {
        field: 'nomComplet',
        header: this.i18n({ id: 'nombreYApellidos', value: 'Nom i cognoms' })
      },
      {
        field: 'document',
        header: this.i18n({ id: 'documento', value: 'Document' })
      },
      {
        field: 'expedientId',
        header: this.i18n({ id: 'expedienteSIAS', value: 'Expedient SIAS' })
      },
      {
        field: 'dataNaixement',
        header: this.i18n({ id: 'dataNaixement', value: 'Data naixement' }),
        type: 'date'
      },
      {
        field: 'telefon',
        header: this.i18n({ id: 'telefono', value: 'Telefon' })
      },
      {
        field: 'observacionsDomicili',
        header: this.i18n({ id: 'pisoPuerta', value: 'Pis-porta' })
      },
      {
        field: 'dataIngres',
        header: this.i18n({ id: 'dataIngreso', value: 'Data ingrés' }),
        type: 'timestamp'
      },
      {
        field: 'dataBaixa',
        header: this.i18n({ id: 'dataBaixa', value: 'Data baixa' }),
        type: 'timestamp'
      },
      {
        field: 'motiuSortidaDid',
        header: this.i18n({ id: 'motiuSortidaDid', value: 'Motiu Sortida' }),
        type: 'dictionary',
        typeKey: this.diccionarioKey.RECURSO_MOTIVOS_BAJA
      }
    ]
  }

  private _setLoading(loading: boolean) {
    this.tableData = {
      ...this.tableData,
      loading: loading,
      rows: null,
    };
  }

}
