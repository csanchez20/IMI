import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { SessionQuery } from '@app/core/auth';
import { SERVICIO_GUARDAMUEBLES, SERVICIO_SAUV, SERVICIO_VIVIENDAS } from '@app/core/model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-incidencias',
  templateUrl: './incidencias.component.html',
  styleUrls: ['./incidencias.component.scss']
})
export class IncidenciasComponent implements OnInit {

  isAuthorized: boolean;
  isAuthorized$: Observable<boolean>;

  constructor(
    private sessionQuery: SessionQuery,
    private cd: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this._isAuthorized();
  }

  private _isAuthorized(): void {
    this.sessionQuery.service$.subscribe(service => {
      this.isAuthorized = [SERVICIO_VIVIENDAS, SERVICIO_SAUV].includes(service);
      this.cd.markForCheck();
    });
  }

}
