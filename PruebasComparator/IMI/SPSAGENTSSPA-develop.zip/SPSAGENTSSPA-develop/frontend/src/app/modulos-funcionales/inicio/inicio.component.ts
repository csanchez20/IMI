import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { SessionQuery } from '@app/core/auth';
import { HttpStatusService } from '@app/core/interceptors';
import { DialogService } from 'primeng/api';
import { Subject } from 'rxjs';
import { DialogExpiracioSessioComponent } from './dialog-expiracio-sessio/dialog-expiracio-sessio.component';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InicioAgentsComponent implements OnInit {

  eventsSubject: Subject<void> = new Subject<void>();
  
  constructor(
    private sessionQuery: SessionQuery,
    private httpStatusService: HttpStatusService,
    private dialogService: DialogService
    ) {}

  ngOnInit(): void {
    this.sessionQuery.service$.subscribe( service => {
      if (service !== null) {
        this.eventsSubject.next();
      }
    });
    this.httpStatusService.getTokenExpired$.subscribe( () => {
      this._openDialogExpiracioSessio();
    });
  }

  private _openDialogExpiracioSessio() {
    const ref = this.dialogService.open(DialogExpiracioSessioComponent, {
      header: 'Sessió finalitzada',
      width: '60%',
      contentStyle: { 'max-height': '400px', overflow: 'auto' },
      closable: false
    });
  }

  get isUserAuthorized() {
    return !this.sessionQuery.isServiceViviendas();
  }

}

