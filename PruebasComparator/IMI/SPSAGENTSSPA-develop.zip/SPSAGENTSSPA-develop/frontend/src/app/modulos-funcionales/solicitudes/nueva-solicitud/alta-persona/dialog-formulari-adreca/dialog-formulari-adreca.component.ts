import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { ConsultaAdrecaRDTO, ObtenirAdrecesResponseRDTO } from '@app/core/model';
import { DynamicDialogConfig, DynamicDialogRef, DialogService } from 'primeng/api';
import { DireccionService } from '@app/servicios';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';
import { DialogGeocodificacionResultsComponent } from '@app/shared/agrupaciones/dialog-geocodificacion-results/dialog-geocodificacion-results.component';

@Component({
  selector: 'app-dialog-formulari-adreca',
  templateUrl: './dialog-formulari-adreca.component.html',
  styleUrls: ['./dialog-formulari-adreca.component.scss']
})
export class DialogFormulariAdrecaComponent implements OnInit {

  // Formulari de l'adreca
  adrecaForm: FormGroup;

  // Dades de l'adreça
  dades: ConsultaAdrecaRDTO;

  message;

  hasGeocoded_ = false;
 
  diccionarioKey = DiccionarioKey;

  private sub: Subscription;
  private sub2: Subscription;

  constructor(
    public config: DynamicDialogConfig,
    private ref: DynamicDialogRef,
    private addressService: DireccionService,
    private dialogService: DialogService,
    private i18n: I18n,
    private cd: ChangeDetectorRef,
    public dictionaryQuery: DictionaryQuery
  ) { }
 
  ngOnInit() {
    this.obtenirDades();
  }

  /**
  * Mètode per a rebre les dades necessàries
  */
  obtenirDades() {
    this.adrecaForm = this.config.data.adrecaForm;
    console.log('form init: ', this.adrecaForm)
    this.dades = this.config.data.dades;
    if (this.dades) {
      console.log('dades entro: ', this.dades)
      this.adrecaForm.get('adreca').patchValue(this.dades);
    }
  }

  /**
  * Mètode per a tancar la modal del test
  */
  tancarModal(esSubmit: boolean) {
    if (esSubmit) {
      this.adrecaForm.patchValue(this.adrecaForm.getRawValue());
      if (this.adrecaForm.get(['adreca', 'adrAP']).value) {
        const data = this.dictionaryQuery.getDictionaryKey(this.diccionarioKey.PBA);
        const ap = data.find(mestre => mestre.codi === this.adrecaForm.get(['adreca', 'adrAP']).value).descripcio;
        this.adrecaForm.patchValue({ adreca: { adrAPDescr: ap } });
        this.ref.close(this.adrecaForm);
        // this.apartamentPis$.subscribe(data => {
        //   const ap = data.find(mestre => mestre.codi === this.adrecaForm.get(['adreca', 'adrAP']).value).descripcio;
        //   this.adrecaForm.patchValue({ adreca: { adrAPDescr: ap } });
        //   this.ref.close(this.adrecaForm);
        // });
      } else {
        this.ref.close({
          adrecaForm: this.adrecaForm,
          hasGeocoded: this.hasGeocoded_
        });
      }
    } else {
      this.ref.close();
    }
  }

  /**
  * Mètode per a setejar el valor del formulari de l'adreça
  * @param formulariAdreca formulari de l'adreça
  */
  setAdreca(formulariAdreca: FormGroup) {
    this.adrecaForm.setControl('adreca', formulariAdreca);
    this.ref.close({
      adrecaForm: this.adrecaForm,
      hasGeocoded: this.hasGeocoded_
    });
  }

  handleGeoLocation() {
  this.message = null;
  const address = this.adrecaForm.get('adreca') as FormGroup;
  if (!address.get('adrNomCarrer').value) {
    this.message = "Geolocalització: 'Entra com a minim el nom del carrer";
  } else {
    this.sub = this.addressService
      .geoCodObtenir({
        adrNomCarrer: (address.get('adrNomCarrer').value as string).normalize('NFD').replace(/[\u0300-\u036f]/g, ""),
        adrTipusVia: address.get('adrTipusVia').value,
        adrNum1: address.get('adrNum1').value,
        adrNum2: address.get('adrNum2').value ? address.get('adrNum2').value : null,
        adrLletra1: address.get('adrLletra1').value ? address.get('adrLletra1').value : null,
        adrLletra2: address.get('adrLletra2').value ? address.get('adrLletra2').value : null,
      })
      .subscribe((res: ObtenirAdrecesResponseRDTO) => {
        if (res && res.listDirpost) {
          if (res.listDirpost.length === 0) {
            this.message = "Geolocalització: No s'han trobat coincidències";
          } else if (res.listDirpost.length === 1) {
            this.sethasGeocoded(true);
            this._patchGeocodLines(res.listDirpost[0]);
          } else {
            // obrir dialog
            const ref2 = this.dialogService.open(
              DialogGeocodificacionResultsComponent,
              {
                data: res.listDirpost,
                header: this.i18n({
                  id: 'geolocalizacionResultados',
                  value: 'Geolocalizació resultats'
                }),
                width: '40%'
              }
            );

            this.sub2 = ref2.onClose.subscribe(res2 => {
              if (res2) {
                this.sethasGeocoded(true);
                this._patchGeocodLines(res2);
              }
            });
          }
        }
        this.cd.markForCheck();
      });
    }
  }

  private _patchGeocodLines(obj) {
    console.log('geo: ', obj)
    this.adrecaForm.controls.adreca.patchValue(
      {
        adrNomCarrer: obj['nom27'],
        adrTipusVia: obj['tipusVia'],
        adrDistricte: obj['districte'],
        adrBarri: obj['barri'],
        barriDesc: obj['barriDesc'] ? obj['barriDesc'] : obj['descBarri'],
        adrNum1: obj['numpostI'],
        adrNum2: obj['numpostF'] !== obj['numpostI'] ? obj['numpostF'] : null,
        adrCP: obj['codPost'],
        adrCodiCarrer: obj['codi']
      },
      { emitEvent: false }
    );
    console.log('this.adrecaForm.controls.adreca: ', this.adrecaForm.getRawValue().adreca)
  }

  private sethasGeocoded(value: boolean) {
    this.hasGeocoded_ = value;
  }

}
