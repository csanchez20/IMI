import { DOCUMENT } from '@angular/common';
import { ChangeDetectorRef, Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DadesCentreUsuari, SessionQuery, SessionService } from '@app/core/auth';
import { AuthUser, ImiSpsInfo } from '@app/core/auth/model';
import { HttpStatusService } from '@app/core/interceptors';
import { CentreggRDTO } from '@app/core/model';
import { ServiciosIMI, SERVICIO_KEY_HAB, SERVICIO_KEY_RES, SERVICIO_KEY_RESPLUS, SERVICIO_KEY_SAUV, SERVICIO_RESPIR, SERVICIO_RESPIRPLUS, SERVICIO_SAUV, SERVICIO_VIVIENDAS } from '@app/core/model/servicio';
import { EquipamentsService } from '@app/servicios';
import { SeguridadCintraosService } from '@app/servicios/seguridad-cintraos/seguridad-cintraos.service';
import { environment } from '@env/environment';
import { SelectItem } from 'primeng/api';
import { of } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-selecciona-centre',
  templateUrl: './selecciona-centre.component.html',
  styleUrls: ['./selecciona-centre.component.scss']
})
export class SeleccionaCentreComponent implements OnInit {

  form: FormGroup;
  grups: SelectItem[] = [];
  usuaris: SelectItem[] = [];
  showUsuaris = false;
  showError = false;
  msgError: string;
  redirectUrlSeguridad = false;
  cantAcces = false;
  servei: number;
  codiReferenciaCentre: string = null;
  hasCentro = false;

  constructor(
    private seguridadCintraosService: SeguridadCintraosService,
    private router: Router,
    private fb: FormBuilder,
    private cd: ChangeDetectorRef,
    private sessionService: SessionService,
    private equipamentsService: EquipamentsService,
    private sessionQuery: SessionQuery,
    private httpStatusService: HttpStatusService,
    @Inject(DOCUMENT) private document: Document
  ) {
    this.form = this.fb.group({
      grup: [null, Validators.required]
    });
  }

  ngOnInit() {
    this.sessionService.callSessionInfo()
      .pipe(
        catchError(err => {
          return of(null);
        })
      )
      .subscribe(sessionInfo => {
        console.log('sessionInfo: ', sessionInfo);
        if (sessionInfo !== null) {
          const authUser: AuthUser = {
            clientId: environment.clientid,
            imiAuthorization: sessionInfo,
            imiSpsInfo: null
          }
          this.sessionService.login(authUser);
          this._cercaGrups();
          this.showError = false;
          this._hasPermisosRol();
        } else {
          this._validaSeguridad()
        }
      });
  }

  private _validaSeguridad() {
    if (environment.urlSeguridad !== '') {
      const baseUrl = this.document.location.href;
      if (!baseUrl.startsWith(environment.urlSeguridad)) {
        this.redirectUrlSeguridad = true;
        this._goToAppSegurizada();
      } else {
        this.msgError = 'Hi ha problemes amb el servidor, torna a accedir.';
        this.showError = true;
      }
    } else {
      this.showUsuaris = true;
      this._initUsuaris();
    }
  }

  private _goToAppSegurizada() {
    this.document.location.href= environment.urlSeguridad
  }

  private _hasPermisosRol(): void {
    if(this.sessionQuery.getRoleUserId() === null) {
      this.msgError = 'No tens permisos per accedir.';
      this.showError = true;
      this.cantAcces = true;
    } else {
      this.showError = false;
      this.cantAcces = false;
    }
  }
  private _initUsuaris() {
    const usuaris = this.sessionService.mockUsersLogin();
    usuaris.map(user => {
      this.usuaris = [
        ...this.usuaris,
        {
          label: user,
          value: user
        }
      ]
    })
  }

  onSubmit(): void {   
    if (this.servei) {
      this._saveDadesToStore();
      this.router.navigate(['/inici'], { replaceUrl: true });
    } else {
      this.msgError = 'Grup mal configurat, contacti amb l\'administrador.';
      this.showError = true;
    }
  }

  changeGrup(grup: SelectItem) {
    this.showError = false;
    this.form.get('grup').setValue(grup.value);
    this._calcularServicio();
  }

  selectUsuari(usuari: SelectItem) {
    this.showError = false;
    this.sessionService.loginMock(usuari.value);
    this._hasPermisosRol();
    this._cercaGrups();
  }

  private _cercaGrups() {
    this.seguridadCintraosService.getGrupsUsuari()
      .pipe(
        catchError(err => {
          this.httpStatusService.validationErrors = err;
          return of([]);
        })
      )
      .subscribe((centres: SelectItem[]) => {
        this._actualizaGrups(centres);
      })
  }

  private _actualizaGrups(grups: SelectItem[]) {
    if (grups && grups.length > 0) {
      this.grups = grups;
    } else if (environment.urlSeguridad === '') {
      const grups: SelectItem[] = this.sessionQuery.getAuthUser().imiAuthorization.grp.map(grup => {
        return {
          value: grup,
          label: grup
        }
      })
      this.grups = grups.length > 0 ? grups : [];
    } else if (environment.urlSeguridad !== '') {
      this.msgError = 'Grup mal configurat, contacti amb l\'administrador.';
      this.showError = true;
    }
    this.cd.markForCheck();
  }

  private _calcularServicio() {
    this.hasCentro = false;
    this.codiReferenciaCentre = null;
    this.servei = null;
    const grup = this.form.get('grup').value as string;
    switch (grup) {
      case SERVICIO_KEY_HAB:
        this.servei = SERVICIO_VIVIENDAS;
        break;
      case SERVICIO_KEY_SAUV:
        this.servei = SERVICIO_SAUV;
        break;
      case SERVICIO_KEY_RES:
        this.servei = SERVICIO_RESPIR;
        break;
      case SERVICIO_KEY_RESPLUS:
        this.servei = SERVICIO_RESPIRPLUS;
        break;
      default:
        this._calcularServicioByCentro();
        break;
    }
  }

  private _calcularServicioByCentro() {
    const centre = (this.form.get('grup').value as string).slice(-4); 
    this.equipamentsService.getDatosGestionEquipament(centre)
      .pipe(
        catchError(err => {
          this.httpStatusService.validationErrors = err;
          this.showError = true;
          return of(null);
        })
      )
      .subscribe((res: CentreggRDTO) => {
        if (res && res.respostaDid !== ServiciosIMI.GUARDAMUEBLES) {
          this.hasCentro = true;
          this.servei = res.respostaDid
          this.codiReferenciaCentre = res.codiReferencia
        } else {
          this.msgError = 'Grup mal configurat, contacti amb l\'administrador.';
          this.showError = true;
        }
      })
  }

  private _saveDadesToStore() {
    let centro: string = null; 
    if (this.hasCentro) {
      centro = (this.form.get('grup').value as string).slice(-4); 
      const dadesCentreUsuari: DadesCentreUsuari = {
        centreId: centro,
        codiReferencia: this.codiReferenciaCentre
      }
      this.sessionService.setDadesCentreUsuari(dadesCentreUsuari);
    }
    const imiSpsInfo: ImiSpsInfo = {
      centro: centro
    };
    this.sessionService.setService(this.servei);
    this.sessionService.updateImiSpsInfo(imiSpsInfo);
  }

}
