import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FichaEquipamentsModule } from './ficha-equipaments/ficha-equipaments.module';
import { EquipamentsRoutingModule } from './equipaments-routing.module';
import { EquipamentsComponent } from './equipaments.component';
import { ListadoEquipamentsModule } from './listado-equipaments/listado-equipaments.module';
import { SharedModule } from '@app/shared/shared.module';

@NgModule({
  declarations: [
    EquipamentsComponent
  ],
  imports: [
    CommonModule,
    EquipamentsRoutingModule,
    ListadoEquipamentsModule,
    FichaEquipamentsModule,
    SharedModule
  ]
})
export class EquipamentsModule { }
