import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SessionQuery } from '@app/core/auth';
import { ConsultaAdrecaRDTO } from '@app/core/model';
import { CentreggRDTO, CentroDTO } from '@app/core/model/equipaments';
import { DataDocumentacionEntidad, TIPUS_ENTIDAD_EQUIPAMENT } from '@app/shared/agrupaciones/documentacion-general/documentacion-general.component';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-ficha-equipaments',
  templateUrl: './ficha-equipaments.component.html',
  styleUrls: ['./ficha-equipaments.component.scss']
})
export class FichaEquipamentsComponent implements OnInit {
  centroDTO: CentroDTO;
  adrecaCintraos: ConsultaAdrecaRDTO;
  datosEquipament: CentreggRDTO;
  dataDocEntidad: DataDocumentacionEntidad;

  constructor(private route: ActivatedRoute, private sessionQuery: SessionQuery) {}

  ngOnInit() {
    this.centroDTO = this.route.snapshot.data[
      'equipament'
    ].datosEquipa.datosBasicosEq;
    this.adrecaCintraos = this.route.snapshot.data[
      'equipament'
    ].datosEquipa.adrecaCintraos;
    this.datosEquipament = this.route.snapshot.data[
      'equipament'
    ].datosEquipa.datosGestionEq;

    this.dataDocEntidad = {
      entitatId: this.datosEquipament.centreId,
      tipusEntitatDid: TIPUS_ENTIDAD_EQUIPAMENT
    }

  }

  isSauv() {
    return this.sessionQuery.isServiceSAUV();
  }
}
