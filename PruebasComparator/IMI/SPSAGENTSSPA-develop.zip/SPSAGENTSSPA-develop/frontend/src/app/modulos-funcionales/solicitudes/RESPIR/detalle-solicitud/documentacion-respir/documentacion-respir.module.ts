import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DocumentacionRespirComponent } from './documentacion-respir.component';
import { PanelModule } from 'primeng/primeng';
import { BotonMultifuncionGestionDocumentosModule } from '@app/shared/agrupaciones/boton-multifuncion-gestion-documentos/boton-multifuncion-gestion-documentos.module';

@NgModule({
  declarations: [DocumentacionRespirComponent],
  imports: [
    CommonModule,
    PanelModule,
    BotonMultifuncionGestionDocumentosModule
  ],
  exports: [DocumentacionRespirComponent]
})
export class DocumentacionRespirModule { }
