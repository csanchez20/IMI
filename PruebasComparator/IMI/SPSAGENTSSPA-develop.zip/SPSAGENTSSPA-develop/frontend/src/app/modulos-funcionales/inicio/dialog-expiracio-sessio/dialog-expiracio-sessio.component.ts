import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dialog-expiracio-sessio',
  templateUrl: './dialog-expiracio-sessio.component.html',
  styleUrls: ['./dialog-expiracio-sessio.component.scss']
})
export class DialogExpiracioSessioComponent implements OnInit {

  constructor(
    readonly router: Router
  ) { }

  ngOnInit() {
  }

  goLogin() {
    this.router.navigate(['']).then(() => {
      const url = window.location.protocol + '//' + window.location.host + '/APPS/spsagentsspa/';
      window.location.href = url;
    });
  }

}
