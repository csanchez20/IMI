import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogDetalleProfesionalesContactoComponent } from './dialog-detalle-profesionales-contacto.component';

describe('DialogDetalleProfesionalesContactoComponent', () => {
  let component: DialogDetalleProfesionalesContactoComponent;
  let fixture: ComponentFixture<DialogDetalleProfesionalesContactoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogDetalleProfesionalesContactoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogDetalleProfesionalesContactoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
