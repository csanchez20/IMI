import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentacionRespirComponent } from './documentacion-respir.component';

describe('DocumentacionRespirComponent', () => {
  let component: DocumentacionRespirComponent;
  let fixture: ComponentFixture<DocumentacionRespirComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentacionRespirComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentacionRespirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
