import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogLlistatUsuarisSiasComponent } from './dialog-llistat-usuaris-sias.component';

describe('DialogLlistatUsuarisSiasComponent', () => {
  let component: DialogLlistatUsuarisSiasComponent;
  let fixture: ComponentFixture<DialogLlistatUsuarisSiasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogLlistatUsuarisSiasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogLlistatUsuarisSiasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
