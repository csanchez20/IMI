import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListadoIncidenciasEquipamentComponent } from './listado-incidencias-equipament.component';

describe('ListadoIncidenciasEquipamentComponent', () => {
  let component: ListadoIncidenciasEquipamentComponent;
  let fixture: ComponentFixture<ListadoIncidenciasEquipamentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListadoIncidenciasEquipamentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListadoIncidenciasEquipamentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
