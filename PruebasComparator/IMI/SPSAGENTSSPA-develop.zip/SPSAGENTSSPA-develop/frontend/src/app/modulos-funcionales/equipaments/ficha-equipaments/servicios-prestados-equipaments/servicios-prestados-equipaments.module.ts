import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ServiciosPrestadosEquipamentsComponent } from './servicios-prestados-equipaments.component';
import { PanelModule } from 'primeng/panel';
import { SharedModule } from '@app/shared/shared.module';
import { DropdownModule, InputTextModule, MessageModule } from 'primeng/primeng';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { LimitDecimalModule } from '@app/shared/directivas/limit-decimal/limit-decimal.module';


@NgModule({
  declarations: [
    ServiciosPrestadosEquipamentsComponent
  ],
  imports: [
    CommonModule,
    PanelModule,
    SharedModule,
    DropdownModule,
    ReactiveFormsModule,
    TableModule,
    InputTextModule,
    FormsModule,
    MessageModule,
    LimitDecimalModule
  ],
  exports: [
    ServiciosPrestadosEquipamentsComponent
  ]
})
export class ServiciosPrestadosEquipamentsModule { }
