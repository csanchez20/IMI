import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AyudaContextualModule } from '@app/shared/agrupaciones/ayuda-contextual/ayuda-contextual.module';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
// import { BloqueTareasComponent } from './bloque-tareas/bloque-tareas.component';
// import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
// import { ListadoComunicacionesComponent } from './bloque-notificaciones/listado-comunicaciones/listado-comunicaciones.component';
// import { ListadoAvisosComponent } from './bloque-notificaciones/listado-avisos/listado-avisos.component';
// import { DialogEditshowTaskModule } from './bloque-tareas/dialog-editshow-task/dialog-editshow-task.module';
// import { AyudaContextualModule } from '@app/shared/agrupaciones/ayuda-contextual/ayuda-contextual.module';
import { SharedModule } from '@app/shared/shared.module';
// import { BloqueIndicadoresComponent } from './bloque-indicadores/bloque-indicadores.component';
// import { BloqueNotificacionesComponent } from './bloque-notificaciones/bloque-notificaciones.component';
import { MomentModule } from 'ngx-moment';
import { DynamicDialogModule } from 'primeng/components/dynamicdialog/dynamicdialog';
import { ButtonModule, CardModule, CheckboxModule, DialogModule, DialogService, DropdownModule, PanelModule, TabMenuModule, TabViewModule } from 'primeng/primeng';
import { TableModule } from 'primeng/table';
import { BloqueNotificacionesComponent } from './bloque-notificaciones/bloque-notificaciones.component';
import { ListadoAvisosComponent } from './bloque-notificaciones/listado-avisos/listado-avisos.component';
import { BloqueTareasComponent } from './bloque-tareas/bloque-tareas.component';
import { DialogExpiracioSessioComponent } from './dialog-expiracio-sessio/dialog-expiracio-sessio.component';
import { InicioAgentsRoutingModule } from './inicio-routing.module';
import { InicioAgentsComponent } from './inicio.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    PanelModule,
    TabViewModule,
    CardModule,
    DialogModule,
    DropdownModule,
    ButtonModule,
    TableModule,
    TabMenuModule,
    CheckboxModule,
    MomentModule,
    DynamicDialogModule,
    InicioAgentsRoutingModule,
    DatatableListModule,
    // DialogEditshowTaskModule,
    AyudaContextualModule,
    SharedModule

  ],
  declarations: [
    InicioAgentsComponent,
    BloqueTareasComponent,
    BloqueNotificacionesComponent,
    ListadoAvisosComponent,
    DialogExpiracioSessioComponent
  ],
  providers: [
    // InicioGuardamueblesService,
    DialogService
  ],
  entryComponents: [
    DialogExpiracioSessioComponent
  ]

})
export class InicioAgentsModule { }
