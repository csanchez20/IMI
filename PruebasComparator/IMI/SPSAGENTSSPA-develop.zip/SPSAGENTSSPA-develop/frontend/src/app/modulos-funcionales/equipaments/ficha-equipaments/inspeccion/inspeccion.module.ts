import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InspeccionComponent } from './inspeccion.component';
import { DialogModule } from 'primeng/dialog';
import { DynamicDialogModule } from 'primeng/components/dynamicdialog/dynamicdialog';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { FileUploadModule, CalendarModule, ButtonModule, InputTextareaModule, InputTextModule, MessageModule } from 'primeng/primeng';
import { DialogAddInspeccionComponent } from './dialog-add-inspeccion/dialog-add-inspeccion.component';
import { SharedModule } from '@app/shared/shared.module';
import { DialogDetalleInspeccionComponent } from './dialog-detalle-inspeccion/dialog-detalle-inspeccion.component';
import { MomentModule } from 'ngx-moment';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { BotonMultifuncionGestionDocumentosModule } from '@app/shared/agrupaciones/boton-multifuncion-gestion-documentos/boton-multifuncion-gestion-documentos.module';

@NgModule({
  declarations: [
    InspeccionComponent,
    DialogAddInspeccionComponent,
    DialogDetalleInspeccionComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DialogModule,
    DynamicDialogModule,
    DropdownModule,
    FileUploadModule,
    CalendarModule,
    InputTextareaModule,
    InputTextModule,
    ButtonModule,
    MomentModule,
    DatatableListModule,
    SharedModule,
    MessageModule,
    BotonMultifuncionGestionDocumentosModule
  ],
  exports: [
    InspeccionComponent,
    DialogAddInspeccionComponent
  ],
  entryComponents: [
    DialogAddInspeccionComponent,
    DialogDetalleInspeccionComponent
  ]
})
export class InspeccionModule { }
