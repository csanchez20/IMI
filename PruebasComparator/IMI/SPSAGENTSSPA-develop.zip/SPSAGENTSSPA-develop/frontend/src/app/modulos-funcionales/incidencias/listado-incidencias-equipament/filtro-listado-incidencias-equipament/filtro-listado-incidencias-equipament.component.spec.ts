import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroListadoIncidenciasEquipamentComponent } from './filtro-listado-incidencias-equipament.component';

describe('FiltroListadoIncidenciasEquipamentComponent', () => {
  let component: FiltroListadoIncidenciasEquipamentComponent;
  let fixture: ComponentFixture<FiltroListadoIncidenciasEquipamentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiltroListadoIncidenciasEquipamentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltroListadoIncidenciasEquipamentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
