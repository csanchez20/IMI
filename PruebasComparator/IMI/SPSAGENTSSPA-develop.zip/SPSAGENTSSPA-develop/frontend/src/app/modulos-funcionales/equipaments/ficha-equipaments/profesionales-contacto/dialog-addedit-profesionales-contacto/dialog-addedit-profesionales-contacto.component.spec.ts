import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogAddeditProfesionalesContactoComponent } from './dialog-addedit-profesionales-contacto.component';

describe('DialogAddeditProfesionalesContactoComponent', () => {
  let component: DialogAddeditProfesionalesContactoComponent;
  let fixture: ComponentFixture<DialogAddeditProfesionalesContactoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogAddeditProfesionalesContactoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogAddeditProfesionalesContactoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
