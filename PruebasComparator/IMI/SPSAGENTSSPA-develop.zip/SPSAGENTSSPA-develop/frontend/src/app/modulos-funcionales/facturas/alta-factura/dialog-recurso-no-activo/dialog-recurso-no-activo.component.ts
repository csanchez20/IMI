import { Component, OnInit } from '@angular/core';
import { DynamicDialogRef } from 'primeng/api';

@Component({
  selector: 'app-dialog-recurso-no-activo',
  templateUrl: './dialog-recurso-no-activo.component.html',
  styleUrls: ['./dialog-recurso-no-activo.component.scss']
})
export class DialogRecursoNoActivoComponent implements OnInit {

  constructor(
    private ref: DynamicDialogRef
  ) { }

  ngOnInit() {}

  closeDialog() {
    this.ref.close();
  }

}
