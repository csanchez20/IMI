import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DiccionarioKey, DictionaryQuery } from '@app/core/dictionary/state';
import { ConsultaAdrecaRDTO } from '@app/core/model';
import { CentroDTO } from '@app/core/model/equipaments';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-cabecera-ficha-equipaments',
  templateUrl: './cabecera-ficha-equipaments.component.html',
  styleUrls: ['./cabecera-ficha-equipaments.component.scss']
})
export class CabeceraFichaEquipamentsComponent implements OnInit {
  @Input() centroDTO: CentroDTO;
  @Input() adrecaCintraos: ConsultaAdrecaRDTO;
  @Input() codiRef: string;
  nom_empresa;
  diccionarioKey = DiccionarioKey;

  constructor(public dictionaryQuery: DictionaryQuery, private route: ActivatedRoute) {}

  ngOnInit() {
    this.route.paramMap
    .pipe(map(() => window.history.state)).subscribe((state) =>this.nom_empresa = state.empresa  )
  }
}
