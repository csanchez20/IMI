import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, Router, RouterStateSnapshot } from '@angular/router';
import { DictionaryService } from '@app/core/dictionary/state';
import { ConsultaAdrecaRDTO } from '@app/core/model';
import { CentreggRDTO, CentroDTO } from '@app/core/model/equipaments';
import { DireccionService } from '@app/servicios/direccion/direccion.service';
import { EquipamentsService } from '@app/servicios/equipaments/equipaments.service';
import { forkJoin, Observable } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { ParametresGlobalsService } from '@app/servicios/parametres globals/parametres-globals.service';
import { NOM_PARAM_SERVEIS_PRESTATS } from '@app/servicios/equipaments/serveisPrestats.service';
import { SessionService } from '@app/core/auth';
import { EquipamentsCintraosService } from '@app/servicios/equipaments/equipaments-cintraos.service';


@Injectable({
  providedIn: 'root'
})
export class FichaEquipamentResolverService implements Resolve<any> {
  constructor(
    public equipamentService: EquipamentsService,
    public equipamentCintraosService: EquipamentsCintraosService,
    public direccionService: DireccionService,
    public router: Router,
    private dictionaryService: DictionaryService,
    private parametresGlobalsService: ParametresGlobalsService,
    private sessionService: SessionService
  ) {}

  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> {
    const idEquipament = route.paramMap.get('idEquipament');

    return forkJoin({
      diccionario: this.dictionaryService.getTiposVia(),
      parametresGlobals: this.parametresGlobalsService.getParametresGlobals(
        {
          nom: NOM_PARAM_SERVEIS_PRESTATS
        }).pipe(
          map((res: any) => {
            this.sessionService.setPGlobalServeisPrestats(res.llistaCercaParametres);
          }
        )
      ),
      datosEquipa: this.equipamentCintraosService.getCentroCintraos(idEquipament).pipe(
        switchMap((datosBasicosEq: any) => {
          return this.direccionService
            .getDireccionUsuarioByUbicacionId(datosBasicosEq.ubicacioId)
            .pipe(
              switchMap((adrecaCintraos: ConsultaAdrecaRDTO) => {
                // Obtención de los datos de los datos de la 1º pestanya: Datos Gestion Equipament
                return this.equipamentService
                  .getDatosGestionEquipament(idEquipament)
                  .pipe(
                    map((datosGestionEq: CentreggRDTO) => {
                      return {
                        datosBasicosEq: datosBasicosEq,
                        adrecaCintraos: adrecaCintraos,
                        datosGestionEq: datosGestionEq
                      };
                    })
                  );
              })
            );
        })
      )
    });
  }
}
