import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PanelModule, CheckboxModule, ButtonModule, DialogModule, TriStateCheckboxModule } from 'primeng/primeng';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ContextoComponent } from './contexto/contexto.component';
import { SituacionContextoComponent } from './situacion-contexto.component';
import { SituacionUrgenciaComponent } from './situacion-urgencia/situacion-urgencia.component';
import { SharedModule } from '@app/shared/shared.module';

@NgModule({
  declarations: [
    SituacionContextoComponent,
    SituacionUrgenciaComponent,
    ContextoComponent
  ],
  imports: [
    CommonModule,
    PanelModule,
    FormsModule,
    ReactiveFormsModule,
    CheckboxModule,
    TriStateCheckboxModule,
    ButtonModule,
    DialogModule,
    SharedModule
  ],
  exports: [
    SituacionContextoComponent,
    SituacionUrgenciaComponent,
    ContextoComponent
  ]
})
export class SituacionContextoModule { }
