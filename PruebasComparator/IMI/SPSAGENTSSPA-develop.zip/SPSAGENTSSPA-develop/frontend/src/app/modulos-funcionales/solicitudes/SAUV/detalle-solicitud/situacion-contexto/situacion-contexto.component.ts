import { Component, Input, OnInit } from '@angular/core';
import { ResultatConsultaSauvRDTO } from '@app/core/model/solicitudes/solicitud-SAUV';

@Component({
  selector: 'app-situacion-contexto',
  templateUrl: './situacion-contexto.component.html',
  styleUrls: ['./situacion-contexto.component.scss']
})
export class SituacionContextoComponent implements OnInit {

  @Input() datosBasicosSolicitud: ResultatConsultaSauvRDTO;

  constructor() { }

  ngOnInit() {}

}
