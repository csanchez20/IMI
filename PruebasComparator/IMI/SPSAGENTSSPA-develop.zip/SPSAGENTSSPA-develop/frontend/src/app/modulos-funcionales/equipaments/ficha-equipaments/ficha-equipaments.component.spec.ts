import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FichaEquipamentsComponent } from './ficha-equipaments.component';

describe('FichaEquipamentsComponent', () => {
  let component: FichaEquipamentsComponent;
  let fixture: ComponentFixture<FichaEquipamentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FichaEquipamentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FichaEquipamentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
