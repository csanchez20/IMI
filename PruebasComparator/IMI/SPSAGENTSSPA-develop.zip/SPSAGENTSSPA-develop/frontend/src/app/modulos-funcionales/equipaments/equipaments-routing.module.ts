import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EquipamentsComponent } from './equipaments.component';
import { FichaEquipamentResolverService } from './ficha-equipaments/ficha-equipaments-resolver.service';
import { FichaEquipamentsComponent } from './ficha-equipaments/ficha-equipaments.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: EquipamentsComponent,
      },
      {
        path: ':idEquipament',
        component: FichaEquipamentsComponent,
        resolve: { equipament: FichaEquipamentResolverService },
        data: {
          breadcrumb: 'detalleEquipaments'
        },
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EquipamentsRoutingModule { }
