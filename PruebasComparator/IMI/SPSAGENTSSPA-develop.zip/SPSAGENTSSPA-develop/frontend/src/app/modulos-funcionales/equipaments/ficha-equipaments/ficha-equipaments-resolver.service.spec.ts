// import { TestBed, inject } from '@angular/core/testing';
// import { GestionServicioService } from '@app/servicios';
// import { HttpClientTestingModule } from '@angular/common/http/testing';
// import { RouterTestingModule } from '@angular/router/testing';

// describe('FichaUsuarioResolverService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [
//         HttpClientTestingModule,
//         RouterTestingModule
//       ],
//       providers: [
//         GestionServicioService,
//         FichaUsuarioResolverService
//       ],
//     });
//   });

//   it('should be created', inject([FichaUsuarioResolverService], (service: FichaUsuarioResolverService) => {
//     expect(service).toBeTruthy();
//   }));
// });
