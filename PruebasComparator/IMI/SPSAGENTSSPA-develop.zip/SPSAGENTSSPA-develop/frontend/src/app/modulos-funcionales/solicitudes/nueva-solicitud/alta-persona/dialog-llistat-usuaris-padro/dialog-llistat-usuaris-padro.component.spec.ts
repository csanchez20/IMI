import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogLlistatUsuarisPadroComponent } from './dialog-llistat-usuaris-padro.component';

describe('DialogLlistatUsuarisPadroComponent', () => {
  let component: DialogLlistatUsuarisPadroComponent;
  let fixture: ComponentFixture<DialogLlistatUsuarisPadroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogLlistatUsuarisPadroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogLlistatUsuarisPadroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
