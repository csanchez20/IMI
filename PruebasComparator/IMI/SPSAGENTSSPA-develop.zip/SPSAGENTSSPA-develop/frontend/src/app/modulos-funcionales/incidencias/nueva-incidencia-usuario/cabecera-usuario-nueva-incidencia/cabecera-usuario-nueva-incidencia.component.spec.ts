import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CabeceraUsuarioNuevaIncidenciaComponent } from './cabecera-usuario-nueva-incidencia.component';

describe('CabeceraUsuarioNuevaIncidenciaComponent', () => {
  let component: CabeceraUsuarioNuevaIncidenciaComponent;
  let fixture: ComponentFixture<CabeceraUsuarioNuevaIncidenciaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CabeceraUsuarioNuevaIncidenciaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CabeceraUsuarioNuevaIncidenciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
