import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosBasicosSolicitudComponent } from './datos-basicos-solicitud.component';

describe('DatosBasicosSolicitudComponent', () => {
  let component: DatosBasicosSolicitudComponent;
  let fixture: ComponentFixture<DatosBasicosSolicitudComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatosBasicosSolicitudComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatosBasicosSolicitudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
