import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionQuery, SessionService } from '@app/core/auth';
import { DiccionarioKey, DictionaryQuery, DictionaryService } from '@app/core/dictionary/state';
import { HttpStatusService } from '@app/core/interceptors';
import { ConsultaAdrecaRDTO, PreAlta, UsuariAlta } from '@app/core/model';
import { AltaUsuariValidator } from '@app/core/services/alta-usuari.validator.service';
import { FormatterService } from '@app/core/services/formatter.service';
import { DniValidator, EmailValidator, TelefonValidator } from '@app/core/services/validators';
import { DireccionService, MUNICIPI_BARCELONA, UsuariosService } from '@app/servicios';
import { CODE_TIPO_DOCUMENTO_MENOR_SENSE_DOCUMENTS, CODE_TIPO_DOCUMENTO_PERSONA_SENSE_DOCUMENTACIO } from '@app/servicios/personas/personas.service';
import { ERRORS_ALTA_USUARI, FormulariUsuariService, SUCCES_ALTA_USUARI } from '@app/servicios/usuarios/alta/formulari-usuari.service';
import { I18n } from '@ngx-translate/i18n-polyfill';
import moment from 'moment';
import { DialogService } from 'primeng/api';
import { forkJoin, of } from 'rxjs';
import { I18nConfigService } from '../../../../../../projects/spscompspa/src/app/services';
import { DialogFormulariAdrecaComponent } from './dialog-formulari-adreca/dialog-formulari-adreca.component';
import { DialogLlistatUsuarisPadroComponent } from './dialog-llistat-usuaris-padro/dialog-llistat-usuaris-padro.component';
import { DialogLlistatUsuarisSiasComponent } from './dialog-llistat-usuaris-sias/dialog-llistat-usuaris-sias.component';
interface ResultDialogAdreca {
  adrecaForm: FormGroup;
  hasGeocoded: boolean;
}

@Component({
  selector: 'app-alta-persona',
  templateUrl: './alta-persona.component.html',
  styleUrls: ['./alta-persona.component.scss']
})
export class AltaPersonaComponent implements OnInit {

 
  usuari: UsuariAlta;

  // Estat de càrrega de les dades
  esCarregat: boolean;

  // Formulari alta usuari
  altaUsuariForm: FormGroup;

  // Comprovadors
  esDisabled: boolean;

  // Te dades preAltaPadro
  tePadroPrealta: boolean;

  // El tipus document es menos de edat
  esMenor: boolean;

  // El tipus document es sense documentacio
  esSenseDoc: boolean;

  // El tipus document es dni
  esDni: boolean;

  // El tipus document es NIE
  esNie: boolean;

  // El tipus document es passaport
  esPassaport: boolean;

  // Edat de l'usuari
  edat: number;

  // Codi prealta
  codiPreAlta: string = null;

  // Mode del formular
  esEditar: boolean = false;

  // Persona que es vol modificar
  personaEditar: UsuariAlta;

  // Codi getronics per la geocalització

  // Validador geocode
  hasGeoCoded = false;

  dictionaries = null;
  diccionarioKey = DiccionarioKey;


  constructor(
    private formulariUsuariService: FormulariUsuariService,
    private usuarisService: UsuariosService,
    private missatgeService: HttpStatusService,
    private formBuilder: FormBuilder,
    private dialogService: DialogService,
    private sessionQuery: SessionQuery,
    private i18n: I18n,
    private router: Router,
    private route: ActivatedRoute,
    private adrecaService: DireccionService,
    private formatterService: FormatterService,
    private dictionaryService: DictionaryService,
    private cd: ChangeDetectorRef,
    private sessionService: SessionService,
    public i18nConfig: I18nConfigService,
    public dictionaryQuery: DictionaryQuery
  ) { }

  ngOnInit() {
    this.carregaDiccionaris();
    this.inicialitzarDades();
    this.inicialitzarFormulari();
  }

  /**
   * Mètode per a inicialitzar les dades del component
   */
  inicialitzarDades() {
    this.esCarregat = false;
    // this.mestres$ = this.formulariUsuariService.obtenirCatalegs();
    this.esMenor = false;
    this.esSenseDoc = false;
    this.esDni = false;
    this.tePadroPrealta = false;
    this.esDisabled = false;
    this.esPassaport = false;
    this.esNie = false;
    this.esEditar = false;
  }

  /**
   * Mètode per a carregar els valors del diccionari al storage
   */
  carregaDiccionaris() {
    forkJoin({
      d1: this.dictionaryService.getTipoDocumentos(),
      d2: this.dictionaryService.getPaises(),
      d3: this.dictionaryService.getCaracteristicas(),
      d4: this.dictionaryService.getGeneros(),
      d5: this.dictionaryService.getTiposVia(),
      d6: this.dictionaryService.getEstadosCiviles(),
      d7: this.dictionaryService.getIdiomas(),
      d8: this.dictionaryService.getPBA(),
      d9: this.dictionaryService.getDistrictes(),
      d10: this.dictionaryService.getRelacionsServeisMunicipals(),
      d11: this.dictionaryService.getTipoDireccion()
    }).subscribe(dictionaries => {
      this.dictionaries = dictionaries;
      this.cd.markForCheck();
    });
  }

  /**
   * Mètode per a inicialitzar el formulari
   */
  inicialitzarFormulari() {
    this.altaUsuariForm = this.formBuilder.group({
      codiPreAlta: null,
      tipusDocumentDid: null,
      tipusDocument: null,
      document: null,
      nom: null,
      cognom1: null,
      cognom2: null,
      numTargetaSalut: null,
      teAdreca: false,
      adrecaFormal: null,
      dataNaixementNumber: null,
      dataNaixement: null,
      edat: null,
      paisNaixementDid: null,
      nacionalitatDid: null,
      genereDid: null,
      esComplex: null,
      caracteristica: null,
      pes: null,
      observacions: null,
      adrecaPadro: null,
      necessitaTraductor: null,
      relacioAmbServeisMunicipals: null,
      alies: null,
      teAlias: null,
      realitzarPrealta: false,
      realitzarAlta: false,
      adreces: this.formBuilder.array([]),
      telefon1: [null, TelefonValidator],
      telefon2: [null, TelefonValidator],
      telefon3: [null, TelefonValidator],
      telefon4: [null, TelefonValidator],
      idiomaDid: null,
      estatCivilDid: null,
      descripcioTelefon1: null,
      descripcioTelefon2: null,
      descripcioTelefon3: null,
      descripcioTelefon4: null,
      email: [null, EmailValidator],
      expedientId: null
    }, {
      validator: [AltaUsuariValidator, DniValidator]
    });
    const expedientId = this.route.snapshot.paramMap.get('idExpedient');
    if (expedientId) {
      this.setDadesEditar(expedientId);
    } else {
      this.esCarregat = true;
    }
    this.onChangesFormulari();
  }

  /*
  * Métode que crida a diferents métodes en funció dels canvis del formulari
  */
  onChangesFormulari() {
    this.visualitzarObligatorietatDeCamps();
    this.visualitzarBlocAdreca();
    this.teAlias();
  }

  get adreces(): FormArray {
    return this.altaUsuariForm.get('adreces') as FormArray;
  }

  /**
   * Mètode per a afegir un nova adreça
   */
  afegirAdreca(adrecaUsuari, index) {
    const adrecaForm = this.formBuilder.group({
      adreca: this.adrecaService.getAddressFormGroup(),
      tipusAdreca: [null, Validators.required],
      dataIniciUbicacio: [null]
    });
    let dades = null;
    if (adrecaUsuari) {
      adrecaForm.get('tipusAdreca').setValue(adrecaUsuari.get('tipusAdreca').value);
      dades = adrecaUsuari.get('adreca').value;
    }
    const ref = this.dialogService.open(DialogFormulariAdrecaComponent, {
      data: {
        adrecaForm,
        dades
      },
      header: this.i18n({ id: 'dialogAdreca', value: 'Adreça' }),
      width: '90%',
      contentStyle: { 'max-height': '600px', overflow: 'auto' }
    });

    ref.onClose.subscribe((res: ResultDialogAdreca) => {
      if (res) {
        if (adrecaUsuari) {
          this.esborrarAdreca(index);
        }
        if (res.adrecaForm.get('adreca').get('esForaBarcelona').value === false) {
          res.adrecaForm.get('adreca').get('adrMunicipi').setValue(MUNICIPI_BARCELONA);
        }
        this.adreces.push(res.adrecaForm);
        this.ifHasGeoCoded(res.hasGeocoded);
      }
    });
  }

  ifHasGeoCoded(hasGeoCoded: boolean) {
    this.hasGeoCoded = hasGeoCoded;
  }

  /**
   * Mètode per a esborrar una adreça de l'usuari
   * @param index index de l'adreça
   */
  esborrarAdreca(index: number) {
    const adreca = this.adreces.at(index).get('adreca').value;
    if (adreca.ubicacioId) {
      const item = this.personaEditar.listBlocExpedientUbicacio.find(ubicacio => adreca.ubicacioId === ubicacio.ubicacioId);
      // item.dataFinalUbicacio = new Date().getTime();
      item.vigent = false;    
    }
    this.adreces.removeAt(index);
  }

  /**
   * Mètode per a esborrar una adreça de l'usuari
   * @param index index de l'adreça
   */
  editarAdreca(index: number) {
    this.afegirAdreca(this.adreces.controls[index], index);
  }

  /**
   * Métode que visualitza depenent del tipus de document els camps obligatoris
   */
  visualitzarObligatorietatDeCamps() {
    this.altaUsuariForm.get('tipusDocumentDid').valueChanges.subscribe(data => {
      if (data != null) {
        this.esMenor = this.esSenseDoc = this.esDni = this.esPassaport = this.esNie = false;
        if (data === 101705) {
          this.esMenor = true;
        } else if (data === 100004) {
          this.esSenseDoc = true;
        } else if (data === 100001) {
          this.esDni = true;
        } else if (data === 100002) {
          this.esNie = true;
        } else if (data === 100003) {
          this.esPassaport = true;
        }
      }
    });
  }

  /**
   * Métode que visualitza el bloc de adreces
   */
  visualitzarBlocAdreca() {
    this.altaUsuariForm.get('teAdreca').valueChanges.subscribe(data => {
      if (data) {
        this.altaUsuariForm.patchValue({ teAdreca: data }, { emitEvent: false });
      } else {
        this.altaUsuariForm.get('adreces').setValue([]);
      }
    });
  }

  /**
   * Mètode per a actualitzar si un usuari té alies o no
   */
  teAlias() {
    this.altaUsuariForm.get('alies').valueChanges.subscribe(data => {
      this.altaUsuariForm.patchValue({ teAlias: data !== '' }, { emitEvent: false });
    });
  }

  /**
   * Mètode per fer la preAlta
   */
  realitzarPrealta() {
    if (this.altaUsuariForm.valid) {
      this.esCarregat = false;
      this.formulariUsuariService.realitzarPrealta(this.altaUsuariForm.value).subscribe(prealta => {
        this.altaUsuariForm.patchValue({ realitzarPrealta: true });
        this.codiPreAlta = prealta.codiPreAlta;
        this.tractarDadesPrealta(prealta);
        this.esCarregat = true;
      }, error => {
        this.esCarregat = true;
        this.missatgeService.validationErrors = {
          status: '',
          message: ERRORS_ALTA_USUARI['001']
        }
      });
    } else {
      // if (this.altaUsuariForm.errors.dataNaixementNumber) {
      //   this.missatgeService.validationErrors = {
      //     status: '',
      //     message: ERRORS_ALTA_USUARI['504']
      //   }
      // }
      this.esCarregat = true;
      this.resetejarControls(this.altaUsuariForm);
      this.missatgeService.validationErrors = {
        status: '',
        message: ERRORS_ALTA_USUARI['000']
      }
    }
  }

  /**
   * Mètode per a tractar les dades de la prealta
   *
   * @param prealta dades de la prealta
   */
  tractarDadesPrealta(prealta: PreAlta) {
    if (prealta.listaExpedientId && prealta.listaExpedientId.length > 0) {
      this.formulariUsuariService.cercaUsuarisPerExpedient(prealta.listaExpedientId).subscribe(usuaris => {
        this.seleccionarPersonaSias(usuaris);
      });
    } else {
      this.altaUsuariForm.patchValue({ codiPreAlta: prealta.codiPreAlta });
      if (prealta.listaPersonasPadro && prealta.listaPersonasPadro.length > 0) {
        if (prealta.listaPersonasPadro.length === 1) {
          this.setejarDadesPrealta(prealta.listaPersonasPadro[0]);
        } else {
          this.seleccionarPersonaPadro(prealta.listaPersonasPadro);
        }
      }
    }
  }

  /**
   * Mètode per a setejar les dades de l'usuari obtingudes del padró.
   *
   * @param personaPadro dades del usuari del padro de la prealta
   */
  setejarDadesPrealta(personaPadro) {
    const dadesPrealta = this.formulariUsuariService.convertirDadesPrealta(personaPadro);
    this.altaUsuariForm.patchValue(dadesPrealta);
    this.deshabilitarCamps();
    this.tePadroPrealta = true;
  }

  /**
   * Mètode per obrir el dialeg amb el llistat de persones rebudes desde el padró
   *
   * @param listaPersonasPadro llistat de les persones del padró
   */
  seleccionarPersonaPadro(listaPersonasPadro) {
    const dialeg = this.dialogService.open(DialogLlistatUsuarisPadroComponent, {
      data: {
        usuaris: listaPersonasPadro
      },
      header: this.i18n({
        id: 'dialogllistatUsuariPadro',
        value: 'Llistat usuaris'
      }),
      width: '60%'
    });
    dialeg.onClose.subscribe((usuari) => {
      if (usuari && usuari !== 'cancelar') {
        this.setejarDadesPrealta(usuari);
      } else if (usuari === 'cancelar') {
        this.altaUsuariForm.patchValue({ codiPreAlta: this.codiPreAlta });
      }
    });
  }

  /**
   * Mètode per obrir el dialeg amb el llistat de expedients rebuts desde sias i que redirecciona a la seva fitxa
   */
  seleccionarPersonaSias(personasSias) {
    const dialeg = this.dialogService.open(DialogLlistatUsuarisSiasComponent, {
      data: {
        usuaris: personasSias
      },
      header: this.i18n({
        id: 'dialogllistatUsuariSIAS',
        value: 'Llistat usuaris'
      }),
      width: '60%',
      contentStyle: { 'max-height': '25em', overflow: 'auto' }
    });
    dialeg.onClose.subscribe((usuari) => {
      if (usuari && usuari !== 'cancelar') {
        // torrnar servei
        this.router.navigate(['usuaris/',usuari.expedientId]);
      } else if (usuari === 'cancelar') {
        this.altaUsuariForm.patchValue({ codiPreAlta: this.codiPreAlta });
      } else {
        this.codiPreAlta = null;
        this.altaUsuariForm.patchValue({ realitzarPrealta: false });
      }
    });
  }

  /**
   * Mètode que desa el formulari d'alta d'usuari
   */
  onSubmit() {
    if (this.altaUsuariForm.get('realitzarPrealta').value === false) {
      this.missatgeService.validationErrors = {
        status: '',
        message: ERRORS_ALTA_USUARI['503']
      }
    }
    this.esCarregat = false;
    if (this.altaUsuariForm.valid) {
      this.formulariUsuariService.desarUsuari(this.altaUsuariForm).subscribe(res => {
      console.log('onsubmit, no hay errores? ', this.altaUsuariForm)
        this.altaUsuariForm.patchValue({ realitzarAlta: true });
        this.sessionService.setAltaPersonaSol(
          {
            document: this.altaUsuariForm.get('document').value,
            tipusDocument: this.altaUsuariForm.get('tipusDocumentDid').value
          }
        );

        if(this.sessionQuery.isServiceViviendas()){
          this.router.navigate(['/vincular']);
        }else{
          this.router.navigate(['/sol·licituds/nueva/']);
        }
        
        this.missatgeService.validationSucces = {
          summary: '',
          detail: (SUCCES_ALTA_USUARI[501] + ' ' + res.expedientId)
        }
        this.esCarregat = true;
      }, error => {
        this.esCarregat = true;
        this.missatgeService.validationErrors = {
          status: '',
          message: ERRORS_ALTA_USUARI['000']
        }
      });
    } else {
      this.resetejarControls(this.altaUsuariForm);
      this.missatgeService.validationErrors = {
        status: '',
        message: ERRORS_ALTA_USUARI['000']
      }
      this.esCarregat = true;
    }
  }

  /**
   * Mètode per deshabilitar els camps de preAlta
   *
   */
  deshabilitarCamps() {
    this.altaUsuariForm.get('tipusDocumentDid').disable();
    this.altaUsuariForm.get('document').disable();
    this.altaUsuariForm.get('numTargetaSalut').disable();
    this.altaUsuariForm.get('nom').disable();
    this.altaUsuariForm.get('cognom1').disable();
    this.altaUsuariForm.get('cognom2').disable();
    this.altaUsuariForm.get('dataNaixementNumber').disable();
    this.altaUsuariForm.get('edat').disable();
    this.altaUsuariForm.get('paisNaixementDid').disable();
    this.altaUsuariForm.get('nacionalitatDid').disable();
    this.altaUsuariForm.get('adrecaPadro').disable();
  }

  /**
   * Mètode per deshabilitar el camp Numero de Document en els casos que no sigui obligatori
   */
  esSenseDocumentacio() {
    if (this.altaUsuariForm.get('tipusDocument').value) {
      const tipusDoc = this.altaUsuariForm.get('tipusDocument').value;  
      if ((tipusDoc === CODE_TIPO_DOCUMENTO_MENOR_SENSE_DOCUMENTS) || (tipusDoc === CODE_TIPO_DOCUMENTO_PERSONA_SENSE_DOCUMENTACIO)) {
        this.altaUsuariForm.get('document').disable();
        this.altaUsuariForm.get('document').setValue(null);
      } else {
        this.altaUsuariForm.get('document').enable();
      }
      this.altaUsuariForm.get('tipusDocumentDid').setValue(this.altaUsuariForm.get('tipusDocument').value);
    } else {
      this.esMenor = this.esSenseDoc = this.esDni = this.esPassaport = this.esNie = false;
      this.altaUsuariForm.get('tipusDocumentDid').setValue(null);
    }
  }

  /**
   * Mètode per a validar el formulari
   */
  resetejarControls(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.resetejarControls(control);
      }
    });
  }

  /**
   * Métode per calcular l'edat segons la data de naixement
   */
  calculEdat(tipus: string) {
    const dataNaixement = this.altaUsuariForm.get('dataNaixementNumber').value;
    const edat = this.altaUsuariForm.get('edat').value;
    if (tipus === 'data') {
      this.edat = moment().diff(dataNaixement, 'years');
      this.altaUsuariForm.get('edat').setValue(this.edat);
    } else if (tipus === 'edat') {
      if (dataNaixement != null && dataNaixement !== undefined) {
        this.altaUsuariForm.controls.dataNaixementNumber.setValue(moment(dataNaixement).subtract(edat - this.edat, 'years').toDate());
      } else {
        this.altaUsuariForm.controls.dataNaixementNumber.setValue(moment().subtract(edat, 'years').toDate());
      }
      this.edat = edat;
    }
  }

  /**
   * Mètode per a mostrar el missatge d'error corresponent al control
   *
   * @param controlName nom del control
   */
  mostrarError(controlName: string): boolean {
    return this.altaUsuariForm.get(controlName).touched && (this.altaUsuariForm.getError(controlName) || this.altaUsuariForm.get(controlName).invalid);
  }

  /**
   * Métode per mostrar les dades rebudes del sistema per a realitzar la modifiació de l'usuari
   * @param expedientId expedient de l'usuari
   */
  setDadesEditar(expedientId) {
    console.log('Hola entro en setDadesEditar ;;;;)')
    this.esCarregat = true;
    this.esEditar = true;
    forkJoin({
      usuari: this.usuarisService.getUsuarioByExpediente(expedientId),
      tipusAdreca: this.adrecaService.getTiposVia()
    }).subscribe(resposta => {
      this.personaEditar = {...resposta.usuari, codiPreAlta: null};
      if (resposta.usuari.blocBasiques.tipusDocumentDid === (101705 || 100004)) {
        this.altaUsuariForm.get('document').disable();
        this.altaUsuariForm.get('document').setValue(null);
      } else {
        this.altaUsuariForm.get('document').enable();
      }
      let plainObject = {
        ...resposta.usuari.blocBasiques,
        ...resposta.usuari.blocComplementaries,
        ...resposta.usuari.blocSalut,
        tipusDocument: {
          id: resposta.usuari.blocBasiques.tipusDocumentDid
        },
        dataNaixementNumber: resposta.usuari.blocBasiques.dataNaixement
      };
      plainObject = FormatterService.getUTCTimeFromDates(plainObject) as any;
      const adreces = resposta.usuari.listBlocExpedientUbicacio.filter(ubicacio => ubicacio.habilitat === true && ubicacio.dataFinalUbicacio == null);
      let adreces$ = null;
      if (adreces.length > 0) {
        adreces$ = adreces.map(ubicacio => this.adrecaService.getDireccionUsuarioByUbicacionId(ubicacio.ubicacioId));
      }

      forkJoin(
        adreces$ ? adreces$ : of(null),
      ).subscribe(adrecesRes => {
        Object.keys(this.altaUsuariForm.controls).forEach(control => {
          if (control !== 'adreces') {
            this.altaUsuariForm.get(control).setValue(plainObject[control]);
          }
        });
        if (adreces && adreces.length > 0) {
          this.altaUsuariForm.get('teAdreca').setValue(true);
          (adrecesRes as ConsultaAdrecaRDTO[]).forEach(adreca => {
            const adrecaUsuari = resposta.usuari.listBlocExpedientUbicacio
              .filter(ubicacio => ubicacio.habilitat === true && ubicacio.dataFinalUbicacio == null)
              .find(ubicacio => ubicacio.ubicacioId === adreca.ubicacioId);
            const adrecaForm = this.formBuilder.group({
              adreca: this.formBuilder.group(adreca),
              tipusAdreca: adrecaUsuari.tipusAdrecaDid,
              dataIniciUbicacio: adrecaUsuari.dataIniciUbicacio
            });
            this.adreces.push(adrecaForm);
          });
        }
        this.esCarregat = true;
      });
    });
  }

  /**
   * Métode per modificar l'usuari
   * @param personaEditar persona rebuda que serà editada
   * @param altaUsuariForm formulari a enviar
   * @param ubicacions ubicacions a editar
   *
   */
  modificarUsuari() {
    this.esCarregat = false;
    this.formulariUsuariService.actualitzarPersona(this.personaEditar, this.altaUsuariForm).subscribe(res => {
      this.router.navigate([this.personaEditar.blocBasiques.expedientId], { relativeTo: this.route.parent });
    }, error => {
      this.esCarregat = true;
    });
  }

  getAdrecaToString(direccion: FormGroup) {
    return this.formatterService.getAdrecaToString(direccion.getRawValue());
  }

  clickDesar() {
    if (this.esEditar === false) {
      this.onSubmit();
    } else {
      this.modificarUsuari();
    }
  }

  /**
   * Métode per eliminar el footer
   */
  // tslint:disable-next-line: use-life-cycle-interface
  ngOnDestroy() { }

}

