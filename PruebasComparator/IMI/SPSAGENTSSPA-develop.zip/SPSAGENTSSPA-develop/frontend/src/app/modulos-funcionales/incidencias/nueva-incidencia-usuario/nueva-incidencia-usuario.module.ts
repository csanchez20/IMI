import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NuevaIncidenciaUsuarioComponent } from './nueva-incidencia-usuario.component';
import { CabeceraUsuarioNuevaIncidenciaComponent } from './cabecera-usuario-nueva-incidencia/cabecera-usuario-nueva-incidencia.component';
import { DetalleNuevaIncidenciaModule } from '../nueva-incidencia/detalle-nueva-incidencia/detalle-nueva-incidencia.module';
import { MessageModule, PanelModule, AutoCompleteModule, InputTextModule, ButtonModule, MessagesModule, MessageService, DialogService } from 'primeng/primeng';
import { CargaDatosGenericosModule } from '@app/shared/componentes/carga-datos-genericos-spinner/carga-datos-genericos-spinner.module';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { DialogCercaUsuarioComponent } from './dialog-cerca-usuario/dialog-cerca-usuario.component';
import { DynamicDialogModule } from 'primeng/dynamicdialog';

@NgModule({
  declarations: [
    NuevaIncidenciaUsuarioComponent, 
    CabeceraUsuarioNuevaIncidenciaComponent, 
    DialogCercaUsuarioComponent
  ],
  imports: [
    CommonModule,
    DetalleNuevaIncidenciaModule,
    MessageModule,
    PanelModule,
    AutoCompleteModule,
    CargaDatosGenericosModule,
    InputTextModule,
    ButtonModule,
    MessagesModule,
    DatatableListModule,
    DynamicDialogModule
  ],
  bootstrap: [NuevaIncidenciaUsuarioComponent],
  providers: [
    MessageService,
    DialogService
  ],
  entryComponents: [DialogCercaUsuarioComponent]
})
export class NuevaIncidenciaUsuarioModule { }
