import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FacturaRDTO } from '@app/core/model/factura/factura';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PersonaConsultadesRDTO } from '@app/core/model/persona';
import { SolicitudQuery } from '@app/modulos-funcionales/solicitudes/nueva-solicitud/state';
import { I18nConfigService } from '../../../../../projects/spscompspa/src/app/services';
import { FacturaService } from '@app/servicios/factura/factura.service';
import { FileUpload } from 'primeng/primeng';
import { Router } from '@angular/router';
import moment from 'moment';
import { catchError } from 'rxjs/operators';
import { of, Subject } from 'rxjs';
import { RecursosService, SolicitudesService } from '@app/servicios';
import { ButonGestionDocumental } from '@app/shared/agrupaciones/boton-multifuncion-gestion-documentos/boton-multifuncion-gestion-documentos.component';
import { AltaDocumentRDTO } from '@app/core/model';

@Component({
  selector: 'app-nova-factura',
  templateUrl: './nova-factura.component.html',
  styleUrls: ['./nova-factura.component.scss']
})
export class NovaFacturaComponent implements OnInit {

  persona: PersonaConsultadesRDTO;
  form: FormGroup;
  error400 = false;
  messageError400: string;
  dataActualitzacioEstat;
  hasSubmitted = false;

  botonGestionDocumentalFactura: ButonGestionDocumental = {};
  botonGestionDocumentalTransparencia: ButonGestionDocumental = {};
  botonGestionDocumentalJustificacio: ButonGestionDocumental = {};

  constructor(
    public i18nConfig: I18nConfigService,
    private fb: FormBuilder,
    private solicitudQuery: SolicitudQuery,
    private facturaService: FacturaService,
    private router: Router,
    private cd: ChangeDetectorRef,
    private recursosService: RecursosService
  ) { }

  ngOnInit() {
    this.persona = this.solicitudQuery.getDatosPersona();
    this._ompleDadesButonsDocumentsAdd();
    this.recursosService.getRecursoActivoRESPIRPLUS(this.persona.blocBasiques.expedientId).subscribe(res => {
      this.dataActualitzacioEstat = moment(res.solicitudRespirPlusDTO.dataActualitzacioEstat).toDate();
      this._initForm();
    })
  }

  get emitterFactura() {
    return this.botonGestionDocumentalFactura
      && this.botonGestionDocumentalFactura.returnEmitter
        && this.botonGestionDocumentalFactura.returnEmitter.asObservable();
  }
  
  get emitterTransparencia() {
    return this.botonGestionDocumentalTransparencia
      && this.botonGestionDocumentalTransparencia.returnEmitter
        && this.botonGestionDocumentalTransparencia.returnEmitter.asObservable();
  }
  
  get emitterJustificacio() {
    return this.botonGestionDocumentalJustificacio
      && this.botonGestionDocumentalJustificacio.returnEmitter
        && this.botonGestionDocumentalJustificacio.returnEmitter.asObservable();
  }

  setDocumentFactura(documentFactura: AltaDocumentRDTO) {
    this.form.get('docFactOriginal').setValue(documentFactura.document);
  }

  setDocumentTransparencia(documentFactura: AltaDocumentRDTO) {
    this.form.get('docFullTransfer').setValue(documentFactura.document);
  }

  setDocumentJustificacio(documentFactura: AltaDocumentRDTO) {
    this.form.get('docJustificacio').setValue(documentFactura.document);
  }

  onSubmit() {
    this._emitButonsMultifuncions();
    this._setValid();
    this.hasSubmitted = true;
    if (this._validateDates() && !this.form.invalid) {
      let factura: FacturaRDTO = this.form.getRawValue();
      factura = {
        ...factura,
        dataFactura: moment(this.form.get('dataFactura').value).format('DD-MM-YYYY'),
        dataInici: moment(this.form.get('dataInici').value).format('DD-MM-YYYY'),
        dataFi: moment(this.form.get('dataFi').value).format('DD-MM-YYYY')
      }
      delete factura.docFactOriginal;
      delete factura.docJustificacio;
      delete factura.docFullTransfer;
      this._postFactura(factura);
    }
  }

  private _validateDates(): boolean {
    let valid = true;
    const dataFactura = moment(this.form.get('dataFactura').value).toDate()
    const param: Date = new Date();
    param.setMonth(11, 15);
    if ((this.dataActualitzacioEstat > dataFactura)
      || (dataFactura > param)) {
        this._setError();
        valid = false;
      }
    return valid;
  }

  private _postFactura(factura: FacturaRDTO) {
    const file1 = this.form.get('docFactOriginal').value;
    const file2 = this.form.get('docJustificacio').value;
    const file3 = this.form.get('docFullTransfer').value;
    this.facturaService.postFacturaRespirPlus(factura, file1, file2, file3)
      .subscribe(res => {
        if (res) {
          this.router.navigate([
            '/facturas/'
          ]);
        }
    })
  }

  private _setError() {
    this.error400 = true;
    this.messageError400 = "La data de la factura ha d'estar entre la data d'alta de la sol·licitud i el 15 de Desembre de l'any vigent.";
  }

  private _setValid() {
    this.error400 = false;
  }

  private _initForm() {
    this.form = this.fb.group({
      documentId: [{value: '', disabled: true}, Validators.required],
      dataFactura: ['', Validators.required],
      dataInici: ['', Validators.required],
      dataFi: ['', Validators.required],
      numRegResidencia: ['', Validators.required],
      comentaris: [''],
      dies: ['', Validators.required],
      preuPerDia: ['', Validators.required],
      importTotal: ['', Validators.required],
      docFactOriginal: [null, Validators.required],
      docFullTransfer: [null],
      docJustificacio: [null]
    });
    this.form.get('documentId').setValue(this.persona.blocBasiques.document);
  }

  private _ompleDadesButonsDocumentsAdd() {
    this.botonGestionDocumentalFactura = {
      documentId: null,
      returnEmitter: new Subject<void>()
    }
    this.botonGestionDocumentalTransparencia = {
      documentId: null,
      returnEmitter: new Subject<void>()
    }
    this.botonGestionDocumentalJustificacio = {
      documentId: null,
      returnEmitter: new Subject<void>()
    }
  }

  private _emitButonsMultifuncions() {
    this.botonGestionDocumentalFactura.returnEmitter.next();
    this.botonGestionDocumentalTransparencia.returnEmitter.next();
    this.botonGestionDocumentalJustificacio.returnEmitter.next();    
  }
}
