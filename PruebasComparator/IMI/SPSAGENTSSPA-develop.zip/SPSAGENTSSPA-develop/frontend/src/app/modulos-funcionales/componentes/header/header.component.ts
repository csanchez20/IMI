import { Location } from '@angular/common';
import {
  ChangeDetectionStrategy, Component, OnDestroy, OnInit, ViewEncapsulation
} from '@angular/core';
import { Router } from '@angular/router';
import { ImiSpsInfo } from '@app/core/auth/model';
import { SessionQuery, SessionService } from '@app/core/auth/state';
import { HttpStatusService } from '@app/core/interceptors';
import { ServiciosIMI } from '@app/core/model';
import { UserQuery } from '@app/modulos-funcionales/usuarios/state';
import { UsuariosService } from '@app/servicios/usuarios/usuarios.service';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { MenuItem, MessageService, SelectItem } from 'primeng/api';
import { Observable, Subscription } from 'rxjs';
export const ERROR_DURATION_SECONDS = 5;

@AutoUnsubscribe()
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit, OnDestroy {
  servicesList$: Observable<any>;
  currentService: SelectItem;
  currentLanguage: string;
  loading$ = this.httpStatus.loading$;
  acting$ = this.httpStatus.acting$;
  validationErrors$ = this.httpStatus.getvalidationErrors$;
  validationSuccess$ = this.httpStatus.getvalidationSuccess$;
  sub: Subscription;
  sub2: Subscription;
  sub3: Subscription;
  sub4: Subscription;

  constructor(
    private authService: SessionService,
    public authQuery: SessionQuery,
    public userQuery: UserQuery,
    private userService: UsuariosService,
    private httpStatus: HttpStatusService,
    private messageService: MessageService,
    public router: Router,
    public location: Location
  ) {}

  ngOnInit() {
    this.sub = this.authQuery.service$.subscribe(service => {
      if (service !== null) {
        this.sub4 = this.userService
        .getServiciosActivosUsuario()
        .subscribe(services => {
          let items: MenuItem[] = [];
          services.map(service => {
              const serviceActivo = this.authQuery.getServiceActiveValue();
              if (service.value !== ServiciosIMI.GUARDAMUEBLES
                && service.value === serviceActivo) {
                
                items = [
                  ...items,
                  {
                    label: service.label,
                    command: () => {
                      this.onChangeService(service);
                    }
                  }
                ];
                this.currentService = service;
                return;
              }
          });
        });
      }
    });

    this.sub2 = this.validationErrors$.subscribe(error => {
      this.messageService.add({
        key: 'error',
        severity: 'error',
        summary: `${error['status']}`,
        detail: error['message'],
        life: ERROR_DURATION_SECONDS * 1000
      });
    });

    this.sub3 = this.validationSuccess$.subscribe(message => {
      this.messageService.add({
        key: 'success',
        severity: 'success',
        life: ERROR_DURATION_SECONDS * 1000,
        ...message
      });
    });

  }

  onChangeService(service): void {
    this.authService.setService(service);
    this.authService.setPlacesSauv(null);
    this.router.navigate(['inici']);
  }

  logout() {
    this.authService.logout();
  }

  ngOnDestroy() {
    // We'll throw an error if it doesn't
  }

  get userRol() {
    return this.authQuery.getRoleUser();
  }

  canviarGrup(){
    this.authService.setService(null);
    this.currentService.label=null;
    this.currentService.value=null;
    const imiSpsInfo: ImiSpsInfo = {
      centro: null
    };

    this.authService.updateImiSpsInfo(imiSpsInfo);
    this.router.navigate(['/selecciona-centre/']);
  }
}
