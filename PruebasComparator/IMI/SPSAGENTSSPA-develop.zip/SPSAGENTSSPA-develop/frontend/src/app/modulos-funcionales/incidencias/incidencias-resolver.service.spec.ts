import { TestBed } from '@angular/core/testing';

import { IncidenciasResolverService } from './incidencias-resolver.service';

describe('IncidenciasResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IncidenciasResolverService = TestBed.get(IncidenciasResolverService);
    expect(service).toBeTruthy();
  });
});
