import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DiccionarioKey, DictionaryService, DictionaryQuery } from '@app/core/dictionary/state';
import { ResultatConsultaRespirRDTO } from '@app/core/model/solicitudes/solicitud-RESPIR';
import { DialogConfirmComponent } from '@app/shared/componentes/dialog-confirm/dialog-confirm.component';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { DialogService } from 'primeng/api';


import { Subscription, Observable, EMPTY } from 'rxjs';
import moment from 'moment';
import { SolicitudesService, CODE_ESTAT_SOL_VALIDADA_RESPIR, CODE_ESTAT_SOL_NOVALIDADA_RESPIR, CODE_ESTAT_SOL_CANCELLADA_RESPIR, CODE_ESTAT_SOL_APROVADA_RESPIR, CODE_ESTAT_SOL_DENEGADA_RESPIR, CODE_ESTAT_SOL_PENDIENTE_RESPIR, RecursosService } from '@app/servicios';
import { ActivatedRoute } from '@angular/router';
import { CODE_ESTAT_SOL_REQUERIMENT_RESPIR } from '../../../../../servicios/solicitudes/solicitudes.service';
import { ServeisPrestatsService } from '@app/servicios/equipaments/serveisPrestats.service';
import { Observacion, RespuestasEstados } from '@app/core/model/usuarios';
import { DialogMotivoComponent } from '@app/shared/agrupaciones/dialog-motivo/dialog-motivo.component';
import { catchError, map } from 'rxjs/operators';

@Component({
  selector: 'app-datos-basicos-solicitud-RESPIR',
  templateUrl: './datos-basicos-solicitud.component.html',
  styleUrls: ['./datos-basicos-solicitud.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class DatosBasicosSolicitudComponent implements OnInit {
  @Input() detalleSolRESPIR: ResultatConsultaRespirRDTO;
  @Output() cambioEstadoSolicitud: EventEmitter<any> = new EventEmitter<any>();

  loadedResults = false;
  sub: Subscription;
  withDialog = '40%';
  error: string = this.i18n({ id: 'noTieneSolicitud', value: 'No té sol·licitud' });

  diccionarioKey = DiccionarioKey;
  definicioServei: any;
  idSolicitud: number;
  definicioServeiId: number;
  tipusPlacaDid: number;
  noRespuestaActiva = true;

  constructor(
    private dialogService: DialogService,
    private i18n: I18n,
    public dictionaryQuery: DictionaryQuery,
    private dictionaryService: DictionaryService,
    private cd: ChangeDetectorRef,
    private solicitudesService: SolicitudesService,
    private route: ActivatedRoute,
    private definicioServeiService: ServeisPrestatsService,
    private recursosService: RecursosService
  ) {}

  ngOnInit() {
    this.idSolicitud = +this.route.snapshot.paramMap.get('idSolicitud');
    this.definicioServeiId = null;

    this.recursosService.getRecursBySollicitudId(''+this.idSolicitud).pipe(
      catchError(err => {
        if (err.status === 404) {
          this.noRespuestaActiva = false;
          this.cd.markForCheck();
          return EMPTY;
        }
      }),
      map(rec => {
        if (rec.estatRespostaDid === RespuestasEstados.CERRADO) {
          this.noRespuestaActiva = true;
        } else {
          this.noRespuestaActiva = false;
        }
        this.cd.markForCheck();
      })).subscribe();
      
    if (this.detalleSolRESPIR.estatSollicitud === CODE_ESTAT_SOL_APROVADA_RESPIR) {
      this.sub = this.definicioServeiService
        .getDefinicioServeiBySolicitud(this.idSolicitud)
        .subscribe(res => {
          if (res) {
            this.definicioServeiId = res.definicioServeiId;
            this.tipusPlacaDid = res.tipusPlacaDid;
            this.definicioServei = res;
          } else {
            this.definicioServeiId = null;
            this.tipusPlacaDid = null;
          }
          this.cd.markForCheck();
        });
    }
  }

  cancelarPressed() {
    const ref = this.dialogService.open(DialogMotivoComponent, {
      data: {
        pregunta: 'Per quin motiu vols cancel·lar la sol·licitud?'
      },
      header: 'Confirmació de cancel·lació',
      width: this.withDialog
    });

    ref.onClose.subscribe((motivo: any) => {
      if (motivo) {
        this.cambioEstadoSolicitud.emit({
          estatIdDesti: CODE_ESTAT_SOL_CANCELLADA_RESPIR,
          observacions: motivo
        });
      }
    });
  }

  acceptPressed() {
    const ref = this.dialogService.open(DialogConfirmComponent, {
      data: {
        confirmDeleteMessage: 'Estàs segur que vols acceptar la sol·licitud?',
        acceptLabel: this.i18n({ id: 'aceptar', value: 'Acceptar' }),
        cancelLabel: this.i18n({ id: 'cancelar', value: 'Cancel·lar' })
      },
      header: "Confirmació d'acceptació",
      width:this.withDialog,
    });

    this.sub = ref.onClose.subscribe((data: any) => {
      if (data) {
        this.cambioEstadoSolicitud.emit({
          estatIdDesti: CODE_ESTAT_SOL_APROVADA_RESPIR
        });
      }
    });
  }

  refusePressed() {
    const ref = this.dialogService.open(DialogConfirmComponent, {
      data: {
        confirmDeleteMessage: 'Estàs segur que vols denegar la sol·licitud?',
        acceptLabel: this.i18n({ id: 'denegar', value: 'Denegar' }),
        cancelLabel: this.i18n({ id: 'cancelar', value: 'Cancel·lar' }) 
      },
      header: 'Confirmació de denegació',
      width:this.withDialog,
    });

    this.sub = ref.onClose.subscribe((data: any) => {
      if (data) {
        this.cambioEstadoSolicitud.emit({
          estatIdDesti: CODE_ESTAT_SOL_DENEGADA_RESPIR
        });
      }
    });
  }

  enviarPressed() {
    const ref = this.dialogService.open(DialogConfirmComponent, {
      data: {
        confirmDeleteMessage:
          'Estàs segur que vols enviar la documentació pendent?',
        acceptLabel: this.i18n({ id: 'enviar', value: 'Enviar' }),
        cancelLabel: this.i18n({ id: 'cancelar', value: 'Cancel·lar' })
      },
      header: "Confirmació d'enviament de documentació pendent",
      width: '40%'
    });

    ref.onClose.subscribe((motivoCambioEstado: any) => {
      if (motivoCambioEstado) {
        //TODO: Enviar la Documentació a Backend
        this.cambioEstadoSolicitud.emit({
          estatIdDesti: CODE_ESTAT_SOL_PENDIENTE_RESPIR,
          observacions: ''
        });
      }
    });
  }

  showAceptarYDenegar() {
    return (
      this.detalleSolRESPIR.estatSollicitud === CODE_ESTAT_SOL_VALIDADA_RESPIR
    );
  }


  showCancelar() {
    const isIngresado = this.definicioServei && this.definicioServei.dataInici ? true : false;
    return (
      this.detalleSolRESPIR.estatSollicitud !== CODE_ESTAT_SOL_CANCELLADA_RESPIR &&
      this.detalleSolRESPIR.estatSollicitud !== CODE_ESTAT_SOL_DENEGADA_RESPIR &&
      this.detalleSolRESPIR.estatSollicitud !== CODE_ESTAT_SOL_NOVALIDADA_RESPIR &&
      !isIngresado
    );
  }

  showEnviar() {
    return (this.detalleSolRESPIR.estatSollicitud === CODE_ESTAT_SOL_REQUERIMENT_RESPIR);
  }


  download() {
    const fileName = 
      moment(this.detalleSolRESPIR.dataSollicitud).format('DD/MM/YYYY')
        + '_Solicitud_RESPIR_'
        + this.detalleSolRESPIR.expedientId;      

    this.solicitudesService.getPdfSollicitudRespir(this.idSolicitud, fileName).subscribe();
  }




}
