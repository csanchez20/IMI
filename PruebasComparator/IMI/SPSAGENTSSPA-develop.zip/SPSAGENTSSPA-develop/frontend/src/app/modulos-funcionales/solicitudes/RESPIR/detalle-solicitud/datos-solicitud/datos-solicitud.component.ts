import { Component, OnInit, Input } from '@angular/core';
import { ResultatConsultaRespirRDTO } from '@app/core/model/solicitudes/solicitud-RESPIR';

@Component({
  selector: 'app-datos-solicitud',
  templateUrl: './datos-solicitud.component.html',
  styleUrls: ['./datos-solicitud.component.scss']
})
export class DatosSolicitudComponent implements OnInit {

  @Input() detalleSolRESPIR: ResultatConsultaRespirRDTO;

  constructor(
  ) { }

  ngOnInit() {
  }

}
