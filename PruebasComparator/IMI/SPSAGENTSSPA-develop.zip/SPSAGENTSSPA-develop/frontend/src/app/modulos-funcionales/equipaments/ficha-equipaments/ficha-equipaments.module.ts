import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { TabViewModule, CardModule } from 'primeng/primeng';
import { DatosGestionEquipamentsModule } from './datos-gestion-equipaments/datos-gestion-equipaments.module';
import { ProfesionalesContactoModule } from './profesionales-contacto/profesionales-contacto.module';
import { FichaEquipamentsComponent } from './ficha-equipaments.component';
import { InspeccionModule } from './inspeccion/inspeccion.module';
import { AuditoriaModule } from './auditoria/auditoria.module';
import { ServiciosPrestadosEquipamentsModule } from './servicios-prestados-equipaments/servicios-prestados-equipaments.module';
import { CabeceraFichaEquipamentsComponent } from './cabecera-ficha-equipaments/cabecera-ficha-equipaments.component';
import { DocumentacionGeneralModule } from '@app/shared/agrupaciones/documentacion-general/documentacion-general.module';

@NgModule({
  declarations: [
    FichaEquipamentsComponent,
    CabeceraFichaEquipamentsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DatatableListModule,
    TabViewModule,
    CardModule,
    DatosGestionEquipamentsModule,
    ProfesionalesContactoModule,
    InspeccionModule,  
    AuditoriaModule,
    ServiciosPrestadosEquipamentsModule,
    DocumentacionGeneralModule
  ],
  exports: [
    FichaEquipamentsComponent,
    CabeceraFichaEquipamentsComponent
  ],
  providers: []
})
export class FichaEquipamentsModule { }
 