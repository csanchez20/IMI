import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SessionQuery } from '@app/core/auth';
import { DictionaryService } from '@app/core/dictionary/state';
import { InfoItem, TableData } from '@app/core/model/information';
import { AvisRDTO, ParamsAvisos } from '@app/core/model/notificaciones/aviso';
import { NotificacionesService } from '@app/servicios/notificaciones/notificaciones.service';
import { TareasRoutesResolverService } from '@app/servicios/tareas/tareas-routes-resolver.service';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { forkJoin, Observable, Subscription } from 'rxjs';


@AutoUnsubscribe()
@Component({
  selector: 'app-listado-avisos',
  templateUrl: './listado-avisos.component.html',
  styleUrls: ['./listado-avisos.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ListadoAvisosComponent implements OnInit, OnDestroy {

  @Input() change : Observable<void>;
  
  infoAvisos: InfoItem[] = [
    { field: 'text', header: this.i18n({ id: 'detalle', value: 'Detall' }) },
    {
      field: 'dataNotificacio',
      header: this.i18n({id: 'fechaNotificaicon',value: 'Data de notificació'}),
      type: 'timestamp'
    },
    {
      field: 'usuariCreacio',
      header: this.i18n({ id: 'remitente', value: 'Remitent' })
    },
    {
      field: 'acciones',
      header: this.i18n({ id: 'leido', value: 'Llegit' }),
      actionIcons: [
        {
          icon: 'fa fa-check', action: 'show'
        }
      ]
    }
  ];

  numRows = 5;
  tableData: TableData;
  tipoAvisoServicio: number[];
  sub: Subscription;
  paramsCercaAvisosProfId: ParamsAvisos = {};
  paramsCercaAvisosPerfilGrup: ParamsAvisos = {};

  constructor(
    private notificacionesService: NotificacionesService,
    private i18n: I18n,
    private cd: ChangeDetectorRef,
    private sessionQuery: SessionQuery,
    private dictionaryService: DictionaryService,
    public tareasRoutesResolver: TareasRoutesResolverService,
    private router: Router
  ) {}

  ngOnDestroy(): void {}

  ngOnInit() {
    this._initParamsCerca();
    this.getData();
    //Ens subscribim en el Observable per saber si es vol recarregar les dades.
    this.sub = this.change.subscribe( ()=> {
      this.getData();
    });
  }

  private _initParamsCerca() {
    this.paramsCercaAvisosProfId.professionalId = this.sessionQuery.getUserLoggedId();
    this.paramsCercaAvisosPerfilGrup.grupId = this.sessionQuery.getUserGrup();
    this.paramsCercaAvisosPerfilGrup.perfilId = this.sessionQuery.getRoleUserId();
    this.tipoAvisoServicio = this.notificacionesService.getTiposAvisosServicio();
  }

  getData(){
    this._setLoading(true);    

    forkJoin({
      avisosProfesionalId:  this.notificacionesService.getAvisos(this.paramsCercaAvisosProfId),
      avisosPerfilGrup:  this.notificacionesService.getAvisos(this.paramsCercaAvisosPerfilGrup),
    }).subscribe(respuesta => {
      this._setLoading(false);
      const pendingAvisos = [
        ...respuesta.avisosProfesionalId,
        ...respuesta.avisosPerfilGrup
      ];
      const avisos = pendingAvisos.filter(
        aviso => this.tipoAvisoServicio.includes(aviso.tipusNotificacioDid) && aviso.llegit === false
      );
      this.tableData = {
        rows:  avisos ? this._mapComentaris(avisos) : [],
        cols: this.infoAvisos,
        numRowsPerPage: this.numRows,
        numeroTotalResultados: avisos.length
      }
      this.cd.markForCheck();
    });
  }

  private _mapComentaris(avisos: AvisRDTO[]): AvisRDTO[] {
    return avisos.map(avis => {
      return {
        ...avis,
        text: avis.text + ' (' + avis.nomUsuari + ')'
      }
    })
  }

  avisoLeido(avis: AvisRDTO){
    let params: ParamsAvisos = {
      llegit: true,
      professionalId: avis.professionalId,
      tipusNotificacioDid: avis.tipusNotificacioDid,
      expedientId: avis.expedientId,
      text: avis.text
    }

    this.notificacionesService.putAviso(avis.notificacioId, params).subscribe(id => {
      this.getData();
      this.cd.markForCheck();
    });   
  }

  navigateToAviso(avis: AvisRDTO) {
    if(avis.url){
      //resolem la url que ens retorna Cintraos per poder nevagar al avis
      let url = this.tareasRoutesResolver.resolveUrl(avis.url);
      this.router.navigate([url]);
    } 
  }

  private _setLoading(loading: boolean) {
    this.tableData = {
      ...this.tableData,
      loading: loading,
      rows: null
    }
  }
  
}
