import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/api';
import { DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';
import { SessionQuery, IncidenciaType } from '@app/core/auth';
import { IncidenciaRDTO, ModificaIncidencia } from '@app/core/model';
import moment from 'moment';
import { IncidenciasService } from '@app/servicios/incidencias/incidencias.service';

@Component({
  selector: 'app-dialog-edit-detalle-incidencia',
  templateUrl: './dialog-edit-detalle-incidencia.component.html',
  styleUrls: ['./dialog-edit-detalle-incidencia.component.scss']
})
export class DialogEditDetalleIncidenciaComponent implements OnInit {

  incidencia: IncidenciaRDTO;
  form: FormGroup;

  diccionarioKey = DiccionarioKey;
  validators = Validators.required;
  tipoIncidencia: string;

  constructor(
    private fb: FormBuilder,
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    public dictionaryQuery: DictionaryQuery,
    private sessionQuery: SessionQuery,
    private incidenciaService: IncidenciasService
  ) {}

  ngOnInit() {
    this.tipoIncidencia = this.sessionQuery.getIncidenciaType() === IncidenciaType.USUARIO
      ? this.diccionarioKey.TIPO_INCIDENCIAS_USUARIO
      : this.diccionarioKey.TIPO_INCIDENCIAS_EQUIPAMENT;
    this.incidencia = this.config.data;
    this._initForm();
  }

  onSave() {
    if (this.form.valid) {
      const newIncidencia: ModificaIncidencia = {
        dataInici: moment(this.form.get('dates').value.start).valueOf(),
        dataFi: moment(this.form.get('dates').value.end).valueOf(),
        tipusEntitatDid: this.incidenciaService.getEntitatId(),
        ...this.form.value
      }
      delete newIncidencia['dates'];
      this._putIncidencia(newIncidencia);
    }
  }

  private _putIncidencia(incidencia: ModificaIncidencia) {
    this.incidenciaService.putIncidencia(
      this.incidencia.id,
      incidencia
    ).subscribe(res => {
      this.ref.close({
        ...incidencia,
        id: res.id
      });
    })
  }

  closeDialog() {
    this.ref.close();
  }

  private _initForm() {
    this.form = this.fb.group({
      gravetatIncidenciaDid: ['', Validators.required],
      dates: ['', Validators.required],
      tipusIncidenciaDid: ['', Validators.required],
      observacions: ['', Validators.required],
      descripcio: ['', Validators.required]
    });
    this.form.patchValue({
      ...this.incidencia,
      dates: {
        start: moment(this.incidencia.dataInici).toDate(),
        end: this.incidencia.dataFi
          ? moment(this.incidencia.dataFi).toDate()
          : null
      },
    });
  }

}
