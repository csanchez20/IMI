import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroListadoSolicitudesComponent } from './filtro-listado-solicitudes.component';

describe('FiltroListadoSolicitudesComponent', () => {
  let component: FiltroListadoSolicitudesComponent;
  let fixture: ComponentFixture<FiltroListadoSolicitudesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiltroListadoSolicitudesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltroListadoSolicitudesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
