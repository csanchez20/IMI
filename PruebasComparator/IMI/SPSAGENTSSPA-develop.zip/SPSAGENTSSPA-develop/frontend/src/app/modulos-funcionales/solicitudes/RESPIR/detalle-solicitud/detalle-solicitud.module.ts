import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { SharedModule } from '@app/shared/shared.module';
import { MomentModule } from 'ngx-moment';
import {
  ButtonModule,
  CardModule,
  DialogService,
  PanelModule,
  TabViewModule,
  InputTextModule,
  MessageModule
} from 'primeng/primeng';

import { DatosBasicosSolicitudComponent } from './datos-basicos-solicitud/datos-basicos-solicitud.component';
import { DatosSolicitudModule } from './datos-solicitud/datos-solicitud.module';
import { DetalleSolicitudComponent } from './detalle-solicitud.component';
import { DialogReclamacionDocumentoComponent } from '@app/shared/agrupaciones/dialog-reclamacion-documento/dialog-reclamacion-documento.component';
import { DialogReclamacionDocumentoModule } from '@app/shared/agrupaciones/dialog-reclamacion-documento/dialog-reclamacion-documento.module';
import { AppliedFiltersModule } from '../../../../../../projects/spscompspa/src/app/components/applied-filters/applied-filters.module';
import { DialogMotivoModule } from '@app/shared/agrupaciones/dialog-motivo/dialog-motivo.module';
import { DialogMotivoComponent } from '@app/shared/agrupaciones/dialog-motivo/dialog-motivo.component';
import { DocumentacionModule } from '../../nueva-solicitud/inicio-solicitud/documentacion/documentacion.module';
import { DocumentacionRespirModule } from './documentacion-respir/documentacion-respir.module';

@NgModule({
  declarations: [
    DetalleSolicitudComponent,
     DatosBasicosSolicitudComponent,
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    PanelModule,
    TabViewModule,
    CardModule,
    ButtonModule,
    DatatableListModule,
    SharedModule,
    AppliedFiltersModule,
    DatosSolicitudModule,
    DocumentacionModule,
    MomentModule,
    InputTextModule,
    DialogReclamacionDocumentoModule,
    DialogMotivoModule,
    MessageModule,
    DocumentacionRespirModule
  ],
  providers: [
    DialogService
  ],
  bootstrap: [
    DetalleSolicitudComponent
  ],
  entryComponents: [
    DialogReclamacionDocumentoComponent,
    DialogMotivoComponent
  ]
})
export class DetalleSolicitudModule {}
