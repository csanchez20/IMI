import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogExpiracioSessioComponent } from './dialog-expiracio-sessio.component';

describe('DialogExpiracioSessioComponent', () => {
  let component: DialogExpiracioSessioComponent;
  let fixture: ComponentFixture<DialogExpiracioSessioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogExpiracioSessioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogExpiracioSessioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
