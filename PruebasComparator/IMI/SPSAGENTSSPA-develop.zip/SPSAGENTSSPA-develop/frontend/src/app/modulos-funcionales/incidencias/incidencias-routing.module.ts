import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IncidenciasComponent } from './incidencias.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: IncidenciasComponent,
      },
      {
        path: 'nova',
        loadChildren: './nueva-incidencia/nueva-incidencia-generic.module#NuevaIncidenciaGenericModule',
        data: {
          breadcrumb: 'nuevaIncidencia'
        },
      },
      {
        path: ':idIncidencia',
        loadChildren: './detalle-incidencia/detalle-incidencia-generic.module#DetalleIncidenciaGenericModule',
        data: {
          breadcrumb: 'detalleIncidencia'
        }
      }
      // {
      //   path: ':idIncidencia',
      //   component: FichaIncidenciaComponent,
      //   resolve: { incidencia: FichaIncidenciaResolverService },
      //   data: {
      //     breadcrumb: 'detalleIncidencia'
      //   },
      // }
     
      
    ]
  }
];



@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IncidenciasRoutingModule { }
