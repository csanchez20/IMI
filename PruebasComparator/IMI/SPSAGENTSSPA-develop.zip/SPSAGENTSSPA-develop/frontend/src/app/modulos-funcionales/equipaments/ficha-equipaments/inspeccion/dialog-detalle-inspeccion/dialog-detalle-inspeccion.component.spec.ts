import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogDetalleInspeccionComponent } from './dialog-detalle-inspeccion.component';

describe('DialogDetalleInspeccionComponent', () => {
  let component: DialogDetalleInspeccionComponent;
  let fixture: ComponentFixture<DialogDetalleInspeccionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogDetalleInspeccionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogDetalleInspeccionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
