import { Component, OnInit, OnDestroy, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { ActivatedRoute } from '@angular/router';
import { InfoItem } from '@app/core/model/information';
import { of, Observable, forkJoin, Subscription } from 'rxjs';
import { ServeisPrestatsService, NOM_PARAM_SERVEIS_PRESTATS, DIA_INICI_REVISIO, DIA_INICI_OBERT, DIA_FI_OBERT, ESTAT_OBERT, ESTAT_TANCAT, ESTAT_REVISIO, KIT_SERVICIO_ID } from '@app/servicios/equipaments/serveisPrestats.service';
import { ParamServiciosPrestadosCentro, ServiciosPrestados, ServiciosPrestadosPersona, ServiciosPrestadosCentro, ParamsCercaDefinicioServei } from '@app/core/model/equipaments';
import { DatePipe } from '@angular/common';
import { DictionaryQuery, DictionaryService, DiccionarioKey } from '@app/core/dictionary/state';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { HttpStatusService } from '@app/core/interceptors';
import { SelectItem } from 'primeng/api';
import { ParametresGlobalsService } from '@app/servicios/parametres globals/parametres-globals.service';
import { SessionQuery } from '@app/core/auth';
import { catchError } from 'rxjs/operators';
import { ServeisPrestatsEquipamentsService } from '@app/servicios/equipaments/serveis-prestats-equipaments.service';

const SERVICIOS_PRESTADOS_PUNTUALES_ID = '2019102';
interface PersonaConServiciosPrestados {
  persona: ServiciosPrestadosPersona
  serviciosPrestados: Aux;
}
interface Aux {
  [id: number]: ServiciosPrestados;
}
interface HeaderCol {
  header: number;
  id: number;
}
@AutoUnsubscribe()
@Component({
  selector: 'app-servicios-prestados-equipaments',
  templateUrl: './servicios-prestados-equipaments.component.html',
  styleUrls: ['./servicios-prestados-equipaments.component.scss'],
  providers: [DatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ServiciosPrestadosEquipamentsComponent implements OnInit, OnDestroy {

  dictionaryServicios: any;
  
  diccionarioKey = DiccionarioKey;

  // MIN_OPEN_DAY = 11;
  // MAX_OPEN_DAY = 5;
  // MIN_REVISION_DAY = 6;

  minOpenDay: Number;
  maxOpenDay: Number;
  minRevisionDay: Number;

  idEquipament: string;
  cols: HeaderCol[] = [];
  personasConServiciosPrestados: PersonaConServiciosPrestados[] = [];
  foundPeople: boolean = false;
  modificarPressed: boolean = false;

  formParams: FormGroup = this.fb.group({
    any: [new Date().getFullYear(), Validators.required],
    mes: [new Date().getMonth(), Validators.required],
    dia: [new Date().getDate()]
  });

  clonedData: PersonaConServiciosPrestados[] = [];
  editable = false;
  // estado: [{label:'string', value:number}];
  estado: {label: string, value: number}[];
  estadoActual: SelectItem;

  mesos$: Observable<InfoItem[]> = of([
    { label: this.i18n({ id: 'enero', value: 'Gener' }), value: 0 },
    { label: this.i18n({ id: 'febrero', value: 'Febrer' }), value: 1 },
    { label: this.i18n({ id: 'marzo', value: 'Març' }), value: 2 },
    { label: this.i18n({ id: 'abril', value: 'Abril' }), value: 3 },
    { label: this.i18n({ id: 'mayo', value: 'Maig' }), value: 4 },
    { label: this.i18n({ id: 'junio', value: 'Juny' }), value: 5 },
    { label: this.i18n({ id: 'julio', value: 'Juliol' }), value: 6 },
    { label: this.i18n({ id: 'agosto', value: 'Agost' }), value: 7 },
    { label: this.i18n({ id: 'setiembre', value: 'Setembre' }), value: 8 },
    { label: this.i18n({ id: 'octubre', value: 'Octubre' }), value: 9 },
    { label: this.i18n({ id: 'noviembre', value: 'Novembre' }), value: 10 },
    { label: this.i18n({ id: 'diciembre', value: 'Desembre' }), value: 11 },
  ]);
  anys$: Observable<InfoItem[]>;

  constructor(
    private fb: FormBuilder,
    private serveisPrestatsService: ServeisPrestatsService,
    private serveisPrestatsEquipamentsService: ServeisPrestatsEquipamentsService,
    private route: ActivatedRoute,
    private i18n: I18n,
    public datepipe: DatePipe,
    public dictionaryQuery: DictionaryQuery,
    private dictionaryService: DictionaryService,
    private cd: ChangeDetectorRef,
    private httpStatusService: HttpStatusService,
    private parametresGlobalsService: ParametresGlobalsService,
    private sessionQuery: SessionQuery
  ) { }

  ngOnInit() {

    
    // Cargamos los tipos de servicios en el diccionario.
    this.dictionaryService.getServiciosPrestados().subscribe(dictionary => {
      this.dictionaryServicios = dictionary;
    });
    // Creamos un rango de años del 2000 -> al año actual
    let actualYear = new Date().getFullYear()
    let anys = [];
    for (let year = 2000; year <= actualYear; year++) {
      anys = [
        ...anys,
        {
          label: year,
          value: year
        }
      ]
    };
    this.anys$ = of(anys);
    
    this.estado = [
      {
        label: ESTAT_OBERT, value: 0
      },
      {
        label: ESTAT_REVISIO, value: 1
      },
      {
        label: ESTAT_TANCAT, value: 2
      }
    ]
    this.estadoActual = {label: '', value: -1, disabled: false};

    this.idEquipament = this.route.snapshot.paramMap.get('idEquipament');

    // Recuperem els parametres globals amb els dies per l'estat de Serveis Prestats
    this.sessionQuery.getPGlobalServeisPrestats().forEach(element =>{
      if (element.codiParametre === DIA_INICI_REVISIO) {
        this.minRevisionDay = +element.valor;
      }else if (element.codiParametre === DIA_INICI_OBERT) {
        this.minOpenDay = +element.valor;
      }else if (element.codiParametre === DIA_FI_OBERT) {
        this.maxOpenDay = +element.valor;
      }
    });

    this.updateServiciosPrestados();

  }

  initializeState() {    
    const dataPrestacio = new Date();
    dataPrestacio.setMonth(this.formParams.controls.mes.value);
    dataPrestacio.setFullYear(this.formParams.controls.any.value);

    
    const dataActual = new Date();

    // Miramos el mes actual del año actual
    if(dataActual.getMonth() === dataPrestacio.getMonth()
      && dataPrestacio.getFullYear() === dataActual.getFullYear()) {
      // Si el dia es mayor a 11 el estado es abierto
      if(dataActual.getDate() > this.minOpenDay) {        
        this.estadoActual.label = this.estado[0].label;
        this.estadoActual.disabled = false;
      }else {
        this.estadoActual.label = this.estado[2].label;
        this.estadoActual.disabled = true;
      }
    // Miramos el mes anterior del año actual
    }else if(dataPrestacio.getMonth() === dataActual.getMonth()-1
      && dataPrestacio.getFullYear() === dataActual.getFullYear()) {
      // Si el dia es inferior o igual a 5 el estado es abierto
      if(dataActual.getDate() <= this.maxOpenDay) {
        this.estadoActual.label = this.estado[0].label;
        this.estadoActual.disabled = false;
      }else if(dataActual.getDate() >= this.minRevisionDay && dataActual.getDate() <= this.minOpenDay) {
        this.estadoActual.label = this.estado[1].label;
        this.estadoActual.disabled = false;
      }else {
        this.estadoActual.label = this.estado[2].label;
        this.estadoActual.disabled = true;
      }
    // Resto de casos
    }else {
      this.estadoActual.label = this.estado[2].label;;
      this.estadoActual.disabled = true;
    }
  }
    
  updateServiciosPrestados() {
    this.initializeState();
    this.modificarPressed = false;
    //Primer dia de mes
    let dataIniciServei =  this.datepipe.transform(
      new Date(this.formParams.get('any').value, this.formParams.get('mes').value), 'dd/MM/yyyy'
    );
    //Ultim dia de mes
    let dataFinalServei = this.datepipe.transform(
      new Date(this.formParams.get('any').value, this.formParams.get('mes').value + 1, 0), 'dd/MM/yyyy'
    );
    const params: ParamServiciosPrestadosCentro = {
      centreId: this.idEquipament,
      dataPrestacio: dataIniciServei
    }      
    const paramsCercaDefinicio: ParamsCercaDefinicioServei = {
      centreId: this.idEquipament,
      dataInici: dataIniciServei,
      dataFinal: dataFinalServei,
      tipusRespostaDid: this.sessionQuery.getServiceActiveValue(),
      tipusPlanificacioDid: SERVICIOS_PRESTADOS_PUNTUALES_ID
    } 
    forkJoin({
      serviciosPrestados: this.serveisPrestatsService.getServiciosPrestados(paramsCercaDefinicio),
      personas: this.serveisPrestatsService.getServiciosPrestadosPersonas(params),
      serviciosCentro: this.serveisPrestatsService.getServiciosPrestadosCentro(params)
    }).subscribe(respuesta => {
      this.initServiciosCentro(respuesta.serviciosCentro);
      this.initPersonasConServicios(respuesta.personas);
      this.initPUTServiciosPrestados(respuesta.serviciosPrestados);
      this.initPOSTServiciosPrestados();
      this.cd.markForCheck();
    });
    
  }

  initServiciosCentro(serviciosCentro: ServiciosPrestadosCentro[]) {
    this.cols = [];
    serviciosCentro.map(servicio => {
      if (servicio.tipusServeiDid !== KIT_SERVICIO_ID) {
        this.cols = [
          ...this.cols,
          {
            header: servicio.tipusServeiDid,
            id: servicio.serveiContrCentreId
          }
        ];
      }
    });
  }

  initPUTServiciosPrestados(serviciosPrestados: ServiciosPrestados[]) {
    this.personasConServiciosPrestados = this.personasConServiciosPrestados.map(personaServicio => {
      serviciosPrestados.map(servicio => {
        if(servicio.recursId === personaServicio.persona.recursId) {
          personaServicio = {
            ...personaServicio,
            serviciosPrestados: {
              ...personaServicio.serviciosPrestados,
              [servicio.serveiContracteCentreId]: {
                ...servicio,
                mode: 'PUT'
              }
            }
          }
        }
      })
      return personaServicio
    })
  }
    
  initPOSTServiciosPrestados() {
    this.personasConServiciosPrestados = this.personasConServiciosPrestados.map(personaServicio => {
      this.cols.map(servicio => {
        if (!personaServicio.serviciosPrestados[servicio.id]) {
          personaServicio = {
            ...personaServicio,
            serviciosPrestados: {
              ...personaServicio.serviciosPrestados,
              [servicio.id]: {
                recursId: personaServicio.persona.recursId,
                serveiContracteCentreId: servicio.id,
                numUnitats: null,
                dataPrestacio: this.datepipe.transform(
                  new Date(this.formParams.get('any').value, this.formParams.get('mes').value), 
                  'dd/MM/yyyy'
                ),
                mode: 'POST'
              },
            }
          }
        }
      });
      return personaServicio;
    });
  }

  /**
   * Inicializamos el objeto personasConServiciosPrestados con las Personas
   * @param personas 
   */
  initPersonasConServicios(personas: ServiciosPrestadosPersona[]) {
    //El array de "personas" pot tenir persones repetides amb el mateix recursId o diferent.
    //Ens guardarem una array "personasUnicas" sense persones repetides amb el recursId mes petit 
    //si tenim repetida la mateixa persona amb diferensts recursId

    if(personas && personas.length>0 ){
      for(let persona of personas){
        persona['nom']=persona['nom'].split('null').join('');
      }
    }
    let personasUnicas: ServiciosPrestadosPersona[] = [];
    this.personasConServiciosPrestados = [];
    let expedientesDistintos = Array.from(new Set(personas.map(persona => persona.expedientId)));
    expedientesDistintos.map(expedientId => {
      let mismaPersona = personas.filter(persona => expedientId === persona.expedientId);
      let unicaPersona: ServiciosPrestadosPersona;
      unicaPersona = mismaPersona.reduce((unicaPersonaInicial: ServiciosPrestadosPersona, next) => {
        return unicaPersonaInicial.recursId < next.recursId ? unicaPersonaInicial : next ; 
      });

      this.personasConServiciosPrestados = [
        ...this.personasConServiciosPrestados,
        {
          persona: {
            nom: unicaPersona.nom,
            recursId: unicaPersona.recursId,
            expedientId: unicaPersona.expedientId
          },
          serviciosPrestados: {}
        }
      ];
    });

  }
  


  editServiciosPrestados() {

    this.modificarPressed = true;

    for(const persona of this.personasConServiciosPrestados) {
      if(persona.persona) {
        this.foundPeople = true;
      }
    }
    if(this.foundPeople && this.cols.length !== 0) {      
      this.editable = true;
      this.clonedData = JSON.parse(JSON.stringify( this.personasConServiciosPrestados));
    }
  }

  saveServiciosPrestados() {
    delete this.clonedData;
    this.editable = false;
    let serviciosPrestadosPUT: ServiciosPrestados[] = [];
    let serviciosPrestadosPOST: ServiciosPrestados[] = [];
    this.personasConServiciosPrestados.map(personaServicio => {
      this.cols.map(servicio => {
        if (personaServicio.serviciosPrestados[servicio.id].mode === 'PUT') {
          serviciosPrestadosPUT = [
            ...serviciosPrestadosPUT,
            personaServicio.serviciosPrestados[servicio.id]
          ]
        } else {
          if((personaServicio.serviciosPrestados[servicio.id].numUnitats != null) && 
          (personaServicio.serviciosPrestados[servicio.id].numUnitats != undefined)){
             serviciosPrestadosPOST = [
               ...serviciosPrestadosPOST,
               personaServicio.serviciosPrestados[servicio.id]
            ]
          }

        }        
      })
    });


    forkJoin({...this.sendFullRequest(serviciosPrestadosPUT, serviciosPrestadosPOST)}).pipe(
      catchError(err => {
        return of(null);
      }),
    ).subscribe(data => {

      if (data) {
        this.httpStatusService.validationSucces = {
          summary: this.i18n({ id: 'peticionCorrecta', value: 'Petició correcte' }),
          detail: this.i18n({ id: 'servicioEditadoCorr', value: 'Servei editat correctament' })
        }
      } else {
        this.httpStatusService.validationErrors = {
          summary: this.i18n({ id: 'peticionIncorrecta', value: 'Petició incorrecte' }),
          detail: this.i18n({ id: 'error', value: 'ERROR' })
        }
      }
      this.updateServiciosPrestados();
    });

    
  }

  cancelServiciosPrestados() {
    this.personasConServiciosPrestados = this.clonedData;
    delete this.clonedData;
    this.editable = false;
  }

  sendFullRequest(serviciosPrestadosPUT?: ServiciosPrestados[], serviciosPrestadosPOST?: ServiciosPrestados[]) {
    let obs: Observable<any>[] = [];
    if (serviciosPrestadosPUT.length !== 0) {
      obs = [
        ...obs,
        this.putServiciosPrestados(serviciosPrestadosPUT)
      ];
    }
    if (serviciosPrestadosPOST.length !== 0) {
      obs = [
        ...obs,
        this.postServiciosPrestados(serviciosPrestadosPOST)
      ]      
    }
    return obs;
  }

  postServiciosPrestados(serviciosPrestados: ServiciosPrestados[]) {    
    return this.serveisPrestatsEquipamentsService.postServiciosPrestados(serviciosPrestados);
  }

  putServiciosPrestados(serviciosPrestados: ServiciosPrestados[]) {
    return this.serveisPrestatsEquipamentsService.putServiciosPrestados(serviciosPrestados);
  }

  ngOnDestroy() { }

}
