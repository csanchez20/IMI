import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfesionalesContactoComponent } from './profesionales-contacto.component';

describe('ProfesionalesContactoComponent', () => {
  let component: ProfesionalesContactoComponent;
  let fixture: ComponentFixture<ProfesionalesContactoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfesionalesContactoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfesionalesContactoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
