import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PanelModule, CheckboxModule, ButtonModule, DialogModule } from 'primeng/primeng';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatosSolicitudComponent } from './datos-solicitud.component';
import { PeriodoSolicitudComponent } from './periodo-solicitud/periodo-solicitud.component';
import { DerivacionComponent } from './derivacion/derivacion.component';
import { DatosCuidadorComponent } from './datos-cuidador/datos-cuidador.component';
import { MomentModule } from 'ngx-moment';
import { SharedModule } from '@app/shared/shared.module';
import { FichaBasicaFamiliarRespirModule } from '@app/shared/agrupaciones/ficha-basica-familiar-respir/ficha-basica-familiar-respir.module';
@NgModule({
  declarations: [
    DatosSolicitudComponent,
    PeriodoSolicitudComponent,
    DerivacionComponent,
    DatosCuidadorComponent
  ],
  imports: [
    CommonModule,
    PanelModule,
    FormsModule,
    ReactiveFormsModule,
    FichaBasicaFamiliarRespirModule,
    MomentModule,
    SharedModule
  ],
  exports: [
    DatosSolicitudComponent,
    PeriodoSolicitudComponent,
    DerivacionComponent,
    DatosCuidadorComponent
  ]
})
export class DatosSolicitudModule { }
