import { ChangeDetectionStrategy, Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SessionQuery } from '@app/core/auth';
import { DiccionarioKey, DictionaryQuery } from '@app/core/dictionary/state';
import { OptionsDateRange } from '@app/core/model/filtros';
import { FiltersService } from '@app/core/services';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { Message } from 'primeng/api';
import { I18nConfigService } from '../../../../../../projects/spscompspa/src/app/services';


@AutoUnsubscribe()
@Component({
  selector: 'app-filtro-listado-solicitudes',
  templateUrl: './filtro-listado-solicitudes.component.html',
  styleUrls: ['./filtro-listado-solicitudes.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FiltroListadoSolicitudesComponent extends FiltersService
  implements OnInit, OnDestroy {
  @Output() selectedFilters: EventEmitter<any> = new EventEmitter<any>();
  dataOutput: any[] = []; // Objeto para enviar al servicio back para filtrar (con values)
  dataToAppliedFilters: any[] = []; // Objeto para enviar al componente applied-filters (con labels)

  diccionarioKey = DiccionarioKey;

  isServiceSAUV = this.sessionQuery.isServiceSAUV();
  isServiceRespir = this.sessionQuery.isServiceRespir();
  isServiceRespirPlus = this.sessionQuery.isServiceRespirPlus();
  isServiceGuardamobles = this.sessionQuery.isServiceGuardamuebles();

  form: FormGroup = this.fb.group({
    nomUsuari: [''],
    cognom1Usuari: [''],
    cognom2Usuari: [''],
    dates: [''],
    estatSollicitud: [''],
    datesPeriode: ['']
  });

  labels: string[] = [
    this.i18n({ id: 'nomUsuari', value: 'Nom usuari' }),
    this.i18n({ id: 'cognom1Usuari', value: 'Primer cognom' }),
    this.i18n({ id: 'cognom2Usuari', value: 'Segon cognom' }),
    this.i18n({ id: 'fechaInicioSol', value: 'Data inici sol·licitud' }),
    this.i18n({ id: 'fechaFinSol', value: 'Data fi sol·licitud' }),
    this.i18n({ id: 'estatSollicitud', value: 'Estat' }),
    this.i18n({ id: 'dataIniciPeriode', value: 'Data inici període' }),
    this.i18n({ id: 'dataFiPeriode', value: 'Data fi període' })
  ];

  msgs: Message[];

  private _valid = true;

  constructor(
    private fb: FormBuilder,
    public i18nConfig: I18nConfigService,
    public dictionaryQuery: DictionaryQuery,
    private i18n: I18n,
    public sessionQuery: SessionQuery
  ) {
    super();
  }

  ngOnInit() {}

  aplicaFiltros() {
    this._clearMsgs();
    this._hasValueValidInFilters() 
      ? this.onActivateFilters()
      : this._showError();
  }

  onActivateFilters() {
    this._valid = true;
    this.dataOutput = this.whenActivateFilters(this.form);
    this.dataToAppliedFilters = this.whenActivateFiltersToAppliedFilters(
      this.form
    );
    this.selectedFilters.emit(
      this.parseToParamsAux(
        this.dataOutput,
        this.buildOptionsDateRangePicker(this.dataOutput),
      )
    );
  }

  buildOptionsDateRangePicker(data): OptionsDateRange[] {
    const options: OptionsDateRange[] = [
      {
        formControlName: 'dates',
        keyStart: 'dataIniciSollicitud',
        keyEnd: 'dataFiSollicitud'
      },
      {
        formControlName: 'datesPeriode',
        keyStart: 'dataIniciPeriode',
        keyEnd: 'dataFiPeriode'
      }
    ]
    return options;
  }

  setFields(outputData: any) {
    this.whenSetFields(this.form, outputData);
  }

  setResetFilters() {
    this.whenSetResetFields(this.form);
  }

  estadosKeyByService() {
    if (this.isServiceSAUV) {
      return this.diccionarioKey.ESTADOS_SOLICITUD_SAUV;
    } else if (this.isServiceRespir) {
      return this.diccionarioKey.ESTADOS_SOLICITUD_RESPIR;
    } else if (this.isServiceRespirPlus) {
      return this.diccionarioKey.ESTADOS_SOLICITUD_RESPIRPLUS;
    } else if (this.isServiceGuardamobles) {
      return this.diccionarioKey.ESTADOS_SOLICITUD_GUARDAMOBLES;
    }
  }

  isValid() {
    return this._valid;
  }

  private _clearMsgs() {
    this.msgs = [];
  }

  private _showError() {
    this._valid = false;
    this.msgs = [
      {
        severity: 'error', 
        detail: this.i18n({ 
          id: 'minimo1Filtro3Caracteres', 
          value: 'Com a mínim hi ha d\'haver un filtre, si és un camp obert ha de tenir tres caràcters o més' 
        }),
        summary: this.i18n({
          id: 'atencion',
          value: 'ATENCIÓ'
        })
      }
    ];
  }

  private _hasValueValidInFilters(): boolean {
    let isValid = true;
    let atLeastOne = false;

    if (this._hasValue('nomUsuari')) {
      (this.form.get('nomUsuari').value.length < 3)
        ? (isValid = this._markAsError('nomUsuari'))
        : (atLeastOne = true)
    }
    if (this._hasValue('cognom1Usuari')) {
      (this.form.get('cognom1Usuari').value.length < 3)
        ? (isValid = this._markAsError('cognom1Usuari'))
        : (atLeastOne = true)
    }
    if (this._hasValue('cognom2Usuari')) {
      (this.form.get('cognom2Usuari').value.length < 3)
        ? (isValid = this._markAsError('cognom2Usuari'))
        : (atLeastOne = true)
    }
    if (this.form.get('dates').value
      && (this.form.get('dates').value['start']
      || this.form.get('dates').value['end'])) {
        atLeastOne = true;
    } 
    if (this._hasValue('estatSollicitud')) {
      atLeastOne = true;
    }
    if (this.isServiceRespir
      && this._hasValue('datesPeriode')
        && (this.form.get('datesPeriode').value['start']
        || this.form.get('datesPeriode').value['end'])) {
        atLeastOne = true;
    }
    
    return (isValid && atLeastOne);
    
  }

  private _hasValue(formControlName: string) {
    return (this.form.get(formControlName).value !== ''
      && this.form.get(formControlName).value !== null)
        ? true
        : false;
  }

  private _markAsError(formControlName: string) {
    this.form.get(formControlName).setErrors(Validators.required);
    return false;
  }

  ngOnDestroy() {}
}
