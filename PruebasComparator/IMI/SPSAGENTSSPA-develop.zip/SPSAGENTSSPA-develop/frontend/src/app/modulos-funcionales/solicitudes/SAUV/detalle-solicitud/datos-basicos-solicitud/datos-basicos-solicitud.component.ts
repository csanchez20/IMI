import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DiccionarioKey, DictionaryQuery } from '@app/core/dictionary/state';
import { DesassignaPlacaSauvRDTO } from '@app/core/model/solicitudes/plazas';
import { ResultatConsultaSauvRDTO } from '@app/core/model/solicitudes/solicitud-SAUV';
import { ServeisPrestatsService } from '@app/servicios/equipaments/serveisPrestats.service';
import { PlazasService } from '@app/servicios/solicitudes/plazas.service';
import {
  CODE_ESTAT_SOL_APROVADA_SAUV,
  CODE_ESTAT_SOL_CANCELADA_SAUV,
  CODE_ESTAT_SOL_DENEGADA_SAUV,
  CODE_ESTAT_SOL_PENDIENTE_SAUV,
  CODE_ESTAT_SOL_REQUERIMIENTO_SAUV,
  SolicitudesService,
} from '@app/servicios/solicitudes/solicitudes.service';
import { DialogConfirmComponent } from '@app/shared/componentes/dialog-confirm/dialog-confirm.component';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { DialogService } from 'primeng/api';
import { Subscription, EMPTY } from 'rxjs';

import { DialogMotivoComponent } from '../../../../../shared/agrupaciones/dialog-motivo/dialog-motivo.component';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { FormatterService } from '@app/core/services/formatter.service';
import { RecursosService } from '@app/servicios';
import { catchError, map } from 'rxjs/operators';
import { RespuestasEstados } from '@app/core/model';
import moment from 'moment';

@AutoUnsubscribe()
@Component({
  selector: 'app-datos-basicos-solicitud-SAUV',
  templateUrl: './datos-basicos-solicitud.component.html',
  styleUrls: ['./datos-basicos-solicitud.component.scss']
})
export class DatosBasicosSolicitudComponent implements OnInit, OnDestroy {
  @Input() datosBasicosSolicitud: ResultatConsultaSauvRDTO;
  @Output() cambioEstadoSolicitud: EventEmitter<any> = new EventEmitter<any>();

  definicioServei: any;
  idSolicitud: number;
  definicioServeiId: number;
  tipusPlacaDid: number;

  diccionarioKey = DiccionarioKey;

  noRespuestaActiva = true;

  private sub: Subscription;
  private sub2: Subscription;

  constructor(
    private dialogService: DialogService,
    private i18n: I18n,
    private cd: ChangeDetectorRef,
    public dictionaryQuery: DictionaryQuery,
    private route: ActivatedRoute,
    private definicioServeiService: ServeisPrestatsService,
    private plazasService: PlazasService,
    private formatterService: FormatterService,
    private recursosService: RecursosService,
    private solicitudesService: SolicitudesService
  ) {}

  ngOnInit() {
    this.idSolicitud = +this.route.snapshot.paramMap.get('idSolicitud');
    this.definicioServeiId = null;

    this.recursosService.getRecursBySollicitudId(''+this.idSolicitud).pipe(
      catchError(err => {
        if (err.status === 404) {
          this.noRespuestaActiva = false;
          this.cd.markForCheck();
          return EMPTY;
        }
      }),
      map(rec => {
        if (rec.estatRespostaDid === RespuestasEstados.CERRADO) {
          this.noRespuestaActiva = true;
        } else {
          this.noRespuestaActiva = false;
        }
        this.cd.markForCheck();
      })).subscribe();


    if (
      this.datosBasicosSolicitud.estatSollicitud ===
      CODE_ESTAT_SOL_APROVADA_SAUV
    ) {
      this.sub = this.definicioServeiService
        .getDefinicioServeiBySolicitud(this.idSolicitud)
        .subscribe(res => {
          if (res) {
            this.definicioServeiId = res.definicioServeiId;
            this.tipusPlacaDid = res.tipusPlacaDid;
            this.definicioServei = res;
          } else {
            this.definicioServeiId = null;
            this.tipusPlacaDid = null;
          }
          this.cd.markForCheck();
        });
    }
  }

  cancelarPressed() {
    const ref = this.dialogService.open(DialogMotivoComponent, {
      data: {
        pregunta: 'Per quin motiu vols cancel·lar la sol·licitud?'
      },
      header: 'Confirmació de cancel·lació',
      width: '40%'
    });

    ref.onClose.subscribe((motivo: any) => {
      if (motivo) {
        // Si la Solicitud esta aprobada hacer la desasignacion de plaza, finalizar la definicio de servei
        // y sumar una plaza en el centro en el que se habia hecho la asignacion
        let placa: DesassignaPlacaSauvRDTO;
        placa = {
          sollicitudId: this.idSolicitud,
          tipusPlacaDid: this.tipusPlacaDid
        };
        if (
          this.datosBasicosSolicitud.estatSollicitud ===
            CODE_ESTAT_SOL_APROVADA_SAUV &&
          this.definicioServeiId
        ) {
          this.sub2 = this.plazasService.unAsignPlaca(placa).subscribe(res => {
            this.cambioEstadoSolicitud.emit({
              estatIdDesti: CODE_ESTAT_SOL_CANCELADA_SAUV,
              observacions: motivo
            });
          });
        } else {
          this.cambioEstadoSolicitud.emit({
            estatIdDesti: CODE_ESTAT_SOL_CANCELADA_SAUV,
            observacions: motivo
          });
        }
      }
    });
  }

  enviarPressed() {
    const ref = this.dialogService.open(DialogConfirmComponent, {
      data: {
        confirmDeleteMessage:
          'Estàs segur que vols enviar la documentació pendent?',
        acceptLabel: this.i18n({ id: 'enviar', value: 'Enviar' }),
        cancelLabel: this.i18n({ id: 'cancelar', value: 'Cancel·lar' })
      },
      header: "Confirmació d'enviament de documentació pendent",
      width: '40%'
    });

    ref.onClose.subscribe((motivoCambioEstado: any) => {
      if (motivoCambioEstado) {
        //TODO: Enviar la Documentació a Backend
        this.cambioEstadoSolicitud.emit({
          estatIdDesti: CODE_ESTAT_SOL_PENDIENTE_SAUV,
          observacions: ''
        });
      }
    });
  }

  showCancelar() {
    const isIngresado =
      this.definicioServei && this.definicioServei.dataInici ? true : false;
    return (
      this.datosBasicosSolicitud.estatSollicitud !==
        CODE_ESTAT_SOL_CANCELADA_SAUV &&
      this.datosBasicosSolicitud.estatSollicitud !==
        CODE_ESTAT_SOL_DENEGADA_SAUV &&
      !isIngresado
    );
  }

  showEnviar() {
    return (
      this.datosBasicosSolicitud.estatSollicitud ===
      CODE_ESTAT_SOL_REQUERIMIENTO_SAUV
    );
  }

  getCentroDescr(centreId: string) {
    return this.formatterService.getCentroDescr(centreId);
  }

  download() {
    const fileName = 
      moment(this.datosBasicosSolicitud.dataSollicitud).format('DD/MM/YYYY')
        + '_Solicitud_SAUV_'
        + this.datosBasicosSolicitud.expedientId;      

    this.solicitudesService.getPdfSollicitudSAUV(this.idSolicitud, fileName).subscribe();
  }

  ngOnDestroy() {}

}
