import { Component, OnInit, Input } from '@angular/core';
import { ResultatConsultaRespirRDTO } from '@app/core/model/solicitudes/solicitud-RESPIR';

@Component({
  selector: 'app-periodo-solicitud',
  templateUrl: './periodo-solicitud.component.html',
  styleUrls: ['./periodo-solicitud.component.scss']
})
export class PeriodoSolicitudComponent implements OnInit {

  @Input() detalleSolRESPIR: ResultatConsultaRespirRDTO;
  
  constructor() { }

  ngOnInit() {
  }

}
