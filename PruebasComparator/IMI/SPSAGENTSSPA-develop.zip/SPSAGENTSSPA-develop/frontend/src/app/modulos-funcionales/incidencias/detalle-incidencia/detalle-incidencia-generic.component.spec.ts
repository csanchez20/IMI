import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleIncidenciaGenericComponent } from './detalle-incidencia-generic.component';

describe('DetalleIncidenciaGenericComponent', () => {
  let component: DetalleIncidenciaGenericComponent;
  let fixture: ComponentFixture<DetalleIncidenciaGenericComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalleIncidenciaGenericComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalleIncidenciaGenericComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
