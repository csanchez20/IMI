import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { DiccionarioKey, DictionaryQuery } from '@app/core/dictionary/state';
import { ResultatConsultaRespirRDTO } from '@app/core/model';
import { SolicitudesService } from '@app/servicios';
import { ButonGestionDocumental } from '@app/shared/agrupaciones/boton-multifuncion-gestion-documentos/boton-multifuncion-gestion-documentos.component';
import { TIPUS_ENTIDAD_RECURS } from '@app/shared/agrupaciones/documentacion-general/documentacion-general.component';
const TIPUS_DOCUMENT_DNI = 2071102;
const TIPUS_DOCUMENT_TARGETA_SANITARIA = 2071103;	
const TIPUS_DOCUMENT_INFORME_SOCIAL = 2071106;
const TIPUS_DOCUMENT_PERFIL_SOLLICITANT = 2071107;	
const TIPUS_DOCUMENT_INFORME_MEDIC = 2071108;
@Component({
  selector: 'app-documentacion-respir',
  templateUrl: './documentacion-respir.component.html',
  styleUrls: ['./documentacion-respir.component.scss']
})
export class DocumentacionRespirComponent implements OnInit {

  @Input() detalleSolRespir: ResultatConsultaRespirRDTO;

  fotocopiaDni: ButonGestionDocumental;
  fotocopiaTargetaSanitaria: ButonGestionDocumental;
  informeSocial: ButonGestionDocumental;
  perfilSollicitant: ButonGestionDocumental;
  informeMedico: ButonGestionDocumental;

  diccionarioKey = DiccionarioKey;

  constructor(
    private dictionaryQuery: DictionaryQuery,
    public solicitudService: SolicitudesService,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this._loadDocuments();
  }

  updateDocuments() {
    this.solicitudService.getDetalleSolicitudRESPIR(""+this.detalleSolRespir.sollicitudId).subscribe(res => {
      this.detalleSolRespir = res;
      this._loadDocuments();
      this.cd.markForCheck();
    })
  }

  private _loadDocuments() {
    this.fotocopiaDni = {
      documentId: this.detalleSolRespir.documentDni ?
        this.detalleSolRespir.documentDni.documentacioEntitatId
        : null,
      justificacio: this.detalleSolRespir.documentDni ?
        this.detalleSolRespir.documentDni.justificacio
        : null,
      dataPostDocument: {
        ...this.detalleSolRespir.documentDni,
        tipusDocumentDid: TIPUS_DOCUMENT_DNI,
        tipusEntitatDid: TIPUS_ENTIDAD_RECURS,
        entitatId: ""+this.detalleSolRespir.sollicitudId,
        titolDocument: this.dictionaryQuery.getItemDictionaryByKey(TIPUS_DOCUMENT_DNI, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR),
        tipusDocumentDidForm: this.dictionaryQuery.getAllItemDictionaryByKey(TIPUS_DOCUMENT_DNI, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR)
      }
    }
    this.fotocopiaTargetaSanitaria = {
      documentId: this.detalleSolRespir.documentTargetaSanitaria ?
        this.detalleSolRespir.documentTargetaSanitaria.documentacioEntitatId
        : null,
      justificacio: this.detalleSolRespir.documentTargetaSanitaria ?
        this.detalleSolRespir.documentTargetaSanitaria.justificacio
        : null,
      dataPostDocument: {
        ...this.detalleSolRespir.documentTargetaSanitaria,
        tipusDocumentDid: TIPUS_DOCUMENT_TARGETA_SANITARIA,
        tipusEntitatDid: TIPUS_ENTIDAD_RECURS,
        entitatId: ""+this.detalleSolRespir.sollicitudId,
        titolDocument: this.dictionaryQuery.getItemDictionaryByKey(TIPUS_DOCUMENT_TARGETA_SANITARIA, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR),
        tipusDocumentDidForm: this.dictionaryQuery.getAllItemDictionaryByKey(TIPUS_DOCUMENT_TARGETA_SANITARIA, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR)
      }
    }
    this.informeSocial = {
      documentId: this.detalleSolRespir.documentInformeSocial ?
        this.detalleSolRespir.documentInformeSocial.documentacioEntitatId
        : null,
      justificacio: this.detalleSolRespir.documentInformeSocial ?
        this.detalleSolRespir.documentInformeSocial.justificacio
        : null,
      dataPostDocument: {
        ...this.detalleSolRespir.documentInformeSocial,
        tipusDocumentDid: TIPUS_DOCUMENT_INFORME_SOCIAL,
        tipusEntitatDid: TIPUS_ENTIDAD_RECURS,
        entitatId: ""+this.detalleSolRespir.sollicitudId,
        titolDocument: this.dictionaryQuery.getItemDictionaryByKey(TIPUS_DOCUMENT_INFORME_SOCIAL, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR),
        tipusDocumentDidForm: this.dictionaryQuery.getAllItemDictionaryByKey(TIPUS_DOCUMENT_INFORME_SOCIAL, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR)
      }
    }
    this.perfilSollicitant = {
      documentId: this.detalleSolRespir.documentPerfilSollicitant ?
        this.detalleSolRespir.documentPerfilSollicitant.documentacioEntitatId
        : null,
      justificacio: this.detalleSolRespir.documentPerfilSollicitant ?
        this.detalleSolRespir.documentPerfilSollicitant.justificacio
        : null,
      dataPostDocument: {
        ...this.detalleSolRespir.documentPerfilSollicitant,
        tipusDocumentDid: TIPUS_DOCUMENT_PERFIL_SOLLICITANT,
        tipusEntitatDid: TIPUS_ENTIDAD_RECURS,
        entitatId: ""+this.detalleSolRespir.sollicitudId,
        titolDocument: this.dictionaryQuery.getItemDictionaryByKey(TIPUS_DOCUMENT_PERFIL_SOLLICITANT, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR),
        tipusDocumentDidForm: this.dictionaryQuery.getAllItemDictionaryByKey(TIPUS_DOCUMENT_PERFIL_SOLLICITANT, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR)
      }
    }
    this.informeMedico = {
      documentId: this.detalleSolRespir.documentInformeMedic ?
        this.detalleSolRespir.documentInformeMedic.documentacioEntitatId
        : null,
      justificacio: this.detalleSolRespir.documentInformeMedic ?
        this.detalleSolRespir.documentInformeMedic.justificacio
        : null,
      dataPostDocument: {
        ...this.detalleSolRespir.documentInformeMedic,
        tipusDocumentDid: TIPUS_DOCUMENT_INFORME_MEDIC,
        tipusEntitatDid: TIPUS_ENTIDAD_RECURS,
        entitatId: ""+this.detalleSolRespir.sollicitudId,
        titolDocument: this.dictionaryQuery.getItemDictionaryByKey(TIPUS_DOCUMENT_INFORME_MEDIC, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR),
        tipusDocumentDidForm: this.dictionaryQuery.getAllItemDictionaryByKey(TIPUS_DOCUMENT_INFORME_MEDIC, this.diccionarioKey.TIPO_DOCUMENTOS_ADJUNTOS_RESPIR)
      }
    }
  }
}
