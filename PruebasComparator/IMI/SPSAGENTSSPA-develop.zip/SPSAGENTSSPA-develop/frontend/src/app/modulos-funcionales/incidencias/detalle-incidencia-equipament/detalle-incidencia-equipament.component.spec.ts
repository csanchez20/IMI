import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleIncidenciaEquipamentComponent } from './detalle-incidencia-equipament.component';

describe('DetalleIncidenciaEquipamentComponent', () => {
  let component: DetalleIncidenciaEquipamentComponent;
  let fixture: ComponentFixture<DetalleIncidenciaEquipamentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalleIncidenciaEquipamentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalleIncidenciaEquipamentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
