import { Component, OnInit } from '@angular/core';
import { IncidenciaType, SessionQuery } from '@app/core/auth';

@Component({
  selector: 'app-nueva-incidencia-generic',
  templateUrl: './nueva-incidencia-generic.component.html',
  styleUrls: ['./nueva-incidencia-generic.component.scss']
})
export class NuevaIncidenciaGenericComponent implements OnInit {

  moduleName: string;

  constructor(
    private sessionQuery: SessionQuery
  ) { }

  ngOnInit() {
    this._setModule(
      this.sessionQuery.getIncidenciaType()
    );
  }

  private _setModule(type: IncidenciaType) {
    if (type === IncidenciaType.EQUIPAMENT) {
      this.moduleName = 'src/app/modulos-funcionales/incidencias/nueva-incidencia-equipament/nueva-incidencia-equipament.module#NuevaIncidenciaEquipamentModule';
    } else if (type === IncidenciaType.USUARIO) {
      this.moduleName = 'src/app/modulos-funcionales/incidencias/nueva-incidencia-usuario/nueva-incidencia-usuario.module#NuevaIncidenciaUsuarioModule';
    }
  }

}
