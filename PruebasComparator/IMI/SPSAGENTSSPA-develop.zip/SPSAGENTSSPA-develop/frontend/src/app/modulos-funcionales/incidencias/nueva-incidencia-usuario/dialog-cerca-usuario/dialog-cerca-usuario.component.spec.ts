import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogCercaUsuarioComponent } from './dialog-cerca-usuario.component';

describe('DialogCercaUsuarioComponent', () => {
  let component: DialogCercaUsuarioComponent;
  let fixture: ComponentFixture<DialogCercaUsuarioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogCercaUsuarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogCercaUsuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
