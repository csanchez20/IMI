import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SeleccionaCentreComponent } from './selecciona-centre.component';
import { SeleccionaCentreRoutingModule } from './selecciona-centre-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule, DropdownModule, MessageModule } from 'primeng/primeng';
import { SharedModule } from '@app/shared/shared.module';

@NgModule({
  declarations: [SeleccionaCentreComponent],
  imports: [
    CommonModule,
    SeleccionaCentreRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    DropdownModule,
    ButtonModule,
    MessageModule,
    SharedModule
  ]
})
export class SeleccionaCentreModule { }
