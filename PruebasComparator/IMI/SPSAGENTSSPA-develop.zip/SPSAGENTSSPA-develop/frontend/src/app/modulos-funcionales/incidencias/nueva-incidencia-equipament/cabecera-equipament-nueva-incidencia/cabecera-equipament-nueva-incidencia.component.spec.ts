import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CabeceraEquipamentNuevaIncidenciaComponent } from './cabecera-equipament-nueva-incidencia.component';

describe('CabeceraEquipamentNuevaIncidenciaComponent', () => {
  let component: CabeceraEquipamentNuevaIncidenciaComponent;
  let fixture: ComponentFixture<CabeceraEquipamentNuevaIncidenciaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CabeceraEquipamentNuevaIncidenciaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CabeceraEquipamentNuevaIncidenciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
