import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DetalleConsultaIncidenciaComponent } from './detalle-consulta-incidencia.component';
import { PanelModule } from 'primeng/panel';
import { DialogEditDetalleIncidenciaComponent } from './dialog-edit-detalle-incidencia/dialog-edit-detalle-incidencia.component';
import { DialogService } from 'primeng/api';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { SharedModule } from '@app/shared/shared.module';
import { InputTextareaModule, DropdownModule, InputTextModule } from 'primeng/primeng';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RangeDatePickerModule } from '../../../../../../projects/spscompspa/src/public_api';

@NgModule({
  declarations: [
    DetalleConsultaIncidenciaComponent, 
    DialogEditDetalleIncidenciaComponent
  ],
  imports: [
    CommonModule,
    PanelModule,
    DynamicDialogModule,
    SharedModule,
    InputTextareaModule,
    DropdownModule,
    InputTextModule,
    RangeDatePickerModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    DetalleConsultaIncidenciaComponent,
    DialogEditDetalleIncidenciaComponent
  ],
  providers: [DialogService],
  entryComponents: [DialogEditDetalleIncidenciaComponent]
})
export class DetalleConsultaIncidenciaModule { }
