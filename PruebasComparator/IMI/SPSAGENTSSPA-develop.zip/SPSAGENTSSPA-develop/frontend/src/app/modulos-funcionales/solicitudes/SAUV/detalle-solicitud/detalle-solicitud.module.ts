import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TabViewModule, CardModule, ButtonModule, PanelModule, DialogService, InputTextareaModule,  } from 'primeng/primeng';
import { DetalleSolicitudComponent } from './detalle-solicitud.component';
import { DatosBasicosSolicitudComponent } from './datos-basicos-solicitud/datos-basicos-solicitud.component';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '@app/shared/shared.module';
import { SituacionContextoModule } from './situacion-contexto/situacion-contexto.module';
import { AppliedFiltersModule } from '../../../../../../projects/spscompspa/src/public_api';
import { DialogMotivoComponent } from '@app/shared/agrupaciones/dialog-motivo/dialog-motivo.component';
import { DialogMotivoModule } from '../../../../shared/agrupaciones/dialog-motivo/dialog-motivo.module';
import { DocumentacionModule } from '../../nueva-solicitud/inicio-solicitud/documentacion/documentacion.module';
import { DocumentacionSauvModule } from './documentacion-sauv/documentacion-sauv.module';

@NgModule({
  declarations: [
    DetalleSolicitudComponent,
    DatosBasicosSolicitudComponent,
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    PanelModule,
    TabViewModule,
    CardModule,
    ButtonModule,
    InputTextareaModule,
    DatatableListModule,
    SharedModule,
    AppliedFiltersModule,
    SituacionContextoModule,
    DocumentacionModule,
    DialogMotivoModule,
    DocumentacionSauvModule
  ],
  providers: [
    DialogService
  ],
  bootstrap: [
    DetalleSolicitudComponent
  ],
  entryComponents:[
    DialogMotivoComponent
  ]
})
export class DetalleSolicitudModule { }
