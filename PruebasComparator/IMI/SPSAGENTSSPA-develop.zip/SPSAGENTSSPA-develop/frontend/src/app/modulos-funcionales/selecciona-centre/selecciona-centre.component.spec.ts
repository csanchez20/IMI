import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeleccionaCentreComponent } from './selecciona-centre.component';

describe('SeleccionaCentreComponent', () => {
  let component: SeleccionaCentreComponent;
  let fixture: ComponentFixture<SeleccionaCentreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeleccionaCentreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeleccionaCentreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
