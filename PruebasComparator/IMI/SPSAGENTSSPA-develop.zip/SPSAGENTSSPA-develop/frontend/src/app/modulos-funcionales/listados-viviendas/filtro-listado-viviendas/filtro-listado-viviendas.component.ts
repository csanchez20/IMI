import { ChangeDetectorRef, Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SessionQuery } from '@app/core/auth';
import { ParamListadoEquipament, SERVICIO_VIVIENDAS } from '@app/core/model';
import { OptionsDateRange } from '@app/core/model/filtros';
import { FiltersService } from '@app/core/services';
import { EquipamentsService } from '@app/servicios';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { Message, SelectItem } from 'primeng/api';
import { I18nConfigService } from '../../../../../projects/spscompspa/src/app/services';

@Component({
  selector: 'app-filtro-listado-viviendas',
  templateUrl: './filtro-listado-viviendas.component.html',
  styleUrls: ['./filtro-listado-viviendas.component.scss']
})
export class FiltroListadoViviendasComponent extends FiltersService implements OnInit {

  @Output() selectedFilters: EventEmitter<any> = new EventEmitter<any>();

  labels: string[] = [
    this.i18n({id:'centre', value: 'Centre'}),
    this.i18n({ id: 'dataIniciViviendas', value: 'Data inici' }),
    this.i18n({ id: 'dataFiViviendas', value: 'Data fi' }),
  ];

  form: FormGroup;

  dataOutput: any[] = [];
  dataToAppliedFilters: any[] = [];
  msgs: Message[];
  centres: SelectItem[] = [];
  private _valid = true;

  constructor(
    private i18n: I18n,
    public i18nConfig: I18nConfigService,
    private fb: FormBuilder,
    private equipamentsService: EquipamentsService,
    private sessionQuery: SessionQuery,
    private cd: ChangeDetectorRef
  ) { 
    super();
  }

  ngOnInit() {
    const paramsEquipaments: ParamListadoEquipament = {
      estat: true,
      tipusRespostaDid: SERVICIO_VIVIENDAS
    }
    this.form = this.fb.group({
      centre:[{value: '', disabled: true}],
      dates: ['', Validators.required]
    });
    this.equipamentsService.getEquipamentsLite(paramsEquipaments).subscribe(res => {
      this.centres = res;
      this._checkIfHasCentre();
    });
      }

  aplicarFiltros(){
    this.msgs=[];
    this._hasValueValidInFilters() 
      ? this.onActivateFilters()
      : this._showError();
  }

  private _checkIfHasCentre() {
    const dadesCentreUsuari = this.sessionQuery.getDadesCentreUsuari();
    if (dadesCentreUsuari && dadesCentreUsuari.centreId) {
      this.form.get('centre').setValue(this.centres.find(c => c.value === dadesCentreUsuari.centreId));
      this.form.get('centre').disable();
    } else {
      this.form.get('centre').enable();
    }
  }

  private _showError() {
    this._valid = false;
    this.msgs = [
      {
        severity: 'error', 
        detail: this.i18n({ 
          id: 'filtrosFechas', 
          value: 'S\'ha d\'informar la data d\'inici i la data de fi' 
        }),
        summary: this.i18n({
          id: 'atencion',
          value: 'ATENCIÓ'
        })
      }
    ];
  }

  private _hasValueValidInFilters(): boolean {
    let isValid = true;

    if (!this.form.get('dates').value
      || !this.form.get('dates').value['start']
      || !this.form.get('dates').value['end']) {
        isValid = this._markAsError('dates')
    } 
    
    return isValid;
    
  }

  onActivateFilters() {
    this.dataOutput = this.whenActivateFilters(this.form);
    this.dataToAppliedFilters = this.whenActivateFiltersToAppliedFilters(this.form);
    this.selectedFilters.emit(this.parseToParamsAux(this.dataOutput,
      this.buildOptionsDateRangePicker()
      ),
    );
  }

  buildOptionsDateRangePicker(): OptionsDateRange[] {
    const options: OptionsDateRange[] = [
      {
        formControlName: 'dates',
        keyStart: 'dataInici',
        keyEnd: 'dataBaixa'
      }
    ]
    return options;
  }

  setFields(outputData: any) {
    this.whenSetFields(this.form, outputData);
  }

  setResetFilters() {
    this.whenSetResetFields(this.form);
  }

  private _markAsError(formControlName: string) {
    this.form.get(formControlName).setErrors(Validators.required);
    this.form.updateValueAndValidity();
    return false;
  }

}
