import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DetalleNuevaIncidenciaComponent } from './detalle-nueva-incidencia.component';
import { DropdownModule, PanelModule, InputTextareaModule } from 'primeng/primeng';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RangeDatePickerModule } from '../../../../../../projects/spscompspa/src/public_api';

@NgModule({
  declarations: [
    DetalleNuevaIncidenciaComponent
  ],
  imports: [
    CommonModule,
    RangeDatePickerModule,
    DropdownModule,
    PanelModule,
    InputTextareaModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    DetalleNuevaIncidenciaComponent
  ]
})
export class DetalleNuevaIncidenciaModule { }
