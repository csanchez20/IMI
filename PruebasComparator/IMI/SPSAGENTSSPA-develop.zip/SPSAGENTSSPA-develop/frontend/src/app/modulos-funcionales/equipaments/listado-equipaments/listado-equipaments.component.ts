import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TableData, InfoItem } from '@app/core/model/information';
import { EquipamentsService } from '@app/servicios/equipaments/equipaments.service';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { CentreggCercadesRDTO, ParamListadoEquipament, EquipamentsLiteCerca } from '@app/core/model/equipaments';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { SessionQuery } from '@app/core/auth';
import { map, catchError } from 'rxjs/operators';
import { EMPTY, Subscription } from 'rxjs';
import { HttpStatusService } from '@app/core/interceptors';
import moment from 'moment';

@AutoUnsubscribe()
@Component({
  selector: 'app-listado-equipaments',
  templateUrl: './listado-equipaments.component.html',
  styleUrls: ['./listado-equipaments.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class ListadoEquipamentsComponent implements OnInit, OnDestroy {

  dataEquipaments: TableData;
  info: InfoItem[] = [
    { field: 'nom', header: this.i18n({ id: 'nombreEquipament', value: 'Nom Equipament' }) },
    { field: 'nomEmpresa', header: this.i18n({ id: 'nombreEmpresaGestora', value: 'Nom Empresa Gestora' }) },
    { field: 'codiEquipament', header: this.i18n({ id: 'numRegistro', value: 'Número de registre' }) },
    { field: 'estat', header: this.i18n({ id: 'actiu', value: 'Actiu' }), type:'checkbox' }
  ];

  tableButtons: InfoItem[] = [
    { 
      action: 'export', 
      label: 
        moment(new Date()).format('DD/MM/YYYY') 
        + '_Llistat_equipaments'
    }
  ]

  showFilters = false;
  filtersApplied: ParamListadoEquipament = {};

  private sub: Subscription;

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    private equipamentService: EquipamentsService,
    private i18n: I18n,
    private cd: ChangeDetectorRef,
    public sessionQuery: SessionQuery,
    private httpStatusService: HttpStatusService
  ) { }

  ngOnInit(): void {
    this._resetFilters();
    this._saveEquipamentsToTable(null);
  }

  getEquipamentsLite(params: ParamListadoEquipament){
    this._setLoading(true);
    this.sub = this.equipamentService
      .getEquipaments(params)
      .pipe(
        catchError(err => {
          this._setLoading(false);
          if(err.status === 404) {
            this._saveEquipamentsToTable({
              content: [],
              total: 0,
              pageNumber: -1,
              pageSize: 0
            });
            return EMPTY;
          } else {
            this.httpStatusService.validationErrors = err;
          }
        }), 
        map((equipaments) => {
          this._saveEquipamentsToTable(equipaments);
        })
      )
      .subscribe();      
}

  _saveEquipamentsToTable(equipaments: EquipamentsLiteCerca) {
    this.dataEquipaments = {
      cols: this.info,
      rows: equipaments ? equipaments.content : null,
      numeroTotalResultados: equipaments ? equipaments.total : null,
      numRowsPerPage: equipaments ? equipaments.pageSize : null,
      loading: false
    };
    this.cd.markForCheck();
  }

  handleSelectedRow(equipament: CentreggCercadesRDTO) {
    this.router.navigate([equipament.centreId], { relativeTo: this.route, state: {empresa: equipament.nomEmpresa}});
  }

  handleFilters(data: ParamListadoEquipament) { 
    this._resetFilters();
    this.getEquipamentsLite(this.setParams(data)); 
  }

  searchByIndex(value: string) {
    this._resetFilters();
    this.getEquipamentsLite(
      this.setParams({
        campGoogle: value
      })
    );
  }

  paginator(event) {
    this.dataEquipaments.numRowsPerPage = event.tamanyPagina;
    this.getEquipamentsLite(this.setParams(event));
  }

  onLazyLoad(event) {
    if (event && event.tamanyPagina) {
      this.getEquipamentsLite({
        ...this.setParams(event)
      });
    }
  }

  setParams(params: ParamListadoEquipament) {
    this.filtersApplied = {
      ...this.filtersApplied,
      ...params
    };
    return this.filtersApplied;
  }

  private _resetFilters() {
    this.filtersApplied = {
      ...new ParamListadoEquipament(
        this.sessionQuery.getServiceActiveValue(),
        this.filtersApplied.tamanyPagina
      )
    }
  }

  private _setLoading(loading: boolean) {
    this.dataEquipaments = {
      ...this.dataEquipaments,
      loading: loading,
      rows: null
    }
  }

  ngOnDestroy() { }

}
