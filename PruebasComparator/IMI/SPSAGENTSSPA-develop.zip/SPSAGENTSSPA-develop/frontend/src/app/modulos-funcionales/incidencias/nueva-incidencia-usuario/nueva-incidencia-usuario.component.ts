import { Component, OnInit, OnDestroy } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { DictionaryQuery, DiccionarioKey } from '@app/core/dictionary/state';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SessionQuery } from '@app/core/auth';
import { UsuarioLite, AltaIncidencia } from '@app/core/model';
import moment from 'moment';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { IncidenciasService, TIPO_INCIDENCIA_USUARIO } from '@app/servicios/incidencias/incidencias.service';

@AutoUnsubscribe()
@Component({
  selector: 'app-nueva-incidencia-usuario',
  templateUrl: './nueva-incidencia-usuario.component.html',
  styleUrls: ['./nueva-incidencia-usuario.component.scss']
})
export class NuevaIncidenciaUsuarioComponent implements OnInit, OnDestroy {

  isSubmitted = false;
  form: FormGroup;
  formDatosUsuario: FormGroup;
  optTipoIncidencias: SelectItem[];

  private sub: Subscription;

  constructor(
    private incidenciaService: IncidenciasService,
    private dictionaryQuery: DictionaryQuery,
    private sessionQuery: SessionQuery,
    private fb: FormBuilder,
    private router: Router
  ) { }

  ngOnInit() {
    this._initForm();
    this.optTipoIncidencias = this.dictionaryQuery.getDictionaryKey(DiccionarioKey.TIPO_INCIDENCIAS_USUARIO);
  }

  usuarioSelected(usuario: UsuarioLite) {
    this.formDatosUsuario.get('entitatId').setValue(usuario.expedientId);
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.form.valid) {
      this.sub = this.incidenciaService.postIncidencia(
        this._getIncidenciaMapped()
      ).subscribe(res => {
        this.router.navigate([
          '/incidencies/' + res.id
        ]);
      });
    }
  }

  private _initForm() {
    this.form = this.fb.group({
      gravetatIncidenciaDid: ['', Validators.required],
      dates: ['', Validators.required],
      descripcio: ['', Validators.required],
      tipusEntitatDid: [TIPO_INCIDENCIA_USUARIO, Validators.required],
      tipusRespostaDid: [this.sessionQuery.getServiceActiveValue(), Validators.required],
      tipusIncidenciaDid: ['', Validators.required],
      observacions: ['', Validators.required]
    });
    this.formDatosUsuario = this.fb.group({
      entitatId: ['', Validators.required]
    })
  }

  private _getIncidenciaMapped(): AltaIncidencia {
    const newIncidencia: AltaIncidencia = {
      ...this.form.value,
      ...this.formDatosUsuario.value,
      dataInici: moment(this.form.get('dates').value.start).valueOf(),
      dataFi: moment(this.form.get('dates').value.end).valueOf()
    }
    delete newIncidencia['dates'];
    return newIncidencia;
  }

  ngOnDestroy() {}

}
