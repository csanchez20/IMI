import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SituacionContextoComponent } from './situacion-contexto.component';

describe('SituacionContextoComponent', () => {
  let component: SituacionContextoComponent;
  let fixture: ComponentFixture<SituacionContextoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SituacionContextoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SituacionContextoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
