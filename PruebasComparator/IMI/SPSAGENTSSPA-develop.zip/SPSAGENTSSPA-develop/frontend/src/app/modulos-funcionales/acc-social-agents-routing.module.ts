import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthUserGuard } from '@app/core/auth/guards/auth-user.guard';
import { HomeComponent } from './componentes';
import { IncidenciasResolverService } from './incidencias/incidencias-resolver.service';


const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'inici'
      },
      {
        path: 'inici',
        loadChildren: './inicio/inicio.module#InicioAgentsModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          // imiSpsInfoRequired: ['centro'],
          urlToRedirect: 'selecciona-centre'
        }
      },

      {
        path: 'sol·licituds',
        loadChildren: './solicitudes/solicitudes.module#SolicitudesModule',
        canActivate: [AuthUserGuard],
        data: {
          // imiSpsInfoRequired: ['centro'],
          serviceRequired: true,
          urlToRedirect: 'selecciona-centre',
          breadcrumb: 'listaSolicitudes'
        }
      },
      {
        path: 'usuaris',
        loadChildren: './usuarios/usuarios.module#UsuariosModule',
        canActivate: [AuthUserGuard],
        data: {
          // imiSpsInfoRequired: ['centro'],
          serviceRequired: true,
          urlToRedirect: 'selecciona-centre',
          breadcrumb: 'listaUsuarios'
        }
      },
      {
        path: 'equipaments',
        loadChildren: './equipaments/equipaments.module#EquipamentsModule',
        canActivate: [AuthUserGuard],
        data: {
          // imiSpsInfoRequired: ['centro'],
          serviceRequired: true,
          urlToRedirect: 'selecciona-centre',
          breadcrumb: 'equipaments'
        }
      },
      {
        path: 'incidencies',
        resolve: { res: IncidenciasResolverService },
        loadChildren: './incidencias/incidencias.module#IncidenciasModule',
        canActivate: [AuthUserGuard],
        data: {
          // imiSpsInfoRequired: ['centro'],
          serviceRequired: true,
          urlToRedirect: 'selecciona-centre',
          breadcrumb: 'incidencias'
        }
      },
      {
        path: 'vincular',
        loadChildren: './vincular/vincular.module#VincularModule',
        canActivate: [AuthUserGuard],
        data: {
          // imiSpsInfoRequired: ['centro'],
          serviceRequired: true,
          urlToRedirect: 'selecciona-centre',
          breadcrumb: 'vincular'
        }
      },
      {
        path: 'facturas',
        loadChildren: './facturas/facturas.module#FacturasModule',
        canActivate: [AuthUserGuard],
        data: {
          // imiSpsInfoRequired: ['centro'],
          serviceRequired: true,
          urlToRedirect: 'selecciona-centre',
          breadcrumb: 'facturas'
        }
      },
      {
        path: 'selecciona-centre',
        loadChildren: './selecciona-centre/selecciona-centre.module#SeleccionaCentreModule',
        canActivate: [AuthUserGuard],
        data: {
          imiSpsInfoRequired: ['centro'],
          urlToRedirect: 'inici',
          inverse: true
        }
      },
      {
        path: 'ajuda',
        loadChildren: './ayuda/ayuda.module#AyudaModule',
        canActivate: [AuthUserGuard],
        data: {
          // imiSpsInfoRequired: ['centro'],
          serviceRequired: true,
          urlToRedirect: 'selecciona-centre',
          breadcrumb: 'ayudaBreadcrum'
        }
      },
      {
        path: 'tareas/:id',
        loadChildren: './tareas/tareas.module#TareasModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'tareasBread'
        },
      },
      {
        path: 'llistats/habitatges',
        loadChildren: './listados-viviendas/listados-viviendas.module#ListadosViviendasModule',
        canActivate: [AuthUserGuard],
        data: {
          serviceRequired: true,
          urlToRedirect: 'selecciona-grup',
          breadcrumb: 'listadosHabitatges'
        },
      },

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccSocialAgentsRoutingModule {}
