import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListadoIncidenciasUsuarioComponent } from './listado-incidencias-usuario.component';

describe('ListadoIncidenciasUsuarioComponent', () => {
  let component: ListadoIncidenciasUsuarioComponent;
  let fixture: ComponentFixture<ListadoIncidenciasUsuarioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListadoIncidenciasUsuarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListadoIncidenciasUsuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
