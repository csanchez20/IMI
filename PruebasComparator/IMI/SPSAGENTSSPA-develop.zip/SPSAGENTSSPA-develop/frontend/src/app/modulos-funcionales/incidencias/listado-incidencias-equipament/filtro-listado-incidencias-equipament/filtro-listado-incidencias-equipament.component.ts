import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { DiccionarioKey, DictionaryQuery } from '@app/core/dictionary/state';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Message } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { SessionQuery } from '@app/core/auth';
import { FiltersService } from '@app/core/services';
import { I18nConfigService } from '../../../../../../projects/spscompspa/src/app/services';

@Component({
  selector: 'app-filtro-listado-incidencias-equipament',
  templateUrl: './filtro-listado-incidencias-equipament.component.html',
  styleUrls: ['./filtro-listado-incidencias-equipament.component.scss']
})
export class FiltroListadoIncidenciasEquipamentComponent extends FiltersService implements OnInit {

  @Output() selectedFilters: EventEmitter<any> = new EventEmitter<any>();
  dataOutput: any[] = []; // Objeto para enviar al servicio back para filtrar (con values)
  dataToAppliedFilters: any[] = []; // Objeto para enviar al componente applied-filters (con labels)

  diccionarioKey = DiccionarioKey;

  form: FormGroup = this.fb.group({
    nomEquipament: [''],
    tipusIncidenciaDid: [''],
    dates: ['']
  });

  dataInicio: string = this.i18n({
    id: 'fechaInicio',
    value: 'Data inici'
  });
  dataFin: string = this.i18n({
    id: 'fechaFin',
    value: 'Data fi'
  });

  labels: string[] = [
    this.i18n({ id: 'equipamiento', value: 'Equipament' }),
    this.i18n({ id: 'tipusIncidenciaDid', value: 'Tipus incidència' }),
    this.i18n({ id: 'fechaInicio', value: 'Data inici' }),
    this.i18n({ id: 'fechaFin', value: 'Data fi' }),
  ];

  msgs: Message[];

  results;

  private _valid = true;

  constructor(
    private fb: FormBuilder,
    public i18nConfig: I18nConfigService,
    public dictionaryQuery: DictionaryQuery,
    private i18n: I18n,
    public sessionQuery: SessionQuery
  ) {
    super();
  }

  ngOnInit() {
    const dadesCentreUsuari = this.sessionQuery.getDadesCentreUsuari();
    if (dadesCentreUsuari) {
      this.form.get('nomEquipament').setValue(dadesCentreUsuari.codiReferencia);
      this.form.get('nomEquipament').disable();
    }
  }

  aplicaFiltros() {
    this._clearMsgs();
    this._hasValueValidInFilters() 
      ? this.onActivateFilters()
      : this._showError();
  }

  onActivateFilters() {
    this._valid = true;
    this.dataOutput = this.whenActivateFilters(this.form);
    this.dataToAppliedFilters = this.whenActivateFiltersToAppliedFilters(
      this.form
    );
    this.selectedFilters.emit(
      this.parseToParams(
        this.dataOutput,
        'dataInici',
        'dataFi'
      )
    );
  }

  setFields(outputData: any) {
    this.whenSetFields(this.form, outputData);
  }

  setResetFilters() {
    this.whenSetResetFields(this.form);
  }

  isValid() {
    return this._valid;
  }

  private _clearMsgs() {
    this.msgs = [];
  }

  private _showError() {
    this._valid = false;
    this.msgs = [
      {
        severity: 'error', 
        detail: this.i18n({ 
          id: 'minimo1Filtro3Caracteres', 
          value: 'Com a mínim hi ha d\'haver un filtre' 
        }),
        summary: this.i18n({
          id: 'atencion',
          value: 'ATENCIÓ'
        })
      }
    ];
  }

  private _hasValueValidInFilters(): boolean {
    let atLeastOne = false;

    if (this.form.get('dates').value
      && (this.form.get('dates').value['start']
      || this.form.get('dates').value['end'])) {
        atLeastOne = true;
    } 
    if (this._hasValue('tipusIncidenciaDid')) {
      atLeastOne = true;
    }
    if (this._hasValue('nomEquipament')) {
      atLeastOne = true;
    }    

    return atLeastOne;    
  }

  private _hasValue(formControlName: string) {
    return (this.form.get(formControlName).value !== ''
      && this.form.get(formControlName).value !== null)
        ? true
        : false;
  }

}
