import { Component, OnInit } from '@angular/core';
import { IncidenciaType, SessionQuery, SessionService, UbicacionUI } from '@app/core/auth';

@Component({
  selector: 'app-detalle-incidencia-generic',
  templateUrl: './detalle-incidencia-generic.component.html',
  styleUrls: ['./detalle-incidencia-generic.component.scss']
})
export class DetalleIncidenciaGenericComponent implements OnInit {

  moduleName: string;

  constructor(
    private sessionQuery: SessionQuery,
    private sessionService: SessionService
  ) { }

  ngOnInit() {
    this._setModule(
      this.sessionQuery.getIncidenciaType()
    );
  }

  private _setModule(type: IncidenciaType) {
    if (type === IncidenciaType.EQUIPAMENT) {
      this.sessionService.setUbicacionUI(UbicacionUI.INCIDENCIA_EQUIPAMENTS);
      this.moduleName = 'src/app/modulos-funcionales/incidencias/detalle-incidencia-equipament/detalle-incidencia-equipament.module#DetalleIncidenciaEquipamentModule';
    } else if (type === IncidenciaType.USUARIO) {
      this.sessionService.setUbicacionUI(UbicacionUI.INCIDENCIA_USUARI);
      this.moduleName = 'src/app/modulos-funcionales/incidencias/detalle-incidencia-usuario/detalle-incidencia-usuario.module#DetalleIncidenciaUsuarioModule';
    }
  }

}
