import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IncidenciasRoutingModule } from './incidencias-routing.module';
import { IncidenciasComponent } from './incidencias.component';
import { ListadoIncidenciasUsuarioComponent } from './listado-incidencias-usuario/listado-incidencias-usuario.component';
import { ListadoIncidenciasEquipamentComponent } from './listado-incidencias-equipament/listado-incidencias-equipament.component';
import { TabViewModule, CardModule, MessagesModule, ButtonModule, InputTextModule, DropdownModule, CalendarModule, AutoCompleteModule } from 'primeng/primeng';
import { FiltroListadoIncidenciasUsuarioComponent } from './listado-incidencias-usuario/filtro-listado-incidencias-usuario/filtro-listado-incidencias-usuario.component';
import { FiltroListadoIncidenciasEquipamentComponent } from './listado-incidencias-equipament/filtro-listado-incidencias-equipament/filtro-listado-incidencias-equipament.component';
import { DatatableListModule } from '@app/shared/agrupaciones/datatable-list/datatable-list.module';
import { ReactiveFormsModule } from '@angular/forms';
import { NuevaIncidenciaEquipamentModule } from './nueva-incidencia-equipament/nueva-incidencia-equipament.module';
import { NuevaIncidenciaUsuarioModule } from './nueva-incidencia-usuario/nueva-incidencia-usuario.module';
import { RangeDatePickerModule, AppliedFiltersModule } from '../../../../projects/spscompspa/src/public_api';

@NgModule({
  declarations: [
    IncidenciasComponent,
    ListadoIncidenciasUsuarioComponent,
    ListadoIncidenciasEquipamentComponent,
    FiltroListadoIncidenciasUsuarioComponent,
    FiltroListadoIncidenciasEquipamentComponent,
  ],
  imports: [
    CommonModule,
    IncidenciasRoutingModule,
    NuevaIncidenciaEquipamentModule,
    NuevaIncidenciaUsuarioModule,
    TabViewModule,
    CardModule,
    MessagesModule,
    ButtonModule,
    InputTextModule,
    DatatableListModule,
    DropdownModule,
    RangeDatePickerModule,
    ReactiveFormsModule,
    AppliedFiltersModule,
    AutoCompleteModule
  ]
})
export class IncidenciasModule { }
