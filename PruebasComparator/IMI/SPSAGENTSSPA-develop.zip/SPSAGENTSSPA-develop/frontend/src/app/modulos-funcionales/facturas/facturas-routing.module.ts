import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NovaFacturaComponent } from './nova-factura/nova-factura.component';
import { AltaFacturaComponent } from './alta-factura/alta-factura.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'nueva',
        component: NovaFacturaComponent,
        data: {
          breadcrumb: 'nuevaFactura'
        }
      },
      {
        path: '',
        component: AltaFacturaComponent
      }      
    ]
  }
];;

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FacturasRoutingModule { }
