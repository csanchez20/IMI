import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ResultatConsultaSauvRDTO } from '@app/core/model/solicitudes/solicitud-SAUV';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { Observable } from 'rxjs';

@AutoUnsubscribe()
@Component({
  selector: 'app-contexto',
  templateUrl: './contexto.component.html',
  styleUrls: ['./contexto.component.scss']
})
export class ContextoComponent implements OnInit, OnDestroy {
  @Input() datosBasicosSolicitud: ResultatConsultaSauvRDTO;

  results$: Observable<any>;
  loadedResults = false;

  constructor() {}

  ngOnInit() {}

  ngOnDestroy() {}
}
