import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SolicitudesService } from '@app/servicios';
import { ResultatConsultaRespirRDTO, ModificaEstatRespirRDTO } from '@app/core/model/solicitudes/solicitud-RESPIR';
import { Subscription, forkJoin, NEVER } from 'rxjs';
import { DictionaryService } from '@app/core/dictionary/state';
import { catchError } from 'rxjs/operators';
import { HttpStatusService } from '@app/core/interceptors';
import { Documento } from '@app/core/model';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-detalle-solicitud',
  templateUrl: './detalle-solicitud.component.html',
  styleUrls: ['./detalle-solicitud.component.scss']
})
export class DetalleSolicitudComponent implements OnInit {

  idSolicitud: string;
  detalleSolRESPIR: ResultatConsultaRespirRDTO;

  sub: Subscription;
  sub2: Subscription;

  estadosSolRespir: any;
  estadosSolRespirPlus: any;

  listaObligatorios:  Documento[] = [
    {
      obligatorio: true,
      nombreDocumento: this.i18n({
        id: 'fotocopiaDni',
        value: 'Fotocòpia DNI'
      })
    },
    {
      obligatorio: true,
      nombreDocumento: this.i18n({
        id: 'fotocopiaTargetaSanitaria',
        value: "Fotocòpia targeta sanitària"
      })
    },
    {
      obligatorio: true,
      nombreDocumento: this.i18n({
        id: 'informeSocial',
        value: 'Informe social'
      })
    },
    {
      obligatorio: true,
      nombreDocumento: this.i18n({
        id: 'perfilSollicitant',
        value: 'Perfil sol·licitant'
      })
    }
  ];

  listaOpcionales : Documento[]= [
    {
      obligatorio: false,
      nombreDocumento: this.i18n({
        id: 'informeMedico',
        value: 'Informe mèdic'
      })
    }
  ];
  documentacion: FormGroup;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    public solicitudService: SolicitudesService,
    private dictionaryService: DictionaryService,
    private httpStatusService: HttpStatusService,
    private cd: ChangeDetectorRef,
    private i18n: I18n,
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    this.idSolicitud = this.route.snapshot.paramMap.get('idSolicitud');
    this._initFormDocumentacion();
    this.sub = forkJoin({
      detalleSolRESPIR: this.solicitudService.getDetalleSolicitudRESPIR(this.idSolicitud),
      estadosSolRespir: this.dictionaryService.getEstadosSolicitud_RESPIR(),
      estadosSolRespirPlus: this.dictionaryService.getEstadosSolicitud_RESPIRPLUS()
    }).subscribe(sub => {
      this.detalleSolRESPIR = sub.detalleSolRESPIR;
      this.estadosSolRespir = sub.estadosSolRespir;
      this.estadosSolRespirPlus = sub.estadosSolRespirPlus;
    })
  }

  private _initFormDocumentacion() {
    this.documentacion = this.fb.group({
      listaDocumentosObligatorios: this.fb.array([]),
      listaDocumentosOpcionales: this.fb.array([])
    })
  }

  otorgarPlaza() {
    this.router.navigate(['../../places'], { relativeTo: this.route });
  }

  cambioEstadoSolicitud(event: any){
    const modificaEstatRespir = new ModificaEstatRespirRDTO();
    modificaEstatRespir.entitatExternaId = Number(this.idSolicitud);
    modificaEstatRespir.estatIdDesti = event.estatIdDesti;
    modificaEstatRespir.instanciaId = this.detalleSolRESPIR.instanciaFluxId;
    modificaEstatRespir.observacions = event.observacions;

    this.solicitudService.modificaEstadoSolicitudRESPIR(this.idSolicitud, modificaEstatRespir)
    .pipe(
      catchError(e => {
        this.httpStatusService.validationErrors = e;
        return NEVER;
      })
    ).subscribe(res => {
      if (res) {
        this.detalleSolRESPIR = {
          ...this.detalleSolRESPIR,
          estatSollicitud: modificaEstatRespir.estatIdDesti,
          dataActualitzacioEstat: new Date()
        };

        if (event.observacions) {
          this.detalleSolRESPIR = {
            ...this.detalleSolRESPIR,
            motiuEstat: event.observacions
          };
        }
        this.cd.markForCheck();
      }

    });


  }
}
