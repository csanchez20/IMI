import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroListadoIncidenciasUsuarioComponent } from './filtro-listado-incidencias-usuario.component';

describe('FiltroListadoIncidenciasUsuarioComponent', () => {
  let component: FiltroListadoIncidenciasUsuarioComponent;
  let fixture: ComponentFixture<FiltroListadoIncidenciasUsuarioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiltroListadoIncidenciasUsuarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltroListadoIncidenciasUsuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
