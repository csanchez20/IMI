import { Component, OnInit } from '@angular/core';
import { InfoItem, TableData } from '@app/core/model';
import { I18n } from '@ngx-translate/i18n-polyfill';

interface DocumentosAyuda {
  nom: string; //Nom per mostrar en la taula
  nomDocument: string; //Nom del fitxer q es descarregarà
  id: string; //Nom del fitxer dins la carpeta assets/documents
}

@Component({
  selector: 'app-ayuda',
  templateUrl: './ayuda.component.html',
  styleUrls: ['./ayuda.component.scss']
})
export class AyudaComponent implements OnInit {

  tableDataAyuda: TableData;

  cols: InfoItem[] = [
    {
      field: 'nom',
      header: this.i18n({ id: 'nombre', value: "Nom" })
    },
    {
      field: 'acciones',
      header: this.i18n({ id: 'acciones', value: 'Accions' }),
      actionIcons: [
        { icon: 'fa fa-download', action: 'download' }
      ]
    }
  ];

  constructor(
    private i18n: I18n
  ) { }

  ngOnInit() {
    this._initTableData()
  }

  downloadDocument(documentoAyuda: DocumentosAyuda) {
    let link = document.createElement("a");
    link.download = documentoAyuda.nomDocument;
    link.href = "assets/documents/" + documentoAyuda.id
    document.body.appendChild(link);
    link.click();
    link.remove();

  }

  private _initTableData() {
    const documentosAyuda: DocumentosAyuda[] = [
      {
        nom: 'MANUAL USUARI AGENTS EXTERNS',
        nomDocument: 'Manual_Usuari_Equipaments_AGExt_v3.0.pdf',
        id: 'Manual_AGExt.pdf',
      }
    ];

    this.tableDataAyuda = {
      cols: this.cols,
      rows: documentosAyuda,
      numeroTotalResultados: documentosAyuda.length
    }
  }

}
