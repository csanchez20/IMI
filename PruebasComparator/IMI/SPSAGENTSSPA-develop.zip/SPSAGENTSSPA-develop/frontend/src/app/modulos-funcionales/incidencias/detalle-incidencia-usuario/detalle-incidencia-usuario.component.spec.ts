import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleIncidenciaUsuarioComponent } from './detalle-incidencia-usuario.component';

describe('DetalleIncidenciaUsuarioComponent', () => {
  let component: DetalleIncidenciaUsuarioComponent;
  let fixture: ComponentFixture<DetalleIncidenciaUsuarioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalleIncidenciaUsuarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalleIncidenciaUsuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
