// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { DetalleSolicitudComponent } from './detalle-solicitud.component';
// import { PanelModule } from 'primeng/panel';
// import { DireccionConsultaModule } from '../../../../../../../../projects/spscompspa/src/public_api';
// import { CardModule } from 'primeng/card';
// import { RouterTestingModule } from '@angular/router/testing';
// import { GestionServicioService } from '@app/servicios';
// import { HttpClientTestingModule } from '@angular/common/http/testing';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// describe('DetalleSolicitudComponent', () => {
//   let component: DetalleSolicitudComponent;
//   let fixture: ComponentFixture<DetalleSolicitudComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ 
//         DetalleSolicitudComponent
//       ],
//       imports: [
//         BrowserAnimationsModule,
//         PanelModule,
//         DireccionConsultaModule,
//         CardModule,
//         RouterTestingModule,
//         HttpClientTestingModule
//       ],
//       providers: [
//         GestionServicioService
//       ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DetalleSolicitudComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
