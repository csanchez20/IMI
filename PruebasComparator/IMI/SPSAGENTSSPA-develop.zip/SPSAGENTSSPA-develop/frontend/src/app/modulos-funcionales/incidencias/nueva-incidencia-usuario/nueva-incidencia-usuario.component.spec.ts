import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NuevaIncidenciaUsuarioComponent } from './nueva-incidencia-usuario.component';

describe('NuevaIncidenciaUsuarioComponent', () => {
  let component: NuevaIncidenciaUsuarioComponent;
  let fixture: ComponentFixture<NuevaIncidenciaUsuarioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NuevaIncidenciaUsuarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NuevaIncidenciaUsuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
