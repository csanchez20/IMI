import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DictionaryService } from '@app/core/dictionary/state';
import { Documento } from '@app/core/model';
import { ModificaEstatSauvRDTO, ResultatConsultaSauvRDTO } from '@app/core/model/solicitudes/solicitud-SAUV';
import { SolicitudesService } from '@app/servicios/solicitudes/solicitudes.service';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { forkJoin, Subscription } from 'rxjs';

@AutoUnsubscribe()
@Component({
  selector: 'app-detalle-solicitud',
  templateUrl: './detalle-solicitud.component.html',
  styleUrls: ['./detalle-solicitud.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DetalleSolicitudComponent implements OnInit, OnDestroy {
  detalleSolSAUV: ResultatConsultaSauvRDTO;
  idSolicitud: string;

  sub: Subscription;
  sub2: Subscription;

  estadosSolSAUV: any;

  listaObligatorios:  Documento[] = [
    {
      obligatorio: true,
      nombreDocumento: this.i18n({
        id: 'cartaServicios',
        value: 'Carta de serveis'
      })
    },
    {
      obligatorio: true,
      nombreDocumento: this.i18n({
        id: 'consentimientoIngreso',
        value: "Full de consentiment d'ingrés"
      })
    },
    {
      obligatorio: true,
      nombreDocumento: this.i18n({
        id: 'informeMedico',
        value: 'Informe mèdic'
      })
    }
  ];

  listaOpcionales : Documento[]= [
    {
      obligatorio: false,
      nombreDocumento: this.i18n({
        id: 'sentenciaJudIncap',
        value: "Sentència judicial d'incapacitació"
      })
    },
    {
      obligatorio: false,
      nombreDocumento: this.i18n({
        id: 'sentenciaJudAutIn',
        value: "Sentència judicial d'autorització d'ingrés involuntari"
      })
    }
  ];
  documentacion: FormGroup;
  
  // Cuando funcione gestor documental, usar estas variables en vez de las harcoded de arriba
  listaDocumentosObligatorios: Documento[];
  listaDocumentosOpcionales: Documento[];

  constructor(
    private route: ActivatedRoute,
    public solicitudService: SolicitudesService,
    private cd: ChangeDetectorRef,
    private dictionaryService: DictionaryService,
    private i18n: I18n,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.idSolicitud = this.route.snapshot.paramMap.get('idSolicitud');
    this._initFormDocumentacion();
    this.sub = forkJoin({
      detalleSolSAUV: this.solicitudService.getDetalleSolicitudSAUV(
        this.idSolicitud
      ),
      estadosSolSAUV: this.dictionaryService.getEstadosSolicitud_SAUV()
    }).subscribe(sub => {
      this.detalleSolSAUV = sub.detalleSolSAUV;
      this.estadosSolSAUV = sub.estadosSolSAUV;
      // Descomentar cuando funcione gestor documental
      // this.solicitudService.getDocumentos(this.idSolicitud).subscribe(documentos => {
      //   this.listaDocumentosObligatorios = documentos.filter(
      //     doc => doc.obligatorio
      //   );
      //   this.listaDocumentosOpcionales = documentos.filter(
      //     doc => !doc.obligatorio
      //   );
      //   this.cd.markForCheck();
      // });
      this.cd.markForCheck();
    });

  }

  private _initFormDocumentacion() {
    this.documentacion = this.fb.group({
      listaDocumentosObligatorios: this.fb.array([]),
      listaDocumentosOpcionales: this.fb.array([])
    })
  }

  cambioEstadoSolicitud(event: any) {
    const modificaEstatSauv = new ModificaEstatSauvRDTO();
    modificaEstatSauv.entitatExternaId = Number(this.idSolicitud);
    modificaEstatSauv.estatIdDesti = event.estatIdDesti;
    modificaEstatSauv.instanciaId = this.detalleSolSAUV.instanciaFluxId;
    modificaEstatSauv.observacions = event.observacions;

    this.sub2 = this.solicitudService
      .modificaEstadoSolicitudSAUV(this.idSolicitud, modificaEstatSauv)
      .subscribe(instanciaId => {
        if (instanciaId) {
          this.detalleSolSAUV = {
            ...this.detalleSolSAUV,
            estatSollicitud: modificaEstatSauv.estatIdDesti,
            dataActualitzacioEstat: new Date()
          };

          if (event.observacions) {
            this.detalleSolSAUV = {
              ...this.detalleSolSAUV,
              motiuEstat: event.observacions
            };
          }
          this.cd.markForCheck();
        }
      });
  }

  ngOnDestroy() {}
}
