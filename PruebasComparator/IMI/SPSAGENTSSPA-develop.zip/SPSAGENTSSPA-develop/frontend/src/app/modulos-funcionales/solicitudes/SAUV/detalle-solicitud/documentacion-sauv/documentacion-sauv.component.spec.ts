import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentacionSauvComponent } from './documentacion-sauv.component';

describe('DocumentacionSauvComponent', () => {
  let component: DocumentacionSauvComponent;
  let fixture: ComponentFixture<DocumentacionSauvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentacionSauvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentacionSauvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
