import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NuevaIncidenciaGenericComponent } from './nueva-incidencia-generic.component';

describe('NuevaIncidenciaGenericComponent', () => {
  let component: NuevaIncidenciaGenericComponent;
  let fixture: ComponentFixture<NuevaIncidenciaGenericComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NuevaIncidenciaGenericComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NuevaIncidenciaGenericComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
