export * from './footer/footer.component';
export * from './header/header.component';
export * from './menu-principal/menu-principal.component';
export * from './home/home.component';
export * from './page-not-found/page-not-found.component';