import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NuevaIncidenciaEquipamentComponent } from './nueva-incidencia-equipament.component';
import { CabeceraEquipamentNuevaIncidenciaComponent } from './cabecera-equipament-nueva-incidencia/cabecera-equipament-nueva-incidencia.component';
import { DetalleNuevaIncidenciaModule } from '../nueva-incidencia/detalle-nueva-incidencia/detalle-nueva-incidencia.module';
import { MessageModule, PanelModule, AutoCompleteModule, ButtonModule, InputTextModule, MessagesModule } from 'primeng/primeng';
import { CargaDatosGenericosModule } from '@app/shared/componentes/carga-datos-genericos-spinner/carga-datos-genericos-spinner.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    NuevaIncidenciaEquipamentComponent, 
    CabeceraEquipamentNuevaIncidenciaComponent
  ],
  imports: [
    CommonModule,
    DetalleNuevaIncidenciaModule,
    MessageModule,
    PanelModule,
    CargaDatosGenericosModule,
    AutoCompleteModule,
    ButtonModule,
    InputTextModule,
    FormsModule,
    MessagesModule
  ],
  bootstrap: [NuevaIncidenciaEquipamentComponent]
})
export class NuevaIncidenciaEquipamentModule { }
