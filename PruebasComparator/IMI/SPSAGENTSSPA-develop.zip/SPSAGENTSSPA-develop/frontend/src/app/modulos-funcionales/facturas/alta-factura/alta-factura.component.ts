import { Component, OnInit } from '@angular/core';
import { PersonaConsultadesRDTO, ParamsPersonaPerDoc, BlocBasiquesDTO } from '@app/core/model/persona';
import { Observable, Subscription, of } from 'rxjs';
import { TableData, InfoItem } from '@app/core/model';
import { Router, ActivatedRoute } from '@angular/router';
import { DialogService, SelectItem } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { PersonasService, CODE_TIPO_DOCUMENTO_DNI, CODE_TIPO_DOCUMENTO_NIE, CODE_TIPO_DOCUMENTO_PASAPORTE } from '@app/servicios/personas/personas.service';
import { SolicitudService } from '@app/modulos-funcionales/solicitudes/nueva-solicitud/state';
import { SolicitudesService, EquipamentsService, RecursosService } from '@app/servicios';
import { HttpStatusService } from '@app/core/interceptors';
import { SessionQuery } from '@app/core/auth';
import { map, catchError } from 'rxjs/operators';
import { DialogRecursoNoActivoComponent } from './dialog-recurso-no-activo/dialog-recurso-no-activo.component';

@Component({
  selector: 'app-alta-factura',
  templateUrl: './alta-factura.component.html',
  styleUrls: ['./alta-factura.component.scss']
})
export class AltaFacturaComponent implements OnInit {

  tipoDocumentoSelected: any;
  tipoDocumentos: SelectItem[] = [
    {
      label: this.i18n({ id: 'dni', value: 'DNI' }),
      value: CODE_TIPO_DOCUMENTO_DNI
    },
    {
      label: this.i18n({ id: 'nie', value: 'NIE' }),
      value: CODE_TIPO_DOCUMENTO_NIE
    },
    {
      label: this.i18n({ id: 'pasaporte', value: 'Passaport' }),
      value: CODE_TIPO_DOCUMENTO_PASAPORTE
    }
  ];

  persona: PersonaConsultadesRDTO;
  dataTable$: Observable<TableData>;
  info: InfoItem[] = [
    {
      field: 'nom',
      header: this.i18n({ id: 'nombreUsuario', value: "Nom de l'usuari" })
    },
    { 
      field: 'document',
      header: this.i18n({ id: 'documento', value: "Document" }) 
    },
    {
      field: 'telefon1',
      header: this.i18n({ id: 'telefono', value: 'Telèfon' })
    },
    { field: 'email', header: this.i18n({ id: 'email', value: 'Email' }) }
  ];
  canCreateSolicitud = true;

  sub: Subscription;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private dialogService: DialogService,
    private i18n: I18n,
    private personaService: PersonasService,
    private solicitudStore: SolicitudService,
    private solicitudesService: SolicitudesService,
    private httpStatusService: HttpStatusService,
    private recursosService: RecursosService,
    private equipamentService: EquipamentsService,
    public sessionQuery: SessionQuery
  ) {}

  ngOnInit() {}

  buscarUsuario(valDoc: string) {
    const params: ParamsPersonaPerDoc = {
      tipusDocumentDid: '' + this.tipoDocumentoSelected,
      document: valDoc.toUpperCase(),
      tipusVista: '0'
    };
    this.dataTable$ = this.personaService.getPersonaPerDoc(params).pipe(
      map(persona => {
        if (persona) {
          const blocBasicasAux: BlocBasiquesDTO = {
            ...persona.blocBasiques,
            nom: persona.blocBasiques.cognom2
              ? persona.blocBasiques.nom +
                ' ' +
                persona.blocBasiques.cognom1 +
                ' ' +
                persona.blocBasiques.cognom2
              : persona.blocBasiques.nom + ' ' + persona.blocBasiques.cognom1
          };
          this.persona = persona;
          return {
            rows: [blocBasicasAux],
            cols: this.info
          };
        } else {
          return {
            rows: [],
            cols: this.info
          };
        }
      })
    );
  }

  handleSelectedRow(usuario: BlocBasiquesDTO) {
    if (usuario.expedientId) {
      this.recursosService
        .getRecursoActivoRESPIRPLUS(usuario.expedientId)
        .pipe(
          map(res => {
            this.iniciarAltaFactura(usuario.expedientId);
          }),
          catchError(err => {
            if (err.status === 404) {
              this.openAlertRecursoNoActivo();
            } else {
              this.httpStatusService.validationErrors = err;
            }
            return of([]);
          })
        )
        .subscribe();
        // this.iniciarAltaFactura(usuario.expedientId);

      
    }
  }

  iniciarAltaFactura(expedientId: string){
    this.solicitudStore.updateDatosPersona(this.persona);
    this.router.navigate(['nueva/'], {
      relativeTo: this.route
    });
  }  

  openAlertRecursoNoActivo() {
    this.dialogService.open(DialogRecursoNoActivoComponent, {
      header: this.i18n({
        id: 'recursoNoActivo',
        value: 'Recurs no actiu'
      }),
      width: '40%'
    });
  }

  ngOnDestroy() {}

}
