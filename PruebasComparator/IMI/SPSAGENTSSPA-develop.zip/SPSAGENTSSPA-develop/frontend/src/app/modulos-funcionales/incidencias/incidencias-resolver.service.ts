import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { DictionaryService } from '@app/core/dictionary/state';
import { forkJoin, Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IncidenciasResolverService implements Resolve<any> {

  constructor(private dictionaryService: DictionaryService) {}

  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> {      
    return forkJoin({
      d1: this.dictionaryService.getTipoIncidenciasEquipament(),
      d2: this.dictionaryService.getTipoIncidenciasUsuario(),
      d3: this.dictionaryService.getGravedadIncidencias()    
    }).pipe();
  }
}
