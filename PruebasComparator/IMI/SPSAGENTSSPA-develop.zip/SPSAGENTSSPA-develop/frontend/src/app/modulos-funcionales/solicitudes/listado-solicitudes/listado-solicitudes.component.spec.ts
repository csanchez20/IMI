/* import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ListadoSolicitudesComponent } from './listado-solicitudes.component';
import { TableModule } from 'primeng/table';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { from } from 'rxjs';
import { Router } from '@angular/router';
import { SolicitudesService } from '@app/servicios/equipaments/guardamuebles';
import { CalendarModule, DropdownModule, ButtonModule } from 'primeng/primeng';
import { AppliedFiltersModule } from '@app/shared/agrupaciones/applied-filters/applied-filters.module';

describe('ListadoSolicitudesComponent', () => {
  let component: ListadoSolicitudesComponent;
  let fixture: ComponentFixture<ListadoSolicitudesComponent>;
  let service: SolicitudesService;
  let router: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ListadoSolicitudesComponent,

      ],
      imports: [
        TableModule,
        RouterTestingModule,
        HttpClientTestingModule,
        CalendarModule,
        DropdownModule,
        ButtonModule,
        AppliedFiltersModule
      ],
      providers: [
        SolicitudesService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListadoSolicitudesComponent);
    component = fixture.componentInstance;
    service = TestBed.get(SolicitudesService);
    router = TestBed.get(Router);
    fixture.detectChanges();
  });

  beforeEach(() => {
    solicituds = [
      {
        usuario: "usuario1",
        fechaCreacion: "19/12/18",
        fechaResolucion: "2/1/19",
        referente: "referente 1",
        detalles: "detalle de la solicitud",
        estado: "pendiente"
      }
    ]
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('ngOnInit debe de cargar las solicitudes', () => {
    const spy = spyOn(service, 'getSolicitudes').and.returnValue(from([solicituds]));

    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
    // expect(component.listaSolicitudes.length).toBeGreaterThan(0);
  });

  it('La tabla debe de contener 6 columnas', () => {
    component.ngOnInit();
    expect(component.cols.length).toBe(6);
  });

  it('La tabla debe de contener los nombres de las columnas correctos', () => {
    component.ngOnInit();
    expect(component.cols[0].header).toBe('Usuario');
    expect(component.cols[1].header).toBe('Fecha Creación');
    expect(component.cols[2].header).toBe('Fecha Resolución');
    expect(component.cols[3].header).toBe('Referente');
    expect(component.cols[4].header).toBe('Detalles');
    expect(component.cols[5].header).toBe('Estado');
  });

  it('La tabla debe de contener los campos de las columnas correctos', () => {
    component.ngOnInit();
    expect(component.cols[0].field).toBe('usuario');
    expect(component.cols[1].field).toBe('fechaCreacion');
    expect(component.cols[2].field).toBe('fechaResolucion');
    expect(component.cols[3].field).toBe('referente');
    expect(component.cols[4].field).toBe('detalles');
    expect(component.cols[5].field).toBe('estado');
  });

  it('Debe de redireccionar a la Consulta de la solicitud al clicar una celda', () => {
    const spy = spyOn(router, 'navigate');
    component.viewSolicitud(1);
    expect(spy).toHaveBeenCalledWith(['/equipaments/solicitudes/consulta/1'], { relativeTo: component.route });
  });



});
 */
