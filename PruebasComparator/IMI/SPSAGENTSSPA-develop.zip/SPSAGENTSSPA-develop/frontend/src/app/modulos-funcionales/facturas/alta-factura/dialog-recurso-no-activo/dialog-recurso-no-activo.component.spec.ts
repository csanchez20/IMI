import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogRecursoNoActivoComponent } from './dialog-recurso-no-activo.component';

describe('DialogRecursoNoActivoComponent', () => {
  let component: DialogRecursoNoActivoComponent;
  let fixture: ComponentFixture<DialogRecursoNoActivoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogRecursoNoActivoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogRecursoNoActivoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
