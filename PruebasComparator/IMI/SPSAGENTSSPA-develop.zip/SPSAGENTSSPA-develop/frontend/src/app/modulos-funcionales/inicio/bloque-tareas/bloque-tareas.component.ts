import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SessionQuery } from '@app/core/auth';
import { DiccionarioKey, DictionaryQuery, DictionaryService } from '@app/core/dictionary/state';
import { ParamListadoTasca, TascaRDTO } from '@app/core/model/tareas';
import { TareasRoutesResolverService } from '@app/servicios/tareas/tareas-routes-resolver.service';
import { TareasService } from '@app/servicios/tareas/tareas.service';
import moment from 'moment';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { SelectItem } from 'primeng/api';
import { forkJoin, from, Observable, Subscription } from 'rxjs';
import { groupBy, map, mergeMap, reduce, toArray } from 'rxjs/operators';
export const ESTAT_TAREA_PENDENT = 101801;

@AutoUnsubscribe()
@Component({
  selector: 'app-bloque-tareas',
  templateUrl: './bloque-tareas.component.html',
  styleUrls: ['./bloque-tareas.component.scss']
})
export class BloqueTareasComponent implements OnInit, OnDestroy {

  @Input() change : Observable<void>;
 
  // tareasPendientes$: Observable<TascaRDTO[]>;
  tareasPendientes: TascaRDTO[];
  tareasUltimas: TascaRDTO[];
  tareasAgrupadas: SelectItem[];
  tareasAgrupadas$: Observable<{ label: number; value: any }[]>;
  loadingDialogId: number;
  tipoTareaServicio: number[]; 

  paramsCercaTascaProfId: ParamListadoTasca = new ParamListadoTasca();
  paramsCercaTascaPerfilGrup: ParamListadoTasca = new ParamListadoTasca();

  results$: Observable<any>;
  loadedResults = false;

  diccionarioKey = DiccionarioKey;
  private sub: Subscription;
  private sub2: Subscription;
  private sub3: Subscription;

  constructor(
    private sessionQuery: SessionQuery,
    private cd: ChangeDetectorRef,
    private router: Router,
    private tareasService: TareasService,
    private dictionaryService: DictionaryService,
    public dictionaryQuery: DictionaryQuery,
    public tareasRoutesResolver: TareasRoutesResolverService
  ) {}


  ngOnInit() {
    this.getData();
    //Ens subscribim en el Observable per saber si es vol recarregar les dades.
    this.sub3 = this.change.subscribe( ()=> {
      this.getData();
    });
  }

  getData() {
    this.dictionaryService.getTiposTareas().subscribe();
    this.paramsCercaTascaProfId.professionalId = this.sessionQuery.getUserLoggedId(); //TODO: es correcte?
    this.paramsCercaTascaPerfilGrup.grupId = this.sessionQuery.getUserGrup(); //TODO: es correcte?
    this.paramsCercaTascaPerfilGrup.perfilId = this.sessionQuery.getRoleUserId(); //TODO: es correcte?
    this.tipoTareaServicio = this.tareasService.getTiposTareasServei();

    forkJoin({
      tareasProfesionalId:  this.tareasService.getTareas(this.paramsCercaTascaProfId),
      tareasPerfilGrup:  this.tareasService.getTareas(this.paramsCercaTascaPerfilGrup),
    }).subscribe(respuesta => {

      const pendingTasks = [
        ...respuesta.tareasProfesionalId,
        ...respuesta.tareasPerfilGrup
      ]

      this.tareasPendientes = pendingTasks.filter(
        tarea => this.tipoTareaServicio.includes(tarea.tipusNotificacioDid)
      ).filter(
        tarea => tarea.estatNotificacioDid === ESTAT_TAREA_PENDENT
      );;
      this.tareasUltimas = this.tareasPendientes.filter(tarea =>
          moment.unix(tarea.dataFiNotificacio).isAfter(Date.now(), 'day'))
          .sort(this.compare)
          .slice(0, 6);
      if (this.tareasUltimas.length < 6) {
        this.tareasUltimas = this.tareasPendientes.sort(this.compare).slice(0, 6);
      }
      this.cd.markForCheck();

      // Agrupar las tareas Pendientes
      this.tareasAgrupadas$ = from(this.tareasPendientes).pipe(
        groupBy(x => x.tipusNotificacioDid),
        mergeMap(group => {
          return group.pipe(
            reduce((acc: any) => acc + 1, 0),
            map(total => ({ label: group.key, value: total }))
          );
        }),
        toArray()
      );
    });

    // this.results$.subscribe(() => {
    //   this.loadedResults = true;
    //   this.cd.markForCheck();
    // });
  }

  private compare(a: TascaRDTO, b: TascaRDTO) {
    if (a.dataFiNotificacio < b.dataFiNotificacio) {
      return -1;
    }
    if (a.dataFiNotificacio > b.dataFiNotificacio) {
      return 1;
    }
    return 0;
  }

  ngOnDestroy() {}

  navigateToTask(task: TascaRDTO) {
    if(task.url){
      //resolem la url que ens retorna Cintraos per poder nevagar a la tasca
      let url = this.tareasRoutesResolver.resolveUrl(task.url);
      this.router.navigate([url]);
    }    
  }

  mostrarAgrupacionTareas(agrupadas : any) {
    this.router.navigate(['/tareas/'+ agrupadas.label]);
  }
}
