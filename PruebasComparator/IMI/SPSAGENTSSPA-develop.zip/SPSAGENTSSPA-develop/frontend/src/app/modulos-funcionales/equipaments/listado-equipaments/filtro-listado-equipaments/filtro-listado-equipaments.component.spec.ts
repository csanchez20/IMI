/* import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroListadoUsuariosComponent } from './filtro-listado-usuarios.component';

describe('FiltroListadoUsuariosComponent', () => {
  let component: FiltroListadoUsuariosComponent;
  let fixture: ComponentFixture<FiltroListadoUsuariosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiltroListadoUsuariosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltroListadoUsuariosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
 */
