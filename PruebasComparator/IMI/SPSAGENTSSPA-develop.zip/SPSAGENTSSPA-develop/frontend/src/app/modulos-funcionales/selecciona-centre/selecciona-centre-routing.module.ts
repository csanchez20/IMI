import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SeleccionaCentreComponent } from './selecciona-centre.component';

const routes: Routes = [
  {
    path: '',
    component: SeleccionaCentreComponent,
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SeleccionaCentreRoutingModule { }
