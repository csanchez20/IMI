import { Component, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';

@Component({
  selector: 'app-dialog-llistat-usuaris-padro',
  templateUrl: './dialog-llistat-usuaris-padro.component.html',
  styleUrls: ['./dialog-llistat-usuaris-padro.component.scss']
})
export class DialogLlistatUsuarisPadroComponent implements OnInit {

  // TODO tipus objecte
  // Contingut del dialeg
  usuaris;

  // Columnes de la taula
  cols: any[];

  // Persona seleccionada del pop up
  seleccionat: boolean = false;

  // Persona per ser retornada del dialog
  persona;

  constructor(
    public config: DynamicDialogConfig,
    private ref: DynamicDialogRef,
    private i18n: I18n
  ) { }

  ngOnInit() {
    this.obtenirDades();
    this.inicialitzarDades();
  }


  /**
   * Mètode per a rebre les dades necessàries
   */
  obtenirDades() {
    this.usuaris = this.config.data.usuaris;
  }

  inicialitzarDades() {
    this.cols = [
      { field: '', header: '', class: 'columna-icona' },
      { field: 'docId', header: this.i18n({ id: ' ', value: 'Document' }) },
      { field: 'nom', header: this.i18n({ id: ' ', value: 'Nom' }), sortField: '' },
      { field: 'cognom1', header: this.i18n({ id: ' ', value: 'Cognom' }) }
    ];
  }

  /*
  *Cancel.lar la seleccio de persones
  */
  cancelar() {
    this.ref.close('cancelar');
  }

  /**
   * Mètode per a tancar la modal del test
   */
  tancarModal() {
    this.ref.close(this.persona);
  }

}
