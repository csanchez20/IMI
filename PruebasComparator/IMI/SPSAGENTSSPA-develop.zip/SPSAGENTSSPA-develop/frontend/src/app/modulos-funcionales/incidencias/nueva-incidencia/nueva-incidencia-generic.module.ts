import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NuevaIncidenciaGenericComponent } from './nueva-incidencia-generic.component';
import { Routes, RouterModule } from '@angular/router';
import { LazyModule } from '@herodevs/lazy-af';

const routes: Routes = [
  { path: '', component: NuevaIncidenciaGenericComponent }
];

@NgModule({
  declarations: [NuevaIncidenciaGenericComponent],
  imports: [
    CommonModule,
    LazyModule,
    RouterModule.forChild(routes)
  ],
  bootstrap: [NuevaIncidenciaGenericComponent]
})
export class NuevaIncidenciaGenericModule { }
