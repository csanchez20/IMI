import { Component, OnInit, ChangeDetectorRef, Output, EventEmitter, OnDestroy } from '@angular/core';
import { EquipamentsService } from '@app/servicios';
import { SessionQuery } from '@app/core/auth';
import { CentreggCercadesRDTO, ParamListadoEquipament } from '@app/core/model';
import { Subscription, of } from 'rxjs';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { catchError } from 'rxjs/operators';
import { HttpStatusService } from '@app/core/interceptors';
import { Message } from 'primeng/api';
import { I18n } from '@ngx-translate/i18n-polyfill';

@AutoUnsubscribe()
@Component({
  selector: 'app-cabecera-equipament-nueva-incidencia',
  templateUrl: './cabecera-equipament-nueva-incidencia.component.html',
  styleUrls: ['./cabecera-equipament-nueva-incidencia.component.scss']
})
export class CabeceraEquipamentNuevaIncidenciaComponent implements OnInit, OnDestroy {

  @Output() equipamentSelectedEmitter: EventEmitter<CentreggCercadesRDTO> = new EventEmitter<CentreggCercadesRDTO>();

  results: CentreggCercadesRDTO[];
  equipament: CentreggCercadesRDTO = {};

  msgs: Message[];

  isCentreFixed = false;

  private sub: Subscription;

  constructor(
    private equipamentService: EquipamentsService,
    private sessionQuery: SessionQuery,
    private cd: ChangeDetectorRef,
    private httpStatusService: HttpStatusService,
    private i18n: I18n
  ) { }

  ngOnInit() {
    const dadesCentreUsuari = this.sessionQuery.getDadesCentreUsuari();
    if (dadesCentreUsuari) {
      this.isCentreFixed = true;
      this.buscarEquipament(dadesCentreUsuari.codiReferencia);
    }
    
  }

  buscarEquipament(nom: string) {
    let params:ParamListadoEquipament={
      tipusRespostaDid: this.sessionQuery.getServiceActiveValue(),
      estat: true
    }
    if(this.isCentreFixed===true){
      params={
        ...params,
        codiEquipament:nom
      }
    }else{
      params={
        ...params,
        nom:nom
      }
    }
    this.sub = this.equipamentService.getEquipaments(params)
    .pipe(
      catchError(err => {
        this.onClear();
        this._noResults();
        if (err.status === 404) {
          return of({
            content: []
          });
        } else {
          this.httpStatusService.validationErrors = err;
          return of({
            content: []
          });
        }
      })
    )
    .subscribe(res => {
      if (res['content'] !== undefined && res['content'].length > 0) {
        this._clearMsgs();
      }
      this.results = res['content'];
      this.onSelect(this.results[0])
    })
  }
  
  onSelect(equipament: CentreggCercadesRDTO) {
    if (equipament) {
      this.equipament = equipament;
      this.equipamentSelectedEmitter.emit(this.equipament);
      this.cd.markForCheck();
    }
  }
  
  onClear() {
    this.equipament = {}
    this.equipamentSelectedEmitter.emit(null);
  }

  private _noResults() {
    this.msgs = [
      {
        severity: 'error', 
        detail: this.i18n({ 
          id: 'noEncontradoResultado', 
          value: 'No s\'ha trobat cap resultat' 
        }),
        summary: this.i18n({
          id: 'atencion',
          value: 'ATENCIÓ'
        })
      }
    ];
  }

  private _clearMsgs() {
    this.msgs = [];
  }

  ngOnDestroy() {}

}
