import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { SessionService } from './core/auth';
import { DictionaryService } from './core/dictionary/state';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'Equipaments';
  subs: Subscription;
  constructor(
    private dictionaryService: DictionaryService,
    readonly router: Router,
    readonly sessionService: SessionService
  ) {
    /* translate.addLangs(['ca', 'es']);
    translate.setDefaultLang('ca');
    
    const browserLang = translate.getBrowserLang();
    const useLang = browserLang.match(/ca|es/) ? browserLang : 'ca';
    translate.use(useLang);
    this.sessionService.setLanguage(useLang); */
  }

  ngOnInit() {
    this.router.navigate(['']);
    this.sessionService.resetUbicacionUI();
    this.subs = this.dictionaryService.getDictionaries().subscribe();
  }

  ngOnDestroy() {
    if (this.subs) {
      this.subs.unsubscribe();
    }
  }


}
