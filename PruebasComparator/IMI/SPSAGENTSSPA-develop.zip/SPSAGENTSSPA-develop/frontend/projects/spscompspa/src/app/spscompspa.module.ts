import { NgModule } from '@angular/core';
//import {
  //BreadcrumbComponent,
  //RangeDatePickerComponent
//} from './components';
import { ReactiveFormsModule } from '@angular/forms';

const components = [
 // BreadcrumbComponent,
  //RangeDatePickerComponent
];
@NgModule({
  declarations: [
    ...components
  ],
  imports: [

    ReactiveFormsModule
  ],
  exports: [
    ...components
  ]
})
export class SpsCompSpaModule { }
