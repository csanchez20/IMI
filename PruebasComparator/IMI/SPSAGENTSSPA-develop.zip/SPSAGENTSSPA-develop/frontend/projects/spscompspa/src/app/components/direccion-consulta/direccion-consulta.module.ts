import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { DireccionConsultaComponent } from './direccion-consulta.component';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  declarations: [DireccionConsultaComponent],
  exports: [
    DireccionConsultaComponent
  ]

})
export class DireccionConsultaModule { }
