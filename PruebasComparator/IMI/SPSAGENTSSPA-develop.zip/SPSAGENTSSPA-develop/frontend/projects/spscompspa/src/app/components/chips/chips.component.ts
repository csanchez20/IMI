import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';

interface Item {
  key: string;
  value: string;
}

@Component({
  selector: 'sps-chips',
  templateUrl: './chips.component.html',
  styleUrls: ['./chips.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChipsComponent {
  @Input() labels: any[];
  @Input() controls: any[];

  @Output() closeChip: EventEmitter<Item> = new EventEmitter<Item>();
  constructor() { }

  isDate(value) {
    return Object.prototype.toString.call(value) === "[object Date]";
  }
}
