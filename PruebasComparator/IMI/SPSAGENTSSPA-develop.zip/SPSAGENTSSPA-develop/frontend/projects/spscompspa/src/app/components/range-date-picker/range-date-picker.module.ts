import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CardModule } from 'primeng/card';
import { RangeDatePickerComponent } from './range-date-picker.component';
import { ReactiveFormsModule } from '@angular/forms';
import { CalendarModule, MessageModule } from 'primeng/primeng';

@NgModule({
  declarations: [
    RangeDatePickerComponent
  ],
  imports: [
    CommonModule,
    CardModule,
    ReactiveFormsModule,
    CalendarModule,
    MessageModule
  ],
  exports: [
    RangeDatePickerComponent
  ]
})
export class RangeDatePickerModule { }
