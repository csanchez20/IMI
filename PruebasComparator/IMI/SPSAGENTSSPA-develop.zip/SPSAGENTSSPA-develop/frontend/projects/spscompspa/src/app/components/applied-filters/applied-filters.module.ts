import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppliedFiltersComponent } from './applied-filters.component';
import { ChipsModule } from '../chips/chips.module';

@NgModule({
  declarations: [AppliedFiltersComponent],
  imports: [
    CommonModule,
    ChipsModule
  ],
  exports: [AppliedFiltersComponent]
})
export class AppliedFiltersModule { }
