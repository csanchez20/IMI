import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';

interface SelectIt {
  label: string;
  value: string;
}

@Component({
  selector: 'sps-applied-filters',
  templateUrl: './applied-filters.component.html',
  styleUrls: ['./applied-filters.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppliedFiltersComponent implements OnChanges {
  @Input() inputData: any[];
  @Input() labels: string[];
  @Output() noFilters: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() outputData: EventEmitter<any> = new EventEmitter<any>();
  cleanStructure: any[] = [];
  show = true;
  hideTitles = false;
  item: SelectIt;
  filters = [];
  obj = {};
  constructor() {}

  ngOnChanges(changes) {
    const data = changes['inputData']['currentValue'];
    this.cleanStructure = [];
    if (data) {
      for (let i = 0; i < data.length; i++) {
        if (data[i]['dates'] !== undefined) {
          if (data[i]['dates'] && data[i]['dates']['start'] !== undefined) {
            this.cleanStructure.push({
              startDate: data[i]['dates']['start']
            });
          } else {
            this.cleanStructure.push({ startDate: data[i]['dates'] });
          }
          if (data[i]['dates'] && data[i]['dates']['end'] !== undefined) {
            this.cleanStructure.push({
              endDate: data[i]['dates']['end']
            });
          } else {
            this.cleanStructure.push({ endDate: data[i]['dates'] });
          }
        } else if (data[i]['datesPeriode'] !== undefined) {
          if (data[i]['datesPeriode'] && data[i]['datesPeriode']['start'] !== undefined) {
            this.cleanStructure.push({
              startDate: data[i]['datesPeriode']['start']
            });
          } else {
            this.cleanStructure.push({ startDate: data[i]['datesPeriode'] });
          }
          if (data[i]['datesPeriode'] && data[i]['datesPeriode']['end'] !== undefined) {
            this.cleanStructure.push({
              endDate: data[i]['datesPeriode']['end']
            });
          } else {
            this.cleanStructure.push({ endDate: data[i]['datesPeriode'] });
          }
        } else {
          // //Para los checkbox que se llamen "activo"
          // if(data[i].activo === true) data[i].activo = 'Si'
          // else if (data[i].activo === false) data[i].activo = 'No'

          this.cleanStructure.push(data[i]);
        }
      }
    }
  }

  onDeleteAll() {
    this.cleanStructure = this.cleanStructure.map(obj => {
      const newObj = {
        [Object.getOwnPropertyNames(obj)[0]]: null
      };
      return newObj;
    });
    this.noFilters.emit();
  }

  onDeleteFilter(filter: any) {
    let newObj;
    this.cleanStructure = this.cleanStructure.map(obj => {
      if (obj[filter.key] !== undefined) {
        obj = newObj = { [filter.key]: null };
      }
      return obj;
    });
    this.outputData.emit(newObj);
  }

  thereAreFilters(): boolean {
    const t = this.cleanStructure
      .map(obj => Object.values(obj)[0])
      .filter(v => v !== null && v !== '');
    return t.length > 0;
  }
}
