import { ChangeDetectionStrategy, Component, forwardRef, Input, OnInit } from '@angular/core';
import { AbstractControl, ControlValueAccessor, FormBuilder, FormGroup, NG_VALIDATORS, NG_VALUE_ACCESSOR, ValidationErrors, Validator, ValidatorFn } from '@angular/forms';
import { I18n } from '@ngx-translate/i18n-polyfill';
import { I18nConfigService } from '../../services/i18n-config.service';

@Component({
  selector: 'sps-range-date-picker',
  templateUrl: './range-date-picker.component.html',
  styleUrls: ['./range-date-picker.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => RangeDatePickerComponent),
      multi: true
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => RangeDatePickerComponent),
      multi: true
    }
  ]
  // encapsulation: ViewEncapsulation.None
})
export class RangeDatePickerComponent implements ControlValueAccessor, Validator, OnInit {
  public dateRangeForm: FormGroup = this.fb.group({
    start: [''],
    end: ['']
  });

  @Input() labelInicio = 'labelInicioDateRangeDatepicker';
  @Input() labelFin = 'labelFinDateRangeDatepicker';
  @Input() validatorsStartDate: ValidatorFn | ValidatorFn[];
  @Input() validatorsEndDate: ValidatorFn | ValidatorFn[];
  @Input() minDateInicio: Date = null;
  @Input() formSubmitted: boolean = false;
  @Input() canEqualDay = false;

  translatedLabelStart;
  translatedLabelEnd;

  locale;
  /*Valores máximo y mínimo de fecha de inicio y final */
  startDateMax: Date;
  endDateMin: Date;
  startDate: Date;
  endDate: Date;

  constructor(private fb: FormBuilder, private i18n: I18n, private i18nConfig: I18nConfigService) { }

  ngOnInit() {
    this.locale = this.i18nConfig.getLocaleCalendar();

    this.translatedLabelStart = this.i18n({ id: this.labelInicio, value: 'Data inici' });
    this.translatedLabelEnd = this.i18n({ id: this.labelFin, value: 'Data fi' });

    if (this.validatorsStartDate) {
      this.dateRangeForm.get('start').setValidators(this.validatorsStartDate);
    }
    if (this.validatorsEndDate) {
      this.dateRangeForm.get('end').setValidators(this.validatorsEndDate);
    }
    if (this.minDateInicio) {
      this.startDateMax = this.minDateInicio;
    }

    if (this.dateRangeForm.get('start').value) {
      this.onStartSelected(this.dateRangeForm.get('start').value);
    }
  }

  public onTouched: () => void = () => { };

  writeValue(val: any): void {
    val && this.dateRangeForm.setValue(val, { emitEvent: false });
  }

  registerOnChange(fn: any): void {
    this.dateRangeForm.valueChanges.subscribe(fn);
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
    isDisabled ? this.dateRangeForm.disable() : this.dateRangeForm.enable();
  }

  validate(c: AbstractControl): ValidationErrors | null {
    return this.dateRangeForm.valid
      ? null
      : { invalidForm: { valid: false, message: 'dateRange fields are invalid' } };
  }

  onStartSelected(fecha: Date) {
    this.startDateMax = new Date();
    this.startDateMax.setFullYear(fecha.getFullYear());
    this.startDateMax.setMonth(fecha.getMonth());
    if (!this.canEqualDay) {
      this.startDateMax.setDate(fecha.getDate() + 1);
    } else {
      this.startDateMax.setDate(fecha.getDate());
    }
    this.startDate = fecha;
    //  this.startDateSelection.emit(startDate);
  }

  onEndSelected(fecha: Date) {
    this.endDateMin = new Date();
    this.endDateMin.setFullYear(fecha.getFullYear());
    this.endDateMin.setMonth(fecha.getMonth());
    if (!this.canEqualDay) {
      this.endDateMin.setDate(fecha.getDate() - 1);
    } else {
      this.endDateMin.setDate(fecha.getDate());
    }
    this.endDate = fecha;
    // this.endDateSelection.emit(endDate);
  }

  onCloseStartDate(startDate: Date) {
    if (!this.dateRangeForm.get('start').value) {
      this.startDateMax = null;
    }
    // this.startDateSelection.emit(startDate);
  }
  onCloseEndDate(endDate: Date) {
    if (!this.dateRangeForm.get('end').value) {
      this.endDateMin = null;
    }
    // this.endDateSelection.emit(endDate);
  }
}
