import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InformationCardComponent } from './information-card.component';
import { CardModule } from 'primeng/card';

@NgModule({
  declarations: [
    InformationCardComponent
  ],
  imports: [
    CommonModule,
    CardModule
  ],
  exports: [
    InformationCardComponent  ]
})
export class InformationCardModule { } 
