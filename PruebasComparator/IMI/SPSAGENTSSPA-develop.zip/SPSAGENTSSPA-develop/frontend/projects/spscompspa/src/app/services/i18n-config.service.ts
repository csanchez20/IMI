import { Injectable, Inject, LOCALE_ID } from '@angular/core';

const i18nCalendar = {
  'ca': {
    firstDayOfWeek: 1,
    dayNames: ['Diumenge', 'Dilluns', 'Dimarts', 'Dimecres', 'Dijous', 'Divendres', 'Dissabte'],
    dayNamesShort: ['Diu', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    dayNamesMin: ['Diu', 'Dl', 'Dm', 'Dx', 'Dj', 'Dv', 'Ds'],
    monthNames: ['Gener', 'Febrer', 'Març', 'Abril', 'Maig', 'Juny', 'Juliol', 'Agost', 'Setembre', 'Octubre', 'Novembre', 'Desembre'],
    monthNamesShort: ['Gen', 'Feb', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Oct', 'Nov', 'Dec'],
    today: 'Avui',
    clear: 'Borrar',
    dateFormat: 'dd/mm/yy'
  },
  'es': {
    firstDayOfWeek: 1,
    dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
    dayNamesShort: ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'],
    dayNamesMin: ['D', 'L', 'M', 'X', 'J', 'V', 'S'],
    monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto',
      'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
    monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
    today: 'Hoy',
    clear: 'Borrar',
    dateFormat: 'dd/mm/yy'
  }
};

@Injectable({
  providedIn: 'root'
})
export class I18nConfigService {

  constructor(
    @Inject(LOCALE_ID) protected localeId: string
  ) { }

  getLocaleCalendar(): Object {
    if (i18nCalendar.hasOwnProperty(this.localeId)) {
      return i18nCalendar[this.localeId];
    }
    return {};
  }

  getDateFormat() {
    if (i18nCalendar.hasOwnProperty(this.localeId)) {
      return i18nCalendar[this.localeId]['dateFormat'];
    }
    return 'dd/mm/yy';
  }
}
