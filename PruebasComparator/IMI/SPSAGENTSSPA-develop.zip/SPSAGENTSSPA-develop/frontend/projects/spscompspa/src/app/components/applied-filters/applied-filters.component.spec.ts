import { AppliedFiltersComponent } from './applied-filters.component';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { By } from '@angular/platform-browser';


describe('AppliedFiltersComponent', () => {
  const labels = ['Data inici contracte', 'Data fi  contracte', 'Característiques', 'Ubicació'];

  function setup() {
    const fixture: ComponentFixture<AppliedFiltersComponent> = TestBed.createComponent(AppliedFiltersComponent);
    const component: AppliedFiltersComponent = fixture.debugElement.componentInstance;
    // const userService = fixture.debugElement.injector.get(UserService);
    return { fixture, component };
  }
  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [

      ],
      declarations: [AppliedFiltersComponent]
    }).compileComponents();
  });

  it('should create the component', async(() => {
    const { component } = setup();
    expect(component).toBeTruthy();
  }));


  it('debería renderizar Filtres aplicats si pasamos un filtro', () => {
    const { component, fixture } = setup();
    component.labels = labels;
    component.inputData = [{ startDate: null }, { endDate: null }, { derivant: '1' }, { css: null }];
    fixture.detectChanges();
    const compile = fixture.debugElement.nativeElement;
    const paragraph = compile.querySelector('p');

    expect(paragraph.textContent).toContain('Filtres aplicats');
  });

  it('debería renderizar 1 filtro si pasamos un filtro', () => {
    const { component, fixture } = setup();
    component.labels = labels;
    component.inputData = [{ startDate: null }, { endDate: null }, { derivant: '1' }, { css: null }];
    fixture.detectChanges();
    const compile = fixture.debugElement.nativeElement;
    const div = compile.querySelector('div.filtersApps');
    expect(div.textContent).toContain('Característiques: 1');

  });


  it('debería renderizar 2 filtros si pasamos 2 filtros', () => {
    const { component, fixture } = setup();
    component.labels = labels;
    component.inputData = [{ startDate: null }, { endDate: null }, { derivant: '1' }, { css: '2' }];
    fixture.detectChanges();
    const compile = fixture.debugElement.nativeElement;
    const divs = fixture.debugElement.queryAll(By.css('.filtersApps'));
    expect(divs.length).toEqual(2);
  });

  it('debería emitir un evento cuando pulsamos el boton de borrar todos y mno debería haber filtros', () => {
    const { component, fixture } = setup();
    component.labels = labels;
    component.inputData = [{ startDate: null }, { endDate: null }, { derivant: '1' }, { css: null }];
    fixture.detectChanges();
    spyOn(component.noFilters, 'emit');

    const button = fixture.debugElement.query(By.css('.pointerUnderline')).nativeElement as HTMLElement;
    button.click();
    expect(component.noFilters.emit).toHaveBeenCalled();
    expect(component.thereAreFilters()).toBeFalsy();
  });

  it('debería emitir un evento cuando pulsamos el boton de borrar 1 filtro', () => {
    const { component, fixture } = setup();
    component.labels = labels;
    component.inputData = [{ startDate: null }, { endDate: null }, { derivant: '1' }, { css: null }];
    fixture.detectChanges();
    spyOn(component.outputData, 'emit');
    const i = fixture.debugElement.query(By.css('.crossIcon')).nativeElement as HTMLElement;
    i.click();
    expect(component.outputData.emit).toHaveBeenCalledWith({ derivant: null });
    expect(component.thereAreFilters()).toBeFalsy();
  });




});