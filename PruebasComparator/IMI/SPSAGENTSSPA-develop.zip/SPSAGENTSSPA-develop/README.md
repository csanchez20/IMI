# spsagentsspa

Proyecto demo de los componentes drets socials.

Arrancar con `npm run start` 

## Server mock

Instalar mock `npm run install-mock`
Y en otra pestaña el servidor mockeado con `npm run start:server`
O si quieres delay con `npm run start:server:delay`


## Crear el EAR compilando el proyecto de Angular

> mvn clean package -Pwas_build -DskipTests -Dfront.enviroment=XXX

Maven ejecutará los siguientes comandos:
> npm install
> npm run build:XXX

donde XXX puede ser uno de los siguientes valores:
- es:  Compilar para el entorno local en castellano
- dev: Compilar para el entorno de Madrid
- dsv: Compilar para el entorno de DSV
- pre: Compilar para el entorno de PRE
- pro: Compilar para el entorno de PRO

En caso de error de OutOfMemory en la ejecución de Node, hacer lo siguiente:
Buscar el archivo "frontend\node_modules\.bin\ng.cmd" que se genera con el plugin de maven y modificarlo de la siguiente manera:

```
@IF EXIST "%~dp0\node.exe" (
  "%~dp0\node.exe" "--max_old_space_size=8192" "%~dp0\..\@angular\cli\bin\ng" %*
) ELSE (
  @SETLOCAL
  @SET PATHEXT=%PATHEXT:;.JS;=;%
  node "--max_old_space_size=8192" "%~dp0\..\@angular\cli\bin\ng" %*
) 
```